--
-- PostgreSQL database dump
--

\restrict eUVBAMSX2UbTNBbUqVm6oZvpLjC945N6y7goggqLaLm4hAqC82D6X3oBZrwHNQV

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg12+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: ApptSource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ApptSource" AS ENUM (
    'web',
    'mobile',
    'walkin',
    'bot'
);


--
-- Name: ApptStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ApptStatus" AS ENUM (
    'pending',
    'held',
    'confirmed',
    'cancelled',
    'completed',
    'no_show',
    'expired'
);


--
-- Name: BotPlatform; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BotPlatform" AS ENUM (
    'telegram',
    'bale'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'pending',
    'paid',
    'refunded',
    'retained',
    'failed'
);


--
-- Name: StaffRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StaffRole" AS ENUM (
    'Owner',
    'Admin',
    'Stylist'
);


--
-- Name: SubscriptionPlanKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubscriptionPlanKind" AS ENUM (
    'trial',
    'monthly',
    'quarterly',
    'annual'
);


--
-- Name: SubscriptionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubscriptionStatus" AS ENUM (
    'trial',
    'active',
    'grace',
    'expired'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointment (
    id uuid NOT NULL,
    salon_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    staff_member_id uuid NOT NULL,
    chair_id uuid NOT NULL,
    service_id uuid NOT NULL,
    start_at timestamp with time zone NOT NULL,
    end_at timestamp with time zone NOT NULL,
    status public."ApptStatus" NOT NULL,
    source public."ApptSource" NOT NULL,
    hold_expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    time_range tstzrange GENERATED ALWAYS AS (tstzrange(start_at, end_at, '[)'::text)) STORED
);


--
-- Name: bot_chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bot_chat (
    id uuid NOT NULL,
    platform public."BotPlatform" NOT NULL,
    chat_id text NOT NULL,
    customer_id uuid,
    staff_member_id uuid,
    linked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bot_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bot_session (
    id uuid NOT NULL,
    platform public."BotPlatform" NOT NULL,
    chat_id text NOT NULL,
    step text NOT NULL,
    draft_json jsonb NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: chair; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chair (
    id uuid NOT NULL,
    salon_id uuid NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: chair_equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chair_equipment (
    chair_id uuid NOT NULL,
    equipment_id uuid NOT NULL
);


--
-- Name: chair_unavailable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chair_unavailable (
    id uuid NOT NULL,
    chair_id uuid NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL
);


--
-- Name: customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer (
    id uuid NOT NULL,
    phone text NOT NULL,
    full_name text,
    preferred_staff_id uuid,
    no_show_count integer DEFAULT 0 NOT NULL
);


--
-- Name: customer_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_note (
    id uuid NOT NULL,
    customer_id uuid NOT NULL,
    author_id uuid,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: day_off; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.day_off (
    id uuid NOT NULL,
    staff_member_id uuid NOT NULL,
    on_date date NOT NULL,
    start_time time without time zone,
    end_time time without time zone
);


--
-- Name: device_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_token (
    id uuid NOT NULL,
    customer_id uuid NOT NULL,
    token text NOT NULL,
    platform text NOT NULL,
    push_enabled boolean DEFAULT true NOT NULL
);


--
-- Name: equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment (
    id uuid NOT NULL,
    salon_id uuid NOT NULL,
    name text NOT NULL
);


--
-- Name: holiday; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.holiday (
    id uuid NOT NULL,
    salon_id uuid NOT NULL,
    on_date date NOT NULL,
    start_time time without time zone,
    end_time time without time zone
);


--
-- Name: notification_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_log (
    id uuid NOT NULL,
    appointment_id uuid,
    channel text NOT NULL,
    status text NOT NULL,
    error text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    type text DEFAULT 'generic'::text NOT NULL
);


--
-- Name: otp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp (
    id uuid NOT NULL,
    phone text NOT NULL,
    code_hash text NOT NULL,
    issued_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    invalidated boolean DEFAULT false NOT NULL
);


--
-- Name: payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment (
    id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    amount_rial bigint NOT NULL,
    status public."PaymentStatus" DEFAULT 'pending'::public."PaymentStatus" NOT NULL,
    gateway text NOT NULL,
    authority text,
    ref_id text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: platform_admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_admin (
    id uuid NOT NULL,
    phone text NOT NULL,
    full_name text NOT NULL,
    role text DEFAULT 'super_admin'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_login_at timestamp(6) with time zone
);


--
-- Name: platform_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_audit_log (
    id uuid NOT NULL,
    admin_id uuid NOT NULL,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid,
    metadata jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: qr_scan_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.qr_scan_event (
    id uuid NOT NULL,
    salon_id uuid NOT NULL,
    source text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: salon; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salon (
    id uuid NOT NULL,
    name text NOT NULL,
    qr_token text NOT NULL,
    timezone text DEFAULT 'Asia/Tehran'::text NOT NULL,
    auto_approve boolean DEFAULT false NOT NULL,
    brand_accent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    booking_window_days integer DEFAULT 14 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    CONSTRAINT salon_booking_window_days_check CHECK (((booking_window_days >= 0) AND (booking_window_days <= 365)))
);


--
-- Name: salon_notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salon_notification (
    id uuid NOT NULL,
    salon_id uuid NOT NULL,
    audience text DEFAULT 'owner'::text NOT NULL,
    staff_member_id uuid,
    type text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    payload jsonb,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: service; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service (
    id uuid NOT NULL,
    salon_id uuid NOT NULL,
    name text NOT NULL,
    duration_min integer NOT NULL,
    buffer_min integer NOT NULL,
    price_rial bigint NOT NULL,
    requires_deposit boolean DEFAULT false NOT NULL,
    deposit_rial bigint,
    CONSTRAINT chk_buffer_non_negative CHECK ((buffer_min >= 0)),
    CONSTRAINT chk_deposit_non_negative CHECK (((deposit_rial >= 0) OR (deposit_rial IS NULL))),
    CONSTRAINT chk_duration_positive CHECK ((duration_min > 0)),
    CONSTRAINT chk_price_non_negative CHECK ((price_rial >= 0))
);


--
-- Name: service_equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_equipment (
    service_id uuid NOT NULL,
    equipment_id uuid NOT NULL
);


--
-- Name: service_staff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_staff (
    service_id uuid NOT NULL,
    staff_member_id uuid NOT NULL
);


--
-- Name: staff_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff_member (
    id uuid NOT NULL,
    salon_id uuid NOT NULL,
    full_name text NOT NULL,
    role public."StaffRole" NOT NULL,
    active boolean DEFAULT true NOT NULL,
    auto_approve boolean,
    manage_own_availability boolean DEFAULT false NOT NULL,
    phone text
);


--
-- Name: subscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription (
    id uuid NOT NULL,
    salon_id uuid NOT NULL,
    status public."SubscriptionStatus" DEFAULT 'trial'::public."SubscriptionStatus" NOT NULL,
    plan_kind public."SubscriptionPlanKind" DEFAULT 'trial'::public."SubscriptionPlanKind" NOT NULL,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    grace_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: subscription_payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_payment (
    id uuid NOT NULL,
    subscription_id uuid NOT NULL,
    plan_kind public."SubscriptionPlanKind" NOT NULL,
    amount_rial bigint NOT NULL,
    status public."PaymentStatus" DEFAULT 'pending'::public."PaymentStatus" NOT NULL,
    gateway text NOT NULL,
    authority text,
    ref_id text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: waitlist_entry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.waitlist_entry (
    id uuid NOT NULL,
    salon_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    service_id uuid NOT NULL,
    window_start timestamp with time zone NOT NULL,
    window_end timestamp with time zone NOT NULL,
    status text DEFAULT 'waiting'::text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: working_hours; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.working_hours (
    id uuid NOT NULL,
    owner_kind text NOT NULL,
    owner_id uuid NOT NULL,
    weekday integer NOT NULL,
    start_time time without time zone NOT NULL,
    end_time time without time zone NOT NULL
);


--
-- Data for Name: appointment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointment (id, salon_id, customer_id, staff_member_id, chair_id, service_id, start_at, end_at, status, source, hold_expires_at, created_at) FROM stdin;
4d340983-9d69-4b4f-b463-0e29c0c7de57	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	41dccdd8-ec92-4bc5-9dff-a7643c265902	618bbbbb-d814-4b0e-a5ad-83dfab804e2a	adf80c3a-8830-49ab-8010-f48f0cd913d6	ef6f608d-b6bd-4a9f-a622-61dc140da791	2026-08-07 13:30:00+00	2026-08-07 14:00:00+00	pending	web	\N	2026-08-04 13:53:20.398+00
c207ed5f-d9c0-4021-b13c-94eae93d2978	4acda9b4-b53a-452d-b438-3c01cc8a3ca4	bc3355ef-2f4e-4a06-a899-941b7eeffb65	a9955774-e41d-4176-aff4-b10e51138abf	f26d6dd6-26a1-49fc-8d09-762d3e46432d	e31bfa16-c70f-4f18-b8c0-ea4d49b2566b	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 13:52:31.945+00
0d38fc85-8f42-4038-bf84-6f6b9789e6ca	d86a4f90-7ef3-477a-b928-3804c9bd1bca	83cb687b-b6a9-4485-86e3-d99ea12a2459	3799ff0a-0064-4f2a-8717-4d2c35b40060	f2bd08c8-34ee-431d-81b8-8063def28c29	1e467c6c-4dee-4710-8ded-6f4c9d75eb42	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 13:56:05.432+00
b8f61752-ae0c-40fe-bdae-90a4798befb5	c66e014b-5299-4f9f-bc65-195fbad0cd99	c6c26081-9dc1-4f75-8d38-b91cebce621f	05cf7580-8f7d-433b-a660-ab1b55791e8c	587eea71-d4c6-4f7e-9660-0d3a106cb33a	7e6b6901-0c67-43cb-a445-7b2527dfa796	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 13:56:56.509+00
15504f9d-cb34-4f31-ad4a-67fb039bbab0	c66e014b-5299-4f9f-bc65-195fbad0cd99	c6c26081-9dc1-4f75-8d38-b91cebce621f	05cf7580-8f7d-433b-a660-ab1b55791e8c	587eea71-d4c6-4f7e-9660-0d3a106cb33a	7e6b6901-0c67-43cb-a445-7b2527dfa796	2026-08-09 09:30:00+00	2026-08-09 10:00:00+00	confirmed	web	\N	2026-08-07 13:56:56.608+00
88a697b4-9687-49f4-b309-d0740b41d3f9	c66e014b-5299-4f9f-bc65-195fbad0cd99	8364f4c9-65fb-46c1-99c1-1e7c06220188	bee3515c-19e3-454f-922b-8f24d8a75913	587eea71-d4c6-4f7e-9660-0d3a106cb33a	5031b9c0-272b-4691-a688-6581e4b5fcb2	2026-08-12 09:00:00+00	2026-08-12 09:30:00+00	expired	web	2026-08-07 14:11:56.692+00	2026-08-07 13:56:56.693+00
1b06882a-d684-430c-9e8c-403bc8d2c1b2	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	33067a81-2932-4602-b219-cc720ae31261	07f7969e-2964-4ae8-a1c4-305c15e2117f	36ec0484-0b59-4659-8ef4-85a52c6e39f4	497d7969-bf85-4490-9a04-2d991cf1efc2	2026-08-08 11:00:00+00	2026-08-08 11:30:00+00	confirmed	web	\N	2026-08-07 03:23:00.097+00
5be1d76c-12b8-4f61-9247-a904446b8d21	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	33067a81-2932-4602-b219-cc720ae31261	07f7969e-2964-4ae8-a1c4-305c15e2117f	36ec0484-0b59-4659-8ef4-85a52c6e39f4	497d7969-bf85-4490-9a04-2d991cf1efc2	2026-08-06 12:00:00+00	2026-08-06 12:30:00+00	confirmed	web	\N	2026-08-04 22:00:01.219+00
82ccb5e9-9188-4f67-b40e-3ed4d73ac52b	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	33067a81-2932-4602-b219-cc720ae31261	07f7969e-2964-4ae8-a1c4-305c15e2117f	36ec0484-0b59-4659-8ef4-85a52c6e39f4	497d7969-bf85-4490-9a04-2d991cf1efc2	2026-08-06 16:45:00+00	2026-08-06 17:15:00+00	confirmed	web	\N	2026-08-04 22:04:15.002+00
c825a73d-730a-4f5f-bdfa-225041760363	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	33067a81-2932-4602-b219-cc720ae31261	07f7969e-2964-4ae8-a1c4-305c15e2117f	36ec0484-0b59-4659-8ef4-85a52c6e39f4	497d7969-bf85-4490-9a04-2d991cf1efc2	2026-08-05 12:30:00+00	2026-08-05 13:00:00+00	cancelled	web	\N	2026-08-04 21:50:38.842+00
193e6490-d212-4bad-b6ae-8f90b7d9c095	c29ea8c8-5840-4ddb-885c-e70eafb741b5	f69b6ea7-a34f-4df0-bb85-ff223ba93dfe	4c38b9fb-2918-4a7f-91b1-d959717f3cce	1c5dad57-b2d6-4fcb-a1c4-677f9ed40062	ecd54a05-9774-4628-934e-abf783a70b11	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 12:23:39.05+00
23dde323-f717-4edc-aa53-1fbc39a7a5b8	c29ea8c8-5840-4ddb-885c-e70eafb741b5	f69b6ea7-a34f-4df0-bb85-ff223ba93dfe	4c38b9fb-2918-4a7f-91b1-d959717f3cce	1c5dad57-b2d6-4fcb-a1c4-677f9ed40062	ecd54a05-9774-4628-934e-abf783a70b11	2026-08-09 09:30:00+00	2026-08-09 10:00:00+00	confirmed	web	\N	2026-08-07 12:23:39.141+00
e47b0d44-dfa4-44d4-bc4c-271be836d766	c29ea8c8-5840-4ddb-885c-e70eafb741b5	f69b6ea7-a34f-4df0-bb85-ff223ba93dfe	f5a4d790-5134-4522-8243-36d7f0a70027	739269fc-7daa-44ff-aa8c-ee779905e61a	ecd54a05-9774-4628-934e-abf783a70b11	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	cancelled	web	\N	2026-08-07 12:23:39.199+00
507da850-a5a9-4e3a-a878-37f3cda0b140	c29ea8c8-5840-4ddb-885c-e70eafb741b5	f69b6ea7-a34f-4df0-bb85-ff223ba93dfe	f5a4d790-5134-4522-8243-36d7f0a70027	739269fc-7daa-44ff-aa8c-ee779905e61a	ecd54a05-9774-4628-934e-abf783a70b11	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	pending	web	\N	2026-08-07 12:23:39.265+00
c9a828e7-2845-4cae-b08d-929cc20f4d4a	1bb72fda-9b55-4d92-b5ae-07341a7c9aaf	2b922d7d-2347-49d3-8432-aaeb4241e02a	db6cda46-0c20-4e07-8e56-9aa00f532893	05bcc3c8-d781-4866-b412-c691a6844950	63d49f0e-2178-4300-95e8-4f989642dde2	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 12:23:40.304+00
b3a7f30a-38c3-410b-914a-d41aabd3b647	049ff655-e678-4a8a-aa15-dd1d0f082d72	2842b885-cf91-4a17-bd88-d3af8d42af22	fc75b105-1531-42ee-85b0-7bf0027240a4	d30dd962-14de-4ef0-94ae-e99ea8fca2b8	8ae968e4-99cc-41e0-8e2b-21d43410020d	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 11:53:05.167+00
d926c27c-eba8-4e38-b687-e2e7c1c4aa8e	8d4082de-f9bc-483c-8364-fb5373ecee79	ea9070c9-92b1-4c59-be81-1b2e601b0990	0b602742-598d-4d2c-b414-fb497ab0ff4b	088c9625-be10-48f4-9ecc-12016efc8946	68255968-8e13-45f2-ba55-f1a324546113	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 11:58:35.501+00
350af89d-e638-4d52-9ca5-5fce0bdd29b6	6a5b29c2-a8df-467a-8c36-ca49f545625c	8bfa4332-8d77-4fd4-b17f-b8494597dbbf	993150ad-bcfe-46ba-87cc-aaeae9fb4973	a5cb361d-e2e2-43fd-96bc-eabf65d79f16	509b8201-5d9f-4560-be39-140bf5049d0b	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 12:06:40.738+00
3078ab9b-2c0e-4979-94a3-5b546038313a	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	e87629af-03d1-4cff-bf75-3bd05a24f2b4	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	f9b3e60a-9c0f-47ca-82e3-f7f43ee32280	06917464-b6ab-4c69-a66c-3a9aebe57995	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 12:25:58.925+00
a3b3a93a-653d-4bca-8ebe-fdb11749fcd7	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	e87629af-03d1-4cff-bf75-3bd05a24f2b4	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	f9b3e60a-9c0f-47ca-82e3-f7f43ee32280	06917464-b6ab-4c69-a66c-3a9aebe57995	2026-08-09 09:30:00+00	2026-08-09 10:00:00+00	confirmed	web	\N	2026-08-07 12:25:59.017+00
d3cb4659-7a5d-4161-93b7-79d2c90fac24	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	e87629af-03d1-4cff-bf75-3bd05a24f2b4	d32250ab-ddb0-45ac-b21c-aca77709eab2	5daa0943-aca5-438d-a279-213321d089b4	06917464-b6ab-4c69-a66c-3a9aebe57995	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	cancelled	web	\N	2026-08-07 12:25:59.074+00
3203daea-4e5a-4954-b4c5-5ae2666cc92e	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	e87629af-03d1-4cff-bf75-3bd05a24f2b4	d32250ab-ddb0-45ac-b21c-aca77709eab2	5daa0943-aca5-438d-a279-213321d089b4	06917464-b6ab-4c69-a66c-3a9aebe57995	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	cancelled	web	\N	2026-08-07 12:25:59.138+00
06da860e-be78-43f2-9cd1-5a6398988ad6	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	e87629af-03d1-4cff-bf75-3bd05a24f2b4	d32250ab-ddb0-45ac-b21c-aca77709eab2	5daa0943-aca5-438d-a279-213321d089b4	06917464-b6ab-4c69-a66c-3a9aebe57995	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	no_show	web	\N	2026-08-07 12:25:59.192+00
31c4f1c5-d255-4f1b-8c37-e8dd311f405e	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	e87629af-03d1-4cff-bf75-3bd05a24f2b4	d32250ab-ddb0-45ac-b21c-aca77709eab2	5daa0943-aca5-438d-a279-213321d089b4	06917464-b6ab-4c69-a66c-3a9aebe57995	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 12:25:59.275+00
d1c64753-d9b0-4a40-8b22-a922e5f092e2	c21b3648-38a3-4dde-86ea-cbee7d78165f	dc00ef17-8740-4574-b200-7c9c6db41b0e	b8f357fd-925e-416d-b6aa-1c7f138f967f	0b563da0-a8a4-439d-bb7a-ccf7e32b6823	3b908841-7ffc-4cad-bbfa-aaf28faebe66	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 12:25:59.755+00
37a392f7-2ce1-41b4-86cf-fd0a1e0514b2	9d965b2a-2b91-456a-92bb-937b05888fa8	10cbda16-b742-46d2-bd29-f2e658af5cd5	ba7c9524-b0d4-4845-8886-5274ede7fd6a	aedc7aca-46db-4fda-9bb9-19a72723e04d	8213ea5e-0b2b-4950-95eb-53903a8e3991	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 12:26:14.125+00
92c8f217-9b27-49a7-a612-6ae46a5ec5cd	9d965b2a-2b91-456a-92bb-937b05888fa8	10cbda16-b742-46d2-bd29-f2e658af5cd5	ba7c9524-b0d4-4845-8886-5274ede7fd6a	aedc7aca-46db-4fda-9bb9-19a72723e04d	8213ea5e-0b2b-4950-95eb-53903a8e3991	2026-08-09 09:30:00+00	2026-08-09 10:00:00+00	confirmed	web	\N	2026-08-07 12:26:14.233+00
2f50aaaa-7651-407b-82d6-10998cee1153	9d965b2a-2b91-456a-92bb-937b05888fa8	10cbda16-b742-46d2-bd29-f2e658af5cd5	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	dedcd478-5995-49b3-9529-080290a7748d	8213ea5e-0b2b-4950-95eb-53903a8e3991	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	cancelled	web	\N	2026-08-07 12:26:14.309+00
f3b7e9c7-ef59-48d0-95e5-00a1895bd077	9d965b2a-2b91-456a-92bb-937b05888fa8	10cbda16-b742-46d2-bd29-f2e658af5cd5	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	dedcd478-5995-49b3-9529-080290a7748d	8213ea5e-0b2b-4950-95eb-53903a8e3991	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	cancelled	web	\N	2026-08-07 12:26:14.39+00
7ff67103-6800-44b6-9b1b-d54bfa3e8e51	9d965b2a-2b91-456a-92bb-937b05888fa8	10cbda16-b742-46d2-bd29-f2e658af5cd5	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	dedcd478-5995-49b3-9529-080290a7748d	8213ea5e-0b2b-4950-95eb-53903a8e3991	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	no_show	web	\N	2026-08-07 12:26:14.453+00
04e01a40-2b9e-4198-a824-1f1f3c04ac75	9d965b2a-2b91-456a-92bb-937b05888fa8	10cbda16-b742-46d2-bd29-f2e658af5cd5	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	dedcd478-5995-49b3-9529-080290a7748d	8213ea5e-0b2b-4950-95eb-53903a8e3991	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 12:26:14.561+00
db459809-b753-4ca3-a7f3-75dd0e1495bb	b9e33109-b47b-40d5-a0ac-2a0d837c6827	7dad54b4-59d0-477b-a8d4-6ea1f5f6785a	30c7ba5b-2085-4124-a6f2-7986e79071f0	d3af3925-bec6-4477-b2d9-f9da02b2cfca	1e8d5b7c-644b-4e1e-a664-d40a715ccf5e	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 12:26:15.144+00
b4193219-770a-410b-9bbf-c2133ce97e0e	e7f95ac5-5c53-4db7-b274-f0c94730f18c	0fec6858-9c2c-4063-b5f8-7acbc2ed9eef	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	827e26f5-d1ce-45cc-8b99-2078891e1ef0	6395a750-12ab-4088-b351-cd0c98d5f404	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 12:49:23.452+00
bfe6b241-23ab-402d-8c81-1963b50e330e	e7f95ac5-5c53-4db7-b274-f0c94730f18c	0fec6858-9c2c-4063-b5f8-7acbc2ed9eef	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	827e26f5-d1ce-45cc-8b99-2078891e1ef0	6395a750-12ab-4088-b351-cd0c98d5f404	2026-08-09 09:30:00+00	2026-08-09 10:00:00+00	confirmed	web	\N	2026-08-07 12:49:23.538+00
98eeb69d-9e79-4e5a-bed7-5adc029dca88	e7f95ac5-5c53-4db7-b274-f0c94730f18c	0fec6858-9c2c-4063-b5f8-7acbc2ed9eef	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	9b31cc2b-489e-47eb-ba25-973e86cb6f85	6395a750-12ab-4088-b351-cd0c98d5f404	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	cancelled	web	\N	2026-08-07 12:49:23.655+00
53dc7ab7-cfd4-449f-8683-5d61d6dccc2d	e7f95ac5-5c53-4db7-b274-f0c94730f18c	0fec6858-9c2c-4063-b5f8-7acbc2ed9eef	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	9b31cc2b-489e-47eb-ba25-973e86cb6f85	6395a750-12ab-4088-b351-cd0c98d5f404	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	cancelled	web	\N	2026-08-07 12:49:23.712+00
bcec2c53-e328-49dd-a9ca-abf278a43ceb	e7f95ac5-5c53-4db7-b274-f0c94730f18c	0fec6858-9c2c-4063-b5f8-7acbc2ed9eef	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	9b31cc2b-489e-47eb-ba25-973e86cb6f85	6395a750-12ab-4088-b351-cd0c98d5f404	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	no_show	web	\N	2026-08-07 12:49:23.763+00
cf2fcd63-42ea-40c7-9a4b-7d20325e87f0	e7f95ac5-5c53-4db7-b274-f0c94730f18c	0fec6858-9c2c-4063-b5f8-7acbc2ed9eef	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	9b31cc2b-489e-47eb-ba25-973e86cb6f85	6395a750-12ab-4088-b351-cd0c98d5f404	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 12:49:23.84+00
9e40a949-5a18-427d-a0a1-681ac3316726	f9eaed2d-7068-4583-8a46-869324599cc6	6b30cc0f-3d40-47d4-becf-c071a358e3e8	3f9e4c0c-0bdb-460e-982a-781f1baa2ca1	f5372a28-1db2-4007-ba0f-d7ae09762a23	ab451505-6dcb-491a-a17a-373f66456d31	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 12:49:24.311+00
26d3cbe8-8eb8-4167-b95f-47b4cd6bbf53	a3b92139-eb81-4a88-a88d-0e4b23e9368c	0ce00da0-18d6-4fb8-ae42-a208b99b85ef	fe8403ef-6732-42db-868d-4346f296f49c	673165a3-1070-4069-8aec-3d86ddf8a2cd	e176a334-debb-4971-a0fa-9ed38e6545d6	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 12:49:41.812+00
f1000000-0000-4000-8000-000000000001	d7412cac-b652-4a48-a889-e282a2ed5d55	ad63e923-9aa9-48a0-b0f7-967619c1678c	6154b0bb-a33d-4aa1-bb85-e74badea0943	e5799bbe-6845-4fcf-9759-3f130d8e2e21	8b2de3f1-b6c9-4ae3-8374-8208769537d4	2026-08-05 06:30:00+00	2026-08-05 07:15:00+00	completed	web	\N	2026-08-04 13:12:03.457249+00
f1000000-0000-4000-8000-000000000002	d7412cac-b652-4a48-a889-e282a2ed5d55	f5a26f06-7bbc-45c0-b16e-019cba99dac0	6154b0bb-a33d-4aa1-bb85-e74badea0943	e5799bbe-6845-4fcf-9759-3f130d8e2e21	c5a8037d-70c1-4713-aa80-484c8cbb148a	2026-08-06 10:30:00+00	2026-08-06 11:30:00+00	completed	mobile	\N	2026-08-05 13:12:03.457249+00
f1000000-0000-4000-8000-000000000003	d7412cac-b652-4a48-a889-e282a2ed5d55	f7690417-beec-4ace-82fa-3d11b987410d	6154b0bb-a33d-4aa1-bb85-e74badea0943	e5799bbe-6845-4fcf-9759-3f130d8e2e21	9aca819f-e946-472f-a877-70f324eb6daf	2026-08-07 06:00:00+00	2026-08-07 06:30:00+00	completed	walkin	\N	2026-08-07 09:12:03.457249+00
f1000000-0000-4000-8000-000000000004	d7412cac-b652-4a48-a889-e282a2ed5d55	d957112b-bb92-4d78-904e-840ba8abf6fe	6154b0bb-a33d-4aa1-bb85-e74badea0943	d5e35d0a-f860-4607-92e7-8d2f9a2787b8	bb14e9a5-c921-4c60-a82c-a6e9ef1d8c18	2026-08-07 07:30:00+00	2026-08-07 09:00:00+00	confirmed	web	\N	2026-08-06 13:12:03.457249+00
f1000000-0000-4000-8000-000000000006	d7412cac-b652-4a48-a889-e282a2ed5d55	d957112b-bb92-4d78-904e-840ba8abf6fe	6154b0bb-a33d-4aa1-bb85-e74badea0943	d5e35d0a-f860-4607-92e7-8d2f9a2787b8	bb14e9a5-c921-4c60-a82c-a6e9ef1d8c18	2026-08-08 12:30:00+00	2026-08-08 14:00:00+00	held	mobile	2026-08-08 14:30:00+00	2026-08-07 12:37:03.457249+00
f1000000-0000-4000-8000-000000000007	d7412cac-b652-4a48-a889-e282a2ed5d55	d957112b-bb92-4d78-904e-840ba8abf6fe	6154b0bb-a33d-4aa1-bb85-e74badea0943	e5799bbe-6845-4fcf-9759-3f130d8e2e21	9aca819f-e946-472f-a877-70f324eb6daf	2026-08-08 06:30:00+00	2026-08-08 07:00:00+00	confirmed	web	\N	2026-08-07 10:12:03.457249+00
f1000000-0000-4000-8000-000000000008	d7412cac-b652-4a48-a889-e282a2ed5d55	ad63e923-9aa9-48a0-b0f7-967619c1678c	6154b0bb-a33d-4aa1-bb85-e74badea0943	e5799bbe-6845-4fcf-9759-3f130d8e2e21	c5a8037d-70c1-4713-aa80-484c8cbb148a	2026-08-08 09:30:00+00	2026-08-08 10:30:00+00	cancelled	web	\N	2026-08-06 13:12:03.457249+00
f1000000-0000-4000-8000-000000000009	d7412cac-b652-4a48-a889-e282a2ed5d55	f7690417-beec-4ace-82fa-3d11b987410d	6154b0bb-a33d-4aa1-bb85-e74badea0943	e5799bbe-6845-4fcf-9759-3f130d8e2e21	bb14e9a5-c921-4c60-a82c-a6e9ef1d8c18	2026-08-09 07:30:00+00	2026-08-09 09:00:00+00	no_show	mobile	\N	2026-08-06 13:12:03.457249+00
f1000000-0000-4000-8000-000000000010	d7412cac-b652-4a48-a889-e282a2ed5d55	f5a26f06-7bbc-45c0-b16e-019cba99dac0	34d42336-3900-4918-a2d6-9068b8cfe6b0	51d39d57-ca24-4221-8099-a0069676ad6b	bb14e9a5-c921-4c60-a82c-a6e9ef1d8c18	2026-08-06 06:30:00+00	2026-08-06 08:00:00+00	completed	web	\N	2026-08-05 13:12:03.457249+00
f1000000-0000-4000-8000-000000000011	d7412cac-b652-4a48-a889-e282a2ed5d55	ad63e923-9aa9-48a0-b0f7-967619c1678c	34d42336-3900-4918-a2d6-9068b8cfe6b0	51d39d57-ca24-4221-8099-a0069676ad6b	8b2de3f1-b6c9-4ae3-8374-8208769537d4	2026-08-07 06:30:00+00	2026-08-07 07:15:00+00	confirmed	walkin	\N	2026-08-07 10:12:03.457249+00
f1000000-0000-4000-8000-000000000013	d7412cac-b652-4a48-a889-e282a2ed5d55	f7690417-beec-4ace-82fa-3d11b987410d	34d42336-3900-4918-a2d6-9068b8cfe6b0	51d39d57-ca24-4221-8099-a0069676ad6b	c5a8037d-70c1-4713-aa80-484c8cbb148a	2026-08-08 11:30:00+00	2026-08-08 12:30:00+00	confirmed	mobile	\N	2026-08-06 13:12:03.457249+00
f1000000-0000-4000-8000-000000000014	d7412cac-b652-4a48-a889-e282a2ed5d55	f5a26f06-7bbc-45c0-b16e-019cba99dac0	34d42336-3900-4918-a2d6-9068b8cfe6b0	51d39d57-ca24-4221-8099-a0069676ad6b	8b2de3f1-b6c9-4ae3-8374-8208769537d4	2026-08-10 08:30:00+00	2026-08-10 09:15:00+00	confirmed	web	\N	2026-08-06 13:12:03.457249+00
f1000000-0000-4000-8000-000000000015	d7412cac-b652-4a48-a889-e282a2ed5d55	ad63e923-9aa9-48a0-b0f7-967619c1678c	34d42336-3900-4918-a2d6-9068b8cfe6b0	51d39d57-ca24-4221-8099-a0069676ad6b	bb14e9a5-c921-4c60-a82c-a6e9ef1d8c18	2026-08-11 10:30:00+00	2026-08-11 12:00:00+00	confirmed	bot	\N	2026-08-07 11:12:03.457249+00
f1000000-0000-4000-8000-000000000012	d7412cac-b652-4a48-a889-e282a2ed5d55	d957112b-bb92-4d78-904e-840ba8abf6fe	34d42336-3900-4918-a2d6-9068b8cfe6b0	51d39d57-ca24-4221-8099-a0069676ad6b	c5a8037d-70c1-4713-aa80-484c8cbb148a	2026-08-07 09:30:00+00	2026-08-07 10:30:00+00	confirmed	web	\N	2026-08-07 12:52:03.457249+00
f1000000-0000-4000-8000-000000000021	d7412cac-b652-4a48-a889-e282a2ed5d55	ad63e923-9aa9-48a0-b0f7-967619c1678c	34d42336-3900-4918-a2d6-9068b8cfe6b0	51d39d57-ca24-4221-8099-a0069676ad6b	8b2de3f1-b6c9-4ae3-8374-8208769537d4	2026-08-12 05:30:00+00	2026-08-12 06:15:00+00	pending	web	\N	2026-08-07 13:31:29.308321+00
f1000000-0000-4000-8000-000000000022	d7412cac-b652-4a48-a889-e282a2ed5d55	f5a26f06-7bbc-45c0-b16e-019cba99dac0	6154b0bb-a33d-4aa1-bb85-e74badea0943	e5799bbe-6845-4fcf-9759-3f130d8e2e21	9aca819f-e946-472f-a877-70f324eb6daf	2026-08-12 07:00:00+00	2026-08-12 07:30:00+00	pending	web	\N	2026-08-07 13:31:29.308321+00
f1000000-0000-4000-8000-000000000023	d7412cac-b652-4a48-a889-e282a2ed5d55	f7690417-beec-4ace-82fa-3d11b987410d	6154b0bb-a33d-4aa1-bb85-e74badea0943	d5e35d0a-f860-4607-92e7-8d2f9a2787b8	bb14e9a5-c921-4c60-a82c-a6e9ef1d8c18	2026-08-13 08:30:00+00	2026-08-13 10:00:00+00	pending	web	\N	2026-08-07 13:31:29.308321+00
f1000000-0000-4000-8000-000000000024	d7412cac-b652-4a48-a889-e282a2ed5d55	d957112b-bb92-4d78-904e-840ba8abf6fe	34d42336-3900-4918-a2d6-9068b8cfe6b0	51d39d57-ca24-4221-8099-a0069676ad6b	c5a8037d-70c1-4713-aa80-484c8cbb148a	2026-08-14 11:30:00+00	2026-08-14 12:30:00+00	pending	web	\N	2026-08-07 13:31:29.308321+00
f1000000-0000-4000-8000-000000000025	d7412cac-b652-4a48-a889-e282a2ed5d55	ad63e923-9aa9-48a0-b0f7-967619c1678c	6154b0bb-a33d-4aa1-bb85-e74badea0943	e5799bbe-6845-4fcf-9759-3f130d8e2e21	8b2de3f1-b6c9-4ae3-8374-8208769537d4	2026-08-15 08:00:00+00	2026-08-15 08:45:00+00	pending	web	\N	2026-08-07 13:31:29.308321+00
f1000000-0000-4000-8000-000000000026	d7412cac-b652-4a48-a889-e282a2ed5d55	f5a26f06-7bbc-45c0-b16e-019cba99dac0	6154b0bb-a33d-4aa1-bb85-e74badea0943	e5799bbe-6845-4fcf-9759-3f130d8e2e21	9aca819f-e946-472f-a877-70f324eb6daf	2026-08-16 05:30:00+00	2026-08-16 06:00:00+00	pending	web	\N	2026-08-07 13:31:29.308321+00
f1000000-0000-4000-8000-000000000027	d7412cac-b652-4a48-a889-e282a2ed5d55	f7690417-beec-4ace-82fa-3d11b987410d	34d42336-3900-4918-a2d6-9068b8cfe6b0	51d39d57-ca24-4221-8099-a0069676ad6b	bb14e9a5-c921-4c60-a82c-a6e9ef1d8c18	2026-08-17 09:30:00+00	2026-08-17 10:30:00+00	pending	web	\N	2026-08-07 13:31:29.308321+00
7074c64f-428c-429b-8c90-07185eb10629	e7f95ac5-5c53-4db7-b274-f0c94730f18c	d7bc5f7b-38ab-46d3-8912-8deddafc5d66	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	827e26f5-d1ce-45cc-8b99-2078891e1ef0	7b78719c-efae-4e61-9921-a80916707d4a	2026-08-12 09:00:00+00	2026-08-12 09:30:00+00	expired	web	2026-08-07 13:04:23.618+00	2026-08-07 12:49:23.618+00
f8912221-fd03-40ea-bc3b-ebc76f6cebd4	33b55265-4e46-4dfc-8e22-22fd32ccd0f2	7938d187-a625-4d0c-aca0-31a2cac71b3e	4094637e-5070-4e5e-a1c7-627a2f8cb985	198217d7-dcfc-488a-8b1a-fe5d3937dd7a	f93348f2-b0aa-4ad1-9e75-f885bf76c8c6	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 13:56:57.782+00
2fbaf9d6-14d4-4284-a4c2-a51398cc5333	ca682117-4612-4948-ae95-9706f3d56404	9b0a06c0-b2fc-4736-afae-1c183cf6c2fb	50070078-f099-4cb5-a8ce-c6bde911a49e	1f6a2459-5a01-4196-ab32-b0d412037c8d	bc1545f5-f37b-40bc-82b8-c3d8bc2e6a08	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 13:58:33.145+00
84b442fd-1463-496c-97c4-329a6ba9f1a6	ca682117-4612-4948-ae95-9706f3d56404	9b0a06c0-b2fc-4736-afae-1c183cf6c2fb	50070078-f099-4cb5-a8ce-c6bde911a49e	1f6a2459-5a01-4196-ab32-b0d412037c8d	bc1545f5-f37b-40bc-82b8-c3d8bc2e6a08	2026-08-09 09:30:00+00	2026-08-09 10:00:00+00	confirmed	web	\N	2026-08-07 13:58:33.235+00
1b77fefe-cdcb-43a4-8e40-b0a679c7c968	ca682117-4612-4948-ae95-9706f3d56404	9b0a06c0-b2fc-4736-afae-1c183cf6c2fb	f073a0ff-6e6f-43d4-9a63-9ed194b88797	1f6a2459-5a01-4196-ab32-b0d412037c8d	bc1545f5-f37b-40bc-82b8-c3d8bc2e6a08	2026-08-10 09:00:00+00	2026-08-10 09:30:00+00	cancelled	web	\N	2026-08-07 13:58:33.353+00
f1a47354-d172-4483-b16d-371a98320baf	9ce67759-ee69-4264-a07f-891b3f9805e2	73294aa5-8091-491b-b658-e3a66eef9e65	f03e27a5-59d9-4a0d-be4c-9d55c611afa2	ff1d3e5a-5cab-46a5-a6f7-886e43dcf321	a4a0312c-a691-4195-a13a-008c15b41d73	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 13:58:34.425+00
3e5ae360-0258-4e9e-9921-52a6da06c7af	ca682117-4612-4948-ae95-9706f3d56404	576e71fb-cbd8-4d2e-866e-79fd1fb3f6a8	f073a0ff-6e6f-43d4-9a63-9ed194b88797	1f6a2459-5a01-4196-ab32-b0d412037c8d	9d4b5af6-6113-4643-9510-6ea488f58cf2	2026-08-12 09:00:00+00	2026-08-12 09:30:00+00	expired	web	2026-08-07 14:13:33.314+00	2026-08-07 13:58:33.314+00
f1000000-0000-4000-8000-000000000005	d7412cac-b652-4a48-a889-e282a2ed5d55	f5a26f06-7bbc-45c0-b16e-019cba99dac0	6154b0bb-a33d-4aa1-bb85-e74badea0943	e5799bbe-6845-4fcf-9759-3f130d8e2e21	8b2de3f1-b6c9-4ae3-8374-8208769537d4	2026-08-07 11:30:00+00	2026-08-07 12:15:00+00	no_show	bot	\N	2026-08-07 12:47:03.457249+00
51845931-9a13-438c-8695-f99ed8609182	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	d3b1efb2-ea44-4b70-8fc2-cd870f5638bc	fd8e1e25-280c-4c6f-bed3-f070bcce4912	62a18340-f533-4a3a-9c4a-5a004b306a49	1e36221a-ecd2-4d9c-ad49-09c9ec84d1da	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 14:00:06.949+00
ade37cfb-9561-4190-903f-89eae28d7bce	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	d3b1efb2-ea44-4b70-8fc2-cd870f5638bc	fd8e1e25-280c-4c6f-bed3-f070bcce4912	62a18340-f533-4a3a-9c4a-5a004b306a49	1e36221a-ecd2-4d9c-ad49-09c9ec84d1da	2026-08-09 09:30:00+00	2026-08-09 10:00:00+00	confirmed	web	\N	2026-08-07 14:00:07.044+00
bc208f97-dbeb-4dc8-a051-6d3a93c4a808	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	d3b1efb2-ea44-4b70-8fc2-cd870f5638bc	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	62a18340-f533-4a3a-9c4a-5a004b306a49	1e36221a-ecd2-4d9c-ad49-09c9ec84d1da	2026-08-10 09:00:00+00	2026-08-10 09:30:00+00	cancelled	web	\N	2026-08-07 14:00:07.164+00
47400210-8c28-499e-8e99-cd33b95793f7	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	d3b1efb2-ea44-4b70-8fc2-cd870f5638bc	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	62a18340-f533-4a3a-9c4a-5a004b306a49	1e36221a-ecd2-4d9c-ad49-09c9ec84d1da	2026-08-11 09:00:00+00	2026-08-11 09:30:00+00	cancelled	web	\N	2026-08-07 14:00:07.235+00
6fac84dc-0e20-4e6a-95df-78f44c53fe02	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	4aaecd5e-c016-4692-9d35-d83787da5bef	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	62a18340-f533-4a3a-9c4a-5a004b306a49	1fbd6d71-c504-4139-b538-c704d4be8eab	2026-08-12 09:00:00+00	2026-08-12 09:30:00+00	expired	web	2026-08-07 14:15:07.126+00	2026-08-07 14:00:07.127+00
6f629f23-16f0-4692-b6e9-2bdc32aec4c4	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	d3b1efb2-ea44-4b70-8fc2-cd870f5638bc	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	62a18340-f533-4a3a-9c4a-5a004b306a49	1e36221a-ecd2-4d9c-ad49-09c9ec84d1da	2026-08-13 09:00:00+00	2026-08-13 09:30:00+00	no_show	web	\N	2026-08-07 14:00:07.297+00
cccfe2ae-75cb-4edb-8092-5bd558e57b2a	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	d3b1efb2-ea44-4b70-8fc2-cd870f5638bc	fd8e1e25-280c-4c6f-bed3-f070bcce4912	62a18340-f533-4a3a-9c4a-5a004b306a49	1e36221a-ecd2-4d9c-ad49-09c9ec84d1da	2026-08-14 09:00:00+00	2026-08-14 09:30:00+00	confirmed	web	\N	2026-08-07 14:00:07.384+00
50f7b605-c5fa-40ea-b521-14158b2c841c	daaee930-a32d-41c2-8e2d-d59946feb22b	00b48657-4d11-4e3a-88b7-435a71d0b9b5	16d1ba6d-ef25-495d-b7ca-32728de6b6cd	efa5af82-2904-4b89-adad-8d79624a633d	2a0c7a09-ccb4-43b4-9628-92083102989c	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 14:00:07.913+00
d104d254-62a0-431b-a031-2ed3cb1e4f32	41945155-8295-4ffe-9fca-a051aec9d85c	60d5e20c-c037-4312-8834-763838bac6cd	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	26d35845-2fc6-4cf9-8608-12ecb460fcf2	8320733c-90dd-4501-a57f-dd38216f890c	2026-08-12 09:00:00+00	2026-08-12 09:30:00+00	expired	web	2026-08-07 14:15:55.12+00	2026-08-07 14:00:55.121+00
276df2f0-e3f9-4bb8-a080-280bca5c5374	ecfd9427-201f-45b4-b995-0c5903186dcf	6db8511b-a42e-4ed3-b81a-376342998437	bb302d69-79ff-4921-86d1-8e6e22ae92cb	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	46b2c119-af58-4fd8-a8b2-dfc17ca997cd	2026-08-12 09:00:00+00	2026-08-12 09:30:00+00	expired	web	2026-08-07 14:16:55.097+00	2026-08-07 14:01:55.098+00
90000000-0000-0000-0000-000000000001	11111111-1111-1111-1111-111111111111	cccccccc-5555-5555-5555-555555555555	dddddddd-3333-3333-3333-333333333333	33333333-3333-3333-3333-333333333333	44444444-4444-4444-4444-444444444444	2026-08-06 06:30:00+00	2026-08-06 07:05:00+00	completed	web	\N	2026-08-05 14:48:35.458336+00
90000000-0000-0000-0000-000000000002	11111111-1111-1111-1111-111111111111	cccccccc-6666-6666-6666-666666666666	22222222-2222-2222-2222-222222222222	33333333-3333-3333-3333-333333333334	55555555-5555-5555-5555-555555555555	2026-08-06 10:30:00+00	2026-08-06 12:10:00+00	completed	mobile	\N	2026-08-04 14:48:35.458336+00
90000000-0000-0000-0000-000000000003	11111111-1111-1111-1111-111111111111	cccccccc-7777-7777-7777-777777777777	dddddddd-3333-3333-3333-333333333333	33333333-3333-3333-3333-333333333333	66666666-6666-6666-6666-666666666666	2026-08-07 06:30:00+00	2026-08-07 07:20:00+00	confirmed	web	\N	2026-08-06 20:48:35.458336+00
90000000-0000-0000-0000-000000000004	11111111-1111-1111-1111-111111111111	cccccccc-8888-8888-8888-888888888888	22222222-2222-2222-2222-222222222222	33333333-3333-3333-3333-333333333334	77777777-7777-7777-7777-777777777777	2026-08-07 07:30:00+00	2026-08-07 09:45:00+00	pending	bot	\N	2026-08-07 14:03:35.458336+00
90000000-0000-0000-0000-000000000005	11111111-1111-1111-1111-111111111111	cccccccc-5555-5555-5555-555555555555	dddddddd-3333-3333-3333-333333333333	33333333-3333-3333-3333-333333333333	55555555-5555-5555-5555-555555555555	2026-08-07 11:30:00+00	2026-08-07 13:10:00+00	confirmed	walkin	\N	2026-08-07 11:48:35.458336+00
f49d29c7-f499-4442-b226-908911d31ccb	41945155-8295-4ffe-9fca-a051aec9d85c	18d49e49-ed72-4c0b-950b-8fc54973a05b	e366d7da-0479-44df-bd5a-5a2d666f9313	26d35845-2fc6-4cf9-8608-12ecb460fcf2	d46cb866-1e65-45cd-9679-b816fe895535	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 14:00:54.917+00
90000000-0000-0000-0000-000000000006	11111111-1111-1111-1111-111111111111	cccccccc-6666-6666-6666-666666666666	22222222-2222-2222-2222-222222222222	33333333-3333-3333-3333-333333333334	44444444-4444-4444-4444-444444444444	2026-08-08 06:00:00+00	2026-08-08 06:35:00+00	confirmed	mobile	\N	2026-08-07 09:48:35.458336+00
b617683e-a55a-42ec-9383-03016bbe318d	41945155-8295-4ffe-9fca-a051aec9d85c	18d49e49-ed72-4c0b-950b-8fc54973a05b	e366d7da-0479-44df-bd5a-5a2d666f9313	26d35845-2fc6-4cf9-8608-12ecb460fcf2	d46cb866-1e65-45cd-9679-b816fe895535	2026-08-09 09:30:00+00	2026-08-09 10:00:00+00	confirmed	web	\N	2026-08-07 14:00:55.024+00
90000000-0000-0000-0000-000000000007	11111111-1111-1111-1111-111111111111	cccccccc-7777-7777-7777-777777777777	dddddddd-3333-3333-3333-333333333333	33333333-3333-3333-3333-333333333333	66666666-6666-6666-6666-666666666666	2026-08-08 08:30:00+00	2026-08-08 09:20:00+00	pending	web	\N	2026-08-07 14:28:35.458336+00
90000000-0000-0000-0000-000000000008	11111111-1111-1111-1111-111111111111	cccccccc-8888-8888-8888-888888888888	22222222-2222-2222-2222-222222222222	33333333-3333-3333-3333-333333333334	44444444-4444-4444-4444-444444444444	2026-08-09 12:30:00+00	2026-08-09 13:05:00+00	cancelled	web	\N	2026-08-06 14:48:35.458336+00
34340795-0561-4bcd-898b-2f20f5a4f03b	41945155-8295-4ffe-9fca-a051aec9d85c	18d49e49-ed72-4c0b-950b-8fc54973a05b	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	26d35845-2fc6-4cf9-8608-12ecb460fcf2	d46cb866-1e65-45cd-9679-b816fe895535	2026-08-10 09:00:00+00	2026-08-10 09:30:00+00	cancelled	web	\N	2026-08-07 14:00:55.167+00
9549a141-1652-4612-ae4f-9dd776b3928e	41945155-8295-4ffe-9fca-a051aec9d85c	18d49e49-ed72-4c0b-950b-8fc54973a05b	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	26d35845-2fc6-4cf9-8608-12ecb460fcf2	d46cb866-1e65-45cd-9679-b816fe895535	2026-08-11 09:00:00+00	2026-08-11 09:30:00+00	cancelled	web	\N	2026-08-07 14:00:55.247+00
4b9b917a-1882-4707-a369-7f349a533394	41945155-8295-4ffe-9fca-a051aec9d85c	18d49e49-ed72-4c0b-950b-8fc54973a05b	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	26d35845-2fc6-4cf9-8608-12ecb460fcf2	d46cb866-1e65-45cd-9679-b816fe895535	2026-08-13 09:00:00+00	2026-08-13 09:30:00+00	no_show	web	\N	2026-08-07 14:00:55.318+00
4e2abbdd-4cac-4e18-8bce-900f7093bc74	41945155-8295-4ffe-9fca-a051aec9d85c	18d49e49-ed72-4c0b-950b-8fc54973a05b	e366d7da-0479-44df-bd5a-5a2d666f9313	26d35845-2fc6-4cf9-8608-12ecb460fcf2	d46cb866-1e65-45cd-9679-b816fe895535	2026-08-14 09:00:00+00	2026-08-14 09:30:00+00	confirmed	web	\N	2026-08-07 14:00:55.422+00
975d9904-a2bd-409d-b46e-5a51e8f7b60a	d5fb54d8-3c89-493d-8edd-48fb3f04ef42	fd2f3697-2ab6-493e-b75a-acee4acd68ba	e2200c8d-5e09-4149-bea1-d3a6a7f0e421	65175517-9f0c-4da3-86d1-90871674bb91	3b553df5-2dff-496c-8425-8176e770dffb	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 14:00:56.045+00
9eb3d656-d42a-4a2b-9dac-4072e44cc38b	e66c3ae5-4fe0-48ef-a5f8-e2226df0ed55	7a35c058-2247-404a-a8b8-531910a0048a	274d5221-7f2c-46d4-b797-119ae3f82652	d8e47ef5-0633-4c8e-8547-125a436fca96	052aaf78-97c7-4b60-af04-b86c6ca2c5af	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 14:01:17.522+00
abe4a8f7-974f-4fbf-b642-cc8a3ad29133	ecfd9427-201f-45b4-b995-0c5903186dcf	4aa98b51-df1c-4b52-8cb3-4595fdb3e1c3	d41ffc8a-603b-483a-bfe3-3c7994ef116c	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	e2a5c228-635b-4c6e-89bc-e7e0dda33618	2026-08-09 09:00:00+00	2026-08-09 09:30:00+00	confirmed	web	\N	2026-08-07 14:01:54.914+00
608f06e4-1363-4010-bb3c-030f1499ebe1	ecfd9427-201f-45b4-b995-0c5903186dcf	4aa98b51-df1c-4b52-8cb3-4595fdb3e1c3	d41ffc8a-603b-483a-bfe3-3c7994ef116c	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	e2a5c228-635b-4c6e-89bc-e7e0dda33618	2026-08-09 09:30:00+00	2026-08-09 10:00:00+00	confirmed	web	\N	2026-08-07 14:01:55.012+00
d9ed7173-9d8d-4c7f-94e7-6cf8e78701dd	ecfd9427-201f-45b4-b995-0c5903186dcf	4aa98b51-df1c-4b52-8cb3-4595fdb3e1c3	bb302d69-79ff-4921-86d1-8e6e22ae92cb	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	e2a5c228-635b-4c6e-89bc-e7e0dda33618	2026-08-10 09:00:00+00	2026-08-10 09:30:00+00	cancelled	web	\N	2026-08-07 14:01:55.136+00
32ebcaa0-14f5-4df2-92d0-8cdfd4eaeb3e	ecfd9427-201f-45b4-b995-0c5903186dcf	4aa98b51-df1c-4b52-8cb3-4595fdb3e1c3	bb302d69-79ff-4921-86d1-8e6e22ae92cb	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	e2a5c228-635b-4c6e-89bc-e7e0dda33618	2026-08-11 09:00:00+00	2026-08-11 09:30:00+00	cancelled	web	\N	2026-08-07 14:01:55.207+00
6490bafa-0a3e-4d27-a7dd-9ddffeed60b1	ecfd9427-201f-45b4-b995-0c5903186dcf	4aa98b51-df1c-4b52-8cb3-4595fdb3e1c3	bb302d69-79ff-4921-86d1-8e6e22ae92cb	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	e2a5c228-635b-4c6e-89bc-e7e0dda33618	2026-08-13 09:00:00+00	2026-08-13 09:30:00+00	no_show	web	\N	2026-08-07 14:01:55.272+00
a3136b2a-f53c-4a2b-b16b-fd68563e9c23	ecfd9427-201f-45b4-b995-0c5903186dcf	4aa98b51-df1c-4b52-8cb3-4595fdb3e1c3	d41ffc8a-603b-483a-bfe3-3c7994ef116c	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	e2a5c228-635b-4c6e-89bc-e7e0dda33618	2026-08-14 09:00:00+00	2026-08-14 09:30:00+00	confirmed	web	\N	2026-08-07 14:01:55.373+00
59a0cf4e-729b-42e2-9a61-14f892633f74	a8f9e2e8-b848-487b-a2c4-8b7a01f955a3	7a3f491f-7a20-424a-b6bb-60acdf81436c	b25a26a7-eb8d-49a2-b10f-79544277cebb	6b17463d-cd48-4c3c-bd39-f468a9bc6ff0	99eeded0-7a11-4bad-a4ab-7b4e1d0695a4	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 14:01:55.931+00
4d096d26-7e40-43d9-b4b7-86fa25adee63	e71737ea-c9ab-401c-bd67-8525aa0060fd	83693237-8fca-43fa-9c74-40d124261d16	51f6dc27-15f5-44a3-9826-0805962f6322	5d5c2e95-5a1a-477a-865c-c63b42a1cacb	25807141-00a8-4d12-9879-c2933e93c217	2026-08-08 09:00:00+00	2026-08-08 09:30:00+00	pending	web	\N	2026-08-07 14:02:14.244+00
\.


--
-- Data for Name: bot_chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bot_chat (id, platform, chat_id, customer_id, staff_member_id, linked_at) FROM stdin;
\.


--
-- Data for Name: bot_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bot_session (id, platform, chat_id, step, draft_json, updated_at) FROM stdin;
\.


--
-- Data for Name: chair; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chair (id, salon_id, name, active) FROM stdin;
33333333-3333-3333-3333-333333333333	11111111-1111-1111-1111-111111111111	صندلی ۱	t
1e636710-d093-45be-869a-2d331d3d3c49	f3f3eb54-0191-4d27-bd54-81fa82f9b40f	صندلی 1	t
59dd296e-9d8c-4dee-bfe3-759bf6184875	f3f3eb54-0191-4d27-bd54-81fa82f9b40f	صندلی 2	t
1945e54b-19d9-4988-ad4c-c4345f840274	83bc9d7c-d555-4961-8c35-215f48b3f8b7	صندلی 1	t
d4fd394b-d650-4bfb-b19d-577e7854340f	83bc9d7c-d555-4961-8c35-215f48b3f8b7	صندلی Config Stylist	t
8803710a-b0de-435d-a0cf-9a9d897678c1	b6e528ae-c2ac-4579-bd70-4a33806fbcee	E2E Chair	f
1c5dad57-b2d6-4fcb-a1c4-677f9ed40062	c29ea8c8-5840-4ddb-885c-e70eafb741b5	صندلی 1	t
739269fc-7daa-44ff-aa8c-ee779905e61a	c29ea8c8-5840-4ddb-885c-e70eafb741b5	صندلی Booking Stylist	t
7778910e-0e92-43c9-9030-7376e5fc5a89	48b7b978-caca-4b3d-9996-48178b2a4fb5	صندلی 1	t
342e5b11-492d-4021-bf7c-12697600a2ee	48b7b978-caca-4b3d-9996-48178b2a4fb5	صندلی Premium Stylist	t
05bcc3c8-d781-4866-b412-c691a6844950	1bb72fda-9b55-4d92-b5ae-07341a7c9aaf	صندلی 1	t
98d1cb82-2436-4528-a7a7-f38abe109bfd	1bb72fda-9b55-4d92-b5ae-07341a7c9aaf	صندلی Misc Stylist	t
36d5fceb-fe61-47c7-9293-079eddefac1b	1cb71f4e-7f3f-473c-9ba2-9bf38e6943fa	صندلی 1	t
adf80c3a-8830-49ab-8010-f48f0cd913d6	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	صندلی 1	t
f5941d30-215a-40e9-8571-15bc9b9fe8f7	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	صندلی 2	t
5db2dd43-962a-46eb-b4ae-0646785b565c	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	صندلی 3	t
4acdc609-c025-4458-8aa2-2fd082f85e3d	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	صندلی 4	t
7341a8e0-64e5-442e-a15d-9b69f0a065c2	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	صندلی 5	t
44efbbd7-5146-495f-bdcc-5b8b9fb9ca8d	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	صندلی 6	t
ea09a6e2-8fb7-4192-92f9-773631f5a193	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	صندلی 7	t
ff38dd2e-5f2c-4d6d-9b97-51a885e7bb90	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	صندلی 8	t
df024c6d-58d3-46e8-9399-c323b0f0a8ca	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	صندلی 9	t
f6769c38-6269-41fc-9c0e-39c7f2396bde	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	صندلی 10	t
3a164365-6f53-4d44-a2a2-13cc93237064	82ad3b1b-e80e-4d67-95d4-e934f31934a4	صندلی 1	t
471ceace-2ff4-4229-b13d-d2b66bd9bcb8	1ba2c5c1-6c6e-4e84-9343-56d66b2d3226	صندلی 1	t
5d8fa48c-6bd7-4ff3-8c06-f9b84553ca4c	e54af3fc-d38b-41ad-b517-e558fa0e6cbf	صندلی 1	t
0e531f56-7d5f-4ba0-9dec-276fb3d4b47e	c243bba9-2f63-421a-b92f-7e9eee00a7e2	صندلی 1	t
3a4a92df-91bb-4e7a-8a50-ea5c6a381a13	f7bc45c9-75c1-4443-9dee-3b2183130dc0	صندلی 1	t
a155ffe7-df04-44cc-b091-8027dd7f0598	eed48a8d-9014-40d6-903a-955c31140613	صندلی 1	t
2970159a-cab4-492d-a3fa-a76f12c64b96	f2b895e3-8eaf-42e4-b3c6-a244fff4934f	صندلی 1	t
baa02a3a-93d6-48c5-a21b-77f8f71fc98f	3c84048d-601a-4f55-a989-038efc3ddbd2	صندلی 1	t
0ad27df7-3dc1-4be9-bc8c-612152df469c	34c4ebd4-eef3-4225-bcf6-cdaac1521668	صندلی 1	t
c2ce68f0-6f97-4dde-88a5-c8740f9af106	6524f8ac-5aae-4f63-80ca-6cee0c030b20	صندلی 1	t
f1d783d4-6ec7-4595-ac54-e8db52f6df77	6524f8ac-5aae-4f63-80ca-6cee0c030b20	صندلی E2E آرایشگر 1786103567126	t
016ef339-c6f8-4c11-9055-f5b31b05acc6	8a91b095-7147-4ff4-9b71-290b72e6de88	صندلی 1	t
19b6bff0-ce2a-4670-9bee-dc094ec4ea49	8a91b095-7147-4ff4-9b71-290b72e6de88	صندلی RBAC آرایشگر	t
d30dd962-14de-4ef0-94ae-e99ea8fca2b8	049ff655-e678-4a8a-aa15-dd1d0f082d72	صندلی 1	t
7d488cac-2911-4bab-bf57-c138c664683a	3ae5cde0-3a8d-4d60-be96-c4c456e161a0	صندلی 1	t
4ff6487b-8c36-4bca-b5aa-891220ea1473	83738a22-ac2f-4959-ae1f-31ab6a64d166	صندلی 1	t
33fe5c2c-3241-48ae-b17c-20ab36783f0e	e539a6f7-3a89-4777-8cc4-356882028d76	صندلی 1	t
29e4dae1-ae20-42e7-9f6a-fb9ab686f6bb	b332bbaf-9ab8-45da-a7a3-e27644b594e5	صندلی 1	t
36ec0484-0b59-4659-8ef4-85a52c6e39f4	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	1	t
03492156-dfdc-4442-b706-f994911e1c09	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	2	t
5d19f810-97dc-4267-8793-dbca1f162b37	94d4a899-f24e-4163-9da6-d42540203798	صندلی 1	t
bbf6d9b6-728c-4d75-a2a8-a7abe3c77372	37b31e8c-6d49-4cd9-aea2-e27961f8804f	صندلی 1	t
07f4e02f-2563-4504-a2f3-56347f813b39	37b31e8c-6d49-4cd9-aea2-e27961f8804f	صندلی E2E آرایشگر 1786103906345	t
2f3706f2-fad9-4665-a5f4-821ebae3b5a4	ede45a95-710d-4132-8214-e4c2f13f28e0	صندلی 1	t
e7ef16aa-d2c4-4c72-a6a4-cabbe448fa19	ede45a95-710d-4132-8214-e4c2f13f28e0	صندلی RBAC آرایشگر	t
088c9625-be10-48f4-9ecc-12016efc8946	8d4082de-f9bc-483c-8364-fb5373ecee79	صندلی 1	t
35ba7219-9242-4bef-bca2-c8c25232bbc2	d04088e4-0987-405e-a912-9728a30e1fb7	صندلی 1	t
c2d90014-ae59-44c5-8bee-eed3ce7b0190	282f2ee7-f778-4f75-8e41-72ee726e2d71	صندلی 1	t
39df6082-dfdb-46d0-94b7-4698bd30feda	282f2ee7-f778-4f75-8e41-72ee726e2d71	صندلی E2E آرایشگر 1786104391169	t
b86878bc-d76d-4303-9ab4-7780a23c1e17	3ad3c745-12dc-4dca-9e16-ee4c57bd987b	صندلی 1	t
7f7f9c56-8bc8-4eaf-9d1a-50a302270d88	3ad3c745-12dc-4dca-9e16-ee4c57bd987b	صندلی RBAC آرایشگر	t
a5cb361d-e2e2-43fd-96bc-eabf65d79f16	6a5b29c2-a8df-467a-8c36-ca49f545625c	صندلی 1	t
1aa5c02d-ecd5-40c0-b4c7-8318312759ef	36e79989-a20d-4f1e-9b9b-538d101b4014	صندلی 1	t
4ac558b5-44f8-4546-9de3-f135500064d6	1e53029c-8667-4f39-a775-f30d1293f13a	صندلی 1	t
4836283a-3fef-4278-87a6-e0dd9f952489	21835586-a1de-4990-bb83-8f9cc4373a5c	صندلی 1	t
99aa6936-59d7-4002-b3ff-041f1a0d5395	83bc9d7c-d555-4961-8c35-215f48b3f8b7	E2E Chair	f
bab8f300-58d3-4204-aa59-3277363d1036	c3104b98-c5c9-46db-b100-1ad8180b1c11	صندلی 1	t
aedc7aca-46db-4fda-9bb9-19a72723e04d	9d965b2a-2b91-456a-92bb-937b05888fa8	صندلی 1	t
d28b6c43-9429-42f4-9cf4-56a219bf09b0	4c0bfb7e-08bb-4675-9b6c-b7928cbb347e	صندلی 1	t
b55f3be5-c01f-481f-91f1-9eb6ebbf3a90	b6e528ae-c2ac-4579-bd70-4a33806fbcee	صندلی 1	t
ce3a04f7-3d22-4263-ad71-37e751013436	b6e528ae-c2ac-4579-bd70-4a33806fbcee	صندلی Config Stylist	t
30bd2c29-ad59-463e-af7d-fccd0d9c9123	0ed4db5e-a345-4f57-a5ff-7faf1876853c	صندلی 1	t
231cb19e-f41c-4cbe-b658-ea5bb05291e3	b459826c-7585-4616-a22a-665a527778d3	صندلی 1	t
67c2adc8-ec75-4edd-a37a-3d5e1b46f4af	b459826c-7585-4616-a22a-665a527778d3	صندلی 2	t
392b72c3-0526-4897-a2b3-cedd1af26f01	b459826c-7585-4616-a22a-665a527778d3	صندلی 3	t
fc97462e-b8b8-4d08-b537-7960aacd9755	a4288905-c8f2-4797-8922-144befd9dd50	صندلی 1	t
1c57aa8c-3ff7-4f51-a0da-1c068139913a	3e1a529c-c38c-410a-9147-b0776d2cf387	صندلی 1	t
1bdc6c63-46b5-4c70-8e12-ea2ac1cceddc	3e1a529c-c38c-410a-9147-b0776d2cf387	صندلی Config Stylist	t
dedcd478-5995-49b3-9529-080290a7748d	9d965b2a-2b91-456a-92bb-937b05888fa8	صندلی Booking Stylist	t
e4a7de1f-8db2-4272-ae14-25a205230bdf	65b96ada-c840-4a9d-bfbb-5fa5df901d91	صندلی 1	t
9cda35a9-33b7-4489-a82a-dc396f16df97	3e1a529c-c38c-410a-9147-b0776d2cf387	E2E Chair	f
79bdfb29-1cfb-46a0-aad6-ac690d9be91b	bb22b03a-5d16-4b81-b42a-49e37d27593b	صندلی 1	t
f9b3e60a-9c0f-47ca-82e3-f7f43ee32280	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	صندلی 1	t
5daa0943-aca5-438d-a279-213321d089b4	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	صندلی Booking Stylist	t
22f696d2-8e44-403d-8a31-d00f9f28ed85	55809d45-8657-47fe-a0e2-ad8116219af4	صندلی 1	t
cd2fbb4c-8cc6-4c2e-b319-c244fdc849de	55809d45-8657-47fe-a0e2-ad8116219af4	صندلی Premium Stylist	t
0b563da0-a8a4-439d-bb7a-ccf7e32b6823	c21b3648-38a3-4dde-86ea-cbee7d78165f	صندلی 1	t
8203a5e5-02d6-4103-86d4-941fadc45b77	c21b3648-38a3-4dde-86ea-cbee7d78165f	صندلی Misc Stylist	t
44f64b0b-ce04-4d75-b36b-999245141658	8aa546de-8daf-489d-9fe8-8b3118bf9f7a	صندلی 1	t
75718851-1089-4940-b865-d2d1585bae37	a32e5e4b-40d7-4635-939c-79fb4b2fdc68	صندلی 1	t
33b1dae1-ed14-4628-9ae0-e3263846cb84	65b96ada-c840-4a9d-bfbb-5fa5df901d91	صندلی Premium Stylist	t
d3af3925-bec6-4477-b2d9-f9da02b2cfca	b9e33109-b47b-40d5-a0ac-2a0d837c6827	صندلی 1	t
d28a00b0-aed9-424d-b101-e862f444d69b	b9e33109-b47b-40d5-a0ac-2a0d837c6827	صندلی Misc Stylist	t
caa377db-dabe-4ec6-aeff-3b1339fd21d8	94d46edb-1124-4428-993f-64b9e456dbfb	صندلی 1	t
beb49418-82de-4957-9b26-7b747db08739	94d46edb-1124-4428-993f-64b9e456dbfb	صندلی Config Stylist	t
2014b3ea-9336-4072-9fd5-7d5599065c8c	94d46edb-1124-4428-993f-64b9e456dbfb	E2E Chair	f
9fcf1365-b760-455c-af6e-d7670ab4e073	9f5bd53c-a3c5-4380-b111-3bcfc11381d3	صندلی 1	t
827e26f5-d1ce-45cc-8b99-2078891e1ef0	e7f95ac5-5c53-4db7-b274-f0c94730f18c	صندلی 1	t
9b31cc2b-489e-47eb-ba25-973e86cb6f85	e7f95ac5-5c53-4db7-b274-f0c94730f18c	صندلی Booking Stylist	t
6665e72d-56b8-4077-afe9-9792d28ba2c0	5d0f07bd-e701-4d76-8a43-66f370a0fdd6	صندلی 1	t
0b127c72-e6af-4991-b8a8-39cebf222edc	5d0f07bd-e701-4d76-8a43-66f370a0fdd6	صندلی Premium Stylist	t
f5372a28-1db2-4007-ba0f-d7ae09762a23	f9eaed2d-7068-4583-8a46-869324599cc6	صندلی 1	t
4ae84ba7-1789-4b69-a3f4-a15479ce45dd	f9eaed2d-7068-4583-8a46-869324599cc6	صندلی Misc Stylist	t
512ba19e-72ff-4100-b589-41817019052f	a9ce2f38-b34c-414c-858e-d26135c9d819	صندلی 1	t
81b7e517-ebd1-45b0-ac76-499796224248	7b0a02d7-7ef3-49fe-af64-cb4da63051ae	صندلی 1	t
194dad8c-2c13-4da8-b7af-78859a8245b0	7b0a02d7-7ef3-49fe-af64-cb4da63051ae	صندلی E2E آرایشگر 1786106972841	t
b8aa3402-b5b8-4f61-9634-41e5dcd483eb	0c3dfb48-5927-4861-864f-a8543c9eb7ac	صندلی 1	t
f9b95507-e43f-42bc-ab13-e0dcddafa18a	0c3dfb48-5927-4861-864f-a8543c9eb7ac	صندلی RBAC آرایشگر	t
673165a3-1070-4069-8aec-3d86ddf8a2cd	a3b92139-eb81-4a88-a88d-0e4b23e9368c	صندلی 1	t
7491c8e1-7f0f-4fd0-b659-9dcadc6cb92a	04034eee-0de0-4289-a3db-b3faf17d4ca4	صندلی 1	t
e5799bbe-6845-4fcf-9759-3f130d8e2e21	d7412cac-b652-4a48-a889-e282a2ed5d55	صندلی 1	t
51d39d57-ca24-4221-8099-a0069676ad6b	d7412cac-b652-4a48-a889-e282a2ed5d55	صندلی آرایشگر تست	t
d5e35d0a-f860-4607-92e7-8d2f9a2787b8	d7412cac-b652-4a48-a889-e282a2ed5d55	صندلی VIP	t
8f248581-4277-42ba-9233-0e1887a7f425	91117aaf-0c89-4e41-9598-3479ebdb801f	صندلی 1	t
bf2f3d12-7844-42ae-ac7c-2d6d0cccc210	91117aaf-0c89-4e41-9598-3479ebdb801f	صندلی E2E آرایشگر 1786110742856	t
4ddc657a-b4f8-4cf8-a5e3-3bf91dcf691d	793c04cb-a78d-46bc-b66d-713f10e3f731	صندلی 1	t
8cfbb616-4388-4302-8964-903e7570386e	793c04cb-a78d-46bc-b66d-713f10e3f731	صندلی RBAC آرایشگر	t
f26d6dd6-26a1-49fc-8d09-762d3e46432d	4acda9b4-b53a-452d-b438-3c01cc8a3ca4	صندلی 1	t
2daa9168-7197-4b7d-8ca1-46dd79316812	ea76f00a-df7d-4ff1-8dc7-82b563279af8	صندلی 1	t
09430ba9-e7f6-42b1-a7f1-749fa07df2a2	cbcf2e40-16fa-481d-b8da-be5c9642aa5c	صندلی 1	t
24579732-0b21-4e16-8343-182a6b61a96d	cbcf2e40-16fa-481d-b8da-be5c9642aa5c	صندلی E2E آرایشگر 1786110877167	t
b90c8e63-436c-415a-ae95-08999126140c	a03997c7-c54e-4856-9c2c-f84a6a7c7092	صندلی 1	t
641d4d73-2bb8-47a0-98c7-4b6373947074	e3fa9cc9-4249-426a-8a5e-bdfea48ab30e	صندلی 1	t
b9b66f49-adc9-4547-a578-108005051357	e3fa9cc9-4249-426a-8a5e-bdfea48ab30e	صندلی Config Stylist	t
1f500a10-70ef-4698-b114-25fbe0d51fbe	114d6cf5-f9d5-4cb5-ab7a-89b2facecadf	صندلی 1	t
5765d8c6-3ef8-4cbc-aa4a-2e4e12f7524c	114d6cf5-f9d5-4cb5-ab7a-89b2facecadf	صندلی Config Stylist	t
2b99e353-293f-415a-b732-51fa5cc74e9b	4ee90b92-1681-4046-b42d-50582aaf3c55	صندلی 1	t
c91ce9cd-46f3-483c-beb5-13adce6a4742	4ee90b92-1681-4046-b42d-50582aaf3c55	صندلی E2E آرایشگر 1786110955743	t
eeb21972-74c3-44ae-b56b-624d3bcedb81	8fddf0bd-1345-4f94-9277-ce0abe54fc86	صندلی 1	t
f8fb33b1-8d5b-487e-9dae-0ab3313f8e84	8fddf0bd-1345-4f94-9277-ce0abe54fc86	صندلی RBAC آرایشگر	t
f2bd08c8-34ee-431d-81b8-8063def28c29	d86a4f90-7ef3-477a-b928-3804c9bd1bca	صندلی 1	t
94be1c66-7549-4dba-b8c9-27735fbe0b36	ecdda28c-34cf-47e1-bb64-35433730951f	صندلی 1	t
17b74f53-27b8-48cf-9516-4c26dc0b1cec	47a7b865-c608-462c-84b6-37268be1b96c	صندلی 1	t
3e11de57-aec7-4991-8b5f-d954c5e1f520	4a680e73-4c54-4523-a9e2-e0d52299eb58	صندلی 1	t
9298b232-802f-4169-b23c-21ad3403860c	f6b026fa-c4e3-4be6-a2be-796fe9abbe57	صندلی 1	t
e5501cee-e6b9-44e2-aa7e-76d6be4e898b	7cb82de5-0177-4be1-999c-fd7ef40af41b	صندلی 1	t
e8e68f1f-0b0e-4762-b77c-a4d6d0e285a6	b578c0dd-6919-4d23-b7f2-efa770c47aca	صندلی 1	t
03fb9614-ae11-4924-8f77-5cbaf8466683	e3fa9cc9-4249-426a-8a5e-bdfea48ab30e	E2E Chair	f
3502e9d8-865c-4dbe-b819-7e9af7ff70ca	6734a6d0-2423-4322-8476-bae0d501ab64	صندلی 1	t
9c5b49dc-2855-475e-8cfc-ce8be6aaa6bc	2874dacc-057b-490d-96e1-51b76f6b2910	صندلی 1	t
3f5bc8be-f2dd-4bfa-92d5-921c3b952e1d	8acc033d-9bdc-4a9b-a0f2-a7c8f7a8e80d	صندلی E2E آرایشگر 1786111265916	t
5b570db9-071b-4a2b-a3cb-cb6b7878763f	e7b2abf5-4d80-4d5f-a96e-c42395401a4c	صندلی 1	t
59b876eb-b05f-4415-b98a-e362310ecb4d	4f7ed53f-8383-4517-bd6f-8e71b351ce89	صندلی 1	t
11bcdf43-287d-45f4-995e-fc1f2ad21cb0	a8fbfe27-1784-4a99-bf74-6c560de51016	صندلی 1	t
4489cf8b-2916-42fa-b8c8-54604b93ac86	a8fbfe27-1784-4a99-bf74-6c560de51016	صندلی Config Stylist	t
43eb04dd-d502-4760-88b2-714ee3f97b7e	114d6cf5-f9d5-4cb5-ab7a-89b2facecadf	E2E Chair	f
3cba42b4-6adb-4989-9277-b42d0d05af41	75615eb1-bd39-4831-897f-4b6a23901cb7	صندلی 1	t
956eb3ea-02ac-4bfc-bfbb-7d1731fdff84	a8fbfe27-1784-4a99-bf74-6c560de51016	E2E Chair	f
987953d3-d427-4f8a-8031-045c0aff6acd	d1c9c1e8-22db-4add-814e-be04ecc51faf	صندلی 1	t
587eea71-d4c6-4f7e-9660-0d3a106cb33a	c66e014b-5299-4f9f-bc65-195fbad0cd99	صندلی 1	t
4a4ecc6e-6b57-4f34-9e28-39d89f684d3c	c66e014b-5299-4f9f-bc65-195fbad0cd99	صندلی Booking Stylist	t
79b02ef5-a0ec-4905-b9ff-1ab404ba7967	ce2ffe75-4e1d-4e06-9f8d-8ea2ab35b605	صندلی 1	t
15c9e2f0-4497-44dd-920c-3225a600686b	ce2ffe75-4e1d-4e06-9f8d-8ea2ab35b605	صندلی Premium Stylist	t
198217d7-dcfc-488a-8b1a-fe5d3937dd7a	33b55265-4e46-4dfc-8e22-22fd32ccd0f2	صندلی 1	t
d5f5fcef-8bae-4365-adde-9f43556ed141	33b55265-4e46-4dfc-8e22-22fd32ccd0f2	صندلی Misc Stylist	t
52e02b16-cf87-4e89-add9-60619bd5131a	f4131cfd-52ad-46ee-9c9b-c6d358ed5f10	صندلی 1	t
26d35845-2fc6-4cf9-8608-12ecb460fcf2	41945155-8295-4ffe-9fca-a051aec9d85c	صندلی 1	t
fdf1e9f8-8301-4c2f-b594-51bcf4a43473	41945155-8295-4ffe-9fca-a051aec9d85c	صندلی Booking Stylist	t
23648f5a-e24e-4c41-a1a6-a3784ac7ecf1	7ecbf7b9-4944-4750-858d-c838c1fb60db	صندلی 1	t
190c4b40-8114-4ab3-862e-3fdfb9182954	7ecbf7b9-4944-4750-858d-c838c1fb60db	صندلی Premium Stylist	t
65175517-9f0c-4da3-86d1-90871674bb91	d5fb54d8-3c89-493d-8edd-48fb3f04ef42	صندلی 1	t
5f7bfae1-9466-418e-8949-13b6f9ee506b	d5fb54d8-3c89-493d-8edd-48fb3f04ef42	صندلی Misc Stylist	t
3e9d0a59-525b-4726-8533-9ade944d46d4	385375ee-d31c-4ee6-a768-e54d8fd4f59f	صندلی 1	t
01f0af38-1682-4906-a977-d4ba5b38e3f3	7449789e-cf83-4783-a40b-462ca8396e0c	صندلی 1	t
c439c9bd-a178-45b9-a246-89d0acae1e44	7449789e-cf83-4783-a40b-462ca8396e0c	صندلی Config Stylist	t
8cc8a2e2-e614-479b-82e1-922bcda2e9bd	b32a6626-2517-4496-b611-8221818a64cd	صندلی 1	t
a4c14dba-0f50-43ae-87ca-b0c48669924c	843b43c9-fbb2-496e-9604-69698c152179	صندلی 1	t
eefeb090-78d9-4e1b-bbf3-3fe4d4fe71b5	7449789e-cf83-4783-a40b-462ca8396e0c	E2E Chair	f
6af240ea-b0d1-4236-bf89-6c39276314e1	3e99cb18-41bd-457b-9326-d2889b35cec5	صندلی 1	t
1f6a2459-5a01-4196-ab32-b0d412037c8d	ca682117-4612-4948-ae95-9706f3d56404	صندلی 1	t
78a0f4fd-3ac0-4275-b179-a32323356af2	ca682117-4612-4948-ae95-9706f3d56404	صندلی Booking Stylist	t
a2e3c715-0bbf-4a8f-b765-4b2d517052ef	6546637e-4a35-4c02-a418-8ddf714c6b96	صندلی 1	t
51ea5f58-4223-4554-9353-bc60c970a7d9	6546637e-4a35-4c02-a418-8ddf714c6b96	صندلی Premium Stylist	t
ff1d3e5a-5cab-46a5-a6f7-886e43dcf321	9ce67759-ee69-4264-a07f-891b3f9805e2	صندلی 1	t
b0102f4b-7206-4392-b9e2-f5b2701ea49b	9ce67759-ee69-4264-a07f-891b3f9805e2	صندلی Misc Stylist	t
4cb3daaf-0583-4545-ad60-05949b03cbe2	f57024e7-1bbb-4d66-b3e8-3e7007f205c9	صندلی 1	t
ed6ba726-6d7d-4f56-bfce-c8e14170130b	46b5e7c3-4228-4d05-9724-b4d688e772a3	صندلی 1	t
c5eb655d-5259-4300-997e-b290f0cac571	46b5e7c3-4228-4d05-9724-b4d688e772a3	صندلی Config Stylist	t
d9f4dd34-8494-4f85-bc4c-a4d73b248f6d	8acc033d-9bdc-4a9b-a0f2-a7c8f7a8e80d	صندلی 1	t
d86ee85e-1293-4053-bfe6-f576d249a402	e7b2abf5-4d80-4d5f-a96e-c42395401a4c	صندلی RBAC آرایشگر	t
26dbc2f4-1a2a-4319-b559-6d7c17bf166a	46b5e7c3-4228-4d05-9724-b4d688e772a3	E2E Chair	f
a4414bb1-07d5-424d-99f8-25fd84c57ffc	8f50a98a-5249-46bd-83ad-bcc5493292d1	صندلی 1	t
62a18340-f533-4a3a-9c4a-5a004b306a49	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	صندلی 1	t
c4741883-9f7c-4c47-b7ab-af3b03a10452	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	صندلی Booking Stylist	t
c73991dd-f2b5-46a3-9559-5536614fdc66	0acac768-245e-4600-b24d-10357b6a9206	صندلی 1	t
a0327d43-e82c-43bc-89dd-fdac6a3ce746	0acac768-245e-4600-b24d-10357b6a9206	صندلی Premium Stylist	t
efa5af82-2904-4b89-adad-8d79624a633d	daaee930-a32d-41c2-8e2d-d59946feb22b	صندلی 1	t
30d3a3e9-fb2f-4da6-8193-f5c8bb2a24c7	daaee930-a32d-41c2-8e2d-d59946feb22b	صندلی Misc Stylist	t
6b90b157-2e22-43fb-9932-ba1d1bd2a393	9fb475fe-8cac-4fd3-8f89-b522a84d2edf	صندلی 1	t
c753e632-33e9-4bb0-8cbc-cf39243fef1c	f5152ef5-f532-47f7-9ac9-ddc21a287cba	صندلی 1	t
d8e47ef5-0633-4c8e-8547-125a436fca96	e66c3ae5-4fe0-48ef-a5f8-e2226df0ed55	صندلی 1	t
15abcb13-3e78-4c16-94b4-2f0d5d88c5a3	0fbab0e1-6447-4455-bde7-412a6154819d	صندلی 1	t
33333333-3333-3333-3333-333333333334	11111111-1111-1111-1111-111111111111	صندلی ۲	t
ac010000-0000-4000-8000-000000000001	aa000001-0000-4000-8000-000000000001	صندلی ۱	t
ac020000-0000-4000-8000-000000000001	aa000002-0000-4000-8000-000000000002	صندلی ۱	t
ac030000-0000-4000-8000-000000000001	aa000003-0000-4000-8000-000000000003	صندلی ۱	t
ac040000-0000-4000-8000-000000000001	aa000004-0000-4000-8000-000000000004	صندلی ۱	t
ac050000-0000-4000-8000-000000000001	aa000005-0000-4000-8000-000000000005	صندلی ۱	t
ca3cdd6c-a936-47f6-8d4b-326405cbf5d6	1301ed82-4e76-447e-b9b2-203e4ab5e6b7	صندلی 1	t
f47cdf8a-1654-4527-9864-5c84a1d7bde0	11776d89-31cf-4504-9bb8-c4473fac42d1	صندلی 1	t
08096e11-14f5-4180-8a42-3e39ef4f7d4c	11776d89-31cf-4504-9bb8-c4473fac42d1	صندلی Config Stylist	t
c27395cd-525d-4ce5-937e-8f65da2f19cc	11776d89-31cf-4504-9bb8-c4473fac42d1	E2E Chair	f
1e641a63-f525-420c-ab45-9f5d9503913a	4dedcfd1-9cee-4826-9fb1-0cfbfa5886ef	صندلی 1	t
75ef94c4-f803-4b53-8d55-6e5a0edda6c6	ecfd9427-201f-45b4-b995-0c5903186dcf	صندلی 1	t
28472931-9bb9-4b4e-88d1-f7fd8531916b	ecfd9427-201f-45b4-b995-0c5903186dcf	صندلی Booking Stylist	t
eabac63f-822a-4195-9c94-90ce656a571a	bf46a9e5-b9ad-4b7a-857c-c42a838c5105	صندلی 1	t
f536c85e-6c6a-4f64-bda8-f4e0394fa364	bf46a9e5-b9ad-4b7a-857c-c42a838c5105	صندلی Premium Stylist	t
6b17463d-cd48-4c3c-bd39-f468a9bc6ff0	a8f9e2e8-b848-487b-a2c4-8b7a01f955a3	صندلی 1	t
0a8afcc8-f839-40fd-ad10-8425236d22e4	a8f9e2e8-b848-487b-a2c4-8b7a01f955a3	صندلی Misc Stylist	t
67a081de-5fc5-4fd0-b950-5c075f491261	41fe0795-178c-4762-828d-2bf86d3b7d2b	صندلی 1	t
0c7268ab-3d59-46f0-8f0a-2dc1bf69b310	dc36c3db-891c-47ad-a4c1-ecf6f3c4671e	صندلی 1	t
0f54877d-4251-4314-ac05-9381c80f2b01	dc36c3db-891c-47ad-a4c1-ecf6f3c4671e	صندلی E2E آرایشگر 1786111324447	t
ce3420c7-4ca5-4ef5-9ae8-e5b1083b2204	3d0794ce-aed8-4b71-b1df-80de2ee1f392	صندلی 1	t
2bb4030e-6263-4a6d-a24b-90f9371f050e	3d0794ce-aed8-4b71-b1df-80de2ee1f392	صندلی RBAC آرایشگر	t
5d5c2e95-5a1a-477a-865c-c63b42a1cacb	e71737ea-c9ab-401c-bd67-8525aa0060fd	صندلی 1	t
d55ddfe7-875e-40e6-8378-4282ce2bb44d	6e338bf0-ec57-44fe-8b1f-7af52ad1d31e	صندلی 1	t
\.


--
-- Data for Name: chair_equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chair_equipment (chair_id, equipment_id) FROM stdin;
\.


--
-- Data for Name: chair_unavailable; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chair_unavailable (id, chair_id, period_start, period_end) FROM stdin;
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer (id, phone, full_name, preferred_staff_id, no_show_count) FROM stdin;
cccccccc-1111-1111-1111-111111111111	09120000001	سارا محمدی	\N	0
cccccccc-2222-2222-2222-222222222222	09120000002	مریم احمدی	\N	0
cccccccc-3333-3333-3333-333333333333	09120000003	زهرا رضایی	\N	0
cccccccc-4444-4444-4444-444444444444	09120000004	نازنین کریمی	\N	0
54c20cdb-8393-413b-beeb-cafe5fba94c9	09304116932	\N	\N	0
f69b6ea7-a34f-4df0-bb85-ff223ba93dfe	09167314729	\N	\N	0
08c10567-381c-4f47-b917-c50e40ab40f8	09259347135	\N	\N	0
fa03a9b5-b43a-43f8-87d9-7301726405a8	09990091022	\N	\N	0
b135806e-2af9-4226-a866-e7e49ff645db	09495382591	\N	\N	0
de1d7804-b964-416b-a846-0b14ac9afc49	09102123562	\N	\N	0
0ca121ad-f932-4a5c-856f-e6a1e3456dd0	09730044491	\N	\N	0
cf6dcb54-775b-4a27-bb37-64d7746e18a2	09753404242	\N	\N	0
eaad2ff6-8ad1-467a-81c4-b31e344dc7b4	09206746569	\N	\N	0
2c0bf21a-1f23-4eb0-bd8c-2ef35d9934f3	09304116945	\N	\N	0
41dccdd8-ec92-4bc5-9dff-a7643c265902	09025220923	\N	\N	0
db3530cf-4f35-477c-b268-6711c0e1566d	09724644131	\N	\N	0
b2b9a41c-687b-402f-a3d7-3fd3c1c7e75c	09745442207	\N	\N	0
5db256b6-3dd5-4b55-88ab-e66443da3345	09874629930	\N	\N	0
62cf440a-96d0-43cf-a504-f6699b5bb82b	09123456788	\N	\N	0
b4d4fb69-1758-460d-b776-661a6b4990fa	09817935004	\N	\N	0
fdf2559d-cf3d-451b-996a-f510f858c722	09672996037	\N	\N	0
e37b615e-7ed0-4035-b0ff-e0e29b9e458f	09951843990	\N	\N	0
234397d6-207f-4982-8520-2fc22ac46328	09557505779	\N	\N	0
b07049e7-be72-450c-a88e-96c9d82d47e0	09490713428	\N	\N	0
3cef216b-eda8-4b35-995e-57938b57624e	09202531771	\N	\N	0
72f0312e-8e7b-498f-b4a6-48a14594bdb1	09958986201	\N	\N	0
2842b885-cf91-4a17-bd88-d3af8d42af22	09159528770	\N	\N	0
c746c63a-04bd-46b1-9926-f7da672f9b0b	09992690141	\N	\N	0
954623a8-ff48-4bbc-be3f-71207beaf202	09916842675	\N	\N	0
4c984bd6-0d09-4bc7-b3f1-db10edd78c31	09969632109	\N	\N	0
f1fe572a-acea-4fa8-98d4-617667d2b96d	09928243289	\N	\N	0
7d9c6766-bd01-4118-b064-01cdac58c9d7	09903481289	\N	\N	0
1c4027cc-a54e-4b4f-8d56-0d423478e30d	09774249847	\N	\N	0
0a0c0ac9-b54d-4153-a823-68b44cc68054	09820516047	\N	\N	0
5514cacd-49a5-4912-b720-3b1ea098fba3	09635425286	\N	\N	0
ae14a1aa-5149-4f96-8788-2087cd2b3795	09912568459	\N	\N	0
7e3ffe77-1042-4ebb-9d94-583c67e3179d	09560929805	\N	\N	0
0f204c47-c886-487e-a6e3-72472c7a2440	09453336656	\N	\N	0
1fde2af8-3795-4a8b-980a-22f1de252bad	09930903427	\N	\N	0
ea9070c9-92b1-4c59-be81-1b2e601b0990	09146710300	\N	\N	0
716dea79-12b1-4747-bbad-0eb4b4350fe3	09983473399	\N	\N	0
33067a81-2932-4602-b219-cc720ae31261	09304116941	\N	\N	0
736a9c3e-f528-42fc-9364-998f31231fbf	09404116941	\N	\N	0
dfcef11b-15fc-4810-80ef-162e7dffcace	09123456789	\N	\N	0
906976b8-5c20-420f-aafe-83f7056f1440	09129999888	\N	\N	0
c9d5c538-0eb0-4397-a3c8-0891c4a32239	09129999885	\N	\N	0
2d5b142f-ae25-4b6d-ac2c-2480e66dea87	09129999884	\N	\N	0
2d070156-d39d-43f6-a684-d7c9282645cc	09129999883	\N	\N	0
110409e5-5979-432b-8857-ee8445e0cb9e	09304116976	\N	\N	0
c988cfe6-6a71-4651-bdaa-30e41f55b836	09766324268	\N	\N	0
ec48e9e4-5aac-4bfa-a764-c94e822d1db6	09835475818	\N	\N	0
5384646e-4896-400a-9267-14c2930d0bb9	09620385822	\N	\N	0
f53b7e35-74ff-4af5-98bd-5365cdcbce59	09901871402	\N	\N	0
14c1c74e-b123-41f9-bfae-7cc9d7bcb24d	09529334918	\N	\N	0
7a6fabf8-2cf4-49fa-8688-cdcd0299bc68	09447257187	\N	\N	0
dcd7da1f-25c7-42c3-88c8-cd2264a736de	09304516941	\N	\N	0
d81dbc31-1ca8-4d1a-83da-4e6140c5586e	09120000101	\N	\N	0
a293d90b-dfa5-43be-91b2-a499fcb6a28d	09120000201	\N	\N	0
2905ad7f-33f6-4ae1-9dd5-8274343d7efd	09120000301	\N	\N	0
1f2efa00-d115-4e35-a621-e3a32a661f14	09120000401	\N	\N	0
e8b72429-42d2-4884-a47d-4265deb5e2d1	09120000501	\N	\N	0
2e966917-70c1-4662-abe5-743a24516a11	09989803059	\N	\N	0
8bfa4332-8d77-4fd4-b17f-b8494597dbbf	09124532158	\N	\N	0
0ceb1d3e-0e41-4c71-b4d4-e984e77985ea	09965970073	\N	\N	0
ff6fbf85-3ec5-4591-acb7-0fcfe7eaba2f	09595045946	\N	\N	0
9bbe519e-5d8e-4256-900d-cbc150031550	09416380655	\N	\N	0
1fbc6c58-0b22-4a26-a43c-0cedfac231ae	09200609227	\N	\N	0
ac0f0567-0f0f-42ba-afcc-c48b2a92eb27	09916320562	\N	\N	0
a06405b7-6531-4af4-8dcf-a25c597cb56c	09976988252	\N	\N	0
7646989a-d2c5-4d7f-a3e6-c28aae48ef84	09411512735	\N	\N	0
c9a59542-4e01-40c8-b627-fc98d94f85c0	09522587166	\N	\N	0
c9a00520-1de2-4d7d-94b1-ed5d6f14ac7a	09991784512	\N	\N	0
5e66fd46-7c76-4e34-bb63-72f6cdc399f7	09521417438	\N	\N	0
6e73ed3e-3694-48a6-94c9-4c3005e19654	09477815879	\N	\N	0
4d9dcd44-7975-4eb4-854f-72c7030d81ba	09543138538	\N	\N	0
5e224343-1375-453a-b391-62938b63e344	09380389559	\N	\N	0
e61af926-c9f0-4771-aab4-b9149667f268	09951628911	\N	\N	0
5a721d9a-efc9-4066-8fb0-73c0caa60755	09563455492	\N	\N	0
2b922d7d-2347-49d3-8432-aaeb4241e02a	09628061271	\N	\N	0
340a415b-825c-4660-8e9b-17f70191f307	09927911962	\N	\N	0
b50c28ea-1415-4194-9d56-926627fd8a0e	09972692698	\N	\N	0
c42705f2-26ff-4695-94e8-8f56768648f1	09915282008	\N	\N	0
6555e5c5-4835-40a8-9932-0a48ff5896df	09420760746	\N	\N	0
fffe8eed-599a-452a-b7c5-3758d061eb24	09538230777	\N	\N	0
f8d363e7-e1dd-4f5f-92bd-188d63ec224f	09708697074	\N	\N	0
28f85da6-3a19-4caf-b835-3863a9381e13	09924960430	\N	\N	0
37381501-275a-47b7-a345-2822a19f5378	09916173592	\N	\N	0
30cab5b6-52fd-4bfc-99b1-e3c2ef7435fe	09509370830	\N	\N	0
ed2acee8-2009-4b5f-836f-da894d36b184	09482892726	\N	\N	0
0bafe85e-1072-43da-afe7-19b6d7c05d70	09246970001	\N	\N	0
e87629af-03d1-4cff-bf75-3bd05a24f2b4	09134984232	\N	\N	1
732f9b1d-66fa-43b6-bd5e-1d764cc761a5	09977581264	\N	\N	0
d3cea6a5-c823-4c20-89fc-7433f9450ed9	09495689725	\N	\N	0
438bdd2f-994f-4e51-84a2-0defadb999ab	09515481790	\N	\N	0
3b80aa60-8153-4c2e-83e2-65aa88e3f5d1	09366760526	\N	\N	0
7539767d-5d39-4eb8-bf29-ee749d882422	09901307226	\N	\N	0
82ee4324-cbb9-416b-b4df-08099d5547b1	09582052075	\N	\N	0
dc00ef17-8740-4574-b200-7c9c6db41b0e	09685822742	\N	\N	0
07d65267-eb97-496e-b6f4-d9f46062f5ab	09971633535	\N	\N	0
86012f1f-956a-4c79-a5a8-cd050769313a	09921236465	\N	\N	0
d20a98f2-f694-4b4c-bd4a-0952a9f0b71a	09977200147	\N	\N	0
1cda8af5-7560-4f26-b283-ad507a4ce2e4	09426181167	\N	\N	0
7b1c3fb9-9771-4c15-9ff5-a7eba5346908	09554499615	\N	\N	0
1f64b16d-6552-4956-94d9-1f3aaa80ecc7	09705356316	\N	\N	0
d963d47c-242c-415d-a6f3-b915f48ee782	09990507380	\N	\N	0
3f2fa71c-d53c-4743-b11e-57b139fa974e	09944839979	\N	\N	0
10cbda16-b742-46d2-bd29-f2e658af5cd5	09107258063	\N	\N	1
c768e1c9-52d7-4c70-a36e-cba4586fc2a5	09933597670	\N	\N	0
6af32c04-28e4-4cfc-87e2-6536b736782e	09463724631	\N	\N	0
7870264c-c9a6-46b2-9637-468361f2c584	09535185963	\N	\N	0
901fdef6-5de1-4942-a34d-1070cc48cf54	09309708854	\N	\N	0
b259b534-94f9-4bc6-97dc-84bc7e8e1424	09969703073	\N	\N	0
db3ff795-9017-45e6-b2c7-896f67543ab5	09513059823	\N	\N	0
7dad54b4-59d0-477b-a8d4-6ea1f5f6785a	09635745306	\N	\N	0
e61079a0-f756-4819-9f81-ac61f63bffae	09900683145	\N	\N	0
43d62ac7-2c8d-45ec-9351-70746963de09	09576890480	\N	\N	0
85a2301f-2e3f-402c-b4de-03759393db93	09580196110	\N	\N	0
2dab1de7-ec2f-48c3-9a76-91e18ac5c5a7	09513496381	\N	\N	0
0a58368d-661d-4f7b-b212-ef92af16f8fd	09588501461	\N	\N	0
2cae5761-1425-4fc5-884d-c2e6902d7e9a	09510159645	\N	\N	0
cb3183b5-d551-4e0c-abc4-5e2ffe14c07b	09526506963	\N	\N	0
78a91c9c-1a9e-4cf6-827f-8b46ad6da729	09587594167	\N	\N	0
f294aefd-1c3b-4aed-8054-0ee5ff7a9cdc	09543159076	\N	\N	0
413d8ee6-5f02-43f8-95d8-9940ba2960b8	09997986003	\N	\N	0
32ab464e-5955-45b6-a3d7-16b04ee54e99	09991096895	\N	\N	0
08283f13-15a3-43e6-9683-a3c87f3b280b	09491898737	\N	\N	0
c93b8ca6-6c9f-4d0d-92c4-3f20194bb58e	09541891178	\N	\N	0
13ccf555-7628-468e-a415-3208bd0cf1d7	09783544520	\N	\N	0
bac0e04d-d1e1-4b6e-b18e-cef409307699	09967384452	\N	\N	0
cd262d39-6790-404b-a93f-a4d3a9880691	09959513115	\N	\N	0
7a639908-fb80-4c97-b3bd-5250eff0649c	09515579643	\N	\N	0
918136c2-ca86-4ef8-8971-837663b2a64a	09442910165	\N	\N	0
d7bc5f7b-38ab-46d3-8912-8deddafc5d66	09241179588	\N	\N	0
0fec6858-9c2c-4063-b5f8-7acbc2ed9eef	09153752034	\N	\N	1
96ed5c5e-0ecd-4c83-b1cd-c46c22c194f2	09975211806	\N	\N	0
fcfb64ca-1043-44bd-b18f-a9be8f7f1ded	09402873165	\N	\N	0
41c8693e-638c-4742-9da0-9b2fcddb1fea	09574143751	\N	\N	0
97bab1d2-221a-4d6c-979b-55a1a113f907	09399133266	\N	\N	0
9e0d270d-e3f7-4da8-8cf8-2ccf3f5e3efd	09960017196	\N	\N	0
225c44bd-a06d-446d-82a7-5801e9f0a27a	09594251630	\N	\N	0
6b30cc0f-3d40-47d4-becf-c071a358e3e8	09669527369	\N	\N	0
92e34b88-b187-4c7b-b480-a980245664b6	09939155852	\N	\N	0
173a78d3-c36e-4a27-b9af-ab0b3d50a27c	09721076147	\N	\N	0
6fd1b592-bd97-4be9-9fc1-2feb856c4fc0	09885660883	\N	\N	0
c142c1b5-72b9-4028-b2f6-990a7683474e	09627117598	\N	\N	0
c05ac80c-c077-4534-a42f-341ab237330c	09907035470	\N	\N	0
7e1e9578-1a3d-4bbe-ae7d-b0ae422bc71e	09592290534	\N	\N	0
eb1cd582-3dae-4d1a-a096-8c7eef3771bb	09420021328	\N	\N	0
e91aedba-4379-448f-93dd-4990117b0cfc	09969598914	\N	\N	0
0ce00da0-18d6-4fb8-ae42-a208b99b85ef	09168331561	\N	\N	0
87ef2eca-8751-4aa2-9493-7f09b5b116ff	09919458344	\N	\N	0
9df62d28-137d-42c2-a90f-db5eaf7c9686	09509568890	\N	\N	0
4ff91b68-8873-442c-854b-b25fcca7b41f	09507246440	\N	\N	0
d4a076d0-c3ad-459f-9f4e-623b240d1fec	09127969845	\N	\N	0
f3e3c072-df85-4a8d-8fd5-02249984e177	09137969845	\N	\N	0
89d75d9b-6e43-4656-bc52-828afe172073	09147969845	\N	\N	0
d957112b-bb92-4d78-904e-840ba8abf6fe	09157969845	مشتری تست	34d42336-3900-4918-a2d6-9068b8cfe6b0	0
ad63e923-9aa9-48a0-b0f7-967619c1678c	09167969845	الهام تست	6154b0bb-a33d-4aa1-bb85-e74badea0943	0
f7690417-beec-4ace-82fa-3d11b987410d	09187969845	نیلوفر تست	34d42336-3900-4918-a2d6-9068b8cfe6b0	1
050b2242-2640-404f-92cc-58c000cccec4	09712858829	\N	\N	0
a86483fa-ba61-4990-a78c-97dcd1a78825	09875557101	\N	\N	0
bb92b58c-9cde-4226-8a4b-d300389d4248	09636231531	\N	\N	0
46bfd80f-26ee-428f-8b7f-33a5d1d577ad	09923181418	\N	\N	0
c9418114-648c-4ea0-bf3b-07912b38b42a	09506049621	\N	\N	0
9488175a-2f8c-4c9b-9d7b-1f1b567849b8	09464026107	\N	\N	0
bd9fd917-0364-4f45-aea8-5f8360f0d5f1	09932765010	\N	\N	0
bc3355ef-2f4e-4a06-a899-941b7eeffb65	09184336365	\N	\N	0
fd9c2536-b8bb-44d4-abfe-7cff34904eac	09911329502	\N	\N	0
4ebac63d-22ad-4b7f-8207-716835d87a74	09711199414	\N	\N	0
553e98a2-6262-4b8e-a2d2-3185463d502a	09887853376	\N	\N	0
7facaaf0-dfc6-4be5-8fd6-c2027210c432	09622834500	\N	\N	0
8e69aff9-9523-4d90-8f52-68cd3a69090c	09949436825	\N	\N	0
0a1f536d-ab2f-4abf-a720-6de9bf0f4aa3	09494155201	\N	\N	0
8474575e-8eed-492c-9bc9-0bc864535461	09553550915	\N	\N	0
621fc6e0-f3a0-409e-85fc-423590324e68	09794641109	\N	\N	0
2c6dbcb1-0312-48b7-9e90-250f8bf84936	09778220867	\N	\N	0
1b4039ef-8b8c-4205-bc69-9156cfa3454e	09803664272	\N	\N	0
bbeabd1d-d1dc-481f-b90c-c8b23394b8ca	09605325630	\N	\N	0
ce549f33-9522-42b1-b7d6-a3d419c70b99	09984218203	\N	\N	0
abfab575-19be-41ca-a2b9-01aa977015ca	09582726221	\N	\N	0
a0e39f74-3284-4ea0-bcf0-b15611a42c23	09428663627	\N	\N	0
9d0da9bf-4d8f-4ade-a0f5-fe44dcc3d791	09986475629	\N	\N	0
83cb687b-b6a9-4485-86e3-d99ea12a2459	09114060548	\N	\N	0
587b8a2e-4b34-46f3-adca-a1c0a6d11c2f	09963216717	\N	\N	0
63b57288-5314-46af-ad68-f760099c20ee	09908245870	\N	\N	0
977e627f-f7b9-46c6-a8c4-755e9cc552a8	09913921837	\N	\N	0
b0af8d4c-d57f-4289-aa7c-d6669418852d	09910729135	\N	\N	0
2053172e-9096-45a9-b387-7acd13510f21	09586140863	\N	\N	0
f10ac3f8-d3dc-4afb-af3e-a98aef7791ab	09406747983	\N	\N	0
dd16d945-1311-4963-9806-b98c0573202b	09901109792	\N	\N	0
b5342372-3ea1-4dba-8d36-b2ba8cd3fae1	09979966822	\N	\N	0
be242fc9-ac53-4312-82ec-354ca305fa49	09413915894	\N	\N	0
a8f68457-1eb1-44ad-8663-eaccb0532ef9	09517111469	\N	\N	0
cd686348-344d-4366-b03c-adba593a81fa	09793559161	\N	\N	0
2543c09c-005b-444e-b77c-f5c319443166	09901951017	\N	\N	0
86faace3-ed7f-4720-a5ba-ba2b9310fa41	09992984304	\N	\N	0
e7eae6ac-bb51-45f5-b5b0-d1ca2f688620	09556213208	\N	\N	0
4f44a5b2-619f-4486-a24f-1d3c8fd3576d	09434171490	\N	\N	0
c6c26081-9dc1-4f75-8d38-b91cebce621f	09112285447	\N	\N	0
8364f4c9-65fb-46c1-99c1-1e7c06220188	09240067066	\N	\N	0
cb2f05dc-3ff3-4908-8778-be59c3ed9dcc	09963498529	\N	\N	0
c128d585-5842-42ab-a463-6a8446e7f05b	09419149438	\N	\N	0
001b70b6-de3c-4c0a-8f0d-1fe4c3b787b6	09547914046	\N	\N	0
0e493068-a1c9-4419-9684-4a64d2cd09bd	09359436507	\N	\N	0
f522c49b-ab4a-4ef0-a874-93a9e36be72f	09979655003	\N	\N	0
8023c3e9-5c4c-499e-ae68-d6612b52a1c3	09558245740	\N	\N	0
7938d187-a625-4d0c-aca0-31a2cac71b3e	09681245917	\N	\N	0
4d05beec-de3a-427a-9534-d67e95c220eb	09989901094	\N	\N	0
ad4d5243-ff6a-406d-a87f-fd4c18b9636a	09941295294	\N	\N	0
672b28bd-f353-4a51-b929-b8b6c2849152	09589945468	\N	\N	0
9cc2ba4b-e689-437d-994f-7cade167da7a	09494839551	\N	\N	0
a8c312ea-75e5-4d1c-8780-d43cc491b5cd	09930081918	\N	\N	0
9b0a06c0-b2fc-4736-afae-1c183cf6c2fb	09104798073	\N	\N	0
576e71fb-cbd8-4d2e-866e-79fd1fb3f6a8	09234923294	\N	\N	0
134bb7d1-83eb-4467-a66e-b89898804f9e	09939714736	\N	\N	0
d28ac98f-0703-4576-97a2-2e341606341a	09434217528	\N	\N	0
25ec6516-73e1-4936-936a-1a4a7756fc35	09574223587	\N	\N	0
b21e50f7-3765-4988-8e40-18c084195af0	09328560675	\N	\N	0
69654f36-9d42-47ec-803a-61d269f43725	09966253741	\N	\N	0
3d395427-1a34-44f1-8cf9-f4797a61711c	09591358342	\N	\N	0
73294aa5-8091-491b-b658-e3a66eef9e65	09650671982	\N	\N	0
cff0c66b-710f-49a7-af94-b0603e286199	09937274934	\N	\N	0
d4edae16-eca0-40d7-9c48-b5f738de7e4c	09942898011	\N	\N	0
7f80c6c1-572a-4576-9662-9d01a1e21d51	09922928279	\N	\N	0
932abecd-440e-40d4-b8c0-a2ce236f7c7d	09435867300	\N	\N	0
f9d49a1e-03c3-4b5a-8aa7-93b2036e1753	09554353058	\N	\N	0
e202e30e-ed81-4147-ade6-73dc4ecea772	09740635248	\N	\N	0
cccccccc-5555-5555-5555-555555555555	09121000005	نیلوفر حسینی	dddddddd-3333-3333-3333-333333333333	0
cccccccc-6666-6666-6666-666666666666	09121000006	الهام اکبری	22222222-2222-2222-2222-222222222222	1
cccccccc-7777-7777-7777-777777777777	09121000007	رها مرادی	dddddddd-3333-3333-3333-333333333333	0
f5a26f06-7bbc-45c0-b16e-019cba99dac0	09177969845	رها تست	34d42336-3900-4918-a2d6-9068b8cfe6b0	1
98af973b-fdf0-425a-837e-5e75dd7fe8e1	09956367084	\N	\N	0
b5ce87a2-8a70-4d80-9fac-04532c0ec9ae	09954704851	\N	\N	0
ca3e9068-c263-48e8-b9ae-1602ec6c986f	09418264056	\N	\N	0
48727bfe-39bb-47aa-9548-e201a1fc982c	09507358582	\N	\N	0
2bbdadba-24b3-42d6-9c2c-a73285ac5c5f	09798879925	\N	\N	0
4aaecd5e-c016-4692-9d35-d83787da5bef	09234031860	\N	\N	0
d3b1efb2-ea44-4b70-8fc2-cd870f5638bc	09157559992	\N	\N	1
51384482-ab02-4100-99cc-baa7c410ff9b	09943864519	\N	\N	0
51a6be30-68b2-46d4-b3b4-0c49984c8ebf	09424404169	\N	\N	0
9cec6817-012c-4e80-9c88-ed742634bd97	09544687707	\N	\N	0
bfef26f6-39f9-40aa-ad31-0d2bbc074c63	09391985475	\N	\N	0
e3d9af32-2920-4c94-9432-3377503b6f8d	09944637431	\N	\N	0
44dbfb31-4758-4e9e-a93e-a00829f9560a	09537743215	\N	\N	0
00b48657-4d11-4e3a-88b7-435a71d0b9b5	09644616623	\N	\N	0
7e1963cc-1c68-45e5-a3ad-bea8bd103e8b	09917280447	\N	\N	0
06d459e9-d326-491e-9b30-48e87050660f	09952072090	\N	\N	0
bd94fdc7-148b-4071-8d22-2e24ac10c55b	09904541869	\N	\N	0
e3e8192d-66cd-4d02-a792-78e06d51df51	09463231917	\N	\N	0
4d6cbeb1-2b15-4ecb-af4f-f3f198ecd67a	09557906403	\N	\N	0
1f3b14dc-7724-40fb-a898-9fda52b64e4b	09767000332	\N	\N	0
0cf6616b-f540-4e18-976c-2e2fcf150dbe	09960744548	\N	\N	0
88550d54-1480-4a0e-b09a-68447414512b	09966900876	\N	\N	0
1f0e39df-9b2f-462a-9633-76272fac72d8	09593178546	\N	\N	0
c941869b-d0b4-4b6c-82e5-a743c7b8a5d8	09470850073	\N	\N	0
60d5e20c-c037-4312-8834-763838bac6cd	09258163231	\N	\N	0
18d49e49-ed72-4c0b-950b-8fc54973a05b	09145974930	\N	\N	1
4721627b-87a2-4029-8224-779eb117e48c	09931868744	\N	\N	0
5e25ce96-c1b0-4531-af6d-7a7902679d73	09410146828	\N	\N	0
54a93790-af04-410e-9c05-595f10d58f8b	09515223287	\N	\N	0
f29ab847-7021-4916-968f-bf1840bfabb9	09300720408	\N	\N	0
9b1a5ef5-9232-4e20-9082-042c1cd262cc	09935518279	\N	\N	0
fc48c44f-725d-4838-8052-2505c2055031	09545904586	\N	\N	0
fd2f3697-2ab6-493e-b75a-acee4acd68ba	09634261632	\N	\N	0
554d0f23-de7c-4ab1-9a6b-39c8cf88bc52	09922017271	\N	\N	0
3e8d47b1-f6a6-47c0-84ac-fefa6d003031	09759273626	\N	\N	0
6ade64f7-c28b-4eeb-bcfa-fc132a586757	09804098653	\N	\N	0
25e28abe-d9d7-401b-8ea2-77f0a7251962	09682195104	\N	\N	0
0ebc3ce3-f5fe-4eec-b7b6-8c2d17c5a3bb	09914306841	\N	\N	0
3dc442d9-022e-47fb-8bc0-91ac54344f9a	09581221509	\N	\N	0
49ae2475-a831-4018-a01f-84d085febf2e	09479062351	\N	\N	0
8263589e-fac2-4954-b8eb-03e3aee4259c	09931869789	\N	\N	0
7a35c058-2247-404a-a8b8-531910a0048a	09137717929	\N	\N	0
34483c43-a17f-4e6d-b8c6-a38219546789	09930411220	\N	\N	0
2a20f071-2b60-43cc-ad25-62761c43c13f	09977444382	\N	\N	0
efd88857-88c5-4ee3-850b-0b267b14296a	09990134579	\N	\N	0
2f1c5dcd-30d3-4960-a381-b1a312b21db2	09430195788	\N	\N	0
49f7ad92-b3b6-4c28-a5aa-db34bbcf47a8	09537695622	\N	\N	0
ba07ef1b-2178-401b-b857-85c638031577	09751259168	\N	\N	0
e8d9be37-7a85-4c31-a865-307346c3314f	09904974140	\N	\N	0
33411892-73e5-43d0-a227-906cbed2e1d9	09916809095	\N	\N	0
438e6a22-3e90-45be-8307-76bdde8452e3	09548691083	\N	\N	0
4c3e7947-1010-4d68-9533-9ff788bdb0ca	09413458686	\N	\N	0
6db8511b-a42e-4ed3-b81a-376342998437	09278343829	\N	\N	0
4aa98b51-df1c-4b52-8cb3-4595fdb3e1c3	09185407552	\N	\N	1
306d65e9-2ef2-4143-bfb6-67ddefffa491	09911569556	\N	\N	0
8e7e4b01-d2f3-4a30-ad1f-bac5b0a9fe53	09406999955	\N	\N	0
fd2fcd86-f806-41eb-a7b2-b456f4404f57	09522515935	\N	\N	0
2d260995-8cab-4f65-ab52-b67bceec87ba	09300172928	\N	\N	0
f2428f36-eb73-4a41-b76f-ae2c9356adde	09944269814	\N	\N	0
92a2feda-dff9-4ec2-8163-4fa93f071a62	09571847982	\N	\N	0
7a3f491f-7a20-424a-b6bb-60acdf81436c	09645874414	\N	\N	0
d577323d-74ec-4a7d-a556-7c9901809777	09960851531	\N	\N	0
f62bdbaf-cfc1-4601-8734-bda746169de8	09753463583	\N	\N	0
7e429861-f16b-42ab-807a-6836f5325954	09893550237	\N	\N	0
0802ab40-2bf0-4793-ab85-f167aca966f8	09685093258	\N	\N	0
c6e40c6d-c8be-4a78-bb30-4faaf5f98c34	09961895488	\N	\N	0
392d9ad0-bc50-458a-b9df-e715c224fa17	09567386178	\N	\N	0
3ee2e068-b58d-4eba-a2a8-19bf87004798	09414075144	\N	\N	0
ca059ee1-89be-4054-be2c-ed5de8259976	09929334805	\N	\N	0
83693237-8fca-43fa-9c74-40d124261d16	09106033232	\N	\N	0
332955c0-8bfa-45a6-937c-0b6859023429	09982231956	\N	\N	0
cccccccc-8888-8888-8888-888888888888	09121000008	ترانه موسوی	22222222-2222-2222-2222-222222222222	0
\.


--
-- Data for Name: customer_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_note (id, customer_id, author_id, body, created_at) FROM stdin;
f3000000-0000-4000-8000-000000000001	d957112b-bb92-4d78-904e-840ba8abf6fe	6154b0bb-a33d-4aa1-bb85-e74badea0943	ترجیح می‌دهد نوبت‌های صبح برایش رزرو شود.	2026-08-06 13:12:03.457249+00
f3000000-0000-4000-8000-000000000002	f5a26f06-7bbc-45c0-b16e-019cba99dac0	34d42336-3900-4918-a2d6-9068b8cfe6b0	به رنگ‌های گرم علاقه دارد؛ قبل از شروع مشاوره انجام شود.	2026-08-04 13:12:03.457249+00
f3000000-0000-4000-8000-000000000003	f7690417-beec-4ace-82fa-3d11b987410d	6154b0bb-a33d-4aa1-bb85-e74badea0943	یک نوبت عدم حضور در سابقه دارد.	2026-08-02 13:12:03.457249+00
\.


--
-- Data for Name: day_off; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.day_off (id, staff_member_id, on_date, start_time, end_time) FROM stdin;
00c90022-4dbf-43e0-a799-cacbddd65de1	34d42336-3900-4918-a2d6-9068b8cfe6b0	2026-08-10	16:00:00	18:00:00
\.


--
-- Data for Name: device_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_token (id, customer_id, token, platform, push_enabled) FROM stdin;
874a5037-1a00-4807-8058-d2222ab87809	e61af926-c9f0-4771-aab4-b9149667f268	e2e-device-1786105420418	web	t
060c4fa8-2054-4a37-803a-2d0da767d2ce	2b922d7d-2347-49d3-8432-aaeb4241e02a	e2e-customer-device-1786105420427	web	t
068e6365-98c3-419a-9163-66a2013d4c84	7539767d-5d39-4eb8-bf29-ee749d882422	e2e-device-1786105559860	web	t
20683894-2895-4e7e-b931-5d34773ef729	dc00ef17-8740-4574-b200-7c9c6db41b0e	e2e-customer-device-1786105559871	web	t
e8a628de-db89-4233-8398-cf8d322439ef	b259b534-94f9-4bc6-97dc-84bc7e8e1424	e2e-device-1786105575300	web	t
ba23f222-022f-499f-9fb5-81faf78f108a	7dad54b4-59d0-477b-a8d4-6ea1f5f6785a	e2e-customer-device-1786105575308	web	t
73169014-0b5f-49c4-bcb1-fa24940da43c	9e0d270d-e3f7-4da8-8cf8-2ccf3f5e3efd	e2e-device-1786106964406	web	t
d2033b5b-8c70-4dac-888e-bde65215c558	6b30cc0f-3d40-47d4-becf-c071a358e3e8	e2e-customer-device-1786106964413	web	t
5650a0e8-3607-4c4a-ba69-4a7b271dc68d	69654f36-9d42-47ec-803a-61d269f43725	e2e-device-1786111114557	web	t
14c18de1-452f-4757-9bcf-764782bf50a0	73294aa5-8091-491b-b658-e3a66eef9e65	e2e-customer-device-1786111114570	web	t
791335f9-cbad-44cf-a913-fdebd77a0b64	e3d9af32-2920-4c94-9432-3377503b6f8d	e2e-device-1786111208024	web	t
832c0130-ac57-4a6b-9eca-4e4c9a55104f	00b48657-4d11-4e3a-88b7-435a71d0b9b5	e2e-customer-device-1786111208033	web	t
8ccf1b62-d50c-4e0e-81c3-746ddeeeecb8	9b1a5ef5-9232-4e20-9082-042c1cd262cc	e2e-device-1786111256163	web	t
bafe5a63-08e9-4445-be56-85c92d799b5e	fd2f3697-2ab6-493e-b75a-acee4acd68ba	e2e-customer-device-1786111256174	web	t
48998c4e-0d6b-4128-8f36-1c721bcc9b29	f2428f36-eb73-4a41-b76f-ae2c9356adde	e2e-device-1786111316024	web	t
01851884-5be0-42a8-9ae7-5a931978c688	7a3f491f-7a20-424a-b6bb-60acdf81436c	e2e-customer-device-1786111316031	web	t
\.


--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.equipment (id, salon_id, name) FROM stdin;
\.


--
-- Data for Name: holiday; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.holiday (id, salon_id, on_date, start_time, end_time) FROM stdin;
88000000-0000-0000-0000-000000000001	11111111-1111-1111-1111-111111111111	2026-08-12	\N	\N
88000000-0000-0000-0000-000000000002	11111111-1111-1111-1111-111111111111	2026-08-15	13:00:00	15:30:00
456fec72-49cf-4620-9615-6c774b1aefe7	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	2026-08-04	\N	\N
7f087681-a4e1-464b-9f23-8d4281198423	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	2026-08-04	09:00:00	16:00:00
1db5a4cd-9cda-4ad0-b610-06be060cff3e	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	2026-08-06	09:00:00	10:00:00
54e26f86-3db7-41d7-9750-2d68960b4403	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	2026-08-05	\N	\N
ec87ef85-b012-451b-b27b-15535d00beee	d7412cac-b652-4a48-a889-e282a2ed5d55	2026-08-12	\N	\N
c73672eb-ee74-485d-a660-5cf116b5c3c8	d7412cac-b652-4a48-a889-e282a2ed5d55	2026-08-15	13:00:00	15:30:00
\.


--
-- Data for Name: notification_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_log (id, appointment_id, channel, status, error, created_at, type) FROM stdin;
7e3154f2-b555-42ed-a67b-ae78cc398fc1	\N	sms	sent	\N	2026-07-25 19:23:16.888+00	generic
65ce34d8-b011-457d-8533-2d74e3f565c1	c825a73d-730a-4f5f-bdfa-225041760363	sms	sent	\N	2026-08-04 21:50:38.854+00	generic
21a1fe62-eaee-4881-8c70-d41c0196656d	5be1d76c-12b8-4f61-9247-a904446b8d21	sms	sent	\N	2026-08-04 22:00:01.259+00	generic
86da340b-9f7d-407c-ab43-169f9b4b01b3	5be1d76c-12b8-4f61-9247-a904446b8d21	sms	sent	\N	2026-08-04 22:00:01.268+00	generic
c2990862-84d2-4e9f-a3f3-42e766d05956	82ccb5e9-9188-4f67-b40e-3ed4d73ac52b	sms	sent	\N	2026-08-04 22:04:15.011+00	generic
b7f31e01-d207-4e0e-8f44-428b35358c91	82ccb5e9-9188-4f67-b40e-3ed4d73ac52b	sms	sent	\N	2026-08-04 22:04:15.018+00	generic
124b39c8-979e-436d-9fce-f4e14151df6b	c825a73d-730a-4f5f-bdfa-225041760363	sms	sent	\N	2026-08-04 22:54:48.378+00	generic
975445b6-c3c8-4347-9e06-500b1b0196b6	1b06882a-d684-430c-9e8c-403bc8d2c1b2	sms	sent	\N	2026-08-07 03:23:00.121+00	generic
67055d84-ee09-442b-bac5-961e98de868e	1b06882a-d684-430c-9e8c-403bc8d2c1b2	sms	sent	\N	2026-08-07 03:23:00.141+00	generic
85c9bf6c-3994-43e3-badf-a494024e2b0a	b3a7f30a-38c3-410b-914a-d41aabd3b647	sms	sent	\N	2026-08-07 11:53:05.178+00	generic
9e8f917b-c51d-443f-8512-69321feb0d72	d926c27c-eba8-4e38-b687-e2e7c1c4aa8e	sms	sent	\N	2026-08-07 11:58:35.509+00	generic
5ad8e7d1-676f-4ebe-8580-e49d228c3713	350af89d-e638-4d52-9ca5-5fce0bdd29b6	sms	sent	\N	2026-08-07 12:06:40.748+00	generic
97802dc2-e9d2-4ecc-9fa1-e04dcf3c7548	193e6490-d212-4bad-b6ae-8f90b7d9c095	sms	sent	\N	2026-08-07 12:23:39.059+00	generic
713f1000-b74e-4d71-852f-cba2e4fb7efa	193e6490-d212-4bad-b6ae-8f90b7d9c095	sms	sent	\N	2026-08-07 12:23:39.113+00	generic
b775a709-9a0f-4408-aad1-45f2f455992b	23dde323-f717-4edc-aa53-1fbc39a7a5b8	sms	sent	\N	2026-08-07 12:23:39.149+00	generic
0d6ef0f3-5c04-4b5e-8142-3c082b111bec	23dde323-f717-4edc-aa53-1fbc39a7a5b8	sms	sent	\N	2026-08-07 12:23:39.171+00	generic
d88e125b-8529-4c30-b69c-97fdd11b9842	e47b0d44-dfa4-44d4-bc4c-271be836d766	sms	sent	\N	2026-08-07 12:23:39.207+00	generic
71507a9a-25ca-4366-925f-8c9c415ab45f	e47b0d44-dfa4-44d4-bc4c-271be836d766	sms	sent	\N	2026-08-07 12:23:39.238+00	generic
e8232475-22ac-4c89-ab14-a4522254ad87	507da850-a5a9-4e3a-a878-37f3cda0b140	sms	sent	\N	2026-08-07 12:23:39.273+00	generic
b503c8cd-ec84-4e75-8cf7-e8d85effbdc5	c9a828e7-2845-4cae-b08d-929cc20f4d4a	sms	sent	\N	2026-08-07 12:23:40.313+00	generic
dc7a9d72-a42c-4e27-9e66-0ecc7d78eab7	3078ab9b-2c0e-4979-94a3-5b546038313a	sms	sent	\N	2026-08-07 12:25:58.936+00	generic
bb1ad04b-f0c4-4a93-b8ed-fe6c5f98eba5	3078ab9b-2c0e-4979-94a3-5b546038313a	sms	sent	\N	2026-08-07 12:25:58.987+00	generic
2b6068a0-9f80-4a8c-901c-7ab0b5ed245c	a3b3a93a-653d-4bca-8ebe-fdb11749fcd7	sms	sent	\N	2026-08-07 12:25:59.025+00	generic
710e6f76-a8c5-4fda-922c-ded7028e164b	a3b3a93a-653d-4bca-8ebe-fdb11749fcd7	sms	sent	\N	2026-08-07 12:25:59.047+00	generic
06d62c81-217f-4087-9525-4ada8113065c	d3cb4659-7a5d-4161-93b7-79d2c90fac24	sms	sent	\N	2026-08-07 12:25:59.084+00	generic
6a7f6149-6f36-4fca-b8da-93226aa6f189	d3cb4659-7a5d-4161-93b7-79d2c90fac24	sms	sent	\N	2026-08-07 12:25:59.111+00	generic
baa538f6-8f9a-4438-a0b8-a90160907ce0	3203daea-4e5a-4954-b4c5-5ae2666cc92e	sms	sent	\N	2026-08-07 12:25:59.146+00	generic
3cc943b8-d7fe-4fbd-93c1-528c754e6484	3203daea-4e5a-4954-b4c5-5ae2666cc92e	sms	sent	\N	2026-08-07 12:25:59.169+00	generic
0df604c3-3895-425e-9b53-011ed3fae466	06da860e-be78-43f2-9cd1-5a6398988ad6	sms	sent	\N	2026-08-07 12:25:59.201+00	generic
fe7350f6-b2c3-426d-95d0-a9fd91407a87	06da860e-be78-43f2-9cd1-5a6398988ad6	sms	sent	\N	2026-08-07 12:25:59.227+00	generic
05002801-967b-41c6-8fd6-8fcd43a3b3ac	31c4f1c5-d255-4f1b-8c37-e8dd311f405e	sms	sent	\N	2026-08-07 12:25:59.283+00	generic
41b7bf3b-9093-4e92-8890-8fc9e8850daa	31c4f1c5-d255-4f1b-8c37-e8dd311f405e	sms	sent	\N	2026-08-07 12:25:59.29+00	generic
fcbb6456-5087-46a4-a163-aa5d6c1d08ad	d1c64753-d9b0-4a40-8b22-a922e5f092e2	sms	sent	\N	2026-08-07 12:25:59.764+00	generic
c90087b7-4626-4218-8e32-1ab4f8c17e6b	37a392f7-2ce1-41b4-86cf-fd0a1e0514b2	sms	sent	\N	2026-08-07 12:26:14.135+00	generic
25c2e713-90b3-49da-b478-31352b23fb1a	37a392f7-2ce1-41b4-86cf-fd0a1e0514b2	sms	sent	\N	2026-08-07 12:26:14.197+00	generic
2e5a294e-2376-4bba-ab09-800d33b19177	92c8f217-9b27-49a7-a612-6ae46a5ec5cd	sms	sent	\N	2026-08-07 12:26:14.241+00	generic
f9692c30-75ac-4d37-a1b0-db4ae5bd4904	92c8f217-9b27-49a7-a612-6ae46a5ec5cd	sms	sent	\N	2026-08-07 12:26:14.272+00	generic
76ec73b7-b0af-4d14-b7bb-ab5e589f70bb	2f50aaaa-7651-407b-82d6-10998cee1153	sms	sent	\N	2026-08-07 12:26:14.317+00	generic
e5c7b904-b94b-49ed-9d38-beb0ca6c6bc7	2f50aaaa-7651-407b-82d6-10998cee1153	sms	sent	\N	2026-08-07 12:26:14.353+00	generic
0a87f048-b960-4787-a52d-35cf2a879bc4	f3b7e9c7-ef59-48d0-95e5-00a1895bd077	sms	sent	\N	2026-08-07 12:26:14.398+00	generic
217bed93-d95d-4332-b9e5-c26201ae128f	f3b7e9c7-ef59-48d0-95e5-00a1895bd077	sms	sent	\N	2026-08-07 12:26:14.428+00	generic
12d9837a-f5cd-49c1-a651-343e82c5bcac	7ff67103-6800-44b6-9b1b-d54bfa3e8e51	sms	sent	\N	2026-08-07 12:26:14.46+00	generic
ddd4102f-3deb-4f88-b371-f79580a25066	7ff67103-6800-44b6-9b1b-d54bfa3e8e51	sms	sent	\N	2026-08-07 12:26:14.494+00	generic
031ebb13-6502-47bf-bc8a-f3fa6332f291	04e01a40-2b9e-4198-a824-1f1f3c04ac75	sms	sent	\N	2026-08-07 12:26:14.569+00	generic
ef0721cb-a686-48b3-bb8b-98f2691a7c8a	04e01a40-2b9e-4198-a824-1f1f3c04ac75	sms	sent	\N	2026-08-07 12:26:14.578+00	generic
887c7dd9-a982-4d10-a689-e1104371bfa0	db459809-b753-4ca3-a7f3-75dd0e1495bb	sms	sent	\N	2026-08-07 12:26:15.161+00	generic
f01d56ba-a3f2-4e52-aa52-6155ae129548	b4193219-770a-410b-9bbf-c2133ce97e0e	sms	sent	\N	2026-08-07 12:49:23.464+00	generic
64b64190-aa48-4d5e-a9e2-76968c479678	b4193219-770a-410b-9bbf-c2133ce97e0e	sms	sent	\N	2026-08-07 12:49:23.512+00	generic
3e0347a6-7940-4b97-ba5f-95f9ad86b0be	bfe6b241-23ab-402d-8c81-1963b50e330e	sms	sent	\N	2026-08-07 12:49:23.546+00	generic
06031d5e-e417-4c62-a1df-61d1eae18f9d	bfe6b241-23ab-402d-8c81-1963b50e330e	sms	sent	\N	2026-08-07 12:49:23.567+00	generic
a14fac36-8d68-42c1-a60f-826a0b4013c6	98eeb69d-9e79-4e5a-bed7-5adc029dca88	sms	sent	\N	2026-08-07 12:49:23.662+00	generic
83e4c94a-b730-435f-8d6d-d9bbaa314f8a	98eeb69d-9e79-4e5a-bed7-5adc029dca88	sms	sent	\N	2026-08-07 12:49:23.687+00	generic
7035cdf7-1408-4bca-b3fb-ba0fd6b2c405	53dc7ab7-cfd4-449f-8683-5d61d6dccc2d	sms	sent	\N	2026-08-07 12:49:23.72+00	generic
960ced8f-2241-4997-a7c9-13366b6e7b05	53dc7ab7-cfd4-449f-8683-5d61d6dccc2d	sms	sent	\N	2026-08-07 12:49:23.741+00	generic
1419f467-4853-474e-8a87-1dbfa97540a9	bcec2c53-e328-49dd-a9ca-abf278a43ceb	sms	sent	\N	2026-08-07 12:49:23.771+00	generic
69db0547-fcb9-4b37-a786-276789ccea5a	bcec2c53-e328-49dd-a9ca-abf278a43ceb	sms	sent	\N	2026-08-07 12:49:23.795+00	generic
e8a66ccd-4d34-4d8f-8ecf-f36d775a8604	cf2fcd63-42ea-40c7-9a4b-7d20325e87f0	sms	sent	\N	2026-08-07 12:49:23.846+00	generic
fe1a6be4-b2f6-4136-a81a-d30990833897	cf2fcd63-42ea-40c7-9a4b-7d20325e87f0	sms	sent	\N	2026-08-07 12:49:23.853+00	generic
1c78b85d-d39e-4e67-aab9-8694190fc631	9e40a949-5a18-427d-a0a1-681ac3316726	sms	sent	\N	2026-08-07 12:49:24.319+00	generic
d66d6d5a-b00a-4d52-8d75-c83d55c69602	26d3cbe8-8eb8-4167-b95f-47b4cd6bbf53	sms	sent	\N	2026-08-07 12:49:41.821+00	generic
6d207308-d846-40cb-9c92-5d832a479b15	f1000000-0000-4000-8000-000000000005	sms	sent	\N	2026-08-07 13:27:38.688+00	generic
d407fe3e-5b89-4218-aa03-855b8e3bc475	f1000000-0000-4000-8000-000000000012	sms	sent	\N	2026-08-07 13:27:39.45+00	generic
8ec302ef-9606-497a-ad96-f682fa0a4bca	c207ed5f-d9c0-4021-b13c-94eae93d2978	sms	sent	\N	2026-08-07 13:52:31.959+00	booking_notice
7f70ecff-bc7d-444a-8564-c6de9384a411	0d38fc85-8f42-4038-bf84-6f6b9789e6ca	sms	sent	\N	2026-08-07 13:56:05.448+00	booking_notice
64a6772e-5801-4f20-b4f9-c61f40e421ff	b8f61752-ae0c-40fe-bdae-90a4798befb5	sms	sent	\N	2026-08-07 13:56:56.521+00	booking_notice
6f87d47b-6cb3-4291-ac8e-57d072f6d1e8	b8f61752-ae0c-40fe-bdae-90a4798befb5	sms	sent	\N	2026-08-07 13:56:56.575+00	confirmation
e3e99584-ce5f-4948-974e-9e98db9cb74b	15504f9d-cb34-4f31-ad4a-67fb039bbab0	sms	sent	\N	2026-08-07 13:56:56.619+00	booking_notice
53e173ff-585e-4ece-9689-ea3b3f381998	15504f9d-cb34-4f31-ad4a-67fb039bbab0	sms	sent	\N	2026-08-07 13:56:56.645+00	confirmation
59fba5dc-0206-4d05-b8e8-f3e419aa0e0d	f8912221-fd03-40ea-bc3b-ebc76f6cebd4	sms	sent	\N	2026-08-07 13:56:57.789+00	booking_notice
a506878b-0e6b-4530-92cd-7355f67727a2	2fbaf9d6-14d4-4284-a4c2-a51398cc5333	sms	sent	\N	2026-08-07 13:58:33.158+00	booking_notice
888ed822-c1b8-475a-ad4a-fcac9db75e80	2fbaf9d6-14d4-4284-a4c2-a51398cc5333	sms	sent	\N	2026-08-07 13:58:33.207+00	confirmation
ed5db282-96e7-4e5e-bf02-153047f9d37f	84b442fd-1463-496c-97c4-329a6ba9f1a6	sms	sent	\N	2026-08-07 13:58:33.245+00	booking_notice
32679406-6f44-4b81-a740-d952bc8ed3ec	84b442fd-1463-496c-97c4-329a6ba9f1a6	sms	sent	\N	2026-08-07 13:58:33.269+00	confirmation
a704e5eb-1bdf-4a0b-9e96-9b649c3f8106	1b77fefe-cdcb-43a4-8e40-b0a679c7c968	sms	sent	\N	2026-08-07 13:58:33.363+00	booking_notice
ec00d3f5-f511-4b1d-9d86-9bffcf54ecf9	1b77fefe-cdcb-43a4-8e40-b0a679c7c968	sms	sent	\N	2026-08-07 13:58:33.399+00	rejection
dd908d1a-ff08-49e3-851c-848c2cf80991	f1a47354-d172-4483-b16d-371a98320baf	sms	sent	\N	2026-08-07 13:58:34.437+00	booking_notice
1ec1a457-e836-4834-b483-10f1c3025295	51845931-9a13-438c-8695-f99ed8609182	sms	sent	\N	2026-08-07 14:00:06.962+00	booking_notice
adc87005-1c34-403a-aa0d-3021efeeefd2	51845931-9a13-438c-8695-f99ed8609182	sms	sent	\N	2026-08-07 14:00:07.015+00	confirmation
234d38ed-7d40-40cf-8303-beee44a4c51c	ade37cfb-9561-4190-903f-89eae28d7bce	sms	sent	\N	2026-08-07 14:00:07.055+00	booking_notice
a3496182-0c84-40a2-957b-fe91a977fa0a	ade37cfb-9561-4190-903f-89eae28d7bce	sms	sent	\N	2026-08-07 14:00:07.079+00	confirmation
cc8dbc04-849d-4bac-8e30-01168a1279bb	bc208f97-dbeb-4dc8-a051-6d3a93c4a808	sms	sent	\N	2026-08-07 14:00:07.175+00	booking_notice
fc9f10ae-a667-4379-895f-0c79753ed8bc	bc208f97-dbeb-4dc8-a051-6d3a93c4a808	sms	sent	\N	2026-08-07 14:00:07.206+00	rejection
45374f3f-8d1b-4697-baa1-aee4c908b26e	47400210-8c28-499e-8e99-cd33b95793f7	sms	sent	\N	2026-08-07 14:00:07.246+00	booking_notice
ce255b7a-5099-4fe0-b17a-8f09177e1b98	47400210-8c28-499e-8e99-cd33b95793f7	sms	sent	\N	2026-08-07 14:00:07.273+00	cancellation
ee87f51f-30cd-4cfa-bda6-60d6d4491baa	6f629f23-16f0-4692-b6e9-2bdc32aec4c4	sms	sent	\N	2026-08-07 14:00:07.307+00	booking_notice
ec9f3f8c-b41a-4108-81db-76426445987c	6f629f23-16f0-4692-b6e9-2bdc32aec4c4	sms	sent	\N	2026-08-07 14:00:07.335+00	confirmation
4f993a15-00a0-4621-a007-6cb73c94cba7	cccfe2ae-75cb-4edb-8092-5bd558e57b2a	sms	sent	\N	2026-08-07 14:00:07.394+00	confirmation
b5a897e7-3d9a-4518-b59a-da69461a77a6	cccfe2ae-75cb-4edb-8092-5bd558e57b2a	sms	sent	\N	2026-08-07 14:00:07.405+00	booking_notice
6db6ce37-85ce-4cda-82d9-586fd0efff01	50f7b605-c5fa-40ea-b521-14158b2c841c	sms	sent	\N	2026-08-07 14:00:07.925+00	booking_notice
6adc1ec8-6346-4d00-92ad-1de4c7ff5446	f49d29c7-f499-4442-b226-908911d31ccb	sms	sent	\N	2026-08-07 14:00:54.931+00	booking_notice
0e19dca7-b75a-47a2-b9d0-94da9f69388d	f49d29c7-f499-4442-b226-908911d31ccb	sms	sent	\N	2026-08-07 14:00:54.989+00	confirmation
3f1c9a15-19a6-4aa9-bed9-d965bfc74d21	b617683e-a55a-42ec-9383-03016bbe318d	sms	sent	\N	2026-08-07 14:00:55.036+00	booking_notice
aa3fe208-82a1-4001-93e0-e6f14e33ad32	b617683e-a55a-42ec-9383-03016bbe318d	sms	sent	\N	2026-08-07 14:00:55.062+00	confirmation
d5271fe3-97d3-4331-bf5d-65ebe10991a2	34340795-0561-4bcd-898b-2f20f5a4f03b	sms	sent	\N	2026-08-07 14:00:55.179+00	booking_notice
17ff48b1-b53c-48e1-b950-3ecbcf71413e	34340795-0561-4bcd-898b-2f20f5a4f03b	sms	sent	\N	2026-08-07 14:00:55.213+00	rejection
31917577-5177-490b-846c-aeead7ad373b	9549a141-1652-4612-ae4f-9dd776b3928e	sms	sent	\N	2026-08-07 14:00:55.261+00	booking_notice
55a0ec15-6496-4066-99d9-7415a1c859ac	9549a141-1652-4612-ae4f-9dd776b3928e	sms	sent	\N	2026-08-07 14:00:55.29+00	cancellation
f1c0b346-5469-489a-b912-8a37fd3f8e29	4b9b917a-1882-4707-a369-7f349a533394	sms	sent	\N	2026-08-07 14:00:55.329+00	booking_notice
9f62d530-ca62-4774-a355-a33e66e5d849	4b9b917a-1882-4707-a369-7f349a533394	sms	sent	\N	2026-08-07 14:00:55.362+00	confirmation
6e806776-851b-4e09-80a4-5760a6f4410c	4e2abbdd-4cac-4e18-8bce-900f7093bc74	sms	sent	\N	2026-08-07 14:00:55.432+00	confirmation
b7fb0fd2-3350-43df-a731-fba20f2a2cde	4e2abbdd-4cac-4e18-8bce-900f7093bc74	sms	sent	\N	2026-08-07 14:00:55.445+00	booking_notice
6bddd89e-a0bd-4692-b7b5-7f60221b8875	975d9904-a2bd-409d-b46e-5a51e8f7b60a	sms	sent	\N	2026-08-07 14:00:56.056+00	booking_notice
28aa0d3b-15fc-4da8-9c71-e13b60d45ad3	9eb3d656-d42a-4a2b-9dac-4072e44cc38b	sms	sent	\N	2026-08-07 14:01:17.536+00	booking_notice
9b7a7110-26bd-4502-954f-627bb35eaae3	abe4a8f7-974f-4fbf-b642-cc8a3ad29133	sms	sent	\N	2026-08-07 14:01:54.927+00	booking_notice
ac6e2991-5c1a-4d1e-bed1-620ea81e848f	abe4a8f7-974f-4fbf-b642-cc8a3ad29133	sms	sent	\N	2026-08-07 14:01:54.982+00	confirmation
6b3a65dc-54ff-48ac-87ba-96c82ebb7c9f	608f06e4-1363-4010-bb3c-030f1499ebe1	sms	sent	\N	2026-08-07 14:01:55.022+00	booking_notice
891a341a-58d7-4cfc-a7d1-d427b1bb9c2d	608f06e4-1363-4010-bb3c-030f1499ebe1	sms	sent	\N	2026-08-07 14:01:55.046+00	confirmation
d6b52d16-9177-4539-84cc-1b61809ff34a	d9ed7173-9d8d-4c7f-94e7-6cf8e78701dd	sms	sent	\N	2026-08-07 14:01:55.146+00	booking_notice
fd87869d-300e-43b4-b3a2-2fd1e5064608	d9ed7173-9d8d-4c7f-94e7-6cf8e78701dd	sms	sent	\N	2026-08-07 14:01:55.177+00	rejection
52e72740-1b0a-4542-b14f-9f24d50f9f38	32ebcaa0-14f5-4df2-92d0-8cdfd4eaeb3e	sms	sent	\N	2026-08-07 14:01:55.217+00	booking_notice
cc9902b0-ba39-478f-bd6f-15b392d66d0c	32ebcaa0-14f5-4df2-92d0-8cdfd4eaeb3e	sms	sent	\N	2026-08-07 14:01:55.245+00	cancellation
dc33196e-4ba3-43ad-83e7-a88b65190648	6490bafa-0a3e-4d27-a7dd-9ddffeed60b1	sms	sent	\N	2026-08-07 14:01:55.282+00	booking_notice
1d7ad444-25c0-446a-804e-4255f9f779a6	6490bafa-0a3e-4d27-a7dd-9ddffeed60b1	sms	sent	\N	2026-08-07 14:01:55.317+00	confirmation
48afc2c0-bc96-4ef0-93c4-3c52162c0a90	a3136b2a-f53c-4a2b-b16b-fd68563e9c23	sms	sent	\N	2026-08-07 14:01:55.382+00	confirmation
d9b1dd53-411f-466a-a5ff-c0456b8f4666	a3136b2a-f53c-4a2b-b16b-fd68563e9c23	sms	sent	\N	2026-08-07 14:01:55.393+00	booking_notice
350b0def-5a02-44f4-bde9-2335e89df857	59a0cf4e-729b-42e2-9a61-14f892633f74	sms	sent	\N	2026-08-07 14:01:55.943+00	booking_notice
f4e5b912-53e6-40ab-84f4-45459a49edd7	4d096d26-7e40-43d9-b4b7-86fa25adee63	sms	sent	\N	2026-08-07 14:02:14.262+00	booking_notice
\.


--
-- Data for Name: otp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp (id, phone, code_hash, issued_at, expires_at, consumed_at, invalidated) FROM stdin;
1e661196-95cb-45e7-8ec2-b92a0e69d923	09304116932	9fc7d2573162923a909a04340bdcd59b435b93ddaf6318117ec3a3013e20d142	2026-07-25 18:59:02.766+00	2026-07-25 19:09:02.766+00	2026-07-25 18:59:22.296+00	f
65d32893-d3f5-4123-a202-4b36519841b8	09120000001	b1bb9c7762a46424919babd0cd66d855c8321033ac4ba31c47c24637d43c0a2b	2026-07-25 19:05:27.229+00	2026-07-25 19:15:27.229+00	2026-07-25 19:06:00.837+00	f
81aeb3ba-8701-4311-8826-dbd2667c4a28	09120000002	15901cd4d0a508bc783fcf2e4668f2447a5f8889fa09e9d12c38149f88684563	2026-07-25 19:05:27.24+00	2026-07-25 19:15:27.24+00	2026-07-25 19:06:00.857+00	f
33478547-ce6b-4d33-a123-aaf552507750	09120000003	3d5bcefd933457ea7aaa164995e9d533cd5b5a56cda10d8e33fbce2773236fee	2026-07-25 19:05:27.25+00	2026-07-25 19:15:27.25+00	2026-07-25 19:06:00.871+00	f
d01f4dfa-ca4c-4037-bf20-fc9db00c3afb	09120000004	9d8526680fd6ab780e5505232b8f9632743321c6f920d81bcb0a3010275b4a73	2026-07-25 19:05:27.261+00	2026-07-25 19:15:27.261+00	2026-07-25 19:06:00.885+00	f
f72f66df-4224-4630-b2e5-e1e5e21ef7a0	09120000002	ff6f3a786ff558451dfc3adbb80f0b4ebb6120275c6240def9265ca78f0396f1	2026-07-25 19:11:25.683+00	2026-07-25 19:21:25.683+00	2026-07-25 19:11:33.331+00	f
f55671b6-9043-4902-86de-92928bce3626	09120000004	6225a0b5101ba2f05b576ad2d3d9b0f0801568c729f9189f1bb319494d6a863a	2026-07-25 19:22:28.356+00	2026-07-25 19:32:28.356+00	2026-07-25 19:22:40.837+00	f
70c60c8a-b9d2-44a4-b032-497ee2b0d55a	09120000003	18dc6329053c6a73e39b4d16f63ebaaba4ddbfb3389b842692954fc2e2973d5c	2026-07-25 19:22:56.306+00	2026-07-25 19:32:56.306+00	2026-07-25 19:23:08.08+00	f
870c2acd-21b0-40fa-8e76-215607b18842	09120000002	d03b4a5650675044cb9d1eba8485f447d9aa4a4ed9847ecb74e09e81ccc3a853	2026-07-25 19:28:49.858+00	2026-07-25 19:38:49.858+00	2026-07-25 19:28:56.682+00	f
0e1f52d3-6b26-41d1-9c28-2cc654e6592d	09120000001	0ce85b5459c049914dba1cee699c46f04e2809de0c0726719167dfba4a05aa47	2026-07-26 18:31:58.997+00	2026-07-26 18:41:58.997+00	2026-07-26 18:32:13.242+00	f
8ecece6e-dad5-4e81-b9bd-4fca5d041f91	09120000001	a1364cc43f5a9ca603c11353d53798d7c0aa4801156fe0999b29f9318e129d01	2026-07-26 18:40:31.71+00	2026-07-26 18:50:31.71+00	\N	t
f9d606a9-ab38-4eb8-a92b-73f87f7fd84e	09120000001	50720b5ded9616c845efff42a7bb7da7bab4ca63d90e0da62da16ddde2908fad	2026-07-26 18:42:15.41+00	2026-07-26 18:52:15.41+00	2026-07-26 18:42:46.719+00	f
ad937c0d-0fa9-47b1-b962-db129ca102e8	09120000001	764f1b514f03432d7da9ccec7d5056d2c2c73a40d2a9949fff1977e699967c7c	2026-07-26 18:43:37.348+00	2026-07-26 18:53:37.348+00	2026-07-26 18:43:58.043+00	f
864e4315-ff7c-4b3b-88cb-ad5d839a897d	09120000001	ba0922d1a394cb4520a2b08f621d23e9f8fdfe25d496235948c6b6bcac8af352	2026-07-26 18:46:23.14+00	2026-07-26 18:56:23.14+00	2026-07-26 18:46:45.401+00	f
dd8d2be2-d2c4-4ad5-8cf9-a1d6628b8599	09120000001	411cb98e754ec618a0b5f760eabaab626cf90df49fd840d4461ea7fe6d8dee69	2026-07-26 19:12:17.402+00	2026-07-26 19:22:17.402+00	\N	t
b30e0dbf-6c99-445e-92d3-16e52426c64b	09120000001	bfff343d7b13a7acc2d85f54459f3371b35731996a37d86bedea59b153afd917	2026-07-26 19:12:31.5+00	2026-07-26 19:22:31.5+00	2026-07-26 19:12:32.533+00	f
e76e1838-8001-4cde-8217-3b00f7a6cf76	09120000001	fe3240682bf043761cd281ddeca612f28472ed90bf7eb950645dc10a9c0f86b0	2026-07-26 19:18:24.533+00	2026-07-26 19:28:24.533+00	\N	t
e5e63993-2ed6-4e23-b38e-cbc624c424e0	09120000001	7cad16ed257c3ad7694f36ed0915a8bb86c126e312e3e6a4f74be6ac5ad90515	2026-07-26 19:18:42.06+00	2026-07-26 19:28:42.06+00	2026-07-26 19:18:48.071+00	f
9992132a-1492-44d4-ac31-092a1b38d7ac	09120000001	0461a85d9ba75006094452f484ca86dddee8332b32f3514c85c5a8a3d0780cfb	2026-07-26 19:18:51.192+00	2026-07-26 19:28:51.192+00	2026-07-26 19:20:22.901+00	f
001c0fcd-d8c2-4187-93f5-e957b15e2ba9	09304116942	42b851e6b3ec331a1df21c7689bcece3959523fbe94d3e673f52369ecdae3650	2026-07-26 19:37:46.404+00	2026-07-26 19:47:46.404+00	\N	f
66380d68-36e7-4fed-bc81-ef100372b7fc	09304116941	498a8e5240652961a0c8bce6bbab33a705253ff3b4e81403e5cfe3b779263a5a	2026-07-30 22:10:51.188+00	2026-07-30 22:20:51.188+00	2026-07-30 22:11:06.831+00	f
a9e19a2c-221c-4034-a358-5c723af5d2c2	09404116941	ea75ce04e1492fba9a26b56d5f533719d67ec1077e116e885c26c91e7beeca5e	2026-07-30 22:11:57.955+00	2026-07-30 22:21:57.955+00	2026-07-30 22:12:03.875+00	f
9eb22c3e-2a57-49d3-8f67-7af493977c94	09304116945	bc16ffedc21ed1fb3c6c2f2e7d4dfb45dc2b8580bf0862c0a658d2f520598198	2026-08-04 13:35:25.443+00	2026-08-04 13:45:25.443+00	2026-08-04 13:35:42.998+00	f
9246db17-251c-496a-8225-d751563a14b7	09025220923	1a822e8353c1fbd287cf96407d8768782b48b1630f9ff4f710f2cbf96220a230	2026-08-04 13:48:42.075+00	2026-08-04 13:58:42.075+00	2026-08-04 13:49:05.732+00	f
2ff7ee6b-c4a8-4150-ae4b-6c4969bbb2fb	09304116945	164948a8fa669600f5503656c425d61733291296ee27925a1061c37d0637406c	2026-08-04 14:20:11.137+00	2026-08-04 14:30:11.137+00	2026-08-04 14:20:27.174+00	f
0938be09-2982-4798-a673-304c5af2828e	09304116941	04ae7d3ba3888cfa7882208e890557c95e76b060b29709625f6709921587956a	2026-08-04 21:49:55.824+00	2026-08-04 21:59:55.824+00	2026-08-04 21:50:38.46+00	f
30c03f70-7241-4915-b4fd-4b34b18956ef	09123456789	276c97013a00dc4582d836a83ef33f14c56dd71a3c94a0d0badbc03010fa6142	2026-08-04 21:13:07.453+00	2026-08-04 21:23:07.453+00	\N	t
a9a35313-f06e-4e24-8df7-a695e0f3504d	09123456789	b840ccd93dcba91d97c8772cccc1a02068d0b94adbd41cc1a6bde10dee277382	2026-08-07 02:40:01.862+00	2026-08-07 02:50:01.862+00	\N	t
4574047c-d452-4a8c-a0a3-98d80b82344a	09123456789	6bfd5a73999af519cdeb5e13bb2d0731a3ea204e5bc3ac76ad136f91f8fb60e0	2026-08-07 02:40:09.059+00	2026-08-07 02:50:09.059+00	2026-08-07 02:40:21.01+00	f
08fd408d-ce1d-41c2-9765-73718b37fd24	09120000001	d16db50dee7b2b963490c770ffbb3ee120356e135d8591ce1c812df06c70af87	2026-07-26 19:23:02.286+00	2026-07-26 19:33:02.286+00	\N	t
a611ba64-625f-48a1-9e9a-69ed553b7b7d	09120000001	a46b435e1fc81d484495c2b27b1e288009c2e03de8211c98cb25ac55448ef627	2026-08-07 02:40:35.498+00	2026-08-07 02:50:35.498+00	2026-08-07 02:40:35.631+00	f
7897afbc-b95f-4562-9d3c-4a9b631fadd4	09120000001	3ad5acac5310a19235fdf07377c91a010fa9c440d4b87e9d0408ea701b95c3aa	2026-08-07 02:42:35.174+00	2026-08-07 02:52:35.174+00	\N	t
04cf8b5f-512a-4125-ae17-d8fbaba5b570	09120000001	3bcbde8a70e195f234344f9db13f7dd1b750e1985114b3dd801ea19ae1d453f2	2026-08-07 02:42:42.458+00	2026-08-07 02:52:42.458+00	\N	t
13abf0c3-d2b5-4c71-bed4-ce7410ca0a9f	09120000001	93a31d88f8a73502ae6f538430d93eb7d3276835e0cc9ea5ff30a90503daf4f3	2026-08-07 02:42:54.184+00	2026-08-07 02:52:54.184+00	2026-08-07 02:43:08.609+00	f
51a5c875-a2de-4fe5-9bc7-cd0d64d461e4	09120000001	0b560f191f78cca21d3c4869256cbafd35d89a5e24b4d20f106f5ffabfa8ba8b	2026-08-07 02:45:24.004+00	2026-08-07 02:55:24.004+00	\N	t
1242c2f9-e190-44f8-a0ab-1ddf6f239f07	09120000001	7eee6b47917c6043f205a07bb4e0d10bd75cfaa5bc95b0c90f14c9642b66c8fc	2026-08-07 02:45:49.424+00	2026-08-07 02:55:49.424+00	2026-08-07 02:45:58.405+00	f
e17398db-d836-4ef2-8f66-3911e51ce775	09120000001	021a2a235b33eb1e05d6391039feec532f977ebb21ef0b53fdcc31fda8fea90a	2026-08-07 02:47:19.382+00	2026-08-07 02:57:19.382+00	2026-08-07 02:47:20.289+00	f
27b80861-17a2-4f8b-bedb-6df01ab49afb	09304116941	0ace06f478d464ff2f3074dc7d769be62418ae393ce23e75ad6a8b6a34c6cfd3	2026-08-07 03:02:33.62+00	2026-08-07 03:12:33.62+00	2026-08-07 03:02:35.35+00	f
c9e0a5a3-59f2-4f6b-898e-e9236b8785f8	09129999888	20c79ee3f382163247c2f4893013d9a7c765ff9cbedd122ab8b61e2ce973dbfe	2026-08-07 03:12:22.518+00	2026-08-07 03:22:22.518+00	2026-08-07 03:12:22.6+00	f
7a936315-d96f-4975-93ee-356433fb914c	09129999887	e3eb09621c1c5824dcca505634cc734ae22ea8e44f49c83401607aae81a79c69	2026-08-07 03:14:27.888+00	2026-08-07 03:24:27.888+00	\N	f
8eb2b99d-eb01-43cc-8927-7ddfb5cff9dc	09129999886	23faa39054a3efa6a782500ac2a620ac7e42a53c54e8a52622845d5c9555a17b	2026-08-07 03:14:47.996+00	2026-08-07 03:24:47.996+00	\N	f
fd3d0e54-41a3-4518-850a-6e2f96212e30	09129999885	bfce21e37d226411efdc0aa1ff10041d5d2092278441c957a3c94c26f7927eba	2026-08-07 03:15:07.093+00	2026-08-07 03:25:07.093+00	2026-08-07 03:15:07.109+00	f
9e46f0f3-fa87-45a0-a9ce-68b7ac0cefe2	09129999884	05fd86fe1ba4117b7ad9b9546697913b384000f352e95c639e03d4d20b06670e	2026-08-07 03:17:33.906+00	2026-08-07 03:27:33.906+00	2026-08-07 03:17:35.328+00	f
52aa7317-25e0-44f9-9163-80aca81276b9	09129999883	27447986d697273f1e7eda2935fb32b266b6ed89a44713607183f1b4add17a01	2026-08-07 03:18:01.346+00	2026-08-07 03:28:01.346+00	2026-08-07 03:18:01.363+00	f
e87cf656-c3ae-4a77-bd50-6d2250bb1e9c	09304116941	84d582ede9cc686952951306525a2170af802024bc53befa02faf3d974bd161a	2026-08-07 03:20:06.054+00	2026-08-07 03:30:06.054+00	2026-08-07 03:20:06.236+00	f
3f545779-b87e-4f0a-84ac-1c92d07c037f	09304116976	dad7604d2f933ebeaf2c1f34fe927dc5f54985ec442f9ad670fc9f8b78d9ba43	2026-08-07 03:25:00.273+00	2026-08-07 03:35:00.273+00	2026-08-07 03:25:01.827+00	f
de530be7-9220-43e3-a87a-5e44d13f302e	09304116941	bef7fc40aab03567d460ed71eed68dfe1dfdddb1a709c9c7b983e4600a46719d	2026-08-07 03:25:52.048+00	2026-08-07 03:35:52.048+00	2026-08-07 03:25:55.504+00	f
c1344f1c-4ac9-4bdc-b554-2340262e774e	09304116941	1db69c28c898511ff9b1cde238e5cf23cd8c7403f84a399bf2a8b51d8d699316	2026-08-07 03:26:21.257+00	2026-08-07 03:36:21.257+00	2026-08-07 03:26:21.284+00	f
723de64c-ef6b-43d6-8c4b-236bfb2db82a	09304116941	84a5010e772f56a183cc3f478b6805decc68b41fb4cd6bf715fae7279c6a22b6	2026-08-07 03:26:40.609+00	2026-08-07 03:36:40.609+00	2026-08-07 03:26:40.624+00	f
6fd72f45-0e45-4401-84e9-fab47ae7043e	09120000001	0226ab08f639a66507880cc7be15b73969643eb0047e1e16cc63ff9830cf280c	2026-08-07 03:28:31.672+00	2026-08-07 03:38:31.672+00	2026-08-07 03:28:31.69+00	f
59ee4cd4-1a9b-4775-9c02-14a2e7c6a021	09120000001	69b25fb7f27d805d6e18a3b7ab46f94cf25ce253c23a1b95ac3fa8ac52bc1f90	2026-08-07 03:29:00.251+00	2026-08-07 03:39:00.251+00	2026-08-07 03:29:00.294+00	f
2de19180-8880-488c-9eeb-250d1122b515	09120000001	09e09fcee2467ddf90094e2fdaaed3c48a2f1a993044d46eae56af4737c21bb8	2026-08-07 03:31:38.094+00	2026-08-07 03:41:38.094+00	2026-08-07 03:31:38.115+00	f
bf631560-9737-4d64-8d8a-a30eb97cadaf	09120000001	2ff8b5abf9b747fffb434a6614d847bc6fbf355196738e940d8ac8fe027b1e99	2026-08-07 03:32:26.145+00	2026-08-07 03:42:26.145+00	2026-08-07 03:32:26.165+00	f
988459bb-092c-4018-9cb3-e0ffaa585172	09120000001	11185c55dfe9c0a69c8f94d9a8725da4f15aeda5fd431a2138cfc06622aaf63d	2026-08-07 03:35:52.953+00	2026-08-07 03:45:52.953+00	2026-08-07 03:35:52.964+00	f
76b1877a-bcec-435d-8b64-c21938850cfa	09120000001	e0c531076a5254505a55cac1cf2e600bad196569fb4abd0ebb5ae95b2bd22ab8	2026-08-07 03:36:31.31+00	2026-08-07 03:46:31.31+00	2026-08-07 03:36:31.327+00	f
f1fc188a-4166-49d0-80b1-ee3873c8f524	09120000001	6137c9cab66f47c9a2dc63d40e7f763c1af054c43d6b331f8f99bc756908493c	2026-08-07 03:36:46.526+00	2026-08-07 03:46:46.526+00	\N	t
bcd7d7ff-599e-470d-98b8-1cf170b1f7a1	09120000001	b24dc959ecb729bbcd2d327e3b38516b83826bc911dbc13d5f6fee60aaf1a6df	2026-08-07 03:36:52.713+00	2026-08-07 03:46:52.713+00	2026-08-07 03:36:52.733+00	f
7fef47dc-16f4-4e59-bd1c-bf38ffeb6dbe	09304516941	e94be34d27d11ffe09fd78a1933755210c1634f4ac99052b7b7922e465836bca	2026-08-07 03:37:05.016+00	2026-08-07 03:47:05.016+00	2026-08-07 03:37:05.706+00	f
1709fdf0-d8b2-433f-8f8e-169fb4accc04	09120000001	94043be3fc92e7df79c394666cdd3b585e3e6be0da1b1a729d97965adca32bed	2026-08-07 03:37:18.151+00	2026-08-07 03:47:18.151+00	2026-08-07 03:37:18.162+00	f
4aa0ec7c-eb8e-4437-aaef-72d47b140387	09120000001	a7266d2a3eb4de768b8b71b39e7ee19034c9a615c1716f3bafb9a6d87bc197c9	2026-08-07 03:37:54.784+00	2026-08-07 03:47:54.784+00	2026-08-07 03:37:54.803+00	f
080062fe-242c-4597-915a-2c6ab873da08	09120000001	ddb1d62b68f7700df0fceaab2ffe050efd5bed25b1ba7252717bca74275c8ecb	2026-08-07 03:40:45.511+00	2026-08-07 03:50:45.511+00	2026-08-07 03:40:45.523+00	f
e01eee2f-c61e-434e-8556-5f7b42e71ac0	09120000001	eb2da5b3418a94833556215d1549010e5bcec17912cfcd6094b880e329f12210	2026-08-07 03:41:12.725+00	2026-08-07 03:51:12.725+00	2026-08-07 03:41:12.738+00	f
da43b7a3-812b-49b4-a82c-fb7687d388eb	09120000001	e7138bdda98a13653f4c7d8c0b5b70f00610e55910bb370a6a1e874c207db766	2026-08-07 03:42:55.351+00	2026-08-07 03:52:55.351+00	2026-08-07 03:42:55.362+00	f
fae44ebf-2954-4e79-a628-271322728d89	09120000001	70ae9115f3416b377ad5e1912b1e41722cad2c2203533054c7123a91993e5d7b	2026-08-07 03:43:22.829+00	2026-08-07 03:53:22.829+00	2026-08-07 03:43:22.843+00	f
e1d5f4ff-d29d-40d6-abe3-97fd6297026a	09120000101	4721c1028b6a27ab0cfd440ab13c08d145c1fe93cfe7556cf135c8a95620ce35	2026-08-07 03:43:22.864+00	2026-08-07 03:53:22.864+00	2026-08-07 03:43:22.873+00	f
68700526-ab5e-4d37-9498-df7e4804f31d	09120000201	f3b0f9dbbb26ad02c2dbea0d3a6e0c20c802a2c866af1039e6aa82c6eed5db58	2026-08-07 03:43:22.899+00	2026-08-07 03:53:22.899+00	2026-08-07 03:43:22.907+00	f
8dd526f4-231f-4aee-a883-17c3cb2e4b75	09120000301	eeeca14daeebff1d498d670e834617f2de58cab36c4464c9ab765ec10a33eca1	2026-08-07 03:43:22.928+00	2026-08-07 03:53:22.928+00	2026-08-07 03:43:22.936+00	f
887034af-ceba-46ca-acd2-53b654d317cf	09120000401	44e7b31738f7602572fff92bafa5b6fd3baa01a7379358e07e67b8fa31f557bf	2026-08-07 03:43:22.957+00	2026-08-07 03:53:22.957+00	2026-08-07 03:43:22.966+00	f
3f54a022-154d-4875-aeb1-cc7671ae61b3	09120000501	8ab142e0b3a1c33612f017799ecbc5d0148252a9039af0760d315cdac2bfb599	2026-08-07 03:43:22.988+00	2026-08-07 03:53:22.988+00	2026-08-07 03:43:22.996+00	f
5371c287-d3da-40b8-a467-b79d146be6ac	09120000001	b65aeb5770cf3c93c44a2f81b017ac1157d10b6d6eb25e87762d5bed41666904	2026-08-07 09:57:42.666+00	2026-08-07 10:07:42.666+00	2026-08-07 09:57:42.711+00	f
308c4572-81a7-45df-a655-7d617399982f	09120000001	8a55df352db05519e3e215c222c0ee6a55b33548605872fcb0a3a3a11541f680	2026-08-07 09:59:01.691+00	2026-08-07 10:09:01.691+00	2026-08-07 09:59:01.703+00	f
56f5e707-c0c8-495a-912e-353c250de722	09120000001	ee5e33a98c1f1874c31b6b9963aa613976c9db47d0f6fa703d1059969c67975c	2026-08-07 09:59:32.543+00	2026-08-07 10:09:32.543+00	2026-08-07 09:59:32.558+00	f
b0d778a1-f4e9-4a74-87a3-a1168c31aafb	09120000001	63c93d421f950bec47d29106791ac5821ade214a1bd4c612a5bff5123285f244	2026-08-07 10:00:06.532+00	2026-08-07 10:10:06.532+00	2026-08-07 10:00:06.542+00	f
7b9bfc9c-d654-40b6-8a54-347775972472	09120000001	8c76af7e5f78bc04f45ca656f6bd6853d064d84f49dd16537b212542574d0f24	2026-08-07 10:00:44.985+00	2026-08-07 10:10:44.985+00	2026-08-07 10:00:45.006+00	f
d6d3e8b9-8179-494f-b730-78f8513fad4e	09120000001	bfc0dc0f31e64f1d8129c4db424ddac09301b3e41402baf7f589d7402ded7151	2026-08-07 10:01:44.408+00	2026-08-07 10:11:44.408+00	2026-08-07 10:01:44.419+00	f
332c6bd6-7535-4b92-a1df-319802427797	09120000001	124a603d6e73a0966b87faba09a6604ed646dc05306b1a8ed8d6681e1ed0a7f9	2026-08-07 10:10:31.899+00	2026-08-07 10:20:31.899+00	\N	t
026dae7a-394e-4e60-b765-1715f7e2e488	09120000001	442cdf48419e86812e4c8f10c39ffd9bec0c2a71c1e05565b414016ed5707805	2026-08-07 10:11:45.964+00	2026-08-07 10:21:45.964+00	2026-08-07 10:11:45.983+00	f
d17d7274-6d43-453f-9590-54fa9f525042	09120000001	30621b0fae9208420e818385811d889d37da061867606c91f27ab8cb79754932	2026-08-07 10:15:46.966+00	2026-08-07 10:25:46.966+00	2026-08-07 10:15:46.982+00	f
13776d7d-1ffc-4173-9593-18ba76c5f019	09120000001	a6e651bcb65133e02643d2c10470d6ed143ba32c05ca4d397b616af0b1e53c79	2026-08-07 10:17:37.454+00	2026-08-07 10:27:37.454+00	2026-08-07 10:17:37.469+00	f
0ab36b7c-a858-4aad-bdd0-087487c3a3c2	09120000001	20f12bbe62eec1a798f47653d0feff3b835efac0213256261b860322092c98ff	2026-08-07 10:21:23.366+00	2026-08-07 10:31:23.366+00	2026-08-07 10:21:23.382+00	f
533290bc-6c01-4f86-96a7-6ff516fddcb4	09102041605	d67b7713bf1176e0c09ca60e02d644b124c232ace97dd0095742b07dce757301	2026-08-07 11:27:21.685+00	2026-08-07 11:37:21.685+00	\N	f
815a4c7b-ef9b-4812-a6cb-ac7141b4789e	09102054756	3857e3af3ece958f4b8bac1078409869a45be0d57e33698e9b3304b834f4d4bf	2026-08-07 11:28:04.068+00	2026-08-07 11:38:04.068+00	\N	f
2ff7dc6e-83de-4f3d-ba39-eafea4d36b12	09102123562	6c464a7d06cf24398422d22181a7d89d5d626f7af567e18eaa77eb9ba287530c	2026-08-07 11:29:12.847+00	2026-08-07 11:39:12.847+00	2026-08-07 11:29:13.514+00	f
591d55a9-be16-4ab9-9c5e-dfe4f1d85a1a	09120000001	e56bcdbf42f91402ebdd24af73f4aa8524f2625e0671c63c91e2cdb88045308a	2026-08-07 11:41:53.102+00	2026-08-07 11:51:53.102+00	2026-08-07 11:41:53.685+00	f
2c525cf6-6422-442b-abd4-48c2e663e800	09120000001	6a25047160526b81d0efa21bb96fdf1f3bfa1861c9d2cb394f91a9df79710c26	2026-08-07 11:42:04.7+00	2026-08-07 11:52:04.7+00	2026-08-07 11:42:05.268+00	f
e6cd3da7-0a1e-449d-89cb-e0ef5ec15c30	09730044491	e19a954ec4c50eb25ccbdac33cb083a8f9c24a7c89c1eeae457178ff92cc32e8	2026-08-07 11:43:25.665+00	2026-08-07 11:53:25.665+00	2026-08-07 11:43:26.248+00	f
7765d8c5-feef-4aae-bd79-173dd1e1103e	09830505961	96b06e8a0350cf5d62c8fbb1dd6f7cd722c32997f4e3d57702daeccb3f603d8b	2026-08-07 11:44:12.896+00	2026-08-07 11:54:12.896+00	\N	f
24349eb4-c39c-48f0-a365-b7f22f938282	09753404242	83b410a0eb24e5fb7b909245ea88f50ab15641039e15167688ed39edc8af3210	2026-08-07 11:47:24.772+00	2026-08-07 11:57:24.772+00	2026-08-07 11:47:25.354+00	f
2f20a62e-df71-40a1-8860-1c0124202596	09206746569	ecc6a7c0a29231164a42dce82feb137ba3c9689c60726ced389810059ad97a69	2026-08-07 11:48:02.285+00	2026-08-07 11:58:02.285+00	2026-08-07 11:48:03.352+00	f
ee1464a0-0bec-483b-baa4-5a5756e64d5a	09724644131	2c97bd477debfaadcb76993c5f2fc72c873cf93ded5a16965118a6a6522d4cde	2026-08-07 11:48:57.702+00	2026-08-07 11:58:57.702+00	2026-08-07 11:48:58.285+00	f
33b32674-7055-42e8-973a-b70c7e0cec32	09745442207	9f9097256032eedfab342c59cfed1499c769b38b65f91dfa93d3e170a7377284	2026-08-07 11:50:10.313+00	2026-08-07 12:00:10.313+00	2026-08-07 11:50:10.883+00	f
8cb3097c-277c-44d5-96f6-b54d37fa8140	09874629930	1006663fd22d0007413873bc6d7623fb174217f0feec4e859806d6f460f0c4cf	2026-08-07 11:50:18.782+00	2026-08-07 12:00:18.782+00	2026-08-07 11:50:18.847+00	f
ac9a3e9e-64e8-4017-b25c-0bf0f7c81b99	09874629930	95488c64d54105c5c6cac6a7dd39c48a13d52b478e3ce52892f441d591dfecb2	2026-08-07 11:50:46.925+00	2026-08-07 12:00:46.925+00	\N	f
649bf2f0-c1c9-4190-ad4c-24c0027152e0	09123456789	dedb01991b77e32dd6d18726b4309598730c180a678286605639bf4932a3e030	2026-08-07 11:51:20.225+00	2026-08-07 12:01:20.225+00	\N	f
51a61f0a-0705-4d41-a92c-b1698c24d438	09123456788	02e0bf24675e97a74af53a430e8fcbd3839404cf21d5602761a9b28c2b439408	2026-08-07 11:51:47.342+00	2026-08-07 12:01:47.342+00	2026-08-07 11:51:47.355+00	f
c4740ef7-cc15-4c24-b4ed-298c36ec8b0e	09817935004	0289636e7257550ed3cc55a5eaf5d72c37847109b103ef8d22ec01c8737293eb	2026-08-07 11:52:46.409+00	2026-08-07 12:02:46.409+00	2026-08-07 11:52:46.474+00	f
1eeae2a7-85fe-4f2b-900d-d85c6d923ee2	09817935004	809a90351b8bd70be59419e06c255c29a1e2b571792ea2efdc02b4ba26255542	2026-08-07 11:52:46.525+00	2026-08-07 12:02:46.525+00	2026-08-07 11:52:46.54+00	f
ca0bc21d-44a2-482e-870d-4be712b4baad	09672996037	f6fedd58537b14a08f5ee9b99599894a8012ad43a6966a7a6bae2fad94ce49f5	2026-08-07 11:52:48.142+00	2026-08-07 12:02:48.142+00	2026-08-07 11:52:48.155+00	f
1696599b-4b70-43ca-9acd-33e7104a1f04	09951843990	4615f23f36b60f540465e9e1eeafab2c698dc1b8bbe946081a0b3c7d1bf35f71	2026-08-07 11:52:54.534+00	2026-08-07 12:02:54.534+00	2026-08-07 11:52:54.548+00	f
b0a3b755-9281-4375-a7a5-cad7bcc0f64d	09202531771	6da69eb002d56dc5c735f428451df0de406f9a60d9c37ac7490d110eb77a476f	2026-08-07 11:52:26.858+00	2026-08-07 12:02:26.858+00	2026-08-07 11:52:54.908+00	f
1589503a-d274-422e-9bbc-1d4d5449c257	09557505779	ac539749b4872178cd100380e6c71fad954857fd3464453cf15a8c2f1b893c43	2026-08-07 11:52:54.623+00	2026-08-07 12:02:54.623+00	2026-08-07 11:52:54.636+00	f
9aa885ea-0cb8-4ef7-8e12-b5e26877dbfc	09490713428	4d5bced265522039c3f14ae5d5690c15d916e523ec83ad4014e92137a78ba7aa	2026-08-07 11:52:54.65+00	2026-08-07 12:02:54.65+00	2026-08-07 11:52:54.661+00	f
453a7f98-0110-4881-b8eb-b42f6bd37a8b	09958986201	67a7d0ed056be0aac672e67409fdd026620c5f4c841e33d8b0298156048822b4	2026-08-07 11:53:00.873+00	2026-08-07 12:03:00.873+00	2026-08-07 11:53:00.897+00	f
21340b46-6f13-4663-a4ec-fae549faeefb	09916842675	a37afccba3f9ad8aa5939b29104b8b42dfcc2efa55f302f057809084efc78f43	2026-08-07 11:54:00.329+00	2026-08-07 12:04:00.329+00	2026-08-07 11:54:00.342+00	f
116e1f7e-db0f-435b-917f-76507c362af6	09120000001	25de5dc78b7f7ae057b8094baeb003c6cac4913d957a5acdbdf6745fdcd4b388	2026-08-07 11:54:00.363+00	2026-08-07 12:04:00.363+00	2026-08-07 11:54:00.375+00	f
053e171c-5e09-4fd3-807e-9778d12e5041	09969632109	bd4816bb8751490edb180786d6e4e114264ad564b02462f0aba2d286c74fac74	2026-08-07 11:54:27.866+00	2026-08-07 12:04:27.866+00	2026-08-07 11:54:27.882+00	f
2b5838a0-c673-471d-8fd5-cb7e6f760fe0	09120000001	8222f200ee5a8f684fb8faebf83a77e08ad1ea845c2c5faa8b6c9eb9eaf0e257	2026-08-07 11:54:27.906+00	2026-08-07 12:04:27.906+00	2026-08-07 11:54:27.919+00	f
6ba21520-3a85-4c00-8d39-f9fa41f4fe7d	09159528770	b566f7565dfc84760065a32a6b5af0867c5af7c37e44a9e06e7b8cb0a4ae1296	2026-08-07 11:53:04.157+00	2026-08-07 12:03:04.157+00	2026-08-07 11:53:04.824+00	f
73f91dd1-92f0-4f45-905f-eff4e349388f	09159528770	56f61849336592d459167ec30f1c29fd9257c8c859fbce563b334d359be9744f	2026-08-07 11:53:05.627+00	2026-08-07 12:03:05.627+00	2026-08-07 11:53:05.638+00	f
cb6bf263-d6a4-47e0-beb0-a61af4d03c69	09992690141	4fb177c22ca80ab8a32cd5a6f2707e47765c8fd84fae751a39fe79c6a33d6ad8	2026-08-07 11:53:09.388+00	2026-08-07 12:03:09.388+00	2026-08-07 11:53:09.402+00	f
76ffeef5-d929-4f5f-8bc8-5250370f1d5d	09928243289	be3f6221c28d88bb567269e786579ee70c89f71c68791f6c3eafac1bfadd871c	2026-08-07 11:57:40.035+00	2026-08-07 12:07:40.035+00	2026-08-07 11:57:40.05+00	f
6e7b3312-3709-423b-825a-cd38fc902928	09120000001	881548b9056e569930d500ca27d198a7f46fa9484adfcbbf9d8c954fa7a89957	2026-08-07 11:57:40.076+00	2026-08-07 12:07:40.076+00	2026-08-07 11:57:40.089+00	f
6f6899f3-ba6e-4e94-a9d7-3928db9413f4	09903481289	a5251c6cb75ee6a1af5de9aee6b6adaa34fd58d69f2c160305166752da25909c	2026-08-07 11:58:07.535+00	2026-08-07 12:08:07.535+00	2026-08-07 11:58:07.553+00	f
96ff5a8e-403a-45d2-9538-02d6a1b6794b	09120000001	365f90b9b4b9e170b46d9db8b1c861c70ff2b6f40bccae52de4ed6888805a86c	2026-08-07 11:58:07.584+00	2026-08-07 12:08:07.584+00	2026-08-07 11:58:07.6+00	f
1b308345-8f2f-49ce-acf5-33736552a929	09774249847	e74dd6e7391b0c231eb7af9495ee8eb1b0bd99e6c1f197f2678d3accb4d8eb36	2026-08-07 11:58:20.743+00	2026-08-07 12:08:20.743+00	2026-08-07 11:58:21.327+00	f
a85214c3-7c1f-4b77-8788-e3bc8f333d21	09820516047	03a5c53aa89f2f1a1cec0604727c3673053290328ed1deb87afb194230c91131	2026-08-07 11:58:25.74+00	2026-08-07 12:08:25.74+00	2026-08-07 11:58:25.827+00	f
7f44ced3-9a87-4118-93da-adf6603e2bdd	09820516047	70df0e02963553046bda5f15a0e1fa2a64d55b80c53fcf605b6509ba64d6a9a8	2026-08-07 11:58:25.874+00	2026-08-07 12:08:25.874+00	2026-08-07 11:58:25.898+00	f
732cef16-69af-4653-a730-174c351900c7	09635425286	ea45138629f63fecc1e9ed1343271210c3b0b9faa9133769d0d78fab149937f6	2026-08-07 11:58:27.47+00	2026-08-07 12:08:27.47+00	2026-08-07 11:58:27.489+00	f
068acd6d-a585-4283-a33c-69b2aaa7aaa7	09912568459	dff86ef8c5f74c7db0bc491bcb30c6a55a7e0e91ed26897fad2a914c6283c84b	2026-08-07 11:58:28.389+00	2026-08-07 12:08:28.389+00	2026-08-07 11:58:28.4+00	f
c68d7034-8e7d-4d23-8659-bba9fe7de937	09560929805	6dd92278888aac27d4cf04aba3655289a73286c7dd30033e2d2b9981c5e02a0c	2026-08-07 11:58:28.465+00	2026-08-07 12:08:28.465+00	2026-08-07 11:58:28.474+00	f
499961e9-c2b3-47a5-b748-645f6e51d75c	09453336656	9aa7024ee303a9d4dbbc089d152cccf040f741fe2c4cbb5a25be0b45fe1e0150	2026-08-07 11:58:28.487+00	2026-08-07 12:08:28.487+00	2026-08-07 11:58:28.498+00	f
eab63df4-e3cd-46bf-bd0c-38a74c73941c	09930903427	befa5c32a3b52ff9aac7e057f8f2326dd04b6706a47c13322b1e0eb8784e2426	2026-08-07 11:58:31.262+00	2026-08-07 12:08:31.262+00	2026-08-07 11:58:31.271+00	f
d028cac9-0059-46e9-8043-7769502ee87b	09146710300	06b3b3396b9ced49bdf05dac5103d0c6a70adb039316704a1b75d735d03f4088	2026-08-07 11:58:34.494+00	2026-08-07 12:08:34.494+00	2026-08-07 11:58:35.16+00	f
61eef911-3347-47ea-8ed5-11bc88e3f64a	09146710300	62a643a74712f971a0adc1df75b4fcb88f03e69cc6c26893c954e44581aa8e35	2026-08-07 11:58:35.961+00	2026-08-07 12:08:35.961+00	2026-08-07 11:58:35.971+00	f
4e9001de-6b42-41d1-893f-91ac67c9dbd2	09983473399	9a90e308dbfaa8c484b4dab333e8597f861fb58c7358fda32eb307874b152f1f	2026-08-07 11:58:36.151+00	2026-08-07 12:08:36.151+00	2026-08-07 11:58:36.162+00	f
415d90f8-187d-4143-ab6f-ca2a2122605d	09120000001	050ee0ac768e43cb8c71d0ef221470f927d481421598ac29e1c7229cb82a2c81	2026-08-07 11:58:36.181+00	2026-08-07 12:08:36.181+00	2026-08-07 11:58:36.191+00	f
b5af92e7-e0a1-4969-b40c-cdf76310333f	09120000001	f60f1e8bd3aac1b3a3aed7a3168f15b2664e2e22dcecbc2fbd3c80c7171e9d1c	2026-08-07 11:58:48.476+00	2026-08-07 12:08:48.476+00	2026-08-07 11:58:49.042+00	f
64a0218e-ec08-4065-95e0-776b74a3c614	09120000001	daf92d06087f9eb05c52e751c3bd9ef56970f6a42186493a72a28db11b1c8e9a	2026-08-07 11:59:00.526+00	2026-08-07 12:09:00.526+00	2026-08-07 11:59:01.091+00	f
8792446d-3b92-4b9c-916f-25de648ff5ca	09120000001	cb8df4d9ef036eb9d717049f57700ad29ba6d5119e848a15c6f7f2b940768371	2026-08-07 12:00:03.355+00	2026-08-07 12:10:03.355+00	2026-08-07 12:00:03.939+00	f
bc219b31-5dac-4d10-a8d0-24bf3840c5dd	09120000001	87fb83840adf1da9acf47700bf9b626b9f381ff6956111508b29c3bf844d96a9	2026-08-07 12:00:26.205+00	2026-08-07 12:10:26.205+00	2026-08-07 12:00:26.774+00	f
064946d7-a441-451f-b92b-24e2537d3afd	09120000001	3773047f5e68372e236314260d2ede524e723ab1e432cd0fdd428663d7e096fc	2026-08-07 12:05:57.242+00	2026-08-07 12:15:57.242+00	2026-08-07 12:05:57.826+00	f
2a53ac67-2b3b-4d99-b365-182b4f4f373b	09120000001	5bf5bd9c381d1b799b6f42dc4f573f33003ed4576bfe917016d9b97371c51cb0	2026-08-07 12:06:18.925+00	2026-08-07 12:16:18.925+00	2026-08-07 12:06:19.491+00	f
ad5a7eb6-d9d7-4756-9e63-6067b33b6b48	09766324268	655464034912b7222adc120be35163c484f4962a0dd96d469faaba4344d547b4	2026-08-07 12:06:25.424+00	2026-08-07 12:16:25.424+00	2026-08-07 12:06:26.012+00	f
8316cbe1-8171-43b0-a3d1-1543407f56b4	09835475818	5e9aaa8aee5abf8215ca5a4004f0bbb56319b1b2606c98e1656e1a7499f05b22	2026-08-07 12:06:30.458+00	2026-08-07 12:16:30.458+00	2026-08-07 12:06:30.54+00	f
b7ff4816-2ade-425f-9179-ea14ad55943e	09835475818	de44a8efff3bbad00420107534aae07ea568e124dc66babbb040983507151ffa	2026-08-07 12:06:30.59+00	2026-08-07 12:16:30.59+00	2026-08-07 12:06:30.606+00	f
0db9d770-bbea-491e-9c6f-2c4f6ad417d7	09620385822	59c0c390f336c5592469f6b7b282d8292487d49cf2451fd22aab69b4e7b95bfe	2026-08-07 12:06:32.194+00	2026-08-07 12:16:32.194+00	2026-08-07 12:06:32.207+00	f
eb6b4e5c-ce59-4ab5-9e39-b42d32506f55	09901871402	c3f672f6b38fde49f8291654150a8bc57c5a0e4ba19a8e89d1b210f582a0e2a2	2026-08-07 12:06:33.153+00	2026-08-07 12:16:33.153+00	2026-08-07 12:06:33.165+00	f
702e37cc-be14-477c-b0e6-5f87020d5a53	09529334918	8e5af7396ad90fae66e53af7d1c02338489b984c5e644f5cc714e70ad9333f52	2026-08-07 12:06:33.241+00	2026-08-07 12:16:33.241+00	2026-08-07 12:06:33.256+00	f
b200d5c7-396a-4289-b6ad-104472d770e1	09447257187	30ae5214b250cb98dea34bf4ca002aacfc4395852527742ce10e775e0db0690c	2026-08-07 12:06:33.271+00	2026-08-07 12:16:33.271+00	2026-08-07 12:06:33.283+00	f
3d5a6728-6ac5-4588-b4d0-562c35c46eba	09989803059	efaf75a4ad6f12a42166c28871c710da9a9b4efd9106b5f1bfd4b62fafe69b9e	2026-08-07 12:06:36.359+00	2026-08-07 12:16:36.359+00	2026-08-07 12:06:36.373+00	f
5f0c5f94-f38b-4318-a2d8-24f7a74e9bac	09124532158	9888005004f73fb70323ad38c3b7566795ce9796f8312d1ce1d73fe73bf4cdfd	2026-08-07 12:06:39.722+00	2026-08-07 12:16:39.722+00	2026-08-07 12:06:40.39+00	f
bed26817-a71f-4bcb-b847-f35e703d6682	09124532158	bd5f50ae49e41d9100bb0593a6eabb181d49e2837595116ebd4c1ad7b2dd5dd3	2026-08-07 12:06:41.196+00	2026-08-07 12:16:41.196+00	2026-08-07 12:06:41.207+00	f
fefee594-7f7e-45fa-9785-7d9deeae454f	09965970073	8ef8e6dc2a1b229106504a589991e3533c8d29de236de82efec416edbb638da7	2026-08-07 12:06:41.383+00	2026-08-07 12:16:41.383+00	2026-08-07 12:06:41.393+00	f
a734866f-c5f0-43fe-8ae5-34892e4355c2	09120000001	d6970c42165f6e8f56d28a330c5c0f0bf1ee79aa75e2da779fca6cd919b04a22	2026-08-07 12:06:41.414+00	2026-08-07 12:16:41.414+00	2026-08-07 12:06:41.423+00	f
ea8ee53c-cc7d-4757-9652-2d17b3e169a4	09916320562	8104d2c9888899d28520cf27d1d42cc3a933da4f86e726ddfb852c4dd5ddc3f0	2026-08-07 12:23:37.425+00	2026-08-07 12:33:37.425+00	2026-08-07 12:23:37.481+00	f
a33ace72-d4bc-4832-9451-9816fdb18e6b	09916320562	5d2c3a138b15276222ad81f01cb944e77970b031d557efcf76254e7b398a0957	2026-08-07 12:23:37.501+00	2026-08-07 12:33:37.501+00	2026-08-07 12:23:37.516+00	f
b404cefc-4586-409d-9cff-d20ee3f545d7	09916320562	919736c7899a81a3632fe89654bacd7ed7aa2261ed76416e9609454df705d981	2026-08-07 12:23:37.549+00	2026-08-07 12:33:37.549+00	\N	f
27c0eb83-ff69-4a38-8c53-0a90eb6d0f75	09976988252	b70977900b685141e582368294b2e9e0fe56cb73243195b6d6b91ca1e53cf14c	2026-08-07 12:23:38.075+00	2026-08-07 12:33:38.075+00	2026-08-07 12:23:38.088+00	f
255ceef5-628c-444b-918d-8659bf69a44c	09411512735	bb5ebb58a02c2d7f2d3b3d637a99ef0a37bfc468f1a90d453529e05dabdb5cae	2026-08-07 12:23:38.115+00	2026-08-07 12:33:38.115+00	2026-08-07 12:23:38.126+00	f
96a8c7d8-f154-49d6-a2fd-4a229d3ab9e0	09522587166	247158b05fc4888b7f1d7357a54d3ab832d8d64fea5525f98073a155f2f69345	2026-08-07 12:23:38.168+00	2026-08-07 12:33:38.168+00	2026-08-07 12:23:38.18+00	f
759ccf9c-c6cc-4672-a47d-94b5a310b126	09991784512	c1b29a4407f6a906b514d00ccd2202edf60a7a46ad27b729e6155161c7564455	2026-08-07 12:23:38.819+00	2026-08-07 12:33:38.819+00	2026-08-07 12:23:38.835+00	f
ca0216dd-2919-41bb-96e5-7d0e4e28ab2c	09521417438	09799a3796ffb5707986ead2a4106d99d74d100b72297f8878c312b4736eb828	2026-08-07 12:23:38.879+00	2026-08-07 12:33:38.879+00	2026-08-07 12:23:38.892+00	f
90a7cca1-6432-423a-ab27-22910add7da9	09477815879	d5b23ca485e489a6d574d793c77d7471578d9a093dbcff63d454145c00de9b98	2026-08-07 12:23:38.916+00	2026-08-07 12:33:38.916+00	2026-08-07 12:23:38.927+00	f
22cb9385-fff2-40f0-9fc6-e7efbf252045	09167314729	e75f88917e4e59bc039be1e332ab5a5f6e29564958cdef71e8330edd5b0f5290	2026-08-07 12:23:38.965+00	2026-08-07 12:33:38.965+00	2026-08-07 12:23:38.975+00	f
49ffcb1f-dca8-4905-9dcb-fa140976f068	09259347135	e7eb32ba8d2f7715b1fd49e05f13846b2faa311dea17eab11bd4c88ba0d8127b	2026-08-07 12:23:38.989+00	2026-08-07 12:33:38.989+00	2026-08-07 12:23:39+00	f
5544a3fe-55ec-4fe7-9084-d00c6999a465	09990091022	a4d26aee695b16a987fab1782bbcac0f98608b70c4a670c54f3ba2d6896ebe36	2026-08-07 12:23:39.836+00	2026-08-07 12:33:39.836+00	2026-08-07 12:23:39.848+00	f
adc4c51b-71c8-41da-a8c0-db90aa86e95a	09495382591	ecbdfedfd7d4ec59132e835e95563837e9160053e9fe06ee7cb3b4877d8c9192	2026-08-07 12:23:39.873+00	2026-08-07 12:33:39.873+00	2026-08-07 12:23:39.886+00	f
d64d67dd-bd95-41f5-8aa3-93f33abe4076	09543138538	868305952b9970c070b56b0bf4dd4f9a8378d777ce90771ab294ab97637adc3d	2026-08-07 12:23:39.924+00	2026-08-07 12:33:39.924+00	2026-08-07 12:23:39.937+00	f
e7a1dbea-5af7-48dd-9a86-e305d022d809	09380389559	d0ec99ae1827a5be970636e1439bed2c8bf251ba538e8186cccc87008f176bd2	2026-08-07 12:23:39.954+00	2026-08-07 12:33:39.954+00	2026-08-07 12:23:39.966+00	f
45638409-8095-4b94-bddb-455950f5c8fd	09951628911	49c27f6c344e821766b58172cbf2c19468418f4c8ae973429e2254ac70f38867	2026-08-07 12:23:40.183+00	2026-08-07 12:33:40.183+00	2026-08-07 12:23:40.193+00	f
2d654af5-3ba8-418f-a9e6-7fcc2ca14f96	09563455492	f877f9800ddfe025dc0deb98a636b90d5b1947a24b2b7bd90e24f04af191f942	2026-08-07 12:23:40.231+00	2026-08-07 12:33:40.231+00	2026-08-07 12:23:40.241+00	f
b3906c67-0e2d-422c-ba81-5735821d7794	09628061271	503b8463d5abc07b12ba4adf0761520c68d1788b865ee51a55271a313876269a	2026-08-07 12:23:40.257+00	2026-08-07 12:33:40.257+00	2026-08-07 12:23:40.268+00	f
f6f511d7-3494-40ee-bb0e-cfa729f5b2d4	09927911962	5b7fbe962c0dafa10a22e5ba901bda952505abd632744f8fac65eb81b53f9abb	2026-08-07 12:23:40.388+00	2026-08-07 12:33:40.388+00	2026-08-07 12:23:40.4+00	f
4b25c136-066c-423b-9b13-64033f8946e6	09972692698	338267fe756397e63776411491d6d77f5b49ed0fa7e19483d6ae357b4893dfae	2026-08-07 12:25:57.337+00	2026-08-07 12:35:57.337+00	2026-08-07 12:25:57.394+00	f
d3ce9b7a-8bf5-47c7-a985-62b4b0b03502	09972692698	73fe79de0dca3064114f3b410eac75604b3b92177f642254167e3d1a91d40339	2026-08-07 12:25:57.414+00	2026-08-07 12:35:57.414+00	2026-08-07 12:25:57.428+00	f
42b5af74-7c0d-4abb-91cd-d57d2960fe6b	09972692698	1ff47abbc82bc25277b40ba5fb6c17608d968192c7e2535482ad21ceaca0e19d	2026-08-07 12:25:57.46+00	2026-08-07 12:35:57.46+00	\N	f
eb2803fa-65a1-4c0b-a903-adf640395c9b	09915282008	a3096ba8a941a593e7c23dfb288f66ef8548801d8770c03d5c9566eb1c0f05af	2026-08-07 12:25:58.033+00	2026-08-07 12:35:58.033+00	2026-08-07 12:25:58.046+00	f
b64127f8-45a1-4e9d-b0b6-33116ed822c7	09420760746	cb22543e85f2e5166d276d864e7dd92469e9ed1f3b5990f31f5b0fdd47f92d96	2026-08-07 12:25:58.072+00	2026-08-07 12:35:58.072+00	2026-08-07 12:25:58.084+00	f
82637509-b7f5-409e-8581-98df8a17f9ca	09538230777	fb7027e4f28c31962d42c8ef7c199f882990d3521e72c4126e89150be0640775	2026-08-07 12:25:58.127+00	2026-08-07 12:35:58.127+00	2026-08-07 12:25:58.14+00	f
ade82df4-6060-499a-9a34-0194ef98d388	09708697074	8125ac3b153243444bc14485480d983f41bea21e810e24d18301292ff45d119a	2026-08-07 12:25:58.606+00	2026-08-07 12:35:58.606+00	2026-08-07 12:25:58.618+00	f
b2f06148-e377-4eee-9967-05796f59f287	09924960430	c1b24b2c2b56c2cdd9805a999bd77dbeb6354c058f78dab9b707d4345a171588	2026-08-07 12:25:58.667+00	2026-08-07 12:35:58.667+00	2026-08-07 12:25:58.677+00	f
3209b647-85ac-40c7-b05f-f75f9f016622	09916173592	c38279611dccdebdd2589012257edb6b6c3dad096f8fe636d80385652c3f6844	2026-08-07 12:25:58.727+00	2026-08-07 12:35:58.727+00	2026-08-07 12:25:58.738+00	f
19b34abe-e4ba-4f79-9a17-42d6332279c0	09509370830	a6f999e0f2f9a4bff68691bb348e027d206032b838b5a81302c24793168ee8d0	2026-08-07 12:25:58.776+00	2026-08-07 12:35:58.776+00	2026-08-07 12:25:58.788+00	f
816d9a8e-498c-49c3-8c55-3551660d42e4	09482892726	8dbc20f0e71f10fc66b67c522976cddf2a6f1b4a09aea1418d46d13e0905e83c	2026-08-07 12:25:58.81+00	2026-08-07 12:35:58.81+00	2026-08-07 12:25:58.821+00	f
485f2193-b84d-489b-92b9-3fafe99e5813	09134984232	7fc36cf80ccc64c7c57f71f96140c459fe3eb1c604f4a642a11969d2092c56e0	2026-08-07 12:25:58.854+00	2026-08-07 12:35:58.854+00	2026-08-07 12:25:58.867+00	f
c8258190-fcf2-4166-a5d1-c2f05c34bb2b	09246970001	e5d3a3394efc26efaea437e2e87c680913318ac576aafe8eb51c749adac4bdcc	2026-08-07 12:25:58.882+00	2026-08-07 12:35:58.882+00	2026-08-07 12:25:58.891+00	f
5eb30378-5a45-409c-a778-da7c1346fa61	09977581264	7518f4d485612b3dccfd248d654f526f3e39bc83846b51ca58a9b97a39842a06	2026-08-07 12:25:59.354+00	2026-08-07 12:35:59.354+00	2026-08-07 12:25:59.366+00	f
7fec5360-9c2f-4c24-bb8f-85750033d58d	09495689725	9107ae8325d5a5482e2ecb34be630dee026c325f86738c9ed169bfc66a87bc37	2026-08-07 12:25:59.387+00	2026-08-07 12:35:59.387+00	2026-08-07 12:25:59.397+00	f
9c9ff2a9-c9fa-4e61-9ea5-eeba5af204eb	09515481790	b67f4e5b0a7cf36e1f4d726cef4c4bd32cc16274d700f5d13d882326fd67dd23	2026-08-07 12:25:59.434+00	2026-08-07 12:35:59.434+00	2026-08-07 12:25:59.444+00	f
89196b9b-357b-4d95-9b1d-afeae6c86ca7	09366760526	cbbb5c3834d8d72d8e71c32ad42e96f493c7880210ec48d5c74f709de48a730f	2026-08-07 12:25:59.457+00	2026-08-07 12:35:59.457+00	2026-08-07 12:25:59.467+00	f
c18756f5-da20-4451-978d-3fb14253cef3	09901307226	b376f8a3891bd34135795baad17ebd262f11eee2c8920cdcdf599548d3635439	2026-08-07 12:25:59.635+00	2026-08-07 12:35:59.635+00	2026-08-07 12:25:59.647+00	f
1af9b478-aad1-487e-889c-71880d59415a	09582052075	a476e7d64e1af320858eceb1b48698348ed3a4f452f4941ca7a047f3ebacfbf5	2026-08-07 12:25:59.685+00	2026-08-07 12:35:59.685+00	2026-08-07 12:25:59.696+00	f
c4d3af3c-f567-4ea5-8cd9-41b5282a7f04	09685822742	1ce8f3c27da5338240260612d260d71a25d84c5bce78a6772a8372069a5f2e1b	2026-08-07 12:25:59.709+00	2026-08-07 12:35:59.709+00	2026-08-07 12:25:59.72+00	f
f2c067da-cb32-4b1e-a562-13ed49a4c608	09971633535	a4e083dfba120ff6c16fb22c2fddb087b3a7fddaa186b0fe3c7f3381146bb948	2026-08-07 12:25:59.834+00	2026-08-07 12:35:59.834+00	2026-08-07 12:25:59.844+00	f
47dea700-2c7a-4876-9125-9972b2afc8cd	09921236465	0dbc866652660e726662ce1bac1357c5956ed97046d9e7f947164b2b2f3e6046	2026-08-07 12:26:12.968+00	2026-08-07 12:36:12.968+00	2026-08-07 12:26:12.982+00	f
e931c78c-ac16-4b51-a0a3-042aa521caeb	09921236465	1551c0707c04fdbe7cb1b18759b0b780b4dd5d2b20bcf1b0d583829c93f88864	2026-08-07 12:26:12.995+00	2026-08-07 12:36:12.995+00	2026-08-07 12:26:13.007+00	f
e65f79a3-ced4-4b36-a894-e0331a5e0f5f	09921236465	31a9a761ddeeefb8f82eaec5141f7fd3377171ea5aa9335ae61a7e8f464382c8	2026-08-07 12:26:13.034+00	2026-08-07 12:36:13.034+00	\N	f
2f8a5fd2-68ef-4ec8-b1b4-010a077eb0c4	09977200147	d95ca739f9640550c91f2fd6c585d353af57d973aff454c3dd7802f293022c71	2026-08-07 12:26:13.149+00	2026-08-07 12:36:13.149+00	2026-08-07 12:26:13.159+00	f
290f0373-6868-4ef5-be33-f4529b0f5337	09426181167	a91e9f3ca6bd448a5c798c5f68b20664adcb40af442f563242bf5ca624210ab9	2026-08-07 12:26:13.182+00	2026-08-07 12:36:13.182+00	2026-08-07 12:26:13.192+00	f
e77e8b60-a650-4176-a2e0-bc26bb251190	09554499615	876db518e5856c24f6905aa9fd0cb600e343b6d76141c369eb247c3957241327	2026-08-07 12:26:13.219+00	2026-08-07 12:36:13.219+00	2026-08-07 12:26:13.226+00	f
114edc7e-1529-409d-8ca6-33b9909f2c33	09705356316	94bd32a44289957368e86038b4200bbe36c77fb0d2481ab6588118f9e32aac8d	2026-08-07 12:26:13.707+00	2026-08-07 12:36:13.707+00	2026-08-07 12:26:13.721+00	f
4fe20e58-89c4-4985-a8a6-4d524b971096	09990507380	763a4c337b6fc9586f5ba7e9048f9437e00927aeb524db0042bd286fa8290351	2026-08-07 12:26:13.789+00	2026-08-07 12:36:13.789+00	2026-08-07 12:26:13.803+00	f
de3f1f72-589a-4726-8ff8-31e7844b6af3	09944839979	eff3da998b26bdc5029f9a52390333222a30585327065259aed189e99690fb6f	2026-08-07 12:26:13.871+00	2026-08-07 12:36:13.871+00	2026-08-07 12:26:13.884+00	f
1386dbd6-0868-40ca-846a-92058dd541a1	09595045946	f14b6ce4cc0f3461c556ff707d1c58f8983cafc55dd3f70527005dc14b71aab2	2026-08-07 12:26:13.943+00	2026-08-07 12:36:13.943+00	2026-08-07 12:26:13.958+00	f
bb3e0ef0-1711-4423-a9f3-5cdeaba1add2	09416380655	e6cbd155e4aa8731f76da76794e4e8e1dddd7fdc87ba989a1ed3538a604d1833	2026-08-07 12:26:13.987+00	2026-08-07 12:36:13.987+00	2026-08-07 12:26:14.001+00	f
a4759da0-8791-4d11-b34c-dcf725523b90	09107258063	2b43aff497c18f7f8fff4e3fb101d0294fc55d292e2cff47cbc1ff0cb99f0572	2026-08-07 12:26:14.045+00	2026-08-07 12:36:14.045+00	2026-08-07 12:26:14.057+00	f
628e7e0e-6c20-4a28-b51a-50740ea015ef	09200609227	4dd586b3412056da007d3c1fab562a19fccc318e79734338379e4f41a56ead2d	2026-08-07 12:26:14.075+00	2026-08-07 12:36:14.075+00	2026-08-07 12:26:14.086+00	f
3fae7c21-d7d4-4f15-9304-e8dd45405d18	09933597670	32486b309fc4c656ab4ee8d9e3f3818aa42414ba3de0a032c8f1f9035383023f	2026-08-07 12:26:14.664+00	2026-08-07 12:36:14.664+00	2026-08-07 12:26:14.674+00	f
5c3c372f-4358-46ef-8ecc-076a7042d09d	09463724631	6e482af39476d65e2aac64b3c757aa72b298624aca2904ef06840e7449deb214	2026-08-07 12:26:14.698+00	2026-08-07 12:36:14.698+00	2026-08-07 12:26:14.708+00	f
245092db-d44b-4ced-a048-86c955b924a2	09535185963	f7da5ffe5c12e8b402899c0acb216874d6d60fb80664cd577fe6036bab0bd339	2026-08-07 12:26:14.75+00	2026-08-07 12:36:14.75+00	2026-08-07 12:26:14.76+00	f
244b7d62-78aa-46f4-96d1-75e4a28b6158	09309708854	50d73e46f44737f5d989faff69e8e6298b42442c45faa174a000c8d9ab185ec7	2026-08-07 12:26:14.774+00	2026-08-07 12:36:14.774+00	2026-08-07 12:26:14.785+00	f
636f996c-49f1-4920-876e-5a724ca579c0	09969703073	3f6e4d402f7f95e7c23a247fe70c924334c011cb3fd90e26ba667f062d10f574	2026-08-07 12:26:14.987+00	2026-08-07 12:36:14.987+00	2026-08-07 12:26:15.001+00	f
e54c6060-544a-4181-a90e-66b2b51f0fc6	09513059823	2dda958b818327b7229fe171d69c1d1fdf8d5309ca9685b49ac1ec87d50aac30	2026-08-07 12:26:15.061+00	2026-08-07 12:36:15.061+00	2026-08-07 12:26:15.074+00	f
0487c0ff-8d7b-4da0-b73b-223a4e4e4304	09635745306	6a6d05bcd8946d4a257924ab5567f73d9dbccbfa5f32663affa569323a44a189	2026-08-07 12:26:15.094+00	2026-08-07 12:36:15.094+00	2026-08-07 12:26:15.105+00	f
728aa457-42a9-4d77-bee0-00e1ecbecdc0	09900683145	cd919393fd579e748fdad7763a99356429a4514e50ee763afee4a1edae1f69e6	2026-08-07 12:26:15.263+00	2026-08-07 12:36:15.263+00	2026-08-07 12:26:15.275+00	f
d35afc63-1257-4215-9ee2-03a3c01cf0f8	09576890480	ba4241896aa7f0ab4c3fdcc1a9590330da21420cbd35c5e36a65c9c7f93267ad	2026-08-07 12:28:47.825+00	2026-08-07 12:38:47.825+00	2026-08-07 12:28:48.428+00	f
e8503752-f5d4-45a6-941f-7e20e02753a2	09120000001	67f9d863fd4285029c482c3b32f66a1b544eb1b6b20c58665cb4c3e81a17b412	2026-08-07 12:28:51.531+00	2026-08-07 12:38:51.531+00	2026-08-07 12:28:52.104+00	f
17dfa718-ccc9-4e85-89b3-1397a05c3a4a	09120000001	6e325c613da654fdd3a1b48492b7b9d8a225d1b506f57fd927b583cb474a7c1d	2026-08-07 12:28:56.937+00	2026-08-07 12:38:56.937+00	2026-08-07 12:28:57.624+00	f
dd7622bd-1ec3-47a6-bd64-1a147977e4ed	09580196110	e9a4369d48630cfd50106300a7ec78355d7f95380c4559e480c8701d913f5308	2026-08-07 12:31:33.982+00	2026-08-07 12:41:33.982+00	2026-08-07 12:31:34.563+00	f
71199da4-6ce6-45e4-a90d-c5f296dd2058	09120000001	34eb8b6f44751b7a963b524cf4919530b41858a6913d4e545c71f9374e2b4803	2026-08-07 12:31:37.723+00	2026-08-07 12:41:37.723+00	2026-08-07 12:31:38.299+00	f
1ae8daff-b6fe-4537-b419-c04db39317ae	09120000001	5f3b31066028195f8b636e8b76df49655b6ae293fce7a826eeace1b0ee5130c6	2026-08-07 12:31:47.431+00	2026-08-07 12:41:47.431+00	2026-08-07 12:31:48.013+00	f
b2661731-f697-4b2f-8180-f8655108ccae	09513496381	93d66accec922e916ad6288febc245785b27c5454cd7c12edd74d176c5457cd1	2026-08-07 12:33:36.893+00	2026-08-07 12:43:36.893+00	2026-08-07 12:33:37.482+00	f
fb73536b-900d-4d31-a7b6-dd9eeed60537	09120000001	789b4eff491c22a2b12e940f6406312413376033271afd0075e774adb336bec7	2026-08-07 12:33:41.077+00	2026-08-07 12:43:41.077+00	2026-08-07 12:33:41.675+00	f
a2b6e982-2eda-439f-9ef9-7b2528896c17	09120000001	b3d3b4c18538b51cd87020cfcad3b55556292ba2c9c87ff846b845d7befb6c02	2026-08-07 12:33:52.542+00	2026-08-07 12:43:52.542+00	2026-08-07 12:33:53.108+00	f
d0f6a9c7-9775-4768-82a7-46588db78ea4	09588501461	926d5e253bdfd7c1d6509df023843ec92b6258833f7ddbec57c18c3f61e68af5	2026-08-07 12:35:29.355+00	2026-08-07 12:45:29.355+00	2026-08-07 12:35:29.921+00	f
c5d0b40c-686e-4f80-b0bc-0d3d32756a33	09120000001	8d2645bf998918d378032d6b1169dd244b4c7c04d895ec8bb49b49d3f58ec11f	2026-08-07 12:35:33.539+00	2026-08-07 12:45:33.539+00	2026-08-07 12:35:34.105+00	f
cc2df6fe-3c00-417c-916f-d2693c264672	09120000001	d72f3bac84a6362cb8feda044d333ce5b0a0ba51fefde3b07780902b1bd37c44	2026-08-07 12:35:50.738+00	2026-08-07 12:45:50.738+00	2026-08-07 12:35:51.32+00	f
795be0fd-43ad-431e-8f69-3352f196ecc0	09510159645	8f41c0cd4786f1a539397fab7153daff2f4c770784b8ef0161519d2fc3325a09	2026-08-07 12:36:50.254+00	2026-08-07 12:46:50.254+00	2026-08-07 12:36:50.835+00	f
368667a2-5101-43ff-9fe4-1714e854363f	09120000001	b2a26b5e01fcd5f5a3e6225f8340706f98a910cbf651ebf3a9222592d6130f66	2026-08-07 12:37:39.417+00	2026-08-07 12:47:39.417+00	2026-08-07 12:37:39.981+00	f
e45a1bf2-7a6f-4fd0-a473-b1d489688130	09526506963	c7188f796f5bfdbe2a20b6d758721cd4c55fdf6e5802fb6996c237854a905b31	2026-08-07 12:38:42.204+00	2026-08-07 12:48:42.204+00	2026-08-07 12:38:42.779+00	f
dcf50ec3-2921-4414-80dd-507c7ceff38f	09120000001	09645cb62b5db365a7715bf37bde38c614abdbe098c8cb93ccbb290f5c1069d7	2026-08-07 12:38:45.474+00	2026-08-07 12:48:45.474+00	2026-08-07 12:38:46.046+00	f
b053ac53-5a0a-4756-8b7f-cad371430f10	09120000001	3ff3490cfcc2ca1c7a200b39a32e5d76ef5360ade4446cf903284991b947d8e9	2026-08-07 12:39:03.029+00	2026-08-07 12:49:03.029+00	2026-08-07 12:39:03.613+00	f
19ad2a7e-0a0c-4df2-9b2d-a7af1cbcfec5	09587594167	3ff7d844d5d8710aaa5913dca94844301786b7a79722c2ae5ad3b68eebc32189	2026-08-07 12:39:52.194+00	2026-08-07 12:49:52.194+00	2026-08-07 12:39:52.762+00	f
6c5a494e-fe90-41ca-88a9-9a7b40435d92	09120000001	c7dab29324520aca5a15871a879fd5db38797709559193e341f82c0cebac0d16	2026-08-07 12:39:55.427+00	2026-08-07 12:49:55.427+00	2026-08-07 12:39:55.993+00	f
98344128-7889-4263-bf61-42309dd505d8	09120000001	0ec53d49a9fc1efd768a39ef74e953fb3be3553d19454efa730ec61af3fc9232	2026-08-07 12:40:15.275+00	2026-08-07 12:50:15.275+00	2026-08-07 12:40:15.842+00	f
558a025f-b17e-43b0-913c-0860f321d22f	09543159076	762808233b2867d9b3e6d7b062879ad6bbfd5a6eefd487376fe8ce48c0d366ec	2026-08-07 12:40:52.939+00	2026-08-07 12:50:52.939+00	2026-08-07 12:40:53.507+00	f
cbf6754d-e61f-4bb8-bc10-bee47bad449f	09120000001	0f1f562ff6d72ab2509d08078316977f677fb86b0b8de04dca8d5ce3bd2f5904	2026-08-07 12:40:56.292+00	2026-08-07 12:50:56.292+00	2026-08-07 12:40:56.891+00	f
a7737783-0fdd-463b-9b8d-c73cf71cfeff	09997986003	ec3355c3f439559f98f4b2d1c1a7e6a3664ab4c97ac62ed7a52315eb993508a8	2026-08-07 12:49:22.306+00	2026-08-07 12:59:22.306+00	2026-08-07 12:49:22.352+00	f
cf05cfe6-5976-426a-b3ad-02c647a19a0e	09997986003	121cd2843862c151e0dee32219012cd0b45da83210ae0e9f707df9522ce330f8	2026-08-07 12:49:22.376+00	2026-08-07 12:59:22.376+00	2026-08-07 12:49:22.393+00	f
1920469e-5f94-4896-8fa6-1964692eb682	09997986003	b52ee6ed00e52e4dcb8df4e16f58dce6513b2d883b7987170d255e377b073ed1	2026-08-07 12:49:22.421+00	2026-08-07 12:59:22.421+00	\N	f
8dec7660-b567-4542-aabb-f799e7c8bce6	09991096895	b81062393ada8d10aecf43ad1b82868efb30b97f26b97adab7137385af43d646	2026-08-07 12:49:22.558+00	2026-08-07 12:59:22.558+00	2026-08-07 12:49:22.57+00	f
f0f9e3fd-b7f3-4a6f-a1b6-af34a809be2e	09491898737	fab09a2e6bbc531e32e1131c2c533e281fde90d65949df9fd4f6b15e77288238	2026-08-07 12:49:22.593+00	2026-08-07 12:59:22.593+00	2026-08-07 12:49:22.604+00	f
326dc4b8-83c4-41c2-8ffc-ea0a74f691ae	09541891178	88f0c540bba958af8f1580c20f9e28dc7cdc99858b262b3cfe01dfdfacb91995	2026-08-07 12:49:22.644+00	2026-08-07 12:59:22.644+00	2026-08-07 12:49:22.656+00	f
73b2cef6-1076-4b3d-890e-7cb3042340b1	09783544520	6ab239aa201940901af85ef070f03088e23cbe74db28d31d2240d3d9ccafe8a3	2026-08-07 12:49:23.095+00	2026-08-07 12:59:23.095+00	2026-08-07 12:49:23.107+00	f
69e327cf-6da1-4e10-bbe8-e2348007dd4a	09967384452	7f97916dc0adaa72a20cffbf2d4cc2830092afb5d28419ededeca9f0c5e9db04	2026-08-07 12:49:23.153+00	2026-08-07 12:59:23.153+00	2026-08-07 12:49:23.163+00	f
5239cb9f-0b6f-4d27-bfc0-8d2cf8bdfdae	09959513115	9a7cb857019943c2d2ee02a5a11bd75405dcc6d0f12d7cd8d1281bb4b6faf56d	2026-08-07 12:49:23.25+00	2026-08-07 12:59:23.25+00	2026-08-07 12:49:23.26+00	f
dc9b7e41-90cf-4ff6-a8ea-c8952ea07dd0	09515579643	37ab09ab283a446c6b5b87bd4573fac0338a4fdaa8a7420baff02fa432ed6314	2026-08-07 12:49:23.297+00	2026-08-07 12:59:23.297+00	2026-08-07 12:49:23.307+00	f
1941f44c-7263-4ffa-9499-89646d3d92c4	09442910165	7579226c1d8190339a64f1ca71e07cd043df8454ef310ef81ab9859e41b67596	2026-08-07 12:49:23.329+00	2026-08-07 12:59:23.329+00	2026-08-07 12:49:23.34+00	f
4ce8cea6-4443-42f9-97f4-8214a8c15477	09153752034	7e0c7e4bcef7d57ca1639b9af269915cb7ebce0ef74e302cb6dcd26b191ce015	2026-08-07 12:49:23.383+00	2026-08-07 12:59:23.383+00	2026-08-07 12:49:23.393+00	f
1a88894d-e3ca-43ec-946d-b4ab5e15f116	09241179588	ae478f3c4b9209e91db75f21f005296cc2b5393f25e31993b4b7a3b801817575	2026-08-07 12:49:23.407+00	2026-08-07 12:59:23.407+00	2026-08-07 12:49:23.417+00	f
207436c4-19f3-41e5-aef8-b1a435db67dc	09975211806	ecac85044a3d112c618bc36911ec9d49cf99ac159c59b7601c58af6e526a3cc1	2026-08-07 12:49:23.914+00	2026-08-07 12:59:23.914+00	2026-08-07 12:49:23.924+00	f
ff2b3c76-92dd-44a1-a0d9-460fba7cab2f	09402873165	ae177d2224071c3cccba348dd93e7380a5d395a8edc0054cda237a0231144cc7	2026-08-07 12:49:23.944+00	2026-08-07 12:59:23.944+00	2026-08-07 12:49:23.954+00	f
29d40cae-4dc4-47d8-817d-26a1197dbf7e	09574143751	6f03d02e1f3b7360e6022e0cb22fa16e8260f1a02e1dc49dc3db01bf48fe5d9d	2026-08-07 12:49:23.99+00	2026-08-07 12:59:23.99+00	2026-08-07 12:49:24.001+00	f
345111e5-bd9e-4900-9b7b-9628842ab46d	09399133266	40c36e12b82e56da200ecef3b3cca10a2b4413dd76bfb0cfdca1c69b5c3ecf23	2026-08-07 12:49:24.012+00	2026-08-07 12:59:24.012+00	2026-08-07 12:49:24.022+00	f
bab27065-1c98-4022-927c-d381aefe804d	09960017196	5117169b2eba569cadc3f5296cefa0d63f8358f60f1ea29e344e4934e0f4f1ab	2026-08-07 12:49:24.197+00	2026-08-07 12:59:24.197+00	2026-08-07 12:49:24.209+00	f
35189857-b890-4c1b-a92a-25f007028787	09594251630	ca4e6ae2a4f797a5bb4398546a323fcd69f721b6f907a276906c5ef1dd8d00c5	2026-08-07 12:49:24.246+00	2026-08-07 12:59:24.246+00	2026-08-07 12:49:24.256+00	f
ad2a3271-a894-4aef-ade1-eee3a3643450	09669527369	7cd36253a38d61f555e7c835eceb815a4b3d8b40eb61b1b0cde0440e2114b0ac	2026-08-07 12:49:24.268+00	2026-08-07 12:59:24.268+00	2026-08-07 12:49:24.278+00	f
11bef982-d82d-4685-a536-4685fdaa856d	09939155852	8c01a20a56a3d2a4689692ba2ffb58a67a5e626879af1966f3d5a5526a47425e	2026-08-07 12:49:24.381+00	2026-08-07 12:59:24.381+00	2026-08-07 12:49:24.391+00	f
9cf861cb-a9ac-4dce-9d42-5d841988c30c	09721076147	f78eacbbbd7a65adcd23e108fef1d540d16cce634ab1ff3cd7da9ace2e25f300	2026-08-07 12:49:27.071+00	2026-08-07 12:59:27.071+00	2026-08-07 12:49:27.638+00	f
7c178229-de14-4c0e-a29b-fcd8dcc5f5b2	09885660883	819fd8821255bdcec3ce069da93eda6a87007e8b610d81847102160a7a722b25	2026-08-07 12:49:32.043+00	2026-08-07 12:59:32.043+00	2026-08-07 12:49:32.11+00	f
1b7cc9d2-425d-4863-824c-1f5add233a96	09885660883	4b7b025bd7ae7cb048000dca968b116790f91e102d0b5fb8efa188b32a60d26b	2026-08-07 12:49:32.157+00	2026-08-07 12:59:32.157+00	2026-08-07 12:49:32.174+00	f
c5c3503a-0e92-475d-b0b3-8fb75b839df2	09627117598	de4c015a6de5bf17b7335b7b4bc22db0b335bf0f656df081cfd7ce3fe2cbac25	2026-08-07 12:49:33.851+00	2026-08-07 12:59:33.851+00	2026-08-07 12:49:33.862+00	f
274a44e9-851c-43a8-91ee-33d215342975	09907035470	865f64e6974a25b1966d061b86adca14fa6d4eb64c287a1be1971595f6d3b9f0	2026-08-07 12:49:34.724+00	2026-08-07 12:59:34.724+00	2026-08-07 12:49:34.734+00	f
d8aa67bc-a986-4fc7-bfb5-04e99e9886bf	09592290534	8830f70c86e3258bd4ecd88a0ce06464f9f32cb00897b2346fb215485530795e	2026-08-07 12:49:34.794+00	2026-08-07 12:59:34.794+00	2026-08-07 12:49:34.803+00	f
1460068f-8df4-48af-a4ce-ceab6cf4b839	09420021328	99fdbb07b015618b1e09ca002b3d5950175778961f7c31834d82e97c7b08a9db	2026-08-07 12:49:34.817+00	2026-08-07 12:59:34.817+00	2026-08-07 12:49:34.826+00	f
63b6c072-1c07-4f37-bfcf-a64be919f674	09969598914	5a822db8db07acf25ce3f73be3ff7a655d36a7209ddd3b53ada2e591a1d51cee	2026-08-07 12:49:37.531+00	2026-08-07 12:59:37.531+00	2026-08-07 12:49:37.543+00	f
a3064a5c-0b15-4223-983b-d2b0182e17ee	09168331561	a3603fdc597bb7e8afa7e09773bae109bc926574b0866ba4ecc39dbedebee09d	2026-08-07 12:49:40.802+00	2026-08-07 12:59:40.802+00	2026-08-07 12:49:41.471+00	f
6209ed63-4787-41c8-a254-50ee64cfec17	09168331561	c0fb098a9c29606de8330a635f2bd932fb479f1c860c91b327631b729ee51662	2026-08-07 12:49:42.275+00	2026-08-07 12:59:42.275+00	2026-08-07 12:49:42.288+00	f
322c51b4-3c0f-49e7-b465-220f1afea180	09919458344	7957e7c5d9654cde390a447d72418eb897c64f3ceabb1d779eefaf967c6940ce	2026-08-07 12:49:42.462+00	2026-08-07 12:59:42.462+00	2026-08-07 12:49:42.473+00	f
52fe6f7f-6f43-4199-b4cf-318fe2c6d214	09120000001	ebfd4fd5da655746b24770e403413cb25c27c341af4292ee2f9ee32030c26ad4	2026-08-07 12:49:42.49+00	2026-08-07 12:59:42.49+00	2026-08-07 12:49:42.501+00	f
43ab1db2-31dd-4e58-86e6-79ba1e3ee6a4	09120000001	3b03210983553d5e09cfe55cc3e119552c6a32fd0e0d609b33d502fa794d75a3	2026-08-07 12:50:24.586+00	2026-08-07 13:00:24.586+00	2026-08-07 12:50:25.152+00	f
a634d0d1-45fa-43da-82c9-2a9d718adeca	09120000001	a9a197e5676a8629e7763830e77a82a89eadda55fee9464cb35424f2d6ef3929	2026-08-07 12:50:03.654+00	2026-08-07 13:00:03.654+00	2026-08-07 12:50:04.22+00	f
e6328b3e-f17a-4696-9673-97e978319c2e	09120000001	96c9b848eff149737264e4a9bb61ad14090229ed0066e55ca63f53ef6291eeff	2026-08-07 12:50:44.938+00	2026-08-07 13:00:44.938+00	2026-08-07 12:50:45.523+00	f
020dd630-32d5-4f59-b955-8c39a0bfcb0a	09120000001	4d4e69cf73bf336d26c080c95a7680040b8e011680ea078fe8a1617914663168	2026-08-07 12:51:06.051+00	2026-08-07 13:01:06.051+00	2026-08-07 12:51:06.634+00	f
1d0c14a3-48b8-459c-902f-a99891d03667	09509568890	a7823739b2c7d524a126f778b107d2936835e73d4367d20a26468272da80a6f7	2026-08-07 12:51:39.732+00	2026-08-07 13:01:39.732+00	2026-08-07 12:51:40.316+00	f
541564ba-b476-4e0a-81d5-2b897af8e037	09120000001	3b6ec7592a6f639c6233bc98f7f01fad5ad13e91b303bb5e1626df34ddb79edb	2026-08-07 12:51:42.932+00	2026-08-07 13:01:42.932+00	2026-08-07 12:51:43.499+00	f
d1264a78-ee67-434b-9f77-e4d3aae8ea95	09507246440	44b30b9bfbb557519f8b3570638a185019c358b482fe984f93c0a00661dad538	2026-08-07 12:52:29.53+00	2026-08-07 13:02:29.53+00	2026-08-07 12:52:30.23+00	f
2b10a2f4-436b-471c-88b3-11c56857b52d	09120000001	d5f69602ff6ee86c9b6784a0815c6f6a108e3343b8fc01bc5f0d21a145a18879	2026-08-07 12:52:32.896+00	2026-08-07 13:02:32.896+00	2026-08-07 12:52:33.462+00	f
123c9ccb-c6d4-4e3a-a627-8fee60d558ac	09120000001	2615744a9df8c6362d6dba1d43abe12d1d1234e5bc1e5e1438d235dbd02829a2	2026-08-07 12:52:52.38+00	2026-08-07 13:02:52.38+00	2026-08-07 12:52:52.945+00	f
d413d6dd-e837-46ae-bb0a-c345a59da512	09120000001	61402eec1f2566bbf6d53d54fa68d2822ae0681be55ff9019471e6ee892029aa	2026-08-07 12:57:00.532+00	2026-08-07 13:07:00.532+00	2026-08-07 12:57:00.556+00	f
8e1f69fe-945b-492b-8ad5-56644683e71c	09120000001	be1d00f4ab26b73215b6cbd045971cfff976bfc21f8844025a07f2140280d656	2026-08-07 12:57:12.835+00	2026-08-07 13:07:12.835+00	2026-08-07 12:57:12.851+00	f
c452fd41-d54d-44e2-9acd-55e277434bf7	09120000001	3841926ed8cd0de0cf232461c6ca1a5d366d14e079309fdafed30b67206dcdc4	2026-08-07 12:57:35.595+00	2026-08-07 13:07:35.595+00	2026-08-07 12:57:35.611+00	f
0ad28b9c-1c35-4462-b727-cba4ebc6604b	09304116941	6e4de12b051f58ac59d91419c87897d878362fb472070e804a2a96c579f9bc9a	2026-08-07 13:02:21.435+00	2026-08-07 13:12:21.435+00	2026-08-07 13:02:23.016+00	f
b8b8a442-1e9f-4d17-801d-d1a76a7436af	09127969845	a1c5d33c20b3f63e5987e7538928af6dae34feb8862b0cde3da51133da6e7213	2026-08-07 13:06:09.893+00	2026-08-07 13:16:09.893+00	2026-08-07 13:06:09.905+00	f
4a58ef4b-a937-4d6f-a677-058a88523f88	09137969845	51cae57b512341a5470f2eccbd050b4c021398aca34a3974abadfa1d5ee44485	2026-08-07 13:06:09.954+00	2026-08-07 13:16:09.954+00	2026-08-07 13:06:09.963+00	f
8a0509c3-b525-4246-a26b-cfec49dc9879	09147969845	e6d5bdb0746204b97c716b047b622634f8c13ff419e538c91cbbe266f41a9f5d	2026-08-07 13:06:09.975+00	2026-08-07 13:16:09.975+00	2026-08-07 13:06:09.985+00	f
14caa1f1-5944-42f5-8d46-ed6519bf83d7	09157969845	1cc081337a79fce7e8f6ef0fb739f6e29f09282e88b9acbd00d44b885522210b	2026-08-07 13:06:09.998+00	2026-08-07 13:16:09.998+00	2026-08-07 13:06:10.007+00	f
aefdc8c0-f56b-4ff8-86ba-95bd2c748248	09127969845	25b6381e76bf51faf4b8e18888886469458884059e3b862bc93864d702db2909	2026-08-07 13:07:34.492+00	2026-08-07 13:17:34.492+00	2026-08-07 13:07:35.346+00	f
10bacbbd-33bd-4fd3-a13c-f5c06e2db93a	09127969845	8e29cdf74e9b33612d05cb8f7f8e07c9dcdbe389fb39caf7c00ca5cecbca55a6	2026-08-07 13:08:35.443+00	2026-08-07 13:18:35.443+00	2026-08-07 13:08:35.46+00	f
667aec4b-57db-447b-962e-0c0d129d9396	09127969845	0c74f761530172882f7baf2eec83a07b4bba0f783a548f83b3affd5a0553be50	2026-08-07 13:09:54.156+00	2026-08-07 13:19:54.156+00	2026-08-07 13:09:54.173+00	f
e930e60b-889f-478a-b712-e13dc1a40be0	09157969845	4b943744fbe85ed290764d1b34a92f3e73a33616a6e53f4babe3e2ab0d39061e	2026-08-07 13:09:54.315+00	2026-08-07 13:19:54.315+00	2026-08-07 13:09:54.324+00	f
e3a2e52f-e710-4c3e-b531-142d7ac7b4c2	09167969845	07097dcc5eb87b297643e6e8f83ae031e383502d1de13312f7f8bd8a61a78443	2026-08-07 13:09:54.334+00	2026-08-07 13:19:54.334+00	2026-08-07 13:09:54.343+00	f
ac270fd1-98a4-4843-9369-0411c367a5c7	09177969845	7ad4ceec81452321601483b4cde51bf6b7356271a2c6e6ec027bf5db981be076	2026-08-07 13:09:54.356+00	2026-08-07 13:19:54.356+00	2026-08-07 13:09:54.363+00	f
fd28f2d7-41c2-4923-bcbb-37f30c8644fc	09187969845	f7ea95d6071ef23780818168fe8487df4b7eca7d8381f9823973b70af35b589c	2026-08-07 13:09:54.377+00	2026-08-07 13:19:54.377+00	2026-08-07 13:09:54.385+00	f
dcb54090-df9b-4497-97c2-5a22ee62709f	09127969845	7cd506c3981851fffc4412695ac147e4ff6849412891a1d6bf254df1aa182d4d	2026-08-07 13:12:19.66+00	2026-08-07 13:22:19.66+00	2026-08-07 13:12:19.679+00	f
47ab7514-fc7e-493f-95fc-04640f4b348f	09157969845	73954f24bd5898111f33f7c5b684a139c8b6f37dcbe712fa9d71e02d60010392	2026-08-07 13:12:19.687+00	2026-08-07 13:22:19.687+00	2026-08-07 13:12:19.696+00	f
9a52b9a2-2f29-4226-8f3c-a0f37c3c14fe	09127969845	b0109ebc1466447f0fbead55bbae87b6bf94830aae46c8be99bc1ac1cfc36ddc	2026-08-07 13:13:01.11+00	2026-08-07 13:23:01.11+00	2026-08-07 13:13:01.135+00	f
d916f9df-9eb8-4948-9a8c-f67fd4ef1ef0	09157969845	8b2af77a86206a30ad875c74273e2dc26a7569d76c55592c1127285bee30c292	2026-08-07 13:13:01.144+00	2026-08-07 13:23:01.144+00	2026-08-07 13:13:01.152+00	f
ecac10f0-aa76-40b6-9ca8-7e75efd3e9e4	09127969845	df8dfca2a5e1bfd46a81ce0ed7c69aecc575c2d81b46334ef8c35de5a93df20c	2026-08-07 13:37:24.231+00	2026-08-07 13:47:24.231+00	2026-08-07 13:37:25.097+00	f
bd3138b7-1535-4d16-8f7d-b091cf543018	09127969845	f7343c9a5b3e6464391ff3df650a52118c6f827002c2cf11f965ee6233a869fe	2026-08-07 13:47:45.274+00	2026-08-07 13:57:45.274+00	2026-08-07 13:47:46.455+00	f
de4536ce-51cb-4f71-9c69-a5770931b853	09712858829	e6fac3f712e34eda87067b3b85ad01d831c4180c44a34e781429028cb3b3c804	2026-08-07 13:52:16.96+00	2026-08-07 14:02:16.96+00	2026-08-07 13:52:17.806+00	f
aac073a2-689b-4082-8a0f-cf99ee4f87eb	09875557101	b78297ca6961f6dad731967f3bfa616c5d272e34a0d17a0b81244a3da478f6d1	2026-08-07 13:52:22.14+00	2026-08-07 14:02:22.14+00	2026-08-07 13:52:22.22+00	f
293ede08-8dc7-490c-a6bd-de1e466c47fe	09875557101	4a3c1edd332a0d714b809fb62e79f57c04421afc909f4811efaa8f242990f866	2026-08-07 13:52:22.269+00	2026-08-07 14:02:22.269+00	2026-08-07 13:52:22.289+00	f
cc7b72d4-661e-4455-994b-3aa7637c5c8b	09636231531	6a21832e3ac5d45f5b4dd890b6899f3c50bc0cc8c85fef4af0edbe2210d3a2e2	2026-08-07 13:52:23.874+00	2026-08-07 14:02:23.874+00	2026-08-07 13:52:23.89+00	f
92d86d22-41da-44e9-9e41-92aebf43ea9d	09923181418	50dfac079b41b11974140927431df9a176b1c095370f1518c6cd8ac7ffd36ccf	2026-08-07 13:52:24.862+00	2026-08-07 14:02:24.862+00	2026-08-07 13:52:24.875+00	f
50174da1-3db6-44f1-aaa4-36603c1a6b5e	09506049621	78bdc6c0d310f9849424406bd4a6affb7148f1839b5186046354491e7010d966	2026-08-07 13:52:24.945+00	2026-08-07 14:02:24.945+00	2026-08-07 13:52:24.959+00	f
6d9760fb-6958-4d9d-b87c-fc0a911df7c0	09464026107	7191c935ede005421f7408319acc659599c70f309f19522a02cf80cbe7bb223c	2026-08-07 13:52:24.972+00	2026-08-07 14:02:24.972+00	2026-08-07 13:52:24.984+00	f
16f10398-e285-43ed-88af-003963b8b546	09932765010	ac29ba30344263b8c151fcdd8358c9d42bff7c0f5d68e10ba30f71069ee1909a	2026-08-07 13:52:27.728+00	2026-08-07 14:02:27.728+00	2026-08-07 13:52:27.742+00	f
9b22a0f4-504d-410f-8025-328f8c4ecefb	09184336365	55fa4160b79eb196889e7e2ef0285ad8ac0b3576410f10b43c41e820cd18c4e9	2026-08-07 13:52:30.934+00	2026-08-07 14:02:30.934+00	2026-08-07 13:52:31.602+00	f
f73fd909-c79f-4561-975c-b976e49b0952	09184336365	f6e0bff7e54c06d2d4c75292a619bb6e90b1d74c84fb2a0a112192932c1e7457	2026-08-07 13:52:32.405+00	2026-08-07 14:02:32.405+00	2026-08-07 13:52:32.417+00	f
3e56b6da-d097-4647-9b88-07cef6cbd295	09911329502	42760a69d199f9e56b909d6169047d6b063210b23ffed9d281c7debb9d859a90	2026-08-07 13:52:32.584+00	2026-08-07 14:02:32.584+00	2026-08-07 13:52:32.597+00	f
4fed3173-a6a1-415b-8bec-82a7b8953c75	09711199414	79e8b841d43ad610932d9046aedc1c9c95485b841e208aee76a7441b86ccfd7f	2026-08-07 13:54:31.547+00	2026-08-07 14:04:31.547+00	2026-08-07 13:54:32.131+00	f
c49956a9-4790-4f19-87ad-0117819b23f3	09887853376	815ec3111b264fdd1eba8e73cd92a84f799bff54e7adc909bc9a9692450517ee	2026-08-07 13:54:36.432+00	2026-08-07 14:04:36.432+00	2026-08-07 13:54:36.514+00	f
5bf85b89-84b3-4e94-8e7f-3f5eb596c2a1	09887853376	f0a711b36f5fd6f6b8d68565d59d5b8602963382617da9eab8b4f6f95c40bce2	2026-08-07 13:54:36.568+00	2026-08-07 14:04:36.568+00	2026-08-07 13:54:36.589+00	f
9360735a-8177-4bc8-82d4-abd75a5ed3eb	09622834500	7654f7b69428b7e8e7513fd4c1db85da97ecebde583d6876ea8851df1dbe5f3a	2026-08-07 13:54:38.188+00	2026-08-07 14:04:38.188+00	2026-08-07 13:54:38.204+00	f
409a2976-044c-4d08-8999-ec71f6b44a3d	09778220867	338f7f58b2370bfdcacc65bcb328921eafb083c4f7c133519d4f7a2915f4d11d	2026-08-07 13:55:49.734+00	2026-08-07 14:05:49.734+00	2026-08-07 13:55:50.601+00	f
628deae3-2f9f-48ad-affd-38285884ef87	09803664272	771cdf8cd8060d64fe9562b5b69ba945c0566613e753eefd95c2683eb06f0abf	2026-08-07 13:55:55.051+00	2026-08-07 14:05:55.051+00	2026-08-07 13:55:55.114+00	f
160f5a29-2e19-42c2-9c31-c860e1d61c58	09803664272	4ea892adb00e2ed0a13ee1ba35bff50a0ccde7da409ff4d1e6362d407637ae8f	2026-08-07 13:55:55.161+00	2026-08-07 14:05:55.161+00	2026-08-07 13:55:55.188+00	f
fecc2308-d64e-4f35-98c6-e200784f0740	09605325630	fdd35e5fad3cf534e241311a8b8ccbb0d5239bd52d8e6f69ae2074398af02027	2026-08-07 13:55:56.84+00	2026-08-07 14:05:56.84+00	2026-08-07 13:55:56.864+00	f
a722092c-2a07-4fcb-9128-ea558c37eb95	09984218203	cf249d1512c874efbb0cdffde7505a07b166c8ad480b9d2897559ac6d1c3e303	2026-08-07 13:55:57.811+00	2026-08-07 14:05:57.811+00	2026-08-07 13:55:57.83+00	f
374ee244-3ec5-415e-962a-a8f0871d4203	09582726221	1c052d3dc6fffd18779c39f07c3055a4c020ee3bf156d68db78d8393a8d46e51	2026-08-07 13:55:57.912+00	2026-08-07 14:05:57.912+00	2026-08-07 13:55:57.926+00	f
fe3f7642-50c8-4865-b082-917010c1253e	09428663627	3c00c7014abd7c0e8e3a1135f15f19184531eee52ecf1bbb5c5f70dc9b3c2e09	2026-08-07 13:55:57.941+00	2026-08-07 14:05:57.941+00	2026-08-07 13:55:57.956+00	f
eb251420-aacb-48d2-b6b2-ca6bcd350aea	09986475629	ea27eab0c53fa1788a0356dab9c25426ec0c27268313c1d189406bd8b2d06f08	2026-08-07 13:56:01.064+00	2026-08-07 14:06:01.064+00	2026-08-07 13:56:01.081+00	f
00f671bd-d6ac-4b4b-a89a-b4607c46d2a1	09114060548	27c3d180f1adb0480f5e40ab302f07f007e93af34f28ec51371f770da6dc3f82	2026-08-07 13:56:04.395+00	2026-08-07 14:06:04.395+00	2026-08-07 13:56:05.081+00	f
ea14b3e8-f591-4c31-a55a-ac06b86ddff1	09114060548	4a65dfa32b7161cab1c855eeebf8f5f7d6de76e2660086b068ad60c7338070bd	2026-08-07 13:56:05.886+00	2026-08-07 14:06:05.886+00	2026-08-07 13:56:05.9+00	f
058cbf87-c4e1-4d18-a30c-9b7bf3a85d47	09963216717	cc8b79517f2377afd6da69c79531cbf997530dd705eec58444cbca99b8118277	2026-08-07 13:56:06.095+00	2026-08-07 14:06:06.095+00	2026-08-07 13:56:06.109+00	f
c612b78a-7401-45de-b24f-a591a703fa52	09120000001	147328ed056385630599cfd7e0e2d71d7a644b6917d6b8b6e76a2d38b87af5d8	2026-08-07 13:56:06.129+00	2026-08-07 14:06:06.129+00	2026-08-07 13:56:06.142+00	f
94b51240-6d4e-4ab9-af30-dcf2fcb35d6a	09908245870	f9e960aa360b27dd92092b1da48a925cea9327855ebdbf7253db2d63e7b314fd	2026-08-07 13:56:12.485+00	2026-08-07 14:06:12.485+00	2026-08-07 13:56:12.496+00	f
64687759-1741-45d3-b0a4-dd0e4cc2304b	09908245870	5ab8abc2fe5ba0196fb9122b87028caf7343a987a9e38bb6a57c17851ca790fe	2026-08-07 13:56:12.507+00	2026-08-07 14:06:12.507+00	2026-08-07 13:56:12.517+00	f
7af5cac5-a33d-449d-8048-d2c948b714c5	09901109792	1142b0b17f3d4ba9b3d1f6e85955b4746465d5114ff5507d8386e8cedf590aef	2026-08-07 13:56:55.132+00	2026-08-07 14:06:55.132+00	2026-08-07 13:56:55.221+00	f
72072463-979e-44d8-a3f3-e26b8fc7ca28	09901109792	10cd36db31d195f35f0e9a9eaa3750131d7d3e05b322e97840f7358e9b911ba5	2026-08-07 13:56:55.242+00	2026-08-07 14:06:55.242+00	2026-08-07 13:56:55.258+00	f
d661f02c-eb72-42fb-b82e-d590e5f65097	09901109792	a872acabacb7bb333b8b0f6afe5d94066719d5fb08debd66e97579b6f3c93755	2026-08-07 13:56:55.287+00	2026-08-07 14:06:55.287+00	\N	f
ea1c9863-db10-4eae-a3d9-ff9359dc2547	09979966822	496b7b3ff2f46795842b28a89732b754d5404ccbccbb57a594847e461f2eaa10	2026-08-07 13:56:55.437+00	2026-08-07 14:06:55.437+00	2026-08-07 13:56:55.451+00	f
ff41615a-1e40-4d3f-b14b-9ea8af745c22	09413915894	7787df12cd83f1e2b74caef59dace8b6500c9581a561f3efb5f2eddc75ce96d0	2026-08-07 13:56:55.492+00	2026-08-07 14:06:55.492+00	2026-08-07 13:56:55.512+00	f
c8789431-753c-4a1c-9d1a-972a53d22d5a	09517111469	c4d1b2cb989df0dd64a76e50fba28031fc0abdad2d7272d62ca21355f5a0933b	2026-08-07 13:56:55.568+00	2026-08-07 14:06:55.568+00	2026-08-07 13:56:55.582+00	f
0a65baf1-aae9-4751-9661-a7ac959c49b8	09793559161	56eb7189d108abd5a6b0bfbc5dd8147f6a7d614639c51d25944aa64bddfb9986	2026-08-07 13:56:56.057+00	2026-08-07 14:06:56.057+00	2026-08-07 13:56:56.072+00	f
c09ab845-233f-4680-8f1b-b1af03433895	09901951017	b8cbf3dc6e0748e024b9df787ada757c3840ef8db32bfc14c4058fe5218b3149	2026-08-07 13:56:56.126+00	2026-08-07 14:06:56.126+00	2026-08-07 13:56:56.141+00	f
53b0fc3f-57a5-489c-b38a-49e582503b8b	09992984304	7bed3fc4fb4a0522b97e05d325e5b9ab318930ed29ec0a24f6c9ace2ec58a472	2026-08-07 13:56:56.27+00	2026-08-07 14:06:56.27+00	2026-08-07 13:56:56.285+00	f
2ff67326-51da-4d22-99b1-2c41fe0d2f6c	09556213208	7f13e8528b8fc64664a3cb205de584a31eccd20bfbbff3477471abbdaa38d4db	2026-08-07 13:56:56.342+00	2026-08-07 14:06:56.342+00	2026-08-07 13:56:56.36+00	f
7861d9b3-7faf-46c3-b911-87970d9ad5f9	09434171490	0c9bd1f1638b676ce005d19c0879c808edf5d23d2daf68d2a79fb09a622e77e4	2026-08-07 13:56:56.383+00	2026-08-07 14:06:56.383+00	2026-08-07 13:56:56.396+00	f
89ce3057-0d64-47e7-94c3-f7c38e944bbb	09112285447	50d0ef52826ae031b4b607ece48134e4a70f56c6fd21edbfe8320f821a5e0805	2026-08-07 13:56:56.429+00	2026-08-07 14:06:56.429+00	2026-08-07 13:56:56.444+00	f
5fb7b088-6372-41c2-8d3f-765e90a1bdb9	09240067066	65929ed04756035a9149426922cdc745ad8117593439af803039266a69a98460	2026-08-07 13:56:56.457+00	2026-08-07 14:06:56.457+00	2026-08-07 13:56:56.471+00	f
bbb448df-495b-4479-94cc-78f8ca903cf3	09963498529	859b01154689d2c3457fc54f19077d2bd18e6cdc7efc322217258c6b829c179d	2026-08-07 13:56:57.328+00	2026-08-07 14:06:57.328+00	2026-08-07 13:56:57.343+00	f
4b38e86c-e4d0-451d-8e77-3c296aa9f25d	09419149438	5bf573fb6984a3d9905df14650667ad1511f98612eb06c5a2652ef793e7e00ab	2026-08-07 13:56:57.368+00	2026-08-07 14:06:57.368+00	2026-08-07 13:56:57.383+00	f
f1da3ca5-614a-4c3d-bb1c-230c8ae4da89	09547914046	135e17cbd31fac3da0e3ff7ccce0f90e63c76c9266593fc485e97a6653358c49	2026-08-07 13:56:57.431+00	2026-08-07 14:06:57.431+00	2026-08-07 13:56:57.448+00	f
86ef3db8-7ac3-41f6-9c54-2b400bca923f	09359436507	4874e78fcac3ad77a53d95cad5509a461462664dec900e635be386dae11f9569	2026-08-07 13:56:57.464+00	2026-08-07 14:06:57.464+00	2026-08-07 13:56:57.478+00	f
caaa9261-b6d8-4d3e-9b4d-a6ba87909415	09979655003	3cdc77e9429b8f9e6071e4b390e6d14f53beea69757aaed00466d86f20c04276	2026-08-07 13:56:57.666+00	2026-08-07 14:06:57.666+00	2026-08-07 13:56:57.679+00	f
7bb3199c-6797-4216-8965-14b3824e3839	09558245740	5c44582a0b333c1e9e4acc5ab2d4d6033569b7e0f7cfe85d331b446c849d5328	2026-08-07 13:56:57.721+00	2026-08-07 14:06:57.721+00	2026-08-07 13:56:57.731+00	f
7d89419c-8755-49e5-b34f-ac63093e062b	09681245917	380f95e27732cf5bd00a4980a7dc9392eb6b928d3336380aef1f9fa809129d2c	2026-08-07 13:56:57.74+00	2026-08-07 14:06:57.74+00	2026-08-07 13:56:57.749+00	f
ba959c97-5ab8-4f61-b26e-04a22475f9b0	09912120868	3c7d6bab21fd747214355c057803685e73c6d58dc5509e01d5bdf8562d516c0e	2026-08-07 13:56:57.865+00	2026-08-07 14:06:57.865+00	\N	f
346a1c82-0cca-4e38-95b6-120a94f59584	09930081918	8500790db47e20847a1a75b0181ce57cbb819d219fd7d5d2b73245438bb5e0d0	2026-08-07 13:58:31.909+00	2026-08-07 14:08:31.909+00	2026-08-07 13:58:31.995+00	f
8c46f8c8-5dcf-43e7-a79e-74a1a5a33135	09930081918	378f6d07e60f283363fd2c07ac9e75cb73541f26f9c991e97cfe16c9491a95a9	2026-08-07 13:58:32.014+00	2026-08-07 14:08:32.014+00	2026-08-07 13:58:32.03+00	f
a603c8bf-aad7-404f-ae2d-439cac2fea19	09930081918	3a78b038abfb14669ec205406c2625dbd267b6259e0ea5944c746dc342c6fe0a	2026-08-07 13:58:32.063+00	2026-08-07 14:08:32.063+00	\N	f
10c278a0-7513-49cd-a699-14606a33a770	09949436825	5ddad865a0c966963b36ce04f79f84f9478a85e4d5cc8224bd785f25fefb25d2	2026-08-07 13:58:32.206+00	2026-08-07 14:08:32.206+00	2026-08-07 13:58:32.219+00	f
babd5252-7090-42c2-a1c0-1dac49b6ebcc	09494155201	7e1b1aebeb3a43b1c3d84da37b051454fbcdfc66be84d86c60be435dea118dab	2026-08-07 13:58:32.243+00	2026-08-07 14:08:32.243+00	2026-08-07 13:58:32.257+00	f
4f4b2c9d-79df-4989-b7e4-f393caef75c6	09553550915	5cdb34deeb0f6ee8cf3b950e4a42c829cde110c4eea1e94851b4c800a38c01a9	2026-08-07 13:58:32.301+00	2026-08-07 14:08:32.301+00	2026-08-07 13:58:32.314+00	f
1d0cb1d1-16b2-4d87-b645-0984f2f46cff	09794641109	0a4074aff07ff9848914d9dc39494c9da9aa87b33f736608077a3acbae9a3067	2026-08-07 13:58:32.754+00	2026-08-07 14:08:32.754+00	2026-08-07 13:58:32.768+00	f
f75b14d1-fa40-4470-94d9-5f66df39158e	09913921837	ae1fa116b344a80eb592233d2403f7745b11997e8e17a67f6b1f5284de297082	2026-08-07 13:58:32.815+00	2026-08-07 14:08:32.815+00	2026-08-07 13:58:32.829+00	f
9d7fa20e-ba76-4dbf-b5fb-7f6c6ecf523e	09910729135	127e04916069653a1977e10a84d58c0468587d785dfce42f136ff5381cf7b25b	2026-08-07 13:58:32.923+00	2026-08-07 14:08:32.923+00	2026-08-07 13:58:32.935+00	f
11ea9f19-bfd1-4cc3-b274-6291170c2f4f	09586140863	0836637a0493106fe5e822672a28a00985737a6ac089b7fdfc8e4e46a05b8e12	2026-08-07 13:58:32.98+00	2026-08-07 14:08:32.98+00	2026-08-07 13:58:32.994+00	f
2cb387ba-8f24-494e-b35f-8343f6998205	09406747983	b4be34ee0b3d73d1478bcba5abc3d9e13b42bbecf95a0c9e6ea1d9254568aaa4	2026-08-07 13:58:33.022+00	2026-08-07 14:08:33.022+00	2026-08-07 13:58:33.037+00	f
c4d4291f-90e4-4828-9f04-969650570fd0	09104798073	bbb7dd0da734e024fb0b72edc130f8905336b60056ff00a198192e04e4168ac8	2026-08-07 13:58:33.069+00	2026-08-07 14:08:33.069+00	2026-08-07 13:58:33.082+00	f
5032aaec-29b1-4c97-9ace-e7425e1b780c	09234923294	838f72c1c11ccf774a602f9aa703b2b853619246e6a158653e1938b0fa902f5f	2026-08-07 13:58:33.095+00	2026-08-07 14:08:33.095+00	2026-08-07 13:58:33.11+00	f
bd27c2d9-4208-4e19-8322-805eaf79aceb	09939714736	6e468e234b0f8433f103a6426c224a7cde754cc15c4ece1c49f525eecca16015	2026-08-07 13:58:33.931+00	2026-08-07 14:08:33.931+00	2026-08-07 13:58:33.946+00	f
82e48855-c0df-4f91-9c77-ed431d8a722e	09434217528	c72a466909ebb4d3d69f5100024b11063901fe29a46dadb994f7f3e81589b014	2026-08-07 13:58:33.973+00	2026-08-07 14:08:33.973+00	2026-08-07 13:58:33.989+00	f
3106673f-81fe-4d40-bc25-d6633cdd7893	09574223587	1d5a857f9ccc176f093b6e726e6059607c03538829854881380052dede75dae5	2026-08-07 13:58:34.036+00	2026-08-07 14:08:34.036+00	2026-08-07 13:58:34.051+00	f
17b00df7-2137-4ae2-ad12-f21bca906d81	09328560675	0b796f7ed570eeae5cb34910918723345a2a62e3d710dd5d42b51e6a66243b73	2026-08-07 13:58:34.067+00	2026-08-07 14:08:34.067+00	2026-08-07 13:58:34.084+00	f
a689584c-ca04-43c3-b8ae-f4354caa78bf	09966253741	d28ebc0692ab70601601f9de81fe5502c507919dd1ffd59a1a4a36849a24bee2	2026-08-07 13:58:34.272+00	2026-08-07 14:08:34.272+00	2026-08-07 13:58:34.292+00	f
15293a99-dcfc-45e3-ae92-bf10dd1a506d	09591358342	60d6e2a4c6f6dfab54eb2ae2498e32bc8e1fb96351b56d633de44c0d79fe7de2	2026-08-07 13:58:34.34+00	2026-08-07 14:08:34.34+00	2026-08-07 13:58:34.355+00	f
ab80435b-476c-4bd4-962e-dd4bc7ebb7fc	09650671982	0816e4f236f05ce4ad81474169df4e483256ba683c4bd9e34d8721e24abda2d0	2026-08-07 13:58:34.37+00	2026-08-07 14:08:34.37+00	2026-08-07 13:58:34.383+00	f
7a09b061-9b23-42d6-b962-cc3c41bdec13	09937274934	870a0492cd88d1382013261b05de3e55fbdfb10ce56e4e443a01ed9bdadf4d40	2026-08-07 13:58:34.518+00	2026-08-07 14:08:34.518+00	2026-08-07 13:58:34.535+00	f
5b17e430-6a0a-4ee2-99fc-dd50e2461198	09942898011	9dd5d042bce071041c19a6c7e7158b68f692966ebecf7fb2d32a25865a57d0cc	2026-08-07 13:59:01.249+00	2026-08-07 14:09:01.249+00	2026-08-07 13:59:01.263+00	f
afc0406c-b352-45f3-b439-918181aee209	09942898011	80610706811587253233d8ba25823e928a0f6e43b6808ac153671bdd91a6b268	2026-08-07 13:59:01.276+00	2026-08-07 14:09:01.276+00	2026-08-07 13:59:01.292+00	f
58fb55c1-f74d-40bf-bf98-3aafe8a00faf	09942898011	b379525052bd48450602a534e00a18f0aa9aeefe4aa605756e410f9cd6d29ef5	2026-08-07 13:59:01.318+00	2026-08-07 14:09:01.318+00	\N	f
2da575ee-2fcb-403a-b82f-d95ae6ff2090	09922928279	fcbbc3fc28466523d5d45197dab780775b0d7b5341ec08b85c1df1da7c88fd5a	2026-08-07 13:59:01.432+00	2026-08-07 14:09:01.432+00	2026-08-07 13:59:01.439+00	f
29a08392-479f-4ff2-9207-49a4a7ff4b76	09435867300	b8c9318c273417573b524fd53a2bf06af26bb6dfd0232cf07a285e62224bab8c	2026-08-07 13:59:01.466+00	2026-08-07 14:09:01.466+00	2026-08-07 13:59:01.478+00	f
2cbf392e-b9ea-45b7-9a59-8c480b9e32c7	09554353058	192b3bcb56d1ed91a0d34ccad068ff30d522b5c816ac61fec65eba7f6b6a41a9	2026-08-07 13:59:01.525+00	2026-08-07 14:09:01.525+00	2026-08-07 13:59:01.542+00	f
29107af1-0aae-44e8-ac99-e4ff56d57d49	09740635248	59c1d86ca21a34b725debfe3b6e4fe67e07b47be72a1a25fa6016492c293958a	2026-08-07 13:59:02.004+00	2026-08-07 14:09:02.004+00	2026-08-07 13:59:02.019+00	f
b40d2d68-7537-4a29-bd8f-b74e69132d9b	09956367084	5f012aa8887c6acfcedd9ad94b91c9f0d3f523577d102bf74dd371a04039c00e	2026-08-07 14:00:05.713+00	2026-08-07 14:10:05.713+00	2026-08-07 14:00:05.806+00	f
b569839b-c822-494f-a18a-28c58c9394e2	09956367084	6b7d7b00437c49397dd220c3a2ba10556a81af0365af3a1960d8d106979bcb94	2026-08-07 14:00:05.826+00	2026-08-07 14:10:05.826+00	2026-08-07 14:00:05.842+00	f
0013a76b-a2bf-4978-866d-139d1bbb2c44	09956367084	896af825fa80044e504d2a37acb44939c0c0d82c8c7a5b75b82862b951bf0bae	2026-08-07 14:00:05.872+00	2026-08-07 14:10:05.872+00	\N	f
001d6405-77d8-463d-825f-b6a176c38011	09954704851	ab45a39a383ab5ad68b01c7de932b4b81693fe2e930b8474fe8d90c41967061f	2026-08-07 14:00:06.016+00	2026-08-07 14:10:06.016+00	2026-08-07 14:00:06.03+00	f
58b152d1-45dd-4383-a510-0ae76ad6824e	09418264056	965d168d9eea94e2378a774a2517b28d6144839a55f64b9995eefdb2696cf4c3	2026-08-07 14:00:06.055+00	2026-08-07 14:10:06.055+00	2026-08-07 14:00:06.07+00	f
53699923-99b2-4fc8-b2e1-103f624f330b	09507358582	542a743722d91709e206e21cfff8e9b0fa7a26bab8734c1745f80ad9179e2209	2026-08-07 14:00:06.117+00	2026-08-07 14:10:06.117+00	2026-08-07 14:00:06.129+00	f
83704665-e756-4578-9897-2f273f6bf5e5	09798879925	39c95ebc415980ff80602def27fc05214660f0f02d04345123560fd2aa21ee60	2026-08-07 14:00:06.563+00	2026-08-07 14:10:06.563+00	2026-08-07 14:00:06.571+00	f
c4f5a632-ed1f-4a17-a1a4-a98c66a4becb	09989901094	6856c2c777fe4559a532363eae8fdfebc5ef482d87a12711d33a7d2e28faf161	2026-08-07 14:00:06.614+00	2026-08-07 14:10:06.614+00	2026-08-07 14:00:06.638+00	f
d9e26501-5ab8-465a-95a9-b0bb0a55f7df	09941295294	ba67490cdcfefff9fa165037ee86441401ea0eaa0b1917a9a8433df905076ad3	2026-08-07 14:00:06.725+00	2026-08-07 14:10:06.725+00	2026-08-07 14:00:06.739+00	f
ed6e8908-6b6e-4ebb-801c-520d6313bdb2	09589945468	59307d38be55792ca275915ed64aecdda838ecdb98c2db984d04fc9c4609e589	2026-08-07 14:00:06.785+00	2026-08-07 14:10:06.785+00	2026-08-07 14:00:06.801+00	f
aba436b1-0378-4483-8331-c787b517baa6	09494839551	0b9beeb9db98af08ba38656586581a5998e78c00377c2dbcccabc39951ae2c9a	2026-08-07 14:00:06.824+00	2026-08-07 14:10:06.824+00	2026-08-07 14:00:06.839+00	f
73a0759e-8a68-45f4-b745-21c286c3c7d0	09157559992	4c52b1cea21be94af6106b49459e3cf57b08dca58ecc7fe720caa9b480f8a6f8	2026-08-07 14:00:06.872+00	2026-08-07 14:10:06.872+00	2026-08-07 14:00:06.886+00	f
4d8dc287-0135-47ae-a257-47c5fcec12e6	09234031860	95f2853c7c1b02502102c0ee8baeeba352a8dc0d3eae523b50cb6d9fe03c1a36	2026-08-07 14:00:06.899+00	2026-08-07 14:10:06.899+00	2026-08-07 14:00:06.913+00	f
c5758ff1-dd70-462b-95fb-552d30e6a1f1	09943864519	b1c11c6d8bd00f381ea7a30a0c5333f2c2bb5218e165eb42c44bc6b2aad18ae3	2026-08-07 14:00:07.471+00	2026-08-07 14:10:07.471+00	2026-08-07 14:00:07.483+00	f
fb60a139-faab-4f88-83be-3fd6d0da5e62	09424404169	a0186bd9647744704a3db723d5ce316cb15c34823b59dd427b35602099bc79e3	2026-08-07 14:00:07.506+00	2026-08-07 14:10:07.506+00	2026-08-07 14:00:07.521+00	f
34da7a58-9d94-40d5-bfc1-63bb83d7a13b	09544687707	973e962667193c141f286e011086507339101b5734555baaa4a221d84086046c	2026-08-07 14:00:07.566+00	2026-08-07 14:10:07.566+00	2026-08-07 14:00:07.578+00	f
e36d8404-279a-4d89-ae3a-9097a9d271ff	09391985475	021c59ef9f093ff98e5f71a49bdc4309b2d08e06883ae2ac59dba46c3e5c5c49	2026-08-07 14:00:07.592+00	2026-08-07 14:10:07.592+00	2026-08-07 14:00:07.605+00	f
9809fa3f-cd53-459e-b0a6-e0f0f6776336	09944637431	169b2a6f839e37fbda6d3c05857a8ff24c7a9cfcab26415641e2da6458719692	2026-08-07 14:00:07.775+00	2026-08-07 14:10:07.775+00	2026-08-07 14:00:07.791+00	f
56cfe5a3-2ed8-43b0-8172-1140ff8b565b	09537743215	860f8b421cecea38344a73ab1997271212736bb7833bae612697a975706164fb	2026-08-07 14:00:07.837+00	2026-08-07 14:10:07.837+00	2026-08-07 14:00:07.851+00	f
53877ad6-c64c-4367-b108-6deb8740d0af	09644616623	49b66b40fc4d326a17f69d913d9840683501d4612c88e4323eacb6ddff67b096	2026-08-07 14:00:07.864+00	2026-08-07 14:10:07.864+00	2026-08-07 14:00:07.877+00	f
60347dee-d719-418d-9d3a-ed3bebba70f3	09917280447	a264f73c749c94b228c46ac19ad8b05e5d5037bc827928ffbd408c47ed4bb2c0	2026-08-07 14:00:07.995+00	2026-08-07 14:10:07.995+00	2026-08-07 14:00:08.008+00	f
ee4507c6-8594-4ed1-adaf-f243c4c6bed7	09952072090	494cd760496092b579f2a99da137c3ff6dcbfa4f0c0841b9aee30fc04cbd6cd0	2026-08-07 14:00:53.415+00	2026-08-07 14:10:53.415+00	2026-08-07 14:00:53.517+00	f
2b12f233-303c-462a-af2d-6b80a8954a30	09952072090	c84c203edc725d4a5ec3e4822da69bb2696ea9175e21d451c08c7f116cb48470	2026-08-07 14:00:53.545+00	2026-08-07 14:10:53.545+00	2026-08-07 14:00:53.567+00	f
d9d5c43a-3a0c-44d5-a765-97f93f2f19d7	09952072090	c491fcfff57ea447761efa9708532d5055fd247cffe9114a22cfbbb408766cff	2026-08-07 14:00:53.61+00	2026-08-07 14:10:53.61+00	\N	f
71e51a38-e674-4fbb-8f89-eee5229ca278	09904541869	cd8d321924451bc01783cbeb4180ea7779a3aceeb1b79948f250a2004b8e05d8	2026-08-07 14:00:53.792+00	2026-08-07 14:10:53.792+00	2026-08-07 14:00:53.812+00	f
85d2a254-1955-4975-8d06-7bee0c1344c9	09463231917	3e12bc4bae581d30ecf6ea1e194af492c3eedf471afba1766a689344dd5091fe	2026-08-07 14:00:53.843+00	2026-08-07 14:10:53.843+00	2026-08-07 14:00:53.862+00	f
c953114e-4a9f-4d3d-949c-ad59d39c6fa6	09557906403	3b2b0bf0ee14ead9035c33ffe8146d7007f439d0905edcec41a14902c0e21e20	2026-08-07 14:00:53.919+00	2026-08-07 14:10:53.919+00	2026-08-07 14:00:53.935+00	f
b835a5f3-8600-4c50-8f79-4b1a0724b253	09767000332	5b5caa3a55592dd690b67e52daff808bdec28880cb2511d1abbe8c919eb374ce	2026-08-07 14:00:54.47+00	2026-08-07 14:10:54.47+00	2026-08-07 14:00:54.486+00	f
7efb143b-086d-4648-a3b5-bbb0891e4629	09960744548	7d9c0a9726ea0194ad12f01e820f0aa8ecac8dde5cc84a7d3788028f5eb90225	2026-08-07 14:00:54.543+00	2026-08-07 14:10:54.543+00	2026-08-07 14:00:54.559+00	f
9adade9e-3443-44ed-8904-c7cc62b4550b	09966900876	c2aef24be239df72d4401a42da417d6a88e4280812248aac25435b2a77e1a9c5	2026-08-07 14:00:54.66+00	2026-08-07 14:10:54.66+00	2026-08-07 14:00:54.675+00	f
5171ee76-3863-478b-a4cd-239c799a3ac1	09593178546	941e571ffe111bbcacffaaf1b4b6e020427c2579b56bb1408b8f4d423d8d8067	2026-08-07 14:00:54.727+00	2026-08-07 14:10:54.727+00	2026-08-07 14:00:54.747+00	f
685dffcd-855f-4788-b00a-e368b0cf6330	09470850073	a4af53129d660e2136c9fa29a401f7a19496513fa42ba6c67a7dfd1444d51bb7	2026-08-07 14:00:54.776+00	2026-08-07 14:10:54.776+00	2026-08-07 14:00:54.793+00	f
4916ad14-c60c-445f-9e55-4cbf262a182b	09145974930	6f88dce9dfed0b6b31165023843a0598569a7dde29c159ef99f0035ae5b616f1	2026-08-07 14:00:54.83+00	2026-08-07 14:10:54.83+00	2026-08-07 14:00:54.846+00	f
1f2ee211-8e42-42c8-8a9c-2a2be0ce9948	09258163231	6f01642d6e9047affe5d0360194970e1b8c3bc171b1cbfc6d1f7ca6ad57b71cc	2026-08-07 14:00:54.86+00	2026-08-07 14:10:54.86+00	2026-08-07 14:00:54.876+00	f
231446fc-7502-4393-b42d-0c8dbbd5037f	09931868744	a4e489dafcd2f31419b9eff36523e301a87a15853b0443bc555f04053dff6160	2026-08-07 14:00:55.528+00	2026-08-07 14:10:55.528+00	2026-08-07 14:00:55.545+00	f
d998b26e-973b-45f4-80be-d758182e5c16	09410146828	97bd66c2c4f3a923f2373cc70922efead7bc15a907dd0087d3583b340000b6c7	2026-08-07 14:00:55.575+00	2026-08-07 14:10:55.575+00	2026-08-07 14:00:55.593+00	f
81510364-583d-4063-96c4-421a7b2a52eb	09515223287	aedd97075d89dc166f8a0332c223f2a18aabf271ca7ad265c43907a8a3b8b81e	2026-08-07 14:00:55.65+00	2026-08-07 14:10:55.65+00	2026-08-07 14:00:55.664+00	f
98658d8a-f8b8-4a43-980d-5e7a62789f01	09300720408	cd79500bfe254ec52660491148cff033ef9d2b244bb32752a0c234c41e62f429	2026-08-07 14:00:55.678+00	2026-08-07 14:10:55.678+00	2026-08-07 14:00:55.693+00	f
bedb2d55-1815-423c-b949-e22e77b9b617	09935518279	7759f7a4d5dc53325f5c8049528adfdb95fdb894a88a55ec21cb2dbab5ea615f	2026-08-07 14:00:55.897+00	2026-08-07 14:10:55.897+00	2026-08-07 14:00:55.911+00	f
77bd9b1e-8979-4d1f-8a48-f612b95731c2	09545904586	42d5ffd4188eb5ef8c66942bcbc18af24a1d2058e0ea6630c2c7c5880e2a6621	2026-08-07 14:00:55.958+00	2026-08-07 14:10:55.958+00	2026-08-07 14:00:55.971+00	f
45dc4a5c-6b17-4541-9db5-1e84a1e15a00	09634261632	d7b22ef3e5f3868c5c03302af45cc1135a298e58b68b132d7b9b0b54ff251c2b	2026-08-07 14:00:55.985+00	2026-08-07 14:10:55.985+00	2026-08-07 14:00:55.999+00	f
3bff5ca6-8bd8-47ed-9729-679a4f2a4f47	09922017271	6129e8f0ce244cdd80c83aa6ddf8420fa2111f633e41daa0526f08848e0133b6	2026-08-07 14:00:56.13+00	2026-08-07 14:10:56.13+00	2026-08-07 14:00:56.144+00	f
fb6a0ed4-f5ea-40c6-a86e-f9b287ec2f21	09759273626	f00bf02212c3bd44290bbf0242515b7189d21829fba64a1f8b7e5167cb313ad4	2026-08-07 14:00:59.166+00	2026-08-07 14:10:59.166+00	2026-08-07 14:00:59.774+00	f
df6ae12d-0e2d-4d23-9ec7-f0e7914b5c2a	09804098653	4c6a3492a79811818a2b55e9a3025f18213ddf3518e45e2188bc9b3e21cf2407	2026-08-07 14:01:05.131+00	2026-08-07 14:11:05.131+00	2026-08-07 14:01:05.217+00	f
81d6543f-6d4b-4a25-8862-529420edd05b	09804098653	48fec8a30659f164483561c95f9129d6458d0dc9ba05d55a8650401209b65f2d	2026-08-07 14:01:05.263+00	2026-08-07 14:11:05.263+00	2026-08-07 14:01:05.285+00	f
44643994-7878-43d3-ab7b-5ac099001fe0	09914306841	005367eb95d331e83bbb9230bcc51dbcae7452afc0ef6b225d8b78d07462cec7	2026-08-07 14:01:08.279+00	2026-08-07 14:11:08.279+00	2026-08-07 14:01:08.297+00	f
26a6fe76-27a5-46aa-9d66-367eeafb441e	09581221509	35293ec2a7bde97f03f88b3a1cb3054122c16da26a9e06ad3268fc82820478db	2026-08-07 14:01:08.402+00	2026-08-07 14:11:08.402+00	2026-08-07 14:01:08.418+00	f
5bce4128-653b-4420-b689-70a588016616	09479062351	55b3ac0ff7b2de477f5120d3fbb3a5b35f65a9f438fd61c2677c99b4faf70f89	2026-08-07 14:01:08.433+00	2026-08-07 14:11:08.433+00	2026-08-07 14:01:08.449+00	f
49234d37-16f1-4ee7-9c7b-a0695bd4aed7	09931869789	026b488ad15fc909e90860f3903308aee5244c10a50134d91ba6d6f063d5ad3e	2026-08-07 14:01:12.603+00	2026-08-07 14:11:12.603+00	2026-08-07 14:01:12.618+00	f
22314041-4223-4d36-84e0-26be9ab579ab	09137717929	eacabf017efd791b22e1a9f3b41184cab82652e13d85b2ad627e6e5a1fcc1984	2026-08-07 14:01:16.483+00	2026-08-07 14:11:16.483+00	2026-08-07 14:01:17.071+00	f
8697c1eb-a2be-4df4-a3c0-e42dc3a7a5cd	09137717929	06ee118eea77653b1469e6d8067245b3167856a4986733888a0bd762a04600f5	2026-08-07 14:01:17.912+00	2026-08-07 14:11:17.912+00	2026-08-07 14:01:17.928+00	f
0b3f70c0-5b0e-46a6-95c0-03d4eb232f5d	09930411220	d038b2812efa7a902839d3c0ba160cdf14fb37565f82c166af9349221c91c5b8	2026-08-07 14:01:18.142+00	2026-08-07 14:11:18.142+00	2026-08-07 14:01:18.158+00	f
9bbd55f8-4bf1-48a9-ba75-64de7ee7312d	09682195104	3389a132fca8a0a38d416eac5842836f688217c0a6a34a1dd1ad5fde7af70e00	2026-08-07 14:01:07.107+00	2026-08-07 14:11:07.107+00	2026-08-07 14:01:07.131+00	f
0f54afc9-bbdd-4f79-b4e9-d4cff9df53c8	09977444382	081b0c723a366a78eacfb93dec87363cc356924c41b7e28aaaac8acc9c422ffd	2026-08-07 14:01:53.626+00	2026-08-07 14:11:53.626+00	2026-08-07 14:01:53.717+00	f
515ed539-e0cc-49a5-8a2e-a61bd6a3c338	09977444382	87693f014bda5d1c7c96bf50034493cc18a314d43c21e315f2812e1b564f77ed	2026-08-07 14:01:53.735+00	2026-08-07 14:11:53.735+00	2026-08-07 14:01:53.751+00	f
2e60adf8-875b-4dbf-8791-57516eff790d	09977444382	cb2f4f5b710d735d01556a39092813b65d271642aeea36ba7d1fe62ed6645ae5	2026-08-07 14:01:53.782+00	2026-08-07 14:11:53.782+00	\N	f
137e517d-c31e-446f-a208-7decd68c7d47	09990134579	8084b6bed4f246a8347f8c450403c20d61138e7bbb831b5722994fe9c03a9c35	2026-08-07 14:01:53.928+00	2026-08-07 14:11:53.928+00	2026-08-07 14:01:53.943+00	f
f91f09d6-24d7-49cc-a82a-998bc3cc2e16	09430195788	eef37654a08d7cd855434dfec9681e7bb0dd25e1f980ee6c74e52b7ddbbd5b62	2026-08-07 14:01:53.968+00	2026-08-07 14:11:53.968+00	2026-08-07 14:01:53.983+00	f
f27b92eb-8823-4e7d-b374-219963230f48	09537695622	789065c8eaeb7c00154ec377071e088e0736f4b3fc49c43d9fb69879aca730b2	2026-08-07 14:01:54.031+00	2026-08-07 14:11:54.031+00	2026-08-07 14:01:54.044+00	f
705931c9-8d5e-4925-b591-c4f19f52dc27	09751259168	ac39ea6e8aa044a8098a6cb912b0864f2c8628b1dc9d831e53951c68288820ec	2026-08-07 14:01:54.527+00	2026-08-07 14:11:54.527+00	2026-08-07 14:01:54.542+00	f
d29cc4d1-9b2e-4cea-9839-1306552a596c	09904974140	93001a4f55c4f7ec11551066898e6ec31fe810c3d06d96e5a0b409f0641c2571	2026-08-07 14:01:54.594+00	2026-08-07 14:11:54.594+00	2026-08-07 14:01:54.608+00	f
bb081750-9f16-4a40-9bd5-50a50321ef8a	09916809095	74c0409535240cff30250c2d84f45c6dbbbffccbc8b34031f2ab0d725580ba40	2026-08-07 14:01:54.699+00	2026-08-07 14:11:54.699+00	2026-08-07 14:01:54.712+00	f
290a80ed-5192-492e-b3a1-2f84e4b36a0e	09548691083	e19e03fd5adcd9b6fbd85693d8f739e31e5238716263fed252f753e9a3c1212a	2026-08-07 14:01:54.757+00	2026-08-07 14:11:54.757+00	2026-08-07 14:01:54.771+00	f
1cfc627e-3513-4761-a6b3-b98cb78e6ccc	09413458686	41c4384506c0528fe572275260a35f51d72f2f623df5b7e01121fe3c4c3e3970	2026-08-07 14:01:54.792+00	2026-08-07 14:11:54.792+00	2026-08-07 14:01:54.806+00	f
2f24c400-a9fa-4933-8936-0056344714bd	09185407552	45f9ce2fa5f5d8ebfb52d1878bc4038f32949e1572d8cadbfda935c3254f9967	2026-08-07 14:01:54.839+00	2026-08-07 14:11:54.839+00	2026-08-07 14:01:54.851+00	f
507f4f05-d5fe-4532-8ac5-1069a2d7e387	09278343829	5f7d0f56968916b3a7b51b902e940dedf6ef25ec5356545fb501c1d0e22bd8d6	2026-08-07 14:01:54.864+00	2026-08-07 14:11:54.864+00	2026-08-07 14:01:54.878+00	f
7df87bc9-5d56-4fa4-93a9-8a5d6448afa3	09911569556	7489296f14956710f4953c0a9415e7b8bc1bc76b85252a2a0441b6941d007177	2026-08-07 14:01:55.457+00	2026-08-07 14:11:55.457+00	2026-08-07 14:01:55.471+00	f
34543254-e3f0-4c84-849e-d177afeabc51	09406999955	ec14b3bbae588a4966d44d80b123751edadc341bd64a647a2d20e7c869520ef3	2026-08-07 14:01:55.493+00	2026-08-07 14:11:55.493+00	2026-08-07 14:01:55.507+00	f
214b8058-9f85-4d2f-995c-1049bc96bc70	09522515935	ff3d5d1072900fa02bd8cb80bd5ffa3af5953ccfd4701e653e0708493a5d6274	2026-08-07 14:01:55.551+00	2026-08-07 14:11:55.551+00	2026-08-07 14:01:55.564+00	f
58c04ca1-5c03-4c05-95b7-ca364593d439	09300172928	d17facc29af8b4f0e8cceeee1829070124a433b68f61643a12f72b7b163cbbfc	2026-08-07 14:01:55.577+00	2026-08-07 14:11:55.577+00	2026-08-07 14:01:55.591+00	f
e9add6fc-46fe-4685-acaf-07e8a958b571	09944269814	98e0d33431b9072407650d7cfcdb0e9cf90bcafb0e5f2cc9d5ad0b96821f2ceb	2026-08-07 14:01:55.781+00	2026-08-07 14:11:55.781+00	2026-08-07 14:01:55.798+00	f
e7dcc80a-aa6b-49f2-b033-798f40fcf7a8	09571847982	beba1074e351431a04c5fe1ca74dc199637e1562fb2433e3987a9da8abf32ae9	2026-08-07 14:01:55.847+00	2026-08-07 14:11:55.847+00	2026-08-07 14:01:55.861+00	f
2a359eeb-741e-4087-8970-508b526f8676	09645874414	dd45289c2b3e1ffe216707b919193c7638a0351f849239a9c5be751fea609d43	2026-08-07 14:01:55.874+00	2026-08-07 14:11:55.874+00	2026-08-07 14:01:55.888+00	f
671dadd4-7a26-402e-b5fe-7e485d928f13	09960851531	7460c3cdd3b7d28ee8fa63ea19d846a89f0ede4a6cdf8bcb69b4caf6157aa0c7	2026-08-07 14:01:56.008+00	2026-08-07 14:11:56.008+00	2026-08-07 14:01:56.014+00	f
e27099e3-4d9a-44f9-8eec-6c705f5f6575	09753463583	4a4463889d5b24949b896b4aaeed7f33147a0d91d6e7670ba23c537cb9950c00	2026-08-07 14:01:58.763+00	2026-08-07 14:11:58.763+00	2026-08-07 14:01:59.346+00	f
bd50d223-e8ff-4e2a-92c2-95185e7808d0	09893550237	0efdf9ad99d62dc21aca1a5ee8df18dd34bba71fb066ef5ea11b30bb96a6615d	2026-08-07 14:02:03.713+00	2026-08-07 14:12:03.713+00	2026-08-07 14:02:03.797+00	f
53a9ff28-b2d5-4c6d-a33e-0c5b4449d300	09893550237	5af453aa2a30714898ff7f0b9df33d0b28544f51530cb838eb631726f5459466	2026-08-07 14:02:03.837+00	2026-08-07 14:12:03.837+00	2026-08-07 14:02:03.854+00	f
b6778069-9238-42e2-9648-f200d20ce628	09685093258	bd5244cbb3c1c988024cb80d24d6107aa8dec3f6a60a761a562145bc4a77dd51	2026-08-07 14:02:05.551+00	2026-08-07 14:12:05.551+00	2026-08-07 14:02:05.566+00	f
91bc50ed-03e7-4404-b985-41140d27c854	09961895488	b0de2f79454cf3845765b96b2b7254668919e008663185e4fa3d3a60a5882d52	2026-08-07 14:02:06.592+00	2026-08-07 14:12:06.592+00	2026-08-07 14:02:06.609+00	f
77e439b3-23eb-4337-9305-88925a88be62	09567386178	670a4db988ae475a8a51c7e48734bdca8de989392ee15f0e805c5e5ca7d50f2e	2026-08-07 14:02:06.684+00	2026-08-07 14:12:06.684+00	2026-08-07 14:02:06.697+00	f
b9aa6a9c-d888-4384-a584-f1c94052a5f9	09414075144	720d5fc8db17c710ef5c4e79b213b06e236b9a5d636e57acd732d044bb6af50d	2026-08-07 14:02:06.709+00	2026-08-07 14:12:06.709+00	2026-08-07 14:02:06.723+00	f
5104ca07-6f21-453b-92af-61b906eacb98	09929334805	201dde3dcd92bd646e685e7bf20e0dcc4e19bbab8991b5eafb12fab4122ee56c	2026-08-07 14:02:09.793+00	2026-08-07 14:12:09.793+00	2026-08-07 14:02:09.807+00	f
b58de8f6-9bca-4529-a3d7-9b4d4062f746	09106033232	171cc5eb098c675afeb5d43b736035765bbe3d63213304db039e44ef45915b97	2026-08-07 14:02:13.199+00	2026-08-07 14:12:13.199+00	2026-08-07 14:02:13.881+00	f
35018807-29d0-4e0e-901a-dab93f92beb5	09106033232	6b2b49f93e94620da8d63ab8cb44d556a7f602d99c83bca681ca4af47cf33a22	2026-08-07 14:02:14.684+00	2026-08-07 14:12:14.684+00	2026-08-07 14:02:14.698+00	f
88f642af-a713-47f1-bacd-d39bcd38aa60	09982231956	4de0bb983aed419cb728076531fac79218ed249a8f9f18c914f32a7e1e0084e3	2026-08-07 14:02:14.865+00	2026-08-07 14:12:14.865+00	2026-08-07 14:02:14.879+00	f
1a6595a4-38ce-4820-a94c-ab8edd3549a0	09120000001	895616e1de64ab199172ba58ce63985fa07192fd5b766be1ddf7d76226c29b72	2026-08-07 14:02:14.899+00	2026-08-07 14:12:14.899+00	2026-08-07 14:02:14.914+00	f
dc0082c0-a1b8-46a4-8b6a-50ae15b2e0a1	09127969845	a3ca6369fb2f5b66c2c512855eaf1a42c5c365a48ad53244bf826a6625ad9e75	2026-08-07 14:02:23.924+00	2026-08-07 14:12:23.924+00	2026-08-07 14:02:25.012+00	f
76ac8755-c54d-49f4-9398-58623589e759	09127969845	5671f232183f16e355f68000be76bd0d7c0ec8932a14a8a1369eaf5d41b98267	2026-08-07 14:02:29.293+00	2026-08-07 14:12:29.293+00	2026-08-07 14:02:30.094+00	f
cc4fd3e3-b29f-4639-a068-efea4515f4bd	09127969845	cce4f674ddd9ae7bff6848fa2972f2894d936cc0eb9b0a04dfe6b53a1e5cd6a1	2026-08-07 14:11:04.51+00	2026-08-07 14:21:04.51+00	2026-08-07 14:11:05.456+00	f
43fb1305-0e44-42f2-8af0-0f38509c7647	09127969845	409f1ccb711129bb051e39f7a4c052d3243cc23b0ee42aec0efd6fb493655d5e	2026-08-07 14:28:19.896+00	2026-08-07 14:38:19.896+00	2026-08-07 14:28:22.596+00	f
33c4e184-b0ae-4a81-b0e4-c4ac806cd1a4	09120000999	ad6ebbe4d475fe3d546221df82d0da8ee64f6596137f28d8fb554c665f24ecb8	2026-08-07 14:49:07.263+00	2026-08-07 14:59:07.263+00	2026-08-07 14:49:07.373+00	f
ebc0b6d8-0a06-4965-84e9-835d52f0e2f8	09120000999	d13076d78afbaaf442ec3e43399fc1b04ed29ac8d1bbcd09dd35a6644ca27c11	2026-08-07 14:55:46.611+00	2026-08-07 15:05:46.611+00	2026-08-07 14:55:46.7+00	f
48f75fe4-c0c2-43e4-8759-6f19ecf5d72d	09120000999	4617c79c29989afa413106ffbb858b9bb3a2ae2238ece58f3175de91623e0c69	2026-08-07 14:55:56.268+00	2026-08-07 15:05:56.268+00	2026-08-07 14:55:56.288+00	f
7987f499-4f8e-4857-b2bd-176c6884814b	09120000999	60056735dd15fe4f2b35583418c8f388ac058a15f5ab2e816b5a575d85349d52	2026-08-07 14:56:14.86+00	2026-08-07 15:06:14.86+00	2026-08-07 14:56:14.962+00	f
3acc5885-c43f-43db-939c-a8126ba0eab1	09120000999	1506aeb88ef71a6b2edd9ee629f66ab50444494f33f788193d9e49b4d04c7cd5	2026-08-07 15:02:06.671+00	2026-08-07 15:12:06.671+00	2026-08-07 15:02:06.765+00	f
43e522ff-d5f2-4cc3-8c43-d72b67dc6ef5	09120000001	5df2517a0f453f08a5d5dbadeeb9c1a6a5b6db3c684e00715c9bd765a02f56a9	2026-08-07 15:02:06.839+00	2026-08-07 15:12:06.839+00	2026-08-07 15:02:06.859+00	f
3cff0329-c00b-4cc2-9cc5-7b9de82d2ecd	09120000999	aad326d7b06b35f887db291070c0d2c43b28b232aa38c6a52b93644a4367d9d4	2026-08-07 15:08:53.111+00	2026-08-07 15:18:53.111+00	2026-08-07 15:08:54.399+00	f
f30dd66f-1354-443f-8e88-b33336e686b9	09127969845	1ebc9753b3e928b222eb2ed26211d9ebb7f7a06c6c0ea1a036d5d3ec09edec9a	2026-08-07 15:10:09.34+00	2026-08-07 15:20:09.34+00	2026-08-07 15:10:10.438+00	f
35fb05dd-743b-47eb-92f4-47c67028e5ba	09120000999	5bb3e08b7680623a8055bca2ffb6a6b5a74d61c65ea4dbc3d0a30c7e463b34aa	2026-08-07 15:22:56.542+00	2026-08-07 15:32:56.542+00	2026-08-07 15:22:56.645+00	f
f65bdec9-a4fc-4158-8ce1-f95c92bd3fd6	09120000999	df76469f85356c9c46b3442cfdd646bf0afaef752ebe5f35275bca37c38a750a	2026-08-07 15:23:33.058+00	2026-08-07 15:33:33.058+00	2026-08-07 15:23:33.079+00	f
09a78f81-9308-4c9d-9c0d-8c9e109de772	09120000999	8b0ef4792b9ac17b76d24304c98fc52b38fd421becab3286c0a80293ff6826b6	2026-08-07 15:24:09.509+00	2026-08-07 15:34:09.509+00	2026-08-07 15:24:09.537+00	f
5c641338-61d6-44df-8b3f-adaa0617bc68	09120000999	921421d009b2815c647ba6828e5174b0fa2d794e9fe3bd9043d52319b342eff9	2026-08-07 15:25:59.821+00	2026-08-07 15:35:59.821+00	2026-08-07 15:25:59.913+00	f
79d4bef5-6e36-4a17-afd3-4b8a05932de4	09120000999	eadf7fe37f9204e34aaaf0b20060cca6af3ab9d640f6822f95a33278dab9ab1f	2026-08-07 15:26:21.513+00	2026-08-07 15:36:21.513+00	2026-08-07 15:26:21.535+00	f
3cb2c327-488c-44c9-9a5a-f83b22049e09	09127969845	77bb936861611ac77ffba414c347e9ba990d2a7e8ea3cc9de9f6e951e831caba	2026-08-07 15:29:50.62+00	2026-08-07 15:39:50.62+00	2026-08-07 15:29:52.019+00	f
f8cd1960-f29e-4c9c-8223-302fc18fa66a	09120000999	aa8ad2eb2e9694eec24bf123f52d55acaa876fedcfd6ea236a3c76cfed6b55ce	2026-08-07 15:30:43.12+00	2026-08-07 15:40:43.12+00	2026-08-07 15:30:44.219+00	f
6ef9e8e2-a94e-4e89-a072-deba91b686bb	09127969845	5ac236077982eb3a9c46d0dead29b8a1021852019d111b36d200842e50c60cf0	2026-08-07 16:15:21.155+00	2026-08-07 16:25:21.155+00	2026-08-07 16:15:22.195+00	f
f3c40d30-a015-4826-aeac-b2bee074c660	09120000999	a2e521ce11445bd1adf4cca631c56c2e81effe4b1435837ddfbd75cfc7b3dde0	2026-08-07 16:17:20.32+00	2026-08-07 16:27:20.32+00	2026-08-07 16:17:20.339+00	f
0bceda6b-0243-4033-9514-b261c7cc7f4d	09120000999	3630cdb7ef29ce706f838e3cfa98552fe9277a0b7f71b1328b5d9e91cd766002	2026-08-07 16:18:47.698+00	2026-08-07 16:28:47.698+00	2026-08-07 16:18:47.728+00	f
f060bd9e-27bf-490f-82d1-bc45c54de966	09120000999	8994b3986ed9e29e42196f46b7415d4d3bfb4f1cbb82d06680152663d23d525a	2026-08-07 16:19:03.154+00	2026-08-07 16:29:03.154+00	2026-08-07 16:19:03.173+00	f
6e81b32a-4835-4770-b52b-0227d3100202	09120000999	f130cf286a570426c8e14fd354c8820754547644852e5bbd2fc1a1976aa89051	2026-08-07 16:19:45.756+00	2026-08-07 16:29:45.756+00	2026-08-07 16:19:45.775+00	f
d9312d85-2e95-4544-ae00-68eb0012109a	09120000999	ca00df72233fa11a179cfe851eac323bd87593f975d337daaf5477290a3e3bd6	2026-08-07 16:48:15.333+00	2026-08-07 16:58:15.333+00	2026-08-07 16:48:16.607+00	f
a3e9cd71-c7f4-45b6-840f-79db32222619	09127969845	1819e388b8b4067df678474657f5579c5930b81d09a07b5748be33203594c53a	2026-08-07 16:52:45.804+00	2026-08-07 17:02:45.804+00	2026-08-07 16:52:46.749+00	f
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment (id, appointment_id, amount_rial, status, gateway, authority, ref_id, created_at) FROM stdin;
e31308c8-9d74-4296-9671-8ddac0de5d39	7074c64f-428c-429b-8c90-07185eb10629	100000	pending	unknown	mock-1786106963627-odxk64	\N	2026-08-07 12:49:23.623+00
f2000000-0000-4000-8000-000000000001	f1000000-0000-4000-8000-000000000001	3000000	paid	zarinpal	MOCK-AUTH-001	MOCK-REF-001	2026-08-05 13:12:03.457249+00
f2000000-0000-4000-8000-000000000002	f1000000-0000-4000-8000-000000000002	4500000	paid	idpay	MOCK-AUTH-002	MOCK-REF-002	2026-08-06 13:12:03.457249+00
f2000000-0000-4000-8000-000000000003	f1000000-0000-4000-8000-000000000004	1500000	pending	zarinpal	MOCK-AUTH-003	\N	2026-08-07 12:12:03.457249+00
f2000000-0000-4000-8000-000000000004	f1000000-0000-4000-8000-000000000008	4500000	failed	idpay	MOCK-AUTH-004	\N	2026-08-06 13:12:03.457249+00
c3179473-5426-4ec0-8297-10698bc6a5b1	88a697b4-9687-49f4-b309-d0740b41d3f9	100000	pending	unknown	mock-1786111016702-vwnxt4	\N	2026-08-07 13:56:56.698+00
372b7cb4-963c-4a90-9e5d-95fe916a809a	3e5ae360-0258-4e9e-9921-52a6da06c7af	100000	pending	unknown	mock-1786111113322-up1o4l	\N	2026-08-07 13:58:33.319+00
471cc47f-8064-48b5-b58e-46ec2db4bc1f	6fac84dc-0e20-4e6a-95df-78f44c53fe02	100000	pending	unknown	mock-1786111207135-3xw79d	\N	2026-08-07 14:00:07.132+00
931e15f4-faff-4299-a6f8-9b8b8efb2ffa	d104d254-62a0-431b-a031-2ed3cb1e4f32	100000	pending	unknown	mock-1786111255130-oxqfys	\N	2026-08-07 14:00:55.127+00
be4abb48-6377-4064-8352-ccbd42e05149	276df2f0-e3f9-4bb8-a080-280bca5c5374	100000	pending	unknown	mock-1786111315107-gfyyv3	\N	2026-08-07 14:01:55.103+00
\.


--
-- Data for Name: platform_admin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_admin (id, phone, full_name, role, active, created_at, last_login_at) FROM stdin;
f0000000-0000-4000-8000-000000000001	09120000999	مدیر پلتفرم آرا	super_admin	t	2026-08-07 14:41:55.447906+00	2026-08-07 16:48:16.612+00
\.


--
-- Data for Name: platform_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_audit_log (id, admin_id, action, entity_type, entity_id, metadata, created_at) FROM stdin;
b0a6bbeb-5c39-4f4e-8678-48e2dcf55152	f0000000-0000-4000-8000-000000000001	salon.suspend	salon	11111111-1111-1111-1111-111111111111	{"active": false, "previousActive": true}	2026-08-07 14:56:14.998+00
a77a04c8-e7e0-4ab7-83ac-a1a32c90d009	f0000000-0000-4000-8000-000000000001	salon.activate	salon	11111111-1111-1111-1111-111111111111	{"active": true, "previousActive": false}	2026-08-07 14:56:15.018+00
6aebee21-c97f-41dd-ac69-6fafa4f90bec	f0000000-0000-4000-8000-000000000001	salon.suspend	salon	11111111-1111-1111-1111-111111111111	{"active": false, "previousActive": true}	2026-08-07 15:02:06.899+00
18415747-7b2f-4d66-afb9-62d3723812e8	f0000000-0000-4000-8000-000000000001	salon.activate	salon	11111111-1111-1111-1111-111111111111	{"active": true, "previousActive": false}	2026-08-07 15:02:06.917+00
\.


--
-- Data for Name: qr_scan_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.qr_scan_event (id, salon_id, source, created_at) FROM stdin;
d7b2710c-f982-4009-92b4-81d74bec5720	11111111-1111-1111-1111-111111111111	qr	2026-08-07 11:54:00.405+00
13b455d6-eb29-4527-94f7-44f585ff0a73	11111111-1111-1111-1111-111111111111	qr	2026-08-07 11:54:27.946+00
b2837237-5ef5-445c-af85-041aebcb83f6	11111111-1111-1111-1111-111111111111	qr	2026-08-07 11:57:40.12+00
60c7c7cb-82cc-437d-b2f8-8195d5ecf11b	11111111-1111-1111-1111-111111111111	qr	2026-08-07 11:58:07.632+00
00883fd0-d627-4fc7-b21b-264ddf8cfc73	11111111-1111-1111-1111-111111111111	qr	2026-08-07 11:58:36.213+00
fd4f9d75-6221-4c70-9a7d-a275951c3cf3	11111111-1111-1111-1111-111111111111	qr	2026-08-07 12:06:41.448+00
09fb276b-1c51-4774-8ab2-fd2c239044b0	48b7b978-caca-4b3d-9996-48178b2a4fb5	qr	2026-08-07 12:23:40.092+00
e095acd1-6dc9-4933-80d7-3331bba26547	55809d45-8657-47fe-a0e2-ad8116219af4	qr	2026-08-07 12:25:59.572+00
e4a68a5d-80c6-4177-9254-c243af97fefe	a32e5e4b-40d7-4635-939c-79fb4b2fdc68	e2e	2026-08-07 12:26:13.095+00
0c0e4866-5758-4152-a1c3-61e7360be018	a32e5e4b-40d7-4635-939c-79fb4b2fdc68	e2e-body	2026-08-07 12:26:13.103+00
51259cc7-37c7-474a-96a9-341239ce33de	65b96ada-c840-4a9d-bfbb-5fa5df901d91	qr	2026-08-07 12:26:14.906+00
7bf89ee6-0a31-49ba-a350-efef3dc85335	21835586-a1de-4990-bb83-8f9cc4373a5c	e2e	2026-08-07 12:49:22.506+00
73910a24-df46-4b5f-976f-022dd039a48d	21835586-a1de-4990-bb83-8f9cc4373a5c	e2e-body	2026-08-07 12:49:22.513+00
b4476598-a495-449c-903a-c2c1ac0aa633	5d0f07bd-e701-4d76-8a43-66f370a0fdd6	qr	2026-08-07 12:49:24.133+00
49583574-6cb0-4599-9e09-e34ee3bbd6cf	11111111-1111-1111-1111-111111111111	qr	2026-08-07 12:49:42.521+00
f5000000-0000-4000-8000-000000000001	d7412cac-b652-4a48-a889-e282a2ed5d55	qr	2026-08-02 13:12:03.457249+00
f5000000-0000-4000-8000-000000000002	d7412cac-b652-4a48-a889-e282a2ed5d55	qr	2026-08-04 13:12:03.457249+00
f5000000-0000-4000-8000-000000000003	d7412cac-b652-4a48-a889-e282a2ed5d55	instagram	2026-08-05 13:12:03.457249+00
f5000000-0000-4000-8000-000000000004	d7412cac-b652-4a48-a889-e282a2ed5d55	qr	2026-08-06 13:12:03.457249+00
f5000000-0000-4000-8000-000000000005	d7412cac-b652-4a48-a889-e282a2ed5d55	profile	2026-08-07 13:12:03.457249+00
7fff7a53-23ab-41eb-9109-bd752f864466	11111111-1111-1111-1111-111111111111	qr	2026-08-07 13:56:06.168+00
492b80d1-6e5c-49e9-82a5-5a60db7d3365	4f7ed53f-8383-4517-bd6f-8e71b351ce89	e2e	2026-08-07 13:56:55.38+00
55f0a767-6bde-4be4-a6d5-010d6454206b	4f7ed53f-8383-4517-bd6f-8e71b351ce89	e2e-body	2026-08-07 13:56:55.388+00
e3103a45-f6c6-4269-99fb-2f8bfcf1369f	ce2ffe75-4e1d-4e06-9f8d-8ea2ab35b605	qr	2026-08-07 13:56:57.594+00
3bf1c2c0-bf20-48e4-8f65-194c5237f50e	385375ee-d31c-4ee6-a768-e54d8fd4f59f	e2e	2026-08-07 13:58:32.149+00
9a874835-a6f1-4efd-97be-b6abd2cb22b4	385375ee-d31c-4ee6-a768-e54d8fd4f59f	e2e-body	2026-08-07 13:58:32.157+00
e2add180-c756-4c94-82e2-677736a4b095	6546637e-4a35-4c02-a418-8ddf714c6b96	qr	2026-08-07 13:58:34.198+00
c5450229-5370-4cf1-9f4b-f531d5dc6ad3	a03997c7-c54e-4856-9c2c-f84a6a7c7092	e2e	2026-08-07 13:59:01.387+00
30a6bf68-5a1e-4d76-8dfe-48e33c534cb0	a03997c7-c54e-4856-9c2c-f84a6a7c7092	e2e-body	2026-08-07 13:59:01.396+00
3f1eea6c-9a2d-4536-b1de-7f6443c377b7	843b43c9-fbb2-496e-9604-69698c152179	e2e	2026-08-07 14:00:05.962+00
2e9beba3-9abf-46e5-9445-bc4c5101ccb7	843b43c9-fbb2-496e-9604-69698c152179	e2e-body	2026-08-07 14:00:05.968+00
f3e6570a-39ba-47da-95b7-5fea6856ae03	0acac768-245e-4600-b24d-10357b6a9206	qr	2026-08-07 14:00:07.71+00
cd9187d0-8f8b-4537-8a23-1beab7df1adb	f5152ef5-f532-47f7-9ac9-ddc21a287cba	e2e	2026-08-07 14:00:53.724+00
b9964cdd-d99d-4e18-9ee6-6722a0d41164	f5152ef5-f532-47f7-9ac9-ddc21a287cba	e2e-body	2026-08-07 14:00:53.732+00
314a58ee-3c9c-4062-a74d-fb4bc4dd619f	7ecbf7b9-4944-4750-858d-c838c1fb60db	qr	2026-08-07 14:00:55.821+00
4e949a0c-9231-4b99-9a7f-9382fcc5d70e	1301ed82-4e76-447e-b9b2-203e4ab5e6b7	e2e	2026-08-07 14:01:53.874+00
447c25c9-521e-4101-ad39-98babbc99ab4	1301ed82-4e76-447e-b9b2-203e4ab5e6b7	e2e-body	2026-08-07 14:01:53.882+00
cdf80822-f4e0-469f-a141-a997ce98932f	bf46a9e5-b9ad-4b7a-857c-c42a838c5105	qr	2026-08-07 14:01:55.706+00
73c8b596-1e5a-41cc-8b84-f6415f3f4aea	11111111-1111-1111-1111-111111111111	qr	2026-08-07 14:02:14.939+00
\.


--
-- Data for Name: salon; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salon (id, name, qr_token, timezone, auto_approve, brand_accent, created_at, booking_window_days, active) FROM stdin;
8d4082de-f9bc-483c-8364-fb5373ecee79	E2E Booking سالن 1786103911244	5347ba05-04d6-4ce1-9def-37272469ab12	Asia/Tehran	f	\N	2026-08-07 11:58:31.247+00	14	t
d04088e4-0987-405e-a912-9728a30e1fb7	E2E QR Trial سالن 1786103916135	5db3767e-9a5a-47ea-96a5-e47f75489c9c	Asia/Tehran	f	\N	2026-08-07 11:58:36.137+00	14	t
ea76f00a-df7d-4ff1-8dc7-82b563279af8	E2E QR Trial سالن 1786110752565	73bed531-7d5a-4a36-a615-4359a87d1058	Asia/Tehran	f	\N	2026-08-07 13:52:32.568+00	14	t
ecdda28c-34cf-47e1-bb64-35433730951f	E2E QR Trial سالن 1786110966073	3ff4ba79-cb85-46ec-91ff-f6fa0e58a47b	Asia/Tehran	f	\N	2026-08-07 13:56:06.077+00	14	t
47a7b865-c608-462c-84b6-37268be1b96c	E2E Public Matrix سالن 1786110972467	03bed58e-77d1-43a0-8c90-53195f016f43	Asia/Tehran	f	\N	2026-08-07 13:56:12.473+00	14	t
282f2ee7-f778-4f75-8e41-72ee726e2d71	E2E UI سالن 1786104388182	9d6126a4-d7be-46d8-87be-52243ee3151a	Asia/Tehran	f	\N	2026-08-07 12:06:30.44+00	14	t
3ad3c745-12dc-4dca-9e16-ee4c57bd987b	E2E RBAC سالن 1786104393137	0149ca46-57df-4ff4-8c6a-18815186ffe1	Asia/Tehran	f	\N	2026-08-07 12:06:33.139+00	14	t
f3f3eb54-0191-4d27-bd54-81fa82f9b40f	terghrthrth	a1ba12d8-5847-434a-bab9-b382f689baf5	Asia/Tehran	t	\N	2026-07-25 18:59:02.744+00	14	t
6a5b29c2-a8df-467a-8c36-ca49f545625c	E2E Booking سالن 1786104396339	fdea151d-4f23-4fdb-a7b7-1c3744f51349	Asia/Tehran	f	\N	2026-08-07 12:06:36.342+00	14	t
a4288905-c8f2-4797-8922-144befd9dd50	cbbcbc	73532371-fb72-4f94-b56c-353a35677a45	Asia/Tehran	f	\N	2026-08-07 03:37:05+00	14	t
36e79989-a20d-4f1e-9b9b-538d101b4014	E2E QR Trial سالن 1786104401366	bf52764c-602f-4e02-b51e-403743256cfc	Asia/Tehran	f	\N	2026-08-07 12:06:41.369+00	14	t
cb8d9d1e-9cfa-42e3-88bf-07b6617ca273	قثلثقل	e814529c-33bb-46e4-85b5-022ef3163638	Asia/Tehran	f	violet	2026-07-26 19:37:46.388+00	14	t
4a680e73-4c54-4523-a9e2-e0d52299eb58	E2E Config Matrix سالن 1786110973048	20940f14-f85d-400b-9212-e1bd74cab40f	Asia/Tehran	f	\N	2026-08-07 13:56:13.058+00	14	t
526ae4f7-c7f7-4411-ac5f-3265dafc8db6	E2E Salon	e2e-msiwp8je	Asia/Tehran	f	\N	2026-08-07 12:13:51.907+00	14	t
b459826c-7585-4616-a22a-665a527778d3	طرطررط	a07dd6e2-15dd-4c8d-b000-021ca6629a21	Asia/Tehran	f	\N	2026-08-07 03:25:00.252+00	14	t
6eea0700-5a52-4b70-8a74-ff81d3ecceb0	ضثبصضصثب	da8ab340-e534-4035-b77e-8d7030046278	Asia/Tehran	t	jade	2026-08-04 13:35:25.412+00	14	t
1bb72fda-9b55-4d92-b5ae-07341a7c9aaf	E2E Misc Matrix سالن 1786105420162	f4797cb1-5357-4659-a882-fca2f1f42202	Asia/Tehran	f	\N	2026-08-07 12:23:40.166+00	14	t
1cb71f4e-7f3f-473c-9ba2-9bf38e6943fa	E2E Notification Other سالن 1786105420370	ebc25647-2eb9-472f-88c8-6c9236dbefa8	Asia/Tehran	f	\N	2026-08-07 12:23:40.373+00	14	t
82ad3b1b-e80e-4d67-95d4-e934f31934a4	E2E Salon 1605	92d7dfc0-d259-47ca-8213-16c9df52dbf1	Asia/Tehran	f	\N	2026-08-07 11:27:21.66+00	14	t
1ba2c5c1-6c6e-4e84-9343-56d66b2d3226	Inspect Salon 4756	b3ec739e-8f20-4e1d-8183-a297c657777e	Asia/Tehran	f	\N	2026-08-07 11:28:02.796+00	14	t
e54af3fc-d38b-41ad-b517-e558fa0e6cbf	Inspect Salon 3562	6e36b4d9-7022-4443-a9f7-2a0b4769b637	Asia/Tehran	f	\N	2026-08-07 11:29:11.599+00	14	t
c243bba9-2f63-421a-b92f-7e9eee00a7e2	E2E UI سالن 1786103050596	9806ab0a-2f67-4073-bb91-e245c8421df9	Asia/Tehran	f	\N	2026-08-07 11:44:12.878+00	14	t
f7bc45c9-75c1-4443-9dee-3b2183130dc0	E2E RBAC سالن 1786103053699	ad49d50f-a061-40f2-93f6-21afa98acae0	Asia/Tehran	f	\N	2026-08-07 11:44:41.74+00	14	t
eed48a8d-9014-40d6-903a-955c31140613	E2E Booking سالن 1786103110291	9869d475-bbbd-4e9c-9351-49e5779db44d	Asia/Tehran	f	\N	2026-08-07 11:45:38.333+00	14	t
f2b895e3-8eaf-42e4-b3c6-a244fff4934f	E2E QR سالن 1786103166841	c2f2b67c-2bfe-4d7d-9f45-8a8889e49a9f	Asia/Tehran	f	\N	2026-08-07 11:46:34.892+00	14	t
3c84048d-601a-4f55-a989-038efc3ddbd2	curl-test	d2ff15e0-3de2-4d13-a524-4a9908d19a3a	Asia/Tehran	f	\N	2026-08-07 11:47:09.493+00	14	t
34c4ebd4-eef3-4225-bcf6-cdaac1521668	E2E UI سالن 1786103416459	58ebb031-38e2-4eec-8e4c-22ced95b0f1c	Asia/Tehran	f	\N	2026-08-07 11:50:18.764+00	14	t
6524f8ac-5aae-4f63-80ca-6cee0c030b20	E2E UI سالن 1786103564167	6f4d9893-5069-4aa3-9fab-2fe96440c8aa	Asia/Tehran	f	\N	2026-08-07 11:52:46.391+00	14	t
8a91b095-7147-4ff4-9b71-290b72e6de88	E2E RBAC سالن 1786103574494	703be481-f93b-4099-b654-fbb835dd4eb0	Asia/Tehran	f	\N	2026-08-07 11:52:54.507+00	14	t
049ff655-e678-4a8a-aa15-dd1d0f082d72	E2E Booking سالن 1786103580829	31190936-beff-4205-83b2-41671b568074	Asia/Tehran	f	\N	2026-08-07 11:53:00.84+00	14	t
3ae5cde0-3a8d-4d60-be96-c4c456e161a0	E2E QR سالن 1786103589349	da9e12eb-0d71-4360-8573-5cc29de980da	Asia/Tehran	f	\N	2026-08-07 11:53:09.362+00	14	t
83738a22-ac2f-4959-ae1f-31ab6a64d166	E2E QR Trial سالن 1786103640290	5f5e2a72-20d7-4594-ab1f-7005dca629f5	Asia/Tehran	f	\N	2026-08-07 11:54:00.301+00	14	t
e539a6f7-3a89-4777-8cc4-356882028d76	E2E QR Trial سالن 1786103667830	abba1cba-2f64-469f-849b-c3e57ab11541	Asia/Tehran	f	\N	2026-08-07 11:54:27.84+00	14	t
b332bbaf-9ab8-45da-a7a3-e27644b594e5	E2E QR Trial سالن 1786103859993	b324003c-2364-40ed-acf0-9f823acc658e	Asia/Tehran	f	\N	2026-08-07 11:57:40.004+00	14	t
94d4a899-f24e-4163-9da6-d42540203798	E2E QR Trial سالن 1786103887498	074ba99a-6f26-4474-b25a-c2cb3ba76222	Asia/Tehran	f	\N	2026-08-07 11:58:07.508+00	14	t
37b31e8c-6d49-4cd9-aea2-e27961f8804f	E2E UI سالن 1786103903440	feb9987f-4e3e-42a2-8eea-64f0fe8499ce	Asia/Tehran	f	\N	2026-08-07 11:58:25.71+00	14	t
ede45a95-710d-4132-8214-e4c2f13f28e0	E2E RBAC سالن 1786103908370	e50d061b-4021-4a6f-931d-7c2b1b0fb794	Asia/Tehran	f	\N	2026-08-07 11:58:28.373+00	14	t
b8d1f622-7f06-49a7-aba2-30dcef24f8a7	سیشبیسصب	131df76f-7d95-4155-b220-be3e3d0adb06	Asia/Tehran	f	violet	2026-07-30 22:11:57.935+00	14	t
0f4db935-3ff2-426f-a8cf-16fd66dbd7da	ینهزتنهی	ca89c96c-d579-4df9-8169-93b0590ee8a1	Asia/Tehran	f	violet	2026-08-04 13:48:42.046+00	14	t
3e1a529c-c38c-410a-9147-b0776d2cf387	E2E Config Matrix سالن 1786105557994	0c8565a3-0e90-4b07-bfa4-c512c347efe1	Asia/Tehran	f	\N	2026-08-07 12:25:58.006+00	14	t
bb22b03a-5d16-4b81-b42a-49e37d27593b	E2E Other Tenant سالن 1786105558648	ba8437d5-7337-4398-a906-3bf6be5e0b11	Asia/Tehran	f	\N	2026-08-07 12:25:58.651+00	14	t
c21b3648-38a3-4dde-86ea-cbee7d78165f	E2E Misc Matrix سالن 1786105559617	444d853f-e05f-45f8-aa8e-2f56cbca28ca	Asia/Tehran	f	\N	2026-08-07 12:25:59.62+00	14	t
8aa546de-8daf-489d-9fe8-8b3118bf9f7a	E2E Notification Other سالن 1786105559816	44ce6059-2b6c-40ea-ab8d-14af442b0607	Asia/Tehran	f	\N	2026-08-07 12:25:59.818+00	14	t
11a5ba43-60ac-45c0-84de-ff438ddbd3dc	E2E Booking Matrix سالن 1786105558709	dd98686c-b806-4cd9-8871-08f125a8ebc0	Asia/Tehran	f	\N	2026-08-07 12:25:58.711+00	14	t
4c0bfb7e-08bb-4675-9b6c-b7928cbb347e	E2E Public Matrix سالن 1786105417388	a016cdd0-436a-48de-a64a-4814311abdf2	Asia/Tehran	f	\N	2026-08-07 12:23:37.404+00	14	t
b6e528ae-c2ac-4579-bd70-4a33806fbcee	E2E Config Matrix سالن 1786105418039	8428fd04-64c7-4b8e-a071-8770c201d79d	Asia/Tehran	f	\N	2026-08-07 12:23:38.051+00	14	t
c29ea8c8-5840-4ddb-885c-e70eafb741b5	E2E Booking Matrix سالن 1786105418785	5210d114-cf7f-4342-8a37-d2f37c7f1f66	Asia/Tehran	f	\N	2026-08-07 12:23:38.796+00	14	t
48b7b978-caca-4b3d-9996-48178b2a4fb5	E2E Premium Matrix سالن 1786105419800	29d8b128-0104-4eb5-ac8e-4b71b24540b7	Asia/Tehran	f	\N	2026-08-07 12:23:39.811+00	14	t
0ed4db5e-a345-4f57-a5ff-7faf1876853c	E2E Public Matrix سالن 1786105557291	15b8754e-5d4f-43d0-9a3e-c60b9ba722f7	Asia/Tehran	f	\N	2026-08-07 12:25:57.308+00	14	t
55809d45-8657-47fe-a0e2-ad8116219af4	E2E Premium Matrix سالن 1786105559336	00f85b5c-bb46-4f18-8b18-7c61c6f29f56	Asia/Tehran	f	\N	2026-08-07 12:25:59.339+00	14	t
a32e5e4b-40d7-4635-939c-79fb4b2fdc68	E2E Public Matrix سالن 1786105572950	45381399-6e10-406c-b8cb-6a60c5e09515	Asia/Tehran	f	\N	2026-08-07 12:26:12.953+00	14	t
c3104b98-c5c9-46db-b100-1ad8180b1c11	E2E Other Tenant سالن 1786105573756	7b316656-72d0-4aec-abd6-087776398fd0	Asia/Tehran	f	\N	2026-08-07 12:26:13.758+00	14	t
83bc9d7c-d555-4961-8c35-215f48b3f8b7	E2E Config Matrix سالن 1786105573130	57f0b338-e8c2-4d32-b3c0-ced8cde655d1	Asia/Tehran	f	\N	2026-08-07 12:26:13.134+00	14	t
9d965b2a-2b91-456a-92bb-937b05888fa8	E2E Booking Matrix سالن 1786105573839	981d0e27-c3fa-4821-8e27-8c45f55b5152	Asia/Tehran	f	\N	2026-08-07 12:26:13.841+00	14	t
65b96ada-c840-4a9d-bfbb-5fa5df901d91	E2E Premium Matrix سالن 1786105574634	eb5e9a43-90bf-42db-a382-d61e5268bd77	Asia/Tehran	f	\N	2026-08-07 12:26:14.637+00	14	t
b9e33109-b47b-40d5-a0ac-2a0d837c6827	E2E Misc Matrix سالن 1786105574954	e5f9df71-d433-4c92-8785-19eb921b51b7	Asia/Tehran	f	\N	2026-08-07 12:26:14.958+00	14	t
1e53029c-8667-4f39-a775-f30d1293f13a	E2E Notification Other سالن 1786105575221	daa34a3a-511a-412a-8210-33a8e33a65ad	Asia/Tehran	f	\N	2026-08-07 12:26:15.224+00	14	t
21835586-a1de-4990-bb83-8f9cc4373a5c	E2E Public Matrix سالن 1786106962269	76a02de8-2659-4515-9447-62f15af6c0a3	Asia/Tehran	f	\N	2026-08-07 12:49:22.286+00	14	t
cbcf2e40-16fa-481d-b8da-be5c9642aa5c	E2E UI سالن 1786110874217	ec35bf91-750c-4746-9c59-1232c0d9a2be	Asia/Tehran	f	\N	2026-08-07 13:54:36.415+00	14	t
f6b026fa-c4e3-4be6-a2be-796fe9abbe57	E2E Booking Matrix سالن 1786110973540	a8d4128e-9d30-4533-bfae-74a7b4124014	Asia/Tehran	f	\N	2026-08-07 13:56:13.551+00	14	t
7cb82de5-0177-4be1-999c-fd7ef40af41b	E2E Premium Matrix سالن 1786110974057	81b659c6-293d-437f-91cc-2e002fe7b6f3	Asia/Tehran	f	\N	2026-08-07 13:56:14.068+00	14	t
b578c0dd-6919-4d23-b7f2-efa770c47aca	E2E Misc Matrix سالن 1786110974569	8912c49e-b5c5-4f19-8f63-936606c6f65c	Asia/Tehran	f	\N	2026-08-07 13:56:14.58+00	14	t
4f7ed53f-8383-4517-bd6f-8e71b351ce89	E2E Public Matrix سالن 1786111015091	295a45a4-3289-452c-84e0-aa716915ffb6	Asia/Tehran	f	\N	2026-08-07 13:56:55.108+00	14	t
94d46edb-1124-4428-993f-64b9e456dbfb	E2E Config Matrix سالن 1786106962539	05d179bb-1bda-4f95-90ec-63884e807f40	Asia/Tehran	f	\N	2026-08-07 12:49:22.542+00	14	t
9f5bd53c-a3c5-4380-b111-3bcfc11381d3	E2E Other Tenant سالن 1786106963136	a27a3144-0483-4c3f-9011-e6aec531e61b	Asia/Tehran	f	\N	2026-08-07 12:49:23.138+00	14	t
e7f95ac5-5c53-4db7-b274-f0c94730f18c	E2E Booking Matrix سالن 1786106963233	16ccff6e-c60e-4634-b80f-f90a3d4c1fd3	Asia/Tehran	f	\N	2026-08-07 12:49:23.235+00	14	t
5d0f07bd-e701-4d76-8a43-66f370a0fdd6	E2E Premium Matrix سالن 1786106963898	e6276189-d046-4856-a15c-06d58e65c95b	Asia/Tehran	f	\N	2026-08-07 12:49:23.901+00	14	t
f9eaed2d-7068-4583-8a46-869324599cc6	E2E Misc Matrix سالن 1786106964177	9c726ff9-3fe1-44fe-bdef-688e66d0346c	Asia/Tehran	f	\N	2026-08-07 12:49:24.18+00	14	t
a9ce2f38-b34c-414c-858e-d26135c9d819	E2E Notification Other سالن 1786106964365	ab1d2d8a-f0cf-4106-9ee1-b1136b7ea374	Asia/Tehran	f	\N	2026-08-07 12:49:24.368+00	14	t
7b0a02d7-7ef3-49fe-af64-cb4da63051ae	E2E UI سالن 1786106969742	2e654a73-5a3b-4ee2-ac48-e074707246c0	Asia/Tehran	f	\N	2026-08-07 12:49:32.021+00	14	t
0c3dfb48-5927-4861-864f-a8543c9eb7ac	E2E RBAC سالن 1786106974708	d371276a-f487-4526-9d48-d7ac9a6bdb6a	Asia/Tehran	f	\N	2026-08-07 12:49:34.71+00	14	t
a3b92139-eb81-4a88-a88d-0e4b23e9368c	E2E Booking سالن 1786106977514	93766018-2341-412c-94db-1c234acb96be	Asia/Tehran	f	\N	2026-08-07 12:49:37.517+00	14	t
04034eee-0de0-4289-a3db-b3faf17d4ca4	E2E QR Trial سالن 1786106982444	f0c9cf3d-f122-4d3e-8771-a8c2f44ca57c	Asia/Tehran	f	\N	2026-08-07 12:49:42.447+00	14	t
114d6cf5-f9d5-4cb5-ab7a-89b2facecadf	E2E Config Matrix سالن 1786111253767	2ad34113-f23e-4041-9600-1aa433882451	Asia/Tehran	f	\N	2026-08-07 14:00:53.77+00	14	t
d5fb54d8-3c89-493d-8edd-48fb3f04ef42	E2E Misc Matrix سالن 1786111255876	8fd8a875-1756-40c7-b355-33c95624f63f	Asia/Tehran	f	\N	2026-08-07 14:00:55.879+00	14	t
b32a6626-2517-4496-b611-8221818a64cd	E2E Notification Other سالن 1786111256113	456cdb28-283f-4691-a04d-d68be4ce6c48	Asia/Tehran	f	\N	2026-08-07 14:00:56.116+00	14	t
4dedcfd1-9cee-4826-9fb1-0cfbfa5886ef	E2E Other Tenant سالن 1786111314575	9f26f302-cc15-44b0-901c-41ed4d672f89	Asia/Tehran	f	\N	2026-08-07 14:01:54.578+00	14	t
a8fbfe27-1784-4a99-bf74-6c560de51016	E2E Config Matrix سالن 1786111015417	a5ab6188-59e4-4dca-9169-70589793bc6b	Asia/Tehran	f	\N	2026-08-07 13:56:55.419+00	14	t
33b55265-4e46-4dfc-8e22-22fd32ccd0f2	E2E Misc Matrix سالن 1786111017646	74c5a795-180c-4ef3-8975-2b6a61921894	Asia/Tehran	f	\N	2026-08-07 13:56:57.649+00	14	t
f4131cfd-52ad-46ee-9c9b-c6d358ed5f10	E2E Notification Other سالن 1786111017848	8f6ea2b4-bc90-4353-8c45-2c8ed6da3ba5	Asia/Tehran	f	\N	2026-08-07 13:56:57.851+00	14	t
3e99cb18-41bd-457b-9326-d2889b35cec5	E2E Other Tenant سالن 1786111112797	50c9e04f-fdf0-464e-ab25-f906441b0e94	Asia/Tehran	f	\N	2026-08-07 13:58:32.799+00	14	t
ca682117-4612-4948-ae95-9706f3d56404	E2E Booking Matrix سالن 1786111112904	1db3a2ea-e73b-40a1-9ac7-a9ac216121ca	Asia/Tehran	f	\N	2026-08-07 13:58:32.907+00	14	t
6546637e-4a35-4c02-a418-8ddf714c6b96	E2E Premium Matrix سالن 1786111113892	b424d278-3a1a-440f-9c0b-da5e054039a3	Asia/Tehran	f	\N	2026-08-07 13:58:33.903+00	14	t
6734a6d0-2423-4322-8476-bae0d501ab64	E2E Other Tenant سالن 1786111142048	38899d96-a4ed-456c-9bca-91185f2aad9a	Asia/Tehran	f	\N	2026-08-07 13:59:02.05+00	14	t
2874dacc-057b-490d-96e1-51b76f6b2910	E2E Booking Matrix سالن 1786111142560	2756c474-d291-47f0-8407-da05f96a5609	Asia/Tehran	f	\N	2026-08-07 13:59:02.571+00	14	t
8f50a98a-5249-46bd-83ad-bcc5493292d1	E2E Other Tenant سالن 1786111206596	811c82c2-b323-488e-9392-75c2f3a2b70b	Asia/Tehran	f	\N	2026-08-07 14:00:06.6+00	14	t
2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	E2E Booking Matrix سالن 1786111206707	93b55fd7-d812-4fda-ae89-2f702f1b7d21	Asia/Tehran	f	\N	2026-08-07 14:00:06.71+00	14	t
0acac768-245e-4600-b24d-10357b6a9206	E2E Premium Matrix سالن 1786111207451	722968c9-0566-4677-b174-accc0ce46340	Asia/Tehran	f	\N	2026-08-07 14:00:07.455+00	14	t
f5152ef5-f532-47f7-9ac9-ddc21a287cba	E2E Public Matrix سالن 1786111253353	ad42af06-7868-447e-abd7-d44ee84b2d27	Asia/Tehran	f	\N	2026-08-07 14:00:53.381+00	14	t
ecfd9427-201f-45b4-b995-0c5903186dcf	E2E Booking Matrix سالن 1786111314681	c3910d3c-d031-45fd-ae2f-4fe834319e42	Asia/Tehran	f	\N	2026-08-07 14:01:54.684+00	14	t
bf46a9e5-b9ad-4b7a-857c-c42a838c5105	E2E Premium Matrix سالن 1786111315440	249d2341-17f3-4b55-8152-5fb10a7a2852	Asia/Tehran	f	\N	2026-08-07 14:01:55.443+00	14	t
dc36c3db-891c-47ad-a4c1-ecf6f3c4671e	E2E UI سالن 1786111321445	83b1b8e8-d4cb-4827-9264-9cfd7372b916	Asia/Tehran	f	\N	2026-08-07 14:02:03.697+00	14	t
6e338bf0-ec57-44fe-8b1f-7af52ad1d31e	E2E QR Trial سالن 1786111334846	28f89418-61cf-4012-8881-b0e755c6e2ec	Asia/Tehran	f	\N	2026-08-07 14:02:14.849+00	14	t
d7412cac-b652-4a48-a889-e282a2ed5d55	سالن تست کاربران 7969845	ad0a1a8f-19d9-470b-8ade-bd41555f96d3	Asia/Tehran	f	teal	2026-08-07 13:06:09.874+00	30	t
4ee90b92-1681-4046-b42d-50582aaf3c55	E2E UI سالن 1786110952753	aa3799df-5802-43b2-ae97-7febfaf55de5	Asia/Tehran	f	\N	2026-08-07 13:55:55.031+00	14	t
8fddf0bd-1345-4f94-9277-ce0abe54fc86	E2E RBAC سالن 1786110957793	160b802c-1e7b-47cf-8cc3-da0e0f7607e0	Asia/Tehran	f	\N	2026-08-07 13:55:57.796+00	14	t
d86a4f90-7ef3-477a-b928-3804c9bd1bca	E2E Booking سالن 1786110961046	9de7d72b-c8dc-470a-84fe-9e9f1eb0cda3	Asia/Tehran	f	\N	2026-08-07 13:56:01.049+00	14	t
46b5e7c3-4228-4d05-9724-b4d688e772a3	E2E Config Matrix سالن 1786111205998	1173b6e3-97ff-4a50-ba51-c45267304be7	Asia/Tehran	f	\N	2026-08-07 14:00:06.001+00	14	t
d1c9c1e8-22db-4add-814e-be04ecc51faf	E2E Other Tenant سالن 1786111016102	4f9980da-10a1-4857-acd0-22a8d7f2bee6	Asia/Tehran	f	\N	2026-08-07 13:56:56.107+00	14	t
c66e014b-5299-4f9f-bc65-195fbad0cd99	E2E Booking Matrix سالن 1786111016248	44cdbb46-a3f8-49e4-bafd-f66b0510fc97	Asia/Tehran	f	\N	2026-08-07 13:56:56.25+00	14	t
ce2ffe75-4e1d-4e06-9f8d-8ea2ab35b605	E2E Premium Matrix سالن 1786111017294	f3431772-fd6f-4efc-8614-410ab79cce2f	Asia/Tehran	f	\N	2026-08-07 13:56:57.305+00	14	t
91117aaf-0c89-4e41-9598-3479ebdb801f	E2E UI سالن 1786110739879	9f3f2062-a23e-4a6d-be8a-bbc73eb2f6d5	Asia/Tehran	f	\N	2026-08-07 13:52:22.122+00	14	t
793c04cb-a78d-46bc-b66d-713f10e3f731	E2E RBAC سالن 1786110744843	6ae3170a-74c3-409b-b3b4-b7c3eea99756	Asia/Tehran	f	\N	2026-08-07 13:52:24.846+00	14	t
4acda9b4-b53a-452d-b438-3c01cc8a3ca4	E2E Booking سالن 1786110747710	fdfb160f-7f25-4034-b914-6c4180086b9b	Asia/Tehran	f	\N	2026-08-07 13:52:27.713+00	14	t
daaee930-a32d-41c2-8e2d-d59946feb22b	E2E Misc Matrix سالن 1786111207756	a047c0c5-bbd0-4065-83d2-ee0be20f6dca	Asia/Tehran	f	\N	2026-08-07 14:00:07.758+00	14	t
9fb475fe-8cac-4fd3-8f89-b522a84d2edf	E2E Notification Other سالن 1786111207979	18005520-8e53-4acf-b952-7171d771ea7e	Asia/Tehran	f	\N	2026-08-07 14:00:07.982+00	14	t
11776d89-31cf-4504-9bb8-c4473fac42d1	E2E Config Matrix سالن 1786111313910	0d0d7880-a0e9-4e83-92e7-cf6453131e39	Asia/Tehran	f	\N	2026-08-07 14:01:53.913+00	14	t
a8f9e2e8-b848-487b-a2c4-8b7a01f955a3	E2E Misc Matrix سالن 1786111315760	f33bc5d4-b0f1-4015-9a5e-78fe190b69c9	Asia/Tehran	f	\N	2026-08-07 14:01:55.763+00	14	t
385375ee-d31c-4ee6-a768-e54d8fd4f59f	E2E Public Matrix سالن 1786111111883	05c93704-65be-4b74-8817-9f750822f4da	Asia/Tehran	f	\N	2026-08-07 13:58:31.888+00	14	t
41fe0795-178c-4762-828d-2bf86d3b7d2b	E2E Notification Other سالن 1786111315996	d202c160-cfa1-4772-ab76-0d816cc3e580	Asia/Tehran	f	\N	2026-08-07 14:01:55.999+00	14	t
3d0794ce-aed8-4b71-b1df-80de2ee1f392	E2E RBAC سالن 1786111326568	238c2340-e4e3-4d8e-b1bf-ecbc83657ff7	Asia/Tehran	f	\N	2026-08-07 14:02:06.573+00	14	t
75615eb1-bd39-4831-897f-4b6a23901cb7	E2E Other Tenant سالن 1786111254522	a6850f30-26db-4998-ab4f-533c53e082a4	Asia/Tehran	f	\N	2026-08-07 14:00:54.526+00	14	t
e71737ea-c9ab-401c-bd67-8525aa0060fd	E2E Booking سالن 1786111329776	237c4df2-de88-42ff-abd4-100c40eb367d	Asia/Tehran	f	\N	2026-08-07 14:02:09.779+00	14	t
7449789e-cf83-4783-a40b-462ca8396e0c	E2E Config Matrix سالن 1786111112183	44e6643d-68a0-42a1-9553-61f222de7096	Asia/Tehran	f	\N	2026-08-07 13:58:32.186+00	14	t
9ce67759-ee69-4264-a07f-891b3f9805e2	E2E Misc Matrix سالن 1786111114253	d9bffdda-ad7a-4864-95a5-b1ceed48914a	Asia/Tehran	f	\N	2026-08-07 13:58:34.256+00	14	t
f57024e7-1bbb-4d66-b3e8-3e7007f205c9	E2E Notification Other سالن 1786111114499	5749d90a-cae5-4439-b55c-11290e4cc5ef	Asia/Tehran	f	\N	2026-08-07 13:58:34.502+00	14	t
a03997c7-c54e-4856-9c2c-f84a6a7c7092	E2E Public Matrix سالن 1786111141229	a236251d-3270-4400-ba30-94c5ba0c7f53	Asia/Tehran	f	\N	2026-08-07 13:59:01.232+00	14	t
41945155-8295-4ffe-9fca-a051aec9d85c	E2E Booking Matrix سالن 1786111254641	b169caab-73de-4090-a53f-edcc1789a9e0	Asia/Tehran	f	\N	2026-08-07 14:00:54.644+00	14	t
7ecbf7b9-4944-4750-858d-c838c1fb60db	E2E Premium Matrix سالن 1786111255509	608d8059-16a1-440a-ac64-a1eb061820de	Asia/Tehran	f	\N	2026-08-07 14:00:55.512+00	14	t
8acc033d-9bdc-4a9b-a0f2-a7c8f7a8e80d	E2E UI سالن 1786111262569	b566196f-8844-477d-8107-b223dddfa34c	Asia/Tehran	f	\N	2026-08-07 14:01:05.101+00	14	t
e7b2abf5-4d80-4d5f-a96e-c42395401a4c	E2E RBAC سالن 1786111268247	74e2312c-5e27-4bd4-a7b3-79c62c3928f0	Asia/Tehran	f	\N	2026-08-07 14:01:08.25+00	14	t
e66c3ae5-4fe0-48ef-a5f8-e2226df0ed55	E2E Booking سالن 1786111272582	88b1f35f-79d3-4d68-8992-30648101d37f	Asia/Tehran	f	\N	2026-08-07 14:01:12.585+00	14	t
e3fa9cc9-4249-426a-8a5e-bdfea48ab30e	E2E Config Matrix سالن 1786111141421	ca4f508b-8a42-47a9-9564-cb58dc040b6e	Asia/Tehran	f	\N	2026-08-07 13:59:01.424+00	14	t
843b43c9-fbb2-496e-9604-69698c152179	E2E Public Matrix سالن 1786111205675	ae953cf8-05ce-4db6-898f-7db965bf9a90	Asia/Tehran	f	\N	2026-08-07 14:00:05.692+00	14	t
0fbab0e1-6447-4455-bde7-412a6154819d	E2E QR Trial سالن 1786111278125	c837d214-03d2-414b-8f7f-4f4126e244f8	Asia/Tehran	f	\N	2026-08-07 14:01:18.128+00	14	t
aa000001-0000-4000-8000-000000000001	سالن مریم	salon-maryam	Asia/Tehran	f	\N	2026-07-26 20:23:12.39082+00	14	t
aa000002-0000-4000-8000-000000000002	آرایشگاه شاهین	shahin-barbershop	Asia/Tehran	t	\N	2026-07-26 20:23:12.39082+00	14	t
aa000003-0000-4000-8000-000000000003	سالن نیلوفر	salon-niloofar	Asia/Tehran	f	\N	2026-07-26 20:23:12.39082+00	14	t
aa000004-0000-4000-8000-000000000004	استودیو آرش	arash-studio	Asia/Tehran	t	\N	2026-07-26 20:23:12.39082+00	14	t
aa000005-0000-4000-8000-000000000005	سالن پریسا	salon-parisa	Asia/Tehran	f	\N	2026-07-26 20:23:12.39082+00	14	t
1301ed82-4e76-447e-b9b2-203e4ab5e6b7	E2E Public Matrix سالن 1786111313586	cbd9084c-897e-4f05-bdfd-914c242d90d9	Asia/Tehran	f	\N	2026-08-07 14:01:53.603+00	14	t
11111111-1111-1111-1111-111111111111	سالن رز	salon-rose	Asia/Tehran	f	\N	2026-07-23 16:52:07.108502+00	14	t
\.


--
-- Data for Name: salon_notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salon_notification (id, salon_id, audience, staff_member_id, type, title, body, payload, read_at, created_at) FROM stdin;
29aa3280-f798-41ae-935c-6641e16ce08c	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	all-staff	618bbbbb-d814-4b0e-a5ad-83dfab804e2a	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-07", "appointmentId": "4d340983-9d69-4b4f-b463-0e29c0c7de57", "staffMemberId": "618bbbbb-d814-4b0e-a5ad-83dfab804e2a"}	\N	2026-08-04 13:53:20.406+00
07c2567a-934f-493b-bfe4-e096f8614449	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	all-staff	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "3078ab9b-2c0e-4979-94a3-5b546038313a", "staffMemberId": "d36a99a4-d938-45b0-9d9c-90f6ebe8a19c"}	\N	2026-08-07 12:25:58.941+00
e5478b6b-f11a-4c3f-aeff-2b463c968d57	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	all-staff	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "3078ab9b-2c0e-4979-94a3-5b546038313a", "staffMemberId": "d36a99a4-d938-45b0-9d9c-90f6ebe8a19c"}	\N	2026-08-07 12:25:58.992+00
91000000-0000-0000-0000-000000000001	11111111-1111-1111-1111-111111111111	owner	\N	booking.pending	رزرو جدید در انتظار تأیید	ترانه موسوی برای خدمت کراتین و احیا درخواست رزرو ثبت کرده است.	{"customerName": "ترانه موسوی", "appointmentId": "90000000-0000-0000-0000-000000000004"}	\N	2026-08-07 14:36:35.458336+00
91000000-0000-0000-0000-000000000002	11111111-1111-1111-1111-111111111111	admin	\N	booking.pending	یک رزرو نیاز به بررسی دارد	رزرو فردا ساعت ۱۲ برای زهرا رضایی هنوز تأیید نشده است.	{"appointmentId": "90000000-0000-0000-0000-000000000007"}	\N	2026-08-07 14:28:35.458336+00
91000000-0000-0000-0000-000000000003	11111111-1111-1111-1111-111111111111	stylist	dddddddd-3333-3333-3333-333333333333	booking.approved	رزرو شما تأیید شد	امروز ساعت ۱۰، نیلوفر حسینی برای براشینگ و استایل مراجعه می‌کند.	{"appointmentId": "90000000-0000-0000-0000-000000000003"}	\N	2026-08-07 14:13:35.458336+00
d634ecfc-17ba-4753-81f0-bbb75b52e7f3	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	all-staff	07f7969e-2964-4ae8-a1c4-305c15e2117f	booking.confirmed	رزرو جدید تأیید شد	یک نوبت جدید ثبت و به‌صورت خودکار تأیید شد.	{"date": "2026-08-06", "appointmentId": "82ccb5e9-9188-4f67-b40e-3ed4d73ac52b", "staffMemberId": "07f7969e-2964-4ae8-a1c4-305c15e2117f"}	2026-08-04 22:09:06.674+00	2026-08-04 22:04:15.022+00
7e388857-6196-457a-86fa-dcf7b1209fde	11111111-1111-1111-1111-111111111111	all-staff	dddddddd-3333-3333-3333-333333333333	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "90000000-0000-0000-0000-000000000007", "staffMemberId": "dddddddd-3333-3333-3333-333333333333"}	2026-07-25 19:35:19.379+00	2026-07-25 19:23:16.896+00
91000000-0000-0000-0000-000000000004	11111111-1111-1111-1111-111111111111	all-staff	\N	subscription.expiring	اشتراک سالانه فعال است	اشتراک آرا بیز سالن رز تا یک سال آینده فعال است.	{"plan": "annual"}	2026-08-06 14:48:35.458336+00	2026-08-05 14:48:35.458336+00
79575f3f-d99b-4cb4-a27b-91b50266456d	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	all-staff	07f7969e-2964-4ae8-a1c4-305c15e2117f	booking.confirmed	رزرو جدید تأیید شد	یک نوبت جدید ثبت و به‌صورت خودکار تأیید شد.	{"date": "2026-08-08", "appointmentId": "1b06882a-d684-430c-9e8c-403bc8d2c1b2", "staffMemberId": "07f7969e-2964-4ae8-a1c4-305c15e2117f"}	\N	2026-08-07 03:23:00.146+00
9424c094-56b5-41d9-9b52-a9e29a27ea01	049ff655-e678-4a8a-aa15-dd1d0f082d72	all-staff	fc75b105-1531-42ee-85b0-7bf0027240a4	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "b3a7f30a-38c3-410b-914a-d41aabd3b647", "staffMemberId": "fc75b105-1531-42ee-85b0-7bf0027240a4"}	\N	2026-08-07 11:53:05.184+00
f5a96280-7218-48e1-aaf0-09a52986ce76	6a5b29c2-a8df-467a-8c36-ca49f545625c	all-staff	993150ad-bcfe-46ba-87cc-aaeae9fb4973	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "350af89d-e638-4d52-9ca5-5fce0bdd29b6", "staffMemberId": "993150ad-bcfe-46ba-87cc-aaeae9fb4973"}	\N	2026-08-07 12:06:40.752+00
fe28f8ae-f2a1-494d-8d74-17da862b376c	c29ea8c8-5840-4ddb-885c-e70eafb741b5	all-staff	4c38b9fb-2918-4a7f-91b1-d959717f3cce	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "193e6490-d212-4bad-b6ae-8f90b7d9c095", "staffMemberId": "4c38b9fb-2918-4a7f-91b1-d959717f3cce"}	\N	2026-08-07 12:23:39.064+00
410e1b4f-8ec5-41a2-8550-7f79cb9b7bf1	c29ea8c8-5840-4ddb-885c-e70eafb741b5	all-staff	4c38b9fb-2918-4a7f-91b1-d959717f3cce	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "193e6490-d212-4bad-b6ae-8f90b7d9c095", "staffMemberId": "4c38b9fb-2918-4a7f-91b1-d959717f3cce"}	\N	2026-08-07 12:23:39.117+00
32ff80fa-a9eb-425d-a728-586abe87bad9	c29ea8c8-5840-4ddb-885c-e70eafb741b5	all-staff	4c38b9fb-2918-4a7f-91b1-d959717f3cce	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "23dde323-f717-4edc-aa53-1fbc39a7a5b8", "staffMemberId": "4c38b9fb-2918-4a7f-91b1-d959717f3cce"}	\N	2026-08-07 12:23:39.153+00
3c46d6c9-9e02-4d76-a3cd-47f9209b2673	c29ea8c8-5840-4ddb-885c-e70eafb741b5	all-staff	4c38b9fb-2918-4a7f-91b1-d959717f3cce	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "23dde323-f717-4edc-aa53-1fbc39a7a5b8", "staffMemberId": "4c38b9fb-2918-4a7f-91b1-d959717f3cce"}	\N	2026-08-07 12:23:39.175+00
d125b654-d5e3-4598-bff6-1bf21a749806	c29ea8c8-5840-4ddb-885c-e70eafb741b5	all-staff	f5a4d790-5134-4522-8243-36d7f0a70027	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "e47b0d44-dfa4-44d4-bc4c-271be836d766", "staffMemberId": "f5a4d790-5134-4522-8243-36d7f0a70027"}	\N	2026-08-07 12:23:39.211+00
2c0617c7-d477-4763-ad8e-fc62af074f6a	c29ea8c8-5840-4ddb-885c-e70eafb741b5	all-staff	f5a4d790-5134-4522-8243-36d7f0a70027	booking.rejected	نوبت رد شد	رزرو توسط مدیر رد شد.	{"appointmentId": "e47b0d44-dfa4-44d4-bc4c-271be836d766", "staffMemberId": "f5a4d790-5134-4522-8243-36d7f0a70027"}	\N	2026-08-07 12:23:39.242+00
44473385-56b3-460c-9498-f9a29510b586	c29ea8c8-5840-4ddb-885c-e70eafb741b5	all-staff	f5a4d790-5134-4522-8243-36d7f0a70027	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "507da850-a5a9-4e3a-a878-37f3cda0b140", "staffMemberId": "f5a4d790-5134-4522-8243-36d7f0a70027"}	\N	2026-08-07 12:23:39.277+00
9d7ddb06-dda6-453b-8657-19a353b9b92f	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	all-staff	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "a3b3a93a-653d-4bca-8ebe-fdb11749fcd7", "staffMemberId": "d36a99a4-d938-45b0-9d9c-90f6ebe8a19c"}	\N	2026-08-07 12:25:59.029+00
73121fd5-e5da-4cd6-80dd-598070a97acd	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	all-staff	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "a3b3a93a-653d-4bca-8ebe-fdb11749fcd7", "staffMemberId": "d36a99a4-d938-45b0-9d9c-90f6ebe8a19c"}	\N	2026-08-07 12:25:59.052+00
930a8fd2-39df-4d7d-b8d7-e532af2f28cc	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	all-staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "d3cb4659-7a5d-4161-93b7-79d2c90fac24", "staffMemberId": "d32250ab-ddb0-45ac-b21c-aca77709eab2"}	\N	2026-08-07 12:25:59.088+00
c89047dd-9b19-4732-a8bf-804772a54508	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	all-staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	booking.rejected	نوبت رد شد	رزرو توسط مدیر رد شد.	{"appointmentId": "d3cb4659-7a5d-4161-93b7-79d2c90fac24", "staffMemberId": "d32250ab-ddb0-45ac-b21c-aca77709eab2"}	\N	2026-08-07 12:25:59.115+00
efafd23c-518d-4f3e-8f89-84f916a0334d	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	all-staff	07f7969e-2964-4ae8-a1c4-305c15e2117f	booking.confirmed	رزرو جدید تأیید شد	یک نوبت جدید ثبت و به‌صورت خودکار تأیید شد.	{"date": "2026-08-06", "appointmentId": "5be1d76c-12b8-4f61-9247-a904446b8d21", "staffMemberId": "07f7969e-2964-4ae8-a1c4-305c15e2117f"}	2026-08-04 22:09:06.674+00	2026-08-04 22:00:01.273+00
7ac7c59a-d611-4c8c-b954-08d10333d7b8	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	all-staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "3203daea-4e5a-4954-b4c5-5ae2666cc92e", "staffMemberId": "d32250ab-ddb0-45ac-b21c-aca77709eab2"}	\N	2026-08-07 12:25:59.15+00
21e83039-59f6-4558-8fb7-2921a1871358	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	all-staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "06da860e-be78-43f2-9cd1-5a6398988ad6", "staffMemberId": "d32250ab-ddb0-45ac-b21c-aca77709eab2"}	\N	2026-08-07 12:25:59.205+00
09e28594-f7d4-4df7-a645-8eb486d3a30e	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	all-staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "06da860e-be78-43f2-9cd1-5a6398988ad6", "staffMemberId": "d32250ab-ddb0-45ac-b21c-aca77709eab2"}	\N	2026-08-07 12:25:59.231+00
e7f1af51-56c3-4777-a9ae-bf666f4b5d7d	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	all-staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	booking.confirmed	رزرو جدید تأیید شد	یک نوبت جدید ثبت و به‌صورت خودکار تأیید شد.	{"date": "2026-08-09", "appointmentId": "31c4f1c5-d255-4f1b-8c37-e8dd311f405e", "staffMemberId": "d32250ab-ddb0-45ac-b21c-aca77709eab2"}	\N	2026-08-07 12:25:59.294+00
b1b68bd2-4dca-498a-aa63-5e85920e629b	c21b3648-38a3-4dde-86ea-cbee7d78165f	all-staff	b8f357fd-925e-416d-b6aa-1c7f138f967f	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "d1c64753-d9b0-4a40-8b22-a922e5f092e2", "staffMemberId": "b8f357fd-925e-416d-b6aa-1c7f138f967f"}	2026-08-07 12:25:59.79+00	2026-08-07 12:25:59.769+00
7d313b22-9188-41cf-b954-08ba45125865	9d965b2a-2b91-456a-92bb-937b05888fa8	all-staff	ba7c9524-b0d4-4845-8886-5274ede7fd6a	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "37a392f7-2ce1-41b4-86cf-fd0a1e0514b2", "staffMemberId": "ba7c9524-b0d4-4845-8886-5274ede7fd6a"}	\N	2026-08-07 12:26:14.14+00
f08a20e4-468d-40a1-a84d-531e9446bc73	9d965b2a-2b91-456a-92bb-937b05888fa8	all-staff	ba7c9524-b0d4-4845-8886-5274ede7fd6a	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "37a392f7-2ce1-41b4-86cf-fd0a1e0514b2", "staffMemberId": "ba7c9524-b0d4-4845-8886-5274ede7fd6a"}	\N	2026-08-07 12:26:14.203+00
cc53c3c8-2bb8-4817-9818-56b827e0035e	9d965b2a-2b91-456a-92bb-937b05888fa8	all-staff	ba7c9524-b0d4-4845-8886-5274ede7fd6a	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "92c8f217-9b27-49a7-a612-6ae46a5ec5cd", "staffMemberId": "ba7c9524-b0d4-4845-8886-5274ede7fd6a"}	\N	2026-08-07 12:26:14.248+00
45318c10-8f85-4809-bd50-b61160a60297	8d4082de-f9bc-483c-8364-fb5373ecee79	all-staff	0b602742-598d-4d2c-b414-fb497ab0ff4b	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "d926c27c-eba8-4e38-b687-e2e7c1c4aa8e", "staffMemberId": "0b602742-598d-4d2c-b414-fb497ab0ff4b"}	\N	2026-08-07 11:58:35.515+00
453b5e3a-184a-4736-bac7-a84cbe3f5f33	9d965b2a-2b91-456a-92bb-937b05888fa8	all-staff	ba7c9524-b0d4-4845-8886-5274ede7fd6a	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "92c8f217-9b27-49a7-a612-6ae46a5ec5cd", "staffMemberId": "ba7c9524-b0d4-4845-8886-5274ede7fd6a"}	\N	2026-08-07 12:26:14.279+00
6c6dcca6-747a-45cd-9895-829024ff038e	9d965b2a-2b91-456a-92bb-937b05888fa8	all-staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "2f50aaaa-7651-407b-82d6-10998cee1153", "staffMemberId": "a3b2cb93-a39f-4cb4-9872-bec91a7edd69"}	\N	2026-08-07 12:26:14.323+00
77dec06c-148f-4c87-825c-1688bd2eb966	526ae4f7-c7f7-4411-ac5f-3265dafc8db6	all-staff	\N	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "1c112e04-41e7-4b6c-8b29-addde7f0503a", "staffMemberId": "6b8f1aa6-76fe-41db-9c27-3e6df015dd5e"}	\N	2026-08-07 12:13:52.018+00
71032e93-0c82-400b-a81b-918dbff0613b	526ae4f7-c7f7-4411-ac5f-3265dafc8db6	all-staff	\N	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "1c112e04-41e7-4b6c-8b29-addde7f0503a", "staffMemberId": "6b8f1aa6-76fe-41db-9c27-3e6df015dd5e"}	\N	2026-08-07 12:13:52.079+00
bb69bf03-13f9-4778-925e-f39604bd427c	9d965b2a-2b91-456a-92bb-937b05888fa8	all-staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	booking.rejected	نوبت رد شد	رزرو توسط مدیر رد شد.	{"appointmentId": "2f50aaaa-7651-407b-82d6-10998cee1153", "staffMemberId": "a3b2cb93-a39f-4cb4-9872-bec91a7edd69"}	\N	2026-08-07 12:26:14.36+00
f4000000-0000-4000-8000-000000000005	d7412cac-b652-4a48-a889-e282a2ed5d55	owner	\N	subscription.expiring	یادآوری اشتراک آزمایشی	اشتراک آزمایشی سالن تا چند روز دیگر نیاز به تمدید دارد.	{"plan": "trial"}	2026-08-06 13:12:03.457249+00	2026-08-05 13:12:03.457249+00
91000000-0000-0000-0000-000000000005	11111111-1111-1111-1111-111111111111	owner	\N	new.customer	مشتری جدید	رها مرادی برای اولین بار از آرا وقت رزرو کرده است.	{"customerName": "رها مرادی"}	\N	2026-08-07 11:48:35.458336+00
be3b85c1-4764-4312-b3fe-9f694ffdfd95	1bb72fda-9b55-4d92-b5ae-07341a7c9aaf	all-staff	db6cda46-0c20-4e07-8e56-9aa00f532893	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "c9a828e7-2845-4cae-b08d-929cc20f4d4a", "staffMemberId": "db6cda46-0c20-4e07-8e56-9aa00f532893"}	2026-08-07 12:23:40.341+00	2026-08-07 12:23:40.318+00
8e46afe8-fa9b-4a13-a9ae-c3440cb62bf4	9d965b2a-2b91-456a-92bb-937b05888fa8	all-staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "f3b7e9c7-ef59-48d0-95e5-00a1895bd077", "staffMemberId": "a3b2cb93-a39f-4cb4-9872-bec91a7edd69"}	\N	2026-08-07 12:26:14.404+00
df852e0b-c101-404b-8a89-982ba516d469	9d965b2a-2b91-456a-92bb-937b05888fa8	all-staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "7ff67103-6800-44b6-9b1b-d54bfa3e8e51", "staffMemberId": "a3b2cb93-a39f-4cb4-9872-bec91a7edd69"}	\N	2026-08-07 12:26:14.468+00
c6a935cc-9e42-4b8f-b3e4-3e3f6bfa22a4	9d965b2a-2b91-456a-92bb-937b05888fa8	all-staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "7ff67103-6800-44b6-9b1b-d54bfa3e8e51", "staffMemberId": "a3b2cb93-a39f-4cb4-9872-bec91a7edd69"}	\N	2026-08-07 12:26:14.502+00
98967959-47d2-4c2d-869f-2e770db6010c	9d965b2a-2b91-456a-92bb-937b05888fa8	all-staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	booking.confirmed	رزرو جدید تأیید شد	یک نوبت جدید ثبت و به‌صورت خودکار تأیید شد.	{"date": "2026-08-09", "appointmentId": "04e01a40-2b9e-4198-a824-1f1f3c04ac75", "staffMemberId": "a3b2cb93-a39f-4cb4-9872-bec91a7edd69"}	\N	2026-08-07 12:26:14.585+00
f06fa30a-1aa3-41b6-9585-23bbae9eb411	b9e33109-b47b-40d5-a0ac-2a0d837c6827	all-staff	30c7ba5b-2085-4124-a6f2-7986e79071f0	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "db459809-b753-4ca3-a7f3-75dd0e1495bb", "staffMemberId": "30c7ba5b-2085-4124-a6f2-7986e79071f0"}	2026-08-07 12:26:15.194+00	2026-08-07 12:26:15.17+00
a34aca32-020a-4c12-860e-f2b96eb6052d	e7f95ac5-5c53-4db7-b274-f0c94730f18c	all-staff	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "b4193219-770a-410b-9bbf-c2133ce97e0e", "staffMemberId": "ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740"}	\N	2026-08-07 12:49:23.468+00
0d059208-7c68-4054-b4c2-f7406dd4fdd2	e7f95ac5-5c53-4db7-b274-f0c94730f18c	all-staff	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "b4193219-770a-410b-9bbf-c2133ce97e0e", "staffMemberId": "ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740"}	\N	2026-08-07 12:49:23.516+00
37276a31-22e9-4123-8176-539df93a0f3e	e7f95ac5-5c53-4db7-b274-f0c94730f18c	all-staff	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "bfe6b241-23ab-402d-8c81-1963b50e330e", "staffMemberId": "ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740"}	\N	2026-08-07 12:49:23.55+00
2930ab57-abc5-48b7-9700-21f188b29e10	e7f95ac5-5c53-4db7-b274-f0c94730f18c	all-staff	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "bfe6b241-23ab-402d-8c81-1963b50e330e", "staffMemberId": "ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740"}	\N	2026-08-07 12:49:23.574+00
d920f6b5-450c-4f35-b36b-21037d950e98	e7f95ac5-5c53-4db7-b274-f0c94730f18c	all-staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "98eeb69d-9e79-4e5a-bed7-5adc029dca88", "staffMemberId": "a8bafa5c-6bf7-4441-97d4-b5fae40a1935"}	\N	2026-08-07 12:49:23.666+00
57b30e19-b86c-494e-bc96-602a6c2b03f4	e7f95ac5-5c53-4db7-b274-f0c94730f18c	all-staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	booking.rejected	نوبت رد شد	رزرو توسط مدیر رد شد.	{"appointmentId": "98eeb69d-9e79-4e5a-bed7-5adc029dca88", "staffMemberId": "a8bafa5c-6bf7-4441-97d4-b5fae40a1935"}	\N	2026-08-07 12:49:23.691+00
af16b53e-ffbf-4f79-8ad0-a163385d780f	e7f95ac5-5c53-4db7-b274-f0c94730f18c	all-staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "53dc7ab7-cfd4-449f-8683-5d61d6dccc2d", "staffMemberId": "a8bafa5c-6bf7-4441-97d4-b5fae40a1935"}	\N	2026-08-07 12:49:23.724+00
9f94ebec-afe4-413c-8b9c-c5db2f6453bc	e7f95ac5-5c53-4db7-b274-f0c94730f18c	all-staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "bcec2c53-e328-49dd-a9ca-abf278a43ceb", "staffMemberId": "a8bafa5c-6bf7-4441-97d4-b5fae40a1935"}	\N	2026-08-07 12:49:23.775+00
c6fff4c6-edb2-4dbe-8b80-a2c6a00f0675	e7f95ac5-5c53-4db7-b274-f0c94730f18c	all-staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "bcec2c53-e328-49dd-a9ca-abf278a43ceb", "staffMemberId": "a8bafa5c-6bf7-4441-97d4-b5fae40a1935"}	\N	2026-08-07 12:49:23.798+00
4b092144-39b6-4cba-8312-9997536a35ce	e7f95ac5-5c53-4db7-b274-f0c94730f18c	all-staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	booking.confirmed	رزرو جدید تأیید شد	یک نوبت جدید ثبت و به‌صورت خودکار تأیید شد.	{"date": "2026-08-09", "appointmentId": "cf2fcd63-42ea-40c7-9a4b-7d20325e87f0", "staffMemberId": "a8bafa5c-6bf7-4441-97d4-b5fae40a1935"}	\N	2026-08-07 12:49:23.857+00
64437666-9c64-402c-aa97-10d3a0873d6e	f9eaed2d-7068-4583-8a46-869324599cc6	all-staff	3f9e4c0c-0bdb-460e-982a-781f1baa2ca1	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "9e40a949-5a18-427d-a0a1-681ac3316726", "staffMemberId": "3f9e4c0c-0bdb-460e-982a-781f1baa2ca1"}	2026-08-07 12:49:24.342+00	2026-08-07 12:49:24.323+00
c29b6192-96e7-4afc-bf52-479d312809b6	a3b92139-eb81-4a88-a88d-0e4b23e9368c	all-staff	fe8403ef-6732-42db-868d-4346f296f49c	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "26d3cbe8-8eb8-4167-b95f-47b4cd6bbf53", "staffMemberId": "fe8403ef-6732-42db-868d-4346f296f49c"}	\N	2026-08-07 12:49:41.826+00
f4000000-0000-4000-8000-000000000001	d7412cac-b652-4a48-a889-e282a2ed5d55	owner	\N	booking.pending	رزرو جدید در انتظار تأیید	رها تست برای خدمت پاکسازی پوست درخواست رزرو ثبت کرده است.	{"customerName": "رها تست", "appointmentId": "f1000000-0000-4000-8000-000000000005"}	2026-08-07 13:37:26.729+00	2026-08-07 12:47:03.457249+00
f4000000-0000-4000-8000-000000000002	d7412cac-b652-4a48-a889-e282a2ed5d55	admin	\N	booking.pending	یک رزرو نیاز به بررسی دارد	مشتری تست برای خدمت ناخن و ژل درخواست رزرو ثبت کرده است.	{"customerName": "مشتری تست", "appointmentId": "f1000000-0000-4000-8000-000000000012"}	2026-08-07 13:37:26.729+00	2026-08-07 12:52:03.457249+00
4341bbe1-5b06-4ac1-9048-7464e1e6ec29	d7412cac-b652-4a48-a889-e282a2ed5d55	all-staff	6154b0bb-a33d-4aa1-bb85-e74badea0943	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "f1000000-0000-4000-8000-000000000005", "staffMemberId": "6154b0bb-a33d-4aa1-bb85-e74badea0943"}	2026-08-07 13:37:26.729+00	2026-08-07 13:27:38.693+00
33215df5-c847-4300-800c-e9fdf36670a4	d7412cac-b652-4a48-a889-e282a2ed5d55	all-staff	34d42336-3900-4918-a2d6-9068b8cfe6b0	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "f1000000-0000-4000-8000-000000000012", "staffMemberId": "34d42336-3900-4918-a2d6-9068b8cfe6b0"}	2026-08-07 13:37:26.729+00	2026-08-07 13:27:39.454+00
f4000000-0000-4000-8000-000000000003	d7412cac-b652-4a48-a889-e282a2ed5d55	stylist	34d42336-3900-4918-a2d6-9068b8cfe6b0	booking.approved	رزرو شما تأیید شد	الهام تست امروز ساعت ۱۰ برای پاکسازی پوست مراجعه می‌کند.	{"appointmentId": "f1000000-0000-4000-8000-000000000011"}	2026-08-07 13:37:26.729+00	2026-08-07 12:37:03.457249+00
f4000000-0000-4000-8000-000000000004	d7412cac-b652-4a48-a889-e282a2ed5d55	all-staff	\N	new.customer	مشتری جدید	نیلوفر تست برای اولین بار در سالن ثبت شد.	{"customerId": "f7690417-beec-4ace-82fa-3d11b987410d", "customerName": "نیلوفر تست"}	2026-08-07 13:37:26.729+00	2026-08-07 10:12:03.457249+00
24a3c741-1c6f-498b-af69-e37d0758a6ec	4acda9b4-b53a-452d-b438-3c01cc8a3ca4	all-staff	a9955774-e41d-4176-aff4-b10e51138abf	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "c207ed5f-d9c0-4021-b13c-94eae93d2978", "staffMemberId": "a9955774-e41d-4176-aff4-b10e51138abf"}	\N	2026-08-07 13:52:31.964+00
44cc718e-e920-4f8e-bbef-ee463a71d269	d86a4f90-7ef3-477a-b928-3804c9bd1bca	all-staff	3799ff0a-0064-4f2a-8717-4d2c35b40060	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "0d38fc85-8f42-4038-bf84-6f6b9789e6ca", "staffMemberId": "3799ff0a-0064-4f2a-8717-4d2c35b40060"}	\N	2026-08-07 13:56:05.453+00
39c539ab-824d-4bd3-91d0-47e2f1b31b5a	c66e014b-5299-4f9f-bc65-195fbad0cd99	all-staff	05cf7580-8f7d-433b-a660-ab1b55791e8c	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "b8f61752-ae0c-40fe-bdae-90a4798befb5", "staffMemberId": "05cf7580-8f7d-433b-a660-ab1b55791e8c"}	\N	2026-08-07 13:56:56.527+00
9662181a-3164-419e-aff1-5f0af0063b3b	c66e014b-5299-4f9f-bc65-195fbad0cd99	all-staff	05cf7580-8f7d-433b-a660-ab1b55791e8c	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "b8f61752-ae0c-40fe-bdae-90a4798befb5", "staffMemberId": "05cf7580-8f7d-433b-a660-ab1b55791e8c"}	\N	2026-08-07 13:56:56.579+00
3053207a-7a44-43e8-b6b7-eea95656a554	c66e014b-5299-4f9f-bc65-195fbad0cd99	all-staff	05cf7580-8f7d-433b-a660-ab1b55791e8c	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "15504f9d-cb34-4f31-ad4a-67fb039bbab0", "staffMemberId": "05cf7580-8f7d-433b-a660-ab1b55791e8c"}	\N	2026-08-07 13:56:56.623+00
e55d8cdb-eea4-417e-aa9b-92e72c51f80e	c66e014b-5299-4f9f-bc65-195fbad0cd99	all-staff	05cf7580-8f7d-433b-a660-ab1b55791e8c	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "15504f9d-cb34-4f31-ad4a-67fb039bbab0", "staffMemberId": "05cf7580-8f7d-433b-a660-ab1b55791e8c"}	\N	2026-08-07 13:56:56.649+00
f62ffb5e-1b70-4a98-b141-3f2f238acc7b	33b55265-4e46-4dfc-8e22-22fd32ccd0f2	all-staff	4094637e-5070-4e5e-a1c7-627a2f8cb985	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "f8912221-fd03-40ea-bc3b-ebc76f6cebd4", "staffMemberId": "4094637e-5070-4e5e-a1c7-627a2f8cb985"}	2026-08-07 13:56:57.824+00	2026-08-07 13:56:57.803+00
4451d023-f4af-4d64-bb88-d3da866be73a	ca682117-4612-4948-ae95-9706f3d56404	all-staff	50070078-f099-4cb5-a8ce-c6bde911a49e	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "2fbaf9d6-14d4-4284-a4c2-a51398cc5333", "staffMemberId": "50070078-f099-4cb5-a8ce-c6bde911a49e"}	\N	2026-08-07 13:58:33.162+00
ab62a18e-0a03-4661-865c-b5d952c2596a	ca682117-4612-4948-ae95-9706f3d56404	all-staff	50070078-f099-4cb5-a8ce-c6bde911a49e	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "2fbaf9d6-14d4-4284-a4c2-a51398cc5333", "staffMemberId": "50070078-f099-4cb5-a8ce-c6bde911a49e"}	\N	2026-08-07 13:58:33.212+00
463ee8c3-0b78-4f28-b7f4-34738b97fc96	ca682117-4612-4948-ae95-9706f3d56404	all-staff	50070078-f099-4cb5-a8ce-c6bde911a49e	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "84b442fd-1463-496c-97c4-329a6ba9f1a6", "staffMemberId": "50070078-f099-4cb5-a8ce-c6bde911a49e"}	\N	2026-08-07 13:58:33.249+00
bb18ec7f-bb47-45a8-811f-fdf67a4dc64e	ca682117-4612-4948-ae95-9706f3d56404	all-staff	50070078-f099-4cb5-a8ce-c6bde911a49e	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "84b442fd-1463-496c-97c4-329a6ba9f1a6", "staffMemberId": "50070078-f099-4cb5-a8ce-c6bde911a49e"}	\N	2026-08-07 13:58:33.273+00
77d05d30-b2fb-448a-86b9-804603c0cb9f	ca682117-4612-4948-ae95-9706f3d56404	all-staff	f073a0ff-6e6f-43d4-9a63-9ed194b88797	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-10", "appointmentId": "1b77fefe-cdcb-43a4-8e40-b0a679c7c968", "staffMemberId": "f073a0ff-6e6f-43d4-9a63-9ed194b88797"}	\N	2026-08-07 13:58:33.367+00
1c6990dd-2662-4883-8d40-a0dd21e874a9	ca682117-4612-4948-ae95-9706f3d56404	all-staff	f073a0ff-6e6f-43d4-9a63-9ed194b88797	booking.rejected	نوبت رد شد	رزرو توسط مدیر رد شد.	{"appointmentId": "1b77fefe-cdcb-43a4-8e40-b0a679c7c968", "staffMemberId": "f073a0ff-6e6f-43d4-9a63-9ed194b88797"}	\N	2026-08-07 13:58:33.402+00
b3d876c9-65c6-434b-a08a-58feb7a508f3	9ce67759-ee69-4264-a07f-891b3f9805e2	all-staff	f03e27a5-59d9-4a0d-be4c-9d55c611afa2	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "f1a47354-d172-4483-b16d-371a98320baf", "staffMemberId": "f03e27a5-59d9-4a0d-be4c-9d55c611afa2"}	2026-08-07 13:58:34.468+00	2026-08-07 13:58:34.442+00
6d3413c1-cdd5-4905-9a38-6a4a9a8fb4eb	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	all-staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "51845931-9a13-438c-8695-f99ed8609182", "staffMemberId": "fd8e1e25-280c-4c6f-bed3-f070bcce4912"}	\N	2026-08-07 14:00:06.967+00
09b24335-8f7e-416c-8b14-4c6387d4d0db	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	all-staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "51845931-9a13-438c-8695-f99ed8609182", "staffMemberId": "fd8e1e25-280c-4c6f-bed3-f070bcce4912"}	\N	2026-08-07 14:00:07.019+00
9fe06e49-cc9e-47ce-96de-4810dedd4c61	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	all-staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "ade37cfb-9561-4190-903f-89eae28d7bce", "staffMemberId": "fd8e1e25-280c-4c6f-bed3-f070bcce4912"}	\N	2026-08-07 14:00:07.059+00
fa78a66f-98c7-47e5-84b5-dff5cd7deeb4	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	all-staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "ade37cfb-9561-4190-903f-89eae28d7bce", "staffMemberId": "fd8e1e25-280c-4c6f-bed3-f070bcce4912"}	\N	2026-08-07 14:00:07.083+00
c920edac-0c07-4ca3-9ff7-57a56c9ac760	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	all-staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-10", "appointmentId": "bc208f97-dbeb-4dc8-a051-6d3a93c4a808", "staffMemberId": "a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8"}	\N	2026-08-07 14:00:07.179+00
d082578c-bcd0-4b45-a668-d72690cbefc1	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	all-staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	booking.rejected	نوبت رد شد	رزرو توسط مدیر رد شد.	{"appointmentId": "bc208f97-dbeb-4dc8-a051-6d3a93c4a808", "staffMemberId": "a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8"}	\N	2026-08-07 14:00:07.21+00
325ab4be-2820-4f43-a83b-b9d7c30accc9	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	all-staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-11", "appointmentId": "47400210-8c28-499e-8e99-cd33b95793f7", "staffMemberId": "a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8"}	\N	2026-08-07 14:00:07.25+00
a9bdfd2c-ebc0-4b91-bc7b-23a586ae74ce	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	all-staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-13", "appointmentId": "6f629f23-16f0-4692-b6e9-2bdc32aec4c4", "staffMemberId": "a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8"}	\N	2026-08-07 14:00:07.311+00
8d824727-9301-4ef9-ab89-8e652bdbde94	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	all-staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "6f629f23-16f0-4692-b6e9-2bdc32aec4c4", "staffMemberId": "a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8"}	\N	2026-08-07 14:00:07.339+00
50dfb0db-01ee-4640-b9a2-594a30414e05	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	all-staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	booking.confirmed	رزرو جدید تأیید شد	یک نوبت جدید ثبت و به‌صورت خودکار تأیید شد.	{"date": "2026-08-14", "appointmentId": "cccfe2ae-75cb-4edb-8092-5bd558e57b2a", "staffMemberId": "fd8e1e25-280c-4c6f-bed3-f070bcce4912"}	\N	2026-08-07 14:00:07.409+00
9ea2d014-97a2-482b-9ea4-14883b68dcf9	daaee930-a32d-41c2-8e2d-d59946feb22b	all-staff	16d1ba6d-ef25-495d-b7ca-32728de6b6cd	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "50f7b605-c5fa-40ea-b521-14158b2c841c", "staffMemberId": "16d1ba6d-ef25-495d-b7ca-32728de6b6cd"}	2026-08-07 14:00:07.953+00	2026-08-07 14:00:07.93+00
bc22c210-be57-49a7-9b60-1e1f76f1ba4c	41945155-8295-4ffe-9fca-a051aec9d85c	all-staff	e366d7da-0479-44df-bd5a-5a2d666f9313	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "f49d29c7-f499-4442-b226-908911d31ccb", "staffMemberId": "e366d7da-0479-44df-bd5a-5a2d666f9313"}	\N	2026-08-07 14:00:54.936+00
dce4f5f4-ad7f-4ba2-9679-74be2ae0bc64	41945155-8295-4ffe-9fca-a051aec9d85c	all-staff	e366d7da-0479-44df-bd5a-5a2d666f9313	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "f49d29c7-f499-4442-b226-908911d31ccb", "staffMemberId": "e366d7da-0479-44df-bd5a-5a2d666f9313"}	\N	2026-08-07 14:00:54.994+00
1c4374d2-6119-44fc-9fc3-d638d875f2ad	41945155-8295-4ffe-9fca-a051aec9d85c	all-staff	e366d7da-0479-44df-bd5a-5a2d666f9313	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "b617683e-a55a-42ec-9383-03016bbe318d", "staffMemberId": "e366d7da-0479-44df-bd5a-5a2d666f9313"}	\N	2026-08-07 14:00:55.041+00
eb0d1342-ad7b-4165-b2c7-f43e04a6036b	41945155-8295-4ffe-9fca-a051aec9d85c	all-staff	e366d7da-0479-44df-bd5a-5a2d666f9313	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "b617683e-a55a-42ec-9383-03016bbe318d", "staffMemberId": "e366d7da-0479-44df-bd5a-5a2d666f9313"}	\N	2026-08-07 14:00:55.067+00
c60cc11f-dd1f-4928-a18a-660c3cf6e051	41945155-8295-4ffe-9fca-a051aec9d85c	all-staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-10", "appointmentId": "34340795-0561-4bcd-898b-2f20f5a4f03b", "staffMemberId": "7a95cf70-0805-4d3e-a1e9-b5db7b2f531c"}	\N	2026-08-07 14:00:55.184+00
54ceb8a8-7387-4b82-b474-4833a0d5ee47	41945155-8295-4ffe-9fca-a051aec9d85c	all-staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	booking.rejected	نوبت رد شد	رزرو توسط مدیر رد شد.	{"appointmentId": "34340795-0561-4bcd-898b-2f20f5a4f03b", "staffMemberId": "7a95cf70-0805-4d3e-a1e9-b5db7b2f531c"}	\N	2026-08-07 14:00:55.217+00
73b43b6d-4bd7-4454-8a90-56567b2178d7	41945155-8295-4ffe-9fca-a051aec9d85c	all-staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-11", "appointmentId": "9549a141-1652-4612-ae4f-9dd776b3928e", "staffMemberId": "7a95cf70-0805-4d3e-a1e9-b5db7b2f531c"}	\N	2026-08-07 14:00:55.265+00
ab410109-62a9-4ed1-b91b-fe57bb34ae35	41945155-8295-4ffe-9fca-a051aec9d85c	all-staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-13", "appointmentId": "4b9b917a-1882-4707-a369-7f349a533394", "staffMemberId": "7a95cf70-0805-4d3e-a1e9-b5db7b2f531c"}	\N	2026-08-07 14:00:55.334+00
3644a2eb-95e5-4475-96ab-49a478012cf5	41945155-8295-4ffe-9fca-a051aec9d85c	all-staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "4b9b917a-1882-4707-a369-7f349a533394", "staffMemberId": "7a95cf70-0805-4d3e-a1e9-b5db7b2f531c"}	\N	2026-08-07 14:00:55.366+00
31f8d646-0bb8-4448-9b4d-2728ba6c68ee	41945155-8295-4ffe-9fca-a051aec9d85c	all-staff	e366d7da-0479-44df-bd5a-5a2d666f9313	booking.confirmed	رزرو جدید تأیید شد	یک نوبت جدید ثبت و به‌صورت خودکار تأیید شد.	{"date": "2026-08-14", "appointmentId": "4e2abbdd-4cac-4e18-8bce-900f7093bc74", "staffMemberId": "e366d7da-0479-44df-bd5a-5a2d666f9313"}	\N	2026-08-07 14:00:55.45+00
ba6e3ec3-958a-47e9-a070-6900549b504c	d5fb54d8-3c89-493d-8edd-48fb3f04ef42	all-staff	e2200c8d-5e09-4149-bea1-d3a6a7f0e421	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "975d9904-a2bd-409d-b46e-5a51e8f7b60a", "staffMemberId": "e2200c8d-5e09-4149-bea1-d3a6a7f0e421"}	2026-08-07 14:00:56.083+00	2026-08-07 14:00:56.061+00
87468820-3173-4e5e-b517-be996f41204d	e66c3ae5-4fe0-48ef-a5f8-e2226df0ed55	all-staff	274d5221-7f2c-46d4-b797-119ae3f82652	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "9eb3d656-d42a-4a2b-9dac-4072e44cc38b", "staffMemberId": "274d5221-7f2c-46d4-b797-119ae3f82652"}	\N	2026-08-07 14:01:17.541+00
6ec4d374-e962-412a-951c-ec95bd17fc46	ecfd9427-201f-45b4-b995-0c5903186dcf	all-staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "abe4a8f7-974f-4fbf-b642-cc8a3ad29133", "staffMemberId": "d41ffc8a-603b-483a-bfe3-3c7994ef116c"}	\N	2026-08-07 14:01:54.932+00
978397de-2a63-4b38-b61c-6b21c68ca6a1	ecfd9427-201f-45b4-b995-0c5903186dcf	all-staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "abe4a8f7-974f-4fbf-b642-cc8a3ad29133", "staffMemberId": "d41ffc8a-603b-483a-bfe3-3c7994ef116c"}	\N	2026-08-07 14:01:54.986+00
75c5073e-017a-42e0-b4cc-02e424694525	ecfd9427-201f-45b4-b995-0c5903186dcf	all-staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-09", "appointmentId": "608f06e4-1363-4010-bb3c-030f1499ebe1", "staffMemberId": "d41ffc8a-603b-483a-bfe3-3c7994ef116c"}	\N	2026-08-07 14:01:55.027+00
53baca7d-2f6f-4823-8cbd-f2b825082fc5	ecfd9427-201f-45b4-b995-0c5903186dcf	all-staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "608f06e4-1363-4010-bb3c-030f1499ebe1", "staffMemberId": "d41ffc8a-603b-483a-bfe3-3c7994ef116c"}	\N	2026-08-07 14:01:55.05+00
5b42bf21-ef97-442a-a6a3-87c46b159eae	ecfd9427-201f-45b4-b995-0c5903186dcf	all-staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-10", "appointmentId": "d9ed7173-9d8d-4c7f-94e7-6cf8e78701dd", "staffMemberId": "bb302d69-79ff-4921-86d1-8e6e22ae92cb"}	\N	2026-08-07 14:01:55.151+00
728ec802-b354-491c-bebe-f24620749b77	ecfd9427-201f-45b4-b995-0c5903186dcf	all-staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	booking.rejected	نوبت رد شد	رزرو توسط مدیر رد شد.	{"appointmentId": "d9ed7173-9d8d-4c7f-94e7-6cf8e78701dd", "staffMemberId": "bb302d69-79ff-4921-86d1-8e6e22ae92cb"}	\N	2026-08-07 14:01:55.181+00
a4074e83-40ef-4caf-8e46-5ed4b2b21cae	ecfd9427-201f-45b4-b995-0c5903186dcf	all-staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-11", "appointmentId": "32ebcaa0-14f5-4df2-92d0-8cdfd4eaeb3e", "staffMemberId": "bb302d69-79ff-4921-86d1-8e6e22ae92cb"}	\N	2026-08-07 14:01:55.221+00
f44f9bea-3398-44a2-a03b-ffe5b93a5219	ecfd9427-201f-45b4-b995-0c5903186dcf	all-staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-13", "appointmentId": "6490bafa-0a3e-4d27-a7dd-9ddffeed60b1", "staffMemberId": "bb302d69-79ff-4921-86d1-8e6e22ae92cb"}	\N	2026-08-07 14:01:55.286+00
557707b6-5890-4a5e-ac85-6e867a44bb3e	ecfd9427-201f-45b4-b995-0c5903186dcf	all-staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	booking.approved	نوبت تأیید شد	رزرو توسط مدیر تأیید شد.	{"appointmentId": "6490bafa-0a3e-4d27-a7dd-9ddffeed60b1", "staffMemberId": "bb302d69-79ff-4921-86d1-8e6e22ae92cb"}	\N	2026-08-07 14:01:55.321+00
be41df3c-98d0-4223-82c5-b11d06f35a96	ecfd9427-201f-45b4-b995-0c5903186dcf	all-staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	booking.confirmed	رزرو جدید تأیید شد	یک نوبت جدید ثبت و به‌صورت خودکار تأیید شد.	{"date": "2026-08-14", "appointmentId": "a3136b2a-f53c-4a2b-b16b-fd68563e9c23", "staffMemberId": "d41ffc8a-603b-483a-bfe3-3c7994ef116c"}	\N	2026-08-07 14:01:55.397+00
e3ad7cfc-7a3d-42bd-b642-7254226aae7c	a8f9e2e8-b848-487b-a2c4-8b7a01f955a3	all-staff	b25a26a7-eb8d-49a2-b10f-79544277cebb	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "59a0cf4e-729b-42e2-9a61-14f892633f74", "staffMemberId": "b25a26a7-eb8d-49a2-b10f-79544277cebb"}	2026-08-07 14:01:55.968+00	2026-08-07 14:01:55.946+00
54dd8dd9-36d8-4129-ba92-2d66c90535f0	e71737ea-c9ab-401c-bd67-8525aa0060fd	all-staff	51f6dc27-15f5-44a3-9826-0805962f6322	booking.pending	نوبت در انتظار تأیید	یک رزرو جدید ثبت شد و منتظر تأیید شماست.	{"date": "2026-08-08", "appointmentId": "4d096d26-7e40-43d9-b4b7-86fa25adee63", "staffMemberId": "51f6dc27-15f5-44a3-9826-0805962f6322"}	\N	2026-08-07 14:02:14.267+00
\.


--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service (id, salon_id, name, duration_min, buffer_min, price_rial, requires_deposit, deposit_rial) FROM stdin;
44444444-4444-4444-4444-444444444444	11111111-1111-1111-1111-111111111111	کوتاهی مو	30	5	2500000	f	\N
55555555-5555-5555-5555-555555555555	11111111-1111-1111-1111-111111111111	رنگ مو	90	10	8000000	f	\N
497d7969-bf85-4490-9a04-2d991cf1efc2	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	کوتاهی مو	30	0	0	f	\N
b737300f-f766-48b1-bb89-72d693b89304	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	ننبینهبیذ	90	0	0	f	\N
ef6f608d-b6bd-4a9f-a622-61dc140da791	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	لفشثسق	30	0	0	f	\N
a23a88ad-782d-4ced-830f-552da042c1bf	82ad3b1b-e80e-4d67-95d4-e934f31934a4	E2E Hair	30	0	100000	f	\N
0318bfaf-fe76-4c46-9c46-fb3adfd01304	1ba2c5c1-6c6e-4e84-9343-56d66b2d3226	Inspect Hair	30	0	100000	f	\N
faf6ad96-a197-41ab-89c4-cb87d8182098	e54af3fc-d38b-41ad-b517-e558fa0e6cbf	Inspect Hair	30	0	100000	f	\N
8e6e1cbd-82c0-412e-bcad-0115c42a45c3	c243bba9-2f63-421a-b92f-7e9eee00a7e2	E2E UI سرویس	30	0	500000	f	\N
aec1a45f-3066-4f95-8051-b2c44ff37316	f7bc45c9-75c1-4443-9dee-3b2183130dc0	E2E RBAC سرویس	30	0	500000	f	\N
0361ea0a-cd9f-48b1-9639-55ae549f8eca	eed48a8d-9014-40d6-903a-955c31140613	E2E Booking سرویس	30	0	500000	f	\N
ac55b6f0-8d07-42ec-af6d-cf6b78a5e22c	f2b895e3-8eaf-42e4-b3c6-a244fff4934f	E2E QR سرویس	30	0	500000	f	\N
4b0edb9c-5799-43b5-b736-fc648a6c9c0a	3c84048d-601a-4f55-a989-038efc3ddbd2	svc	30	0	1	f	\N
fa6cd82e-ae46-4b63-b3ad-f7ba136d298f	34c4ebd4-eef3-4225-bcf6-cdaac1521668	E2E UI سرویس	30	0	500000	f	\N
19e28e6c-5cd8-4883-af40-d7aadde15327	6524f8ac-5aae-4f63-80ca-6cee0c030b20	E2E UI سرویس	30	0	500000	f	\N
224f917c-4ef3-48a7-9013-80b216989550	8a91b095-7147-4ff4-9b71-290b72e6de88	E2E RBAC سرویس	30	0	500000	f	\N
95a9f08d-74d7-4ed0-8c32-48046e148026	b8d1f622-7f06-49a7-aba2-30dcef24f8a7	کوتاهی مو	30	0	0	f	\N
4ffeda91-e721-4f4a-bb6a-e0d92cc7ffa7	b459826c-7585-4616-a22a-665a527778d3	براشینگ	30	0	0	f	\N
8ae968e4-99cc-41e0-8e2b-21d43410020d	049ff655-e678-4a8a-aa15-dd1d0f082d72	E2E Booking سرویس	30	0	500000	f	\N
825ca07a-4e5b-4d52-80fd-4880cf1c033c	3ae5cde0-3a8d-4d60-be96-c4c456e161a0	E2E QR سرویس	30	0	500000	f	\N
3fe2d31e-00e3-46fb-b9f7-d716f590db17	83738a22-ac2f-4959-ae1f-31ab6a64d166	E2E QR Trial سرویس	30	0	500000	f	\N
c1d56bbf-2e48-4eaa-846a-75e784505e52	e539a6f7-3a89-4777-8cc4-356882028d76	E2E QR Trial سرویس	30	0	500000	f	\N
f830ce25-2c57-4f18-964e-e5874b0102f9	b332bbaf-9ab8-45da-a7a3-e27644b594e5	E2E QR Trial سرویس	30	0	500000	f	\N
a8ac06ae-eb9a-4c77-a8b6-29f5d7afda12	94d4a899-f24e-4163-9da6-d42540203798	E2E QR Trial سرویس	30	0	500000	f	\N
4ab72951-7f05-4b3e-9c2e-cf900cb1c61f	37b31e8c-6d49-4cd9-aea2-e27961f8804f	E2E UI سرویس	30	0	500000	f	\N
89369143-f318-408f-979f-32397d98c47b	ede45a95-710d-4132-8214-e4c2f13f28e0	E2E RBAC سرویس	30	0	500000	f	\N
b57609fb-6d0d-4bbe-9cd1-97bc6ab079ef	3e1a529c-c38c-410a-9147-b0776d2cf387	E2E Config Matrix سرویس	30	0	500000	f	\N
e2e056a3-8ed7-40e8-84e4-ac06fd4fa634	bb22b03a-5d16-4b81-b42a-49e37d27593b	E2E Other Tenant سرویس	30	0	500000	f	\N
43a04e11-1214-4932-a9e0-0fc928555e62	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	E2E Booking Matrix سرویس	30	0	500000	f	\N
06917464-b6ab-4c69-a66c-3a9aebe57995	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	Booking Matrix Service	30	0	300000	f	\N
04d76778-4be4-43d8-b53c-8e812948bb88	55809d45-8657-47fe-a0e2-ad8116219af4	E2E Premium Matrix سرویس	30	0	500000	f	\N
ecd54a05-9774-4628-934e-abf783a70b11	c29ea8c8-5840-4ddb-885c-e70eafb741b5	Booking Matrix Service	30	0	300000	f	\N
9c8141c1-1841-420b-8348-74da783cc665	48b7b978-caca-4b3d-9996-48178b2a4fb5	E2E Premium Matrix سرویس	30	0	500000	f	\N
63d49f0e-2178-4300-95e8-4f989642dde2	1bb72fda-9b55-4d92-b5ae-07341a7c9aaf	E2E Misc Matrix سرویس	30	0	500000	f	\N
1a2d11db-399d-4c34-8794-da3a709de408	1cb71f4e-7f3f-473c-9ba2-9bf38e6943fa	E2E Notification Other سرویس	30	0	500000	f	\N
68255968-8e13-45f2-ba55-f1a324546113	8d4082de-f9bc-483c-8364-fb5373ecee79	E2E Booking سرویس	30	0	500000	f	\N
87dc1217-8eca-4df2-bf54-5832c6ffbd6d	d04088e4-0987-405e-a912-9728a30e1fb7	E2E QR Trial سرویس	30	0	500000	f	\N
21395461-4627-4dab-b758-584bb5452544	282f2ee7-f778-4f75-8e41-72ee726e2d71	E2E UI سرویس	30	0	500000	f	\N
dc6bd3aa-0972-4a41-ac33-ec0436a1d951	3ad3c745-12dc-4dca-9e16-ee4c57bd987b	E2E RBAC سرویس	30	0	500000	f	\N
509b8201-5d9f-4560-be39-140bf5049d0b	6a5b29c2-a8df-467a-8c36-ca49f545625c	E2E Booking سرویس	30	0	500000	f	\N
553b6325-58d9-4854-9eb7-44ef14574865	36e79989-a20d-4f1e-9b9b-538d101b4014	E2E QR Trial سرویس	30	0	500000	f	\N
3b908841-7ffc-4cad-bbfa-aaf28faebe66	c21b3648-38a3-4dde-86ea-cbee7d78165f	E2E Misc Matrix سرویس	30	0	500000	f	\N
26eb8a95-5606-428c-a7e5-2ea1bdeb8418	8aa546de-8daf-489d-9fe8-8b3118bf9f7a	E2E Notification Other سرویس	30	0	500000	f	\N
dc500c4c-8d92-4651-a883-330129f793e2	a32e5e4b-40d7-4635-939c-79fb4b2fdc68	E2E Public Matrix سرویس	30	0	500000	f	\N
06cb40c6-0469-4b60-8c27-870504c35ba3	83bc9d7c-d555-4961-8c35-215f48b3f8b7	E2E Config Matrix سرویس	30	0	500000	f	\N
13adf2bb-4a17-43cf-8356-09a7b067a0f2	c3104b98-c5c9-46db-b100-1ad8180b1c11	E2E Other Tenant سرویس	30	0	500000	f	\N
658b05db-ad00-4484-8747-c963a4877a8d	9d965b2a-2b91-456a-92bb-937b05888fa8	E2E Booking Matrix سرویس	30	0	500000	f	\N
8213ea5e-0b2b-4950-95eb-53903a8e3991	9d965b2a-2b91-456a-92bb-937b05888fa8	Booking Matrix Service	30	0	300000	f	\N
bd3b9730-2f7d-4fd8-b0af-440177d30a6d	65b96ada-c840-4a9d-bfbb-5fa5df901d91	E2E Premium Matrix سرویس	30	0	500000	f	\N
1e8d5b7c-644b-4e1e-a664-d40a715ccf5e	b9e33109-b47b-40d5-a0ac-2a0d837c6827	E2E Misc Matrix سرویس	30	0	500000	f	\N
ad71be3b-ea13-40d2-a348-b36cdfc1dfef	4c0bfb7e-08bb-4675-9b6c-b7928cbb347e	E2E Public Matrix سرویس	30	0	500000	f	\N
58df76aa-92df-4a4f-927f-e45b53b29ab3	b6e528ae-c2ac-4579-bd70-4a33806fbcee	E2E Config Matrix سرویس	30	0	500000	f	\N
06474c8f-c02b-45b2-8f24-d9bb6241c78c	b6e528ae-c2ac-4579-bd70-4a33806fbcee	E2E Config Service	45	0	750000	f	\N
0b088f13-26c8-4a75-8f5a-6dfb5d40462a	c29ea8c8-5840-4ddb-885c-e70eafb741b5	E2E Booking Matrix سرویس	30	0	500000	f	\N
e5d573c6-05e1-4637-a1d7-8a383d1ae969	0ed4db5e-a345-4f57-a5ff-7faf1876853c	E2E Public Matrix سرویس	30	0	500000	f	\N
522739a3-6aff-4bff-9272-3a680691fda1	1e53029c-8667-4f39-a775-f30d1293f13a	E2E Notification Other سرویس	30	0	500000	f	\N
e519f693-83f9-4b4c-be19-daf0ab7a26e5	21835586-a1de-4990-bb83-8f9cc4373a5c	E2E Public Matrix سرویس	30	0	500000	f	\N
f45d4d3f-1916-4886-855e-f520f32362f9	94d46edb-1124-4428-993f-64b9e456dbfb	E2E Config Matrix سرویس	30	0	500000	f	\N
542046ce-c7df-47d5-9350-b9cf41de228b	9f5bd53c-a3c5-4380-b111-3bcfc11381d3	E2E Other Tenant سرویس	30	0	500000	f	\N
b946e06c-647d-443c-9882-d7f8d05a2773	9f5bd53c-a3c5-4380-b111-3bcfc11381d3	Other tenant service	30	0	0	f	\N
9a6f7162-c782-48ab-a32a-43f47e25239a	e7f95ac5-5c53-4db7-b274-f0c94730f18c	E2E Booking Matrix سرویس	30	0	500000	f	\N
6395a750-12ab-4088-b351-cd0c98d5f404	e7f95ac5-5c53-4db7-b274-f0c94730f18c	Booking Matrix Service	30	0	300000	f	\N
7b78719c-efae-4e61-9921-a80916707d4a	e7f95ac5-5c53-4db7-b274-f0c94730f18c	Booking Matrix Deposit Service	30	0	400000	t	100000
b2671e77-e91d-4dfe-bc54-7a917ea99dc5	5d0f07bd-e701-4d76-8a43-66f370a0fdd6	E2E Premium Matrix سرویس	30	0	500000	f	\N
ab451505-6dcb-491a-a17a-373f66456d31	f9eaed2d-7068-4583-8a46-869324599cc6	E2E Misc Matrix سرویس	30	0	500000	f	\N
e1fc5fe1-8dbe-4535-96b8-ec31effc5bbc	a9ce2f38-b34c-414c-858e-d26135c9d819	E2E Notification Other سرویس	30	0	500000	f	\N
827deda4-7dfc-45e9-8359-b445d0cbe587	7b0a02d7-7ef3-49fe-af64-cb4da63051ae	E2E UI سرویس	30	0	500000	f	\N
556fd105-a1d7-4a65-9a19-27ef5786f090	0c3dfb48-5927-4861-864f-a8543c9eb7ac	E2E RBAC سرویس	30	0	500000	f	\N
e176a334-debb-4971-a0fa-9ed38e6545d6	a3b92139-eb81-4a88-a88d-0e4b23e9368c	E2E Booking سرویس	30	0	500000	f	\N
a8809db2-3782-4a29-8f86-2c355361a7b3	04034eee-0de0-4289-a3db-b3faf17d4ca4	E2E QR Trial سرویس	30	0	500000	f	\N
9aca819f-e946-472f-a877-70f324eb6daf	d7412cac-b652-4a48-a889-e282a2ed5d55	خدمت تست	30	0	500000	f	\N
bb14e9a5-c921-4c60-a82c-a6e9ef1d8c18	d7412cac-b652-4a48-a889-e282a2ed5d55	رنگ و احیا	90	0	8000000	t	1500000
c5a8037d-70c1-4713-aa80-484c8cbb148a	d7412cac-b652-4a48-a889-e282a2ed5d55	ناخن و ژل	60	0	4500000	f	\N
8b2de3f1-b6c9-4ae3-8374-8208769537d4	d7412cac-b652-4a48-a889-e282a2ed5d55	پاکسازی پوست	45	0	3000000	f	\N
8c4ee414-4de8-43c4-8f94-ba0a57daf086	91117aaf-0c89-4e41-9598-3479ebdb801f	E2E UI سرویس	30	0	500000	f	\N
0648a129-f87a-4202-940d-f7ebaacfb103	793c04cb-a78d-46bc-b66d-713f10e3f731	E2E RBAC سرویس	30	0	500000	f	\N
e31bfa16-c70f-4f18-b8c0-ea4d49b2566b	4acda9b4-b53a-452d-b438-3c01cc8a3ca4	E2E Booking سرویس	30	0	500000	f	\N
d0349234-c535-4898-8845-7bd54a468024	ea76f00a-df7d-4ff1-8dc7-82b563279af8	E2E QR Trial سرویس	30	0	500000	f	\N
852572f5-d7c8-4d81-8b9f-d90456d51ef4	cbcf2e40-16fa-481d-b8da-be5c9642aa5c	E2E UI سرویس	30	0	500000	f	\N
c7a3bb1f-bb93-42ed-af35-7c8905e32d4d	d1c9c1e8-22db-4add-814e-be04ecc51faf	E2E Other Tenant سرویس	30	0	500000	f	\N
b8530bc0-4766-4fcb-98b6-a6ec273f0895	d1c9c1e8-22db-4add-814e-be04ecc51faf	Other tenant service	30	0	0	f	\N
258f6b25-cc1e-4ab3-8424-fb6b856286c1	c66e014b-5299-4f9f-bc65-195fbad0cd99	E2E Booking Matrix سرویس	30	0	500000	f	\N
7e6b6901-0c67-43cb-a445-7b2527dfa796	c66e014b-5299-4f9f-bc65-195fbad0cd99	Booking Matrix Service	30	0	300000	f	\N
5031b9c0-272b-4691-a688-6581e4b5fcb2	c66e014b-5299-4f9f-bc65-195fbad0cd99	Booking Matrix Deposit Service	30	0	400000	t	100000
1ca405ec-264e-4fd3-a55a-251d169d26b2	ce2ffe75-4e1d-4e06-9f8d-8ea2ab35b605	E2E Premium Matrix سرویس	30	0	500000	f	\N
f93348f2-b0aa-4ad1-9e75-f885bf76c8c6	33b55265-4e46-4dfc-8e22-22fd32ccd0f2	E2E Misc Matrix سرویس	30	0	500000	f	\N
dc88a250-d31a-482d-a648-2f06f723b8a3	f4131cfd-52ad-46ee-9c9b-c6d358ed5f10	E2E Notification Other سرویس	30	0	500000	f	\N
0426ff37-6b59-4322-a025-e2a1b02e7416	4ee90b92-1681-4046-b42d-50582aaf3c55	E2E UI سرویس	30	0	500000	f	\N
be237e6d-b053-4a41-8720-4e75b808165b	8fddf0bd-1345-4f94-9277-ce0abe54fc86	E2E RBAC سرویس	30	0	500000	f	\N
1e467c6c-4dee-4710-8ded-6f4c9d75eb42	d86a4f90-7ef3-477a-b928-3804c9bd1bca	E2E Booking سرویس	30	0	500000	f	\N
83789233-6a52-434a-9f52-134282df1a94	ecdda28c-34cf-47e1-bb64-35433730951f	E2E QR Trial سرویس	30	0	500000	f	\N
44693791-94a0-410a-8950-4660d9fe8ebf	47a7b865-c608-462c-84b6-37268be1b96c	E2E Public Matrix سرویس	30	0	500000	f	\N
3be0cbff-ecef-4702-89dc-4c9e1d003074	4a680e73-4c54-4523-a9e2-e0d52299eb58	E2E Config Matrix سرویس	30	0	500000	f	\N
7fefca24-60e6-4f6c-8b9f-329df82720cd	f6b026fa-c4e3-4be6-a2be-796fe9abbe57	E2E Booking Matrix سرویس	30	0	500000	f	\N
15b15517-e0d5-48fc-bd69-4d867372e5de	7cb82de5-0177-4be1-999c-fd7ef40af41b	E2E Premium Matrix سرویس	30	0	500000	f	\N
021604ec-fccf-4f49-9891-463546570f8c	b578c0dd-6919-4d23-b7f2-efa770c47aca	E2E Misc Matrix سرویس	30	0	500000	f	\N
66666666-6666-6666-6666-666666666666	11111111-1111-1111-1111-111111111111	براشینگ و استایل	45	5	3500000	f	\N
77777777-7777-7777-7777-777777777777	11111111-1111-1111-1111-111111111111	کراتین و احیا	120	15	15000000	t	3000000
ad010000-0000-4000-8000-000000000001	aa000001-0000-4000-8000-000000000001	رنگ مو	120	10	7500000	f	\N
ad010000-0000-4000-8000-000000000002	aa000001-0000-4000-8000-000000000001	کراتین مو	180	15	15000000	f	\N
ad010000-0000-4000-8000-000000000003	aa000001-0000-4000-8000-000000000001	کوتاهی مو	45	5	2000000	f	\N
ad020000-0000-4000-8000-000000000001	aa000002-0000-4000-8000-000000000002	اصلاح مو	30	5	1500000	f	\N
ad020000-0000-4000-8000-000000000002	aa000002-0000-4000-8000-000000000002	اصلاح ریش	20	5	1000000	f	\N
ad030000-0000-4000-8000-000000000001	aa000003-0000-4000-8000-000000000003	کاشت ناخن	90	10	5000000	f	\N
ad030000-0000-4000-8000-000000000002	aa000003-0000-4000-8000-000000000003	مانیکور	60	5	3000000	f	\N
ad030000-0000-4000-8000-000000000003	aa000003-0000-4000-8000-000000000003	پاکسازی صورت	75	10	4500000	f	\N
ad040000-0000-4000-8000-000000000001	aa000004-0000-4000-8000-000000000004	اصلاح مو	40	5	2500000	f	\N
ad040000-0000-4000-8000-000000000002	aa000004-0000-4000-8000-000000000004	گریم داماد	120	15	8000000	f	\N
ad040000-0000-4000-8000-000000000003	aa000004-0000-4000-8000-000000000004	پاکسازی پوست مردانه	60	10	4000000	f	\N
ad050000-0000-4000-8000-000000000001	aa000005-0000-4000-8000-000000000005	میکاپ عروس	180	15	25000000	t	5000000
09449c96-eec2-48e5-a133-d724d1b03f3f	4f7ed53f-8383-4517-bd6f-8e71b351ce89	E2E Public Matrix سرویس	30	0	500000	f	\N
3e65bdc1-8b9c-45db-9d3b-338bd76c14c0	a8fbfe27-1784-4a99-bf74-6c560de51016	E2E Config Matrix سرویس	30	0	500000	f	\N
b297401b-eec9-4ae4-9141-1bbbc7cfcdec	385375ee-d31c-4ee6-a768-e54d8fd4f59f	E2E Public Matrix سرویس	30	0	500000	f	\N
f08e487e-be2b-430e-8172-82f776af55c4	7449789e-cf83-4783-a40b-462ca8396e0c	E2E Config Matrix سرویس	30	0	500000	f	\N
349fccf3-3827-469f-9548-50ab3978576b	3e99cb18-41bd-457b-9326-d2889b35cec5	E2E Other Tenant سرویس	30	0	500000	f	\N
9674a6f3-5137-4920-a5d2-4c1bc3c8b6b2	3e99cb18-41bd-457b-9326-d2889b35cec5	Other tenant service	30	0	0	f	\N
885d8be0-b911-4e5d-8970-8b5885be8bd9	ca682117-4612-4948-ae95-9706f3d56404	E2E Booking Matrix سرویس	30	0	500000	f	\N
bc1545f5-f37b-40bc-82b8-c3d8bc2e6a08	ca682117-4612-4948-ae95-9706f3d56404	Booking Matrix Service	30	0	300000	f	\N
9d4b5af6-6113-4643-9510-6ea488f58cf2	ca682117-4612-4948-ae95-9706f3d56404	Booking Matrix Deposit Service	30	0	400000	t	100000
4e2d229f-0955-4784-8906-602c78a76f19	6546637e-4a35-4c02-a418-8ddf714c6b96	E2E Premium Matrix سرویس	30	0	500000	f	\N
a4a0312c-a691-4195-a13a-008c15b41d73	9ce67759-ee69-4264-a07f-891b3f9805e2	E2E Misc Matrix سرویس	30	0	500000	f	\N
774cba4e-6f41-44f7-96ba-d61739fa6b04	f57024e7-1bbb-4d66-b3e8-3e7007f205c9	E2E Notification Other سرویس	30	0	500000	f	\N
69767dc6-7986-4aec-adb7-f7f3192cac85	a03997c7-c54e-4856-9c2c-f84a6a7c7092	E2E Public Matrix سرویس	30	0	500000	f	\N
3e3f20cf-6a46-4afe-a3ca-1ab534047689	e3fa9cc9-4249-426a-8a5e-bdfea48ab30e	E2E Config Matrix سرویس	30	0	500000	f	\N
99272d6c-1f0c-4ed6-8db1-757c9e9777bf	6734a6d0-2423-4322-8476-bae0d501ab64	E2E Other Tenant سرویس	30	0	500000	f	\N
8183562c-8410-4dd1-aea8-3ab4b4d567b1	2874dacc-057b-490d-96e1-51b76f6b2910	E2E Booking Matrix سرویس	30	0	500000	f	\N
3bea21cc-652a-44c3-a310-50517f4485e5	843b43c9-fbb2-496e-9604-69698c152179	E2E Public Matrix سرویس	30	0	500000	f	\N
78983f71-530c-4dfd-8784-d76bf45a01c7	46b5e7c3-4228-4d05-9724-b4d688e772a3	E2E Config Matrix سرویس	30	0	500000	f	\N
5667f1fb-e2cb-46ce-bf84-b81a18f51f04	8f50a98a-5249-46bd-83ad-bcc5493292d1	E2E Other Tenant سرویس	30	0	500000	f	\N
ef90c103-1afd-4b95-a160-00471c0b394c	8f50a98a-5249-46bd-83ad-bcc5493292d1	Other tenant service	30	0	0	f	\N
48b4ea02-1609-42a8-a584-6a369ae6e4ef	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	E2E Booking Matrix سرویس	30	0	500000	f	\N
1e36221a-ecd2-4d9c-ad49-09c9ec84d1da	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	Booking Matrix Service	30	0	300000	f	\N
1fbd6d71-c504-4139-b538-c704d4be8eab	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	Booking Matrix Deposit Service	30	0	400000	t	100000
59dc0f1e-f4b6-4ac1-85e2-c4f3e0e4fab7	0acac768-245e-4600-b24d-10357b6a9206	E2E Premium Matrix سرویس	30	0	500000	f	\N
2a0c7a09-ccb4-43b4-9628-92083102989c	daaee930-a32d-41c2-8e2d-d59946feb22b	E2E Misc Matrix سرویس	30	0	500000	f	\N
03fd93de-410b-4c63-b3c9-3b2c5f5b205b	9fb475fe-8cac-4fd3-8f89-b522a84d2edf	E2E Notification Other سرویس	30	0	500000	f	\N
f5848b07-e748-4f51-a571-1aaf9f4af383	f5152ef5-f532-47f7-9ac9-ddc21a287cba	E2E Public Matrix سرویس	30	0	500000	f	\N
c3038973-36a9-490d-a19c-11c0f81d88bc	114d6cf5-f9d5-4cb5-ab7a-89b2facecadf	E2E Config Matrix سرویس	30	0	500000	f	\N
614330ab-8879-4a6e-9a21-8d2b5f467039	75615eb1-bd39-4831-897f-4b6a23901cb7	E2E Other Tenant سرویس	30	0	500000	f	\N
28cab1d8-1cc3-4e50-9a93-b4e28b18a055	75615eb1-bd39-4831-897f-4b6a23901cb7	Other tenant service	30	0	0	f	\N
44881e53-e161-4ad3-9cb7-87e4b688a933	41945155-8295-4ffe-9fca-a051aec9d85c	E2E Booking Matrix سرویس	30	0	500000	f	\N
d46cb866-1e65-45cd-9679-b816fe895535	41945155-8295-4ffe-9fca-a051aec9d85c	Booking Matrix Service	30	0	300000	f	\N
8320733c-90dd-4501-a57f-dd38216f890c	41945155-8295-4ffe-9fca-a051aec9d85c	Booking Matrix Deposit Service	30	0	400000	t	100000
80b59d18-ee5f-46fd-bb97-b96ab8aff158	7ecbf7b9-4944-4750-858d-c838c1fb60db	E2E Premium Matrix سرویس	30	0	500000	f	\N
3b553df5-2dff-496c-8425-8176e770dffb	d5fb54d8-3c89-493d-8edd-48fb3f04ef42	E2E Misc Matrix سرویس	30	0	500000	f	\N
c86c66ba-e70b-4d4b-a9bb-b5c39822f11f	b32a6626-2517-4496-b611-8221818a64cd	E2E Notification Other سرویس	30	0	500000	f	\N
40056d90-9927-4701-ab00-53aef6e6aa30	8acc033d-9bdc-4a9b-a0f2-a7c8f7a8e80d	E2E UI سرویس	30	0	500000	f	\N
99d606ee-033d-466c-8cbb-73310dbd2d13	e7b2abf5-4d80-4d5f-a96e-c42395401a4c	E2E RBAC سرویس	30	0	500000	f	\N
052aaf78-97c7-4b60-af04-b86c6ca2c5af	e66c3ae5-4fe0-48ef-a5f8-e2226df0ed55	E2E Booking سرویس	30	0	500000	f	\N
db5e100f-e0e3-4121-a338-b7f30f28ca5d	0fbab0e1-6447-4455-bde7-412a6154819d	E2E QR Trial سرویس	30	0	500000	f	\N
306606f9-0d23-4ae3-8ceb-847639bdf6ed	1301ed82-4e76-447e-b9b2-203e4ab5e6b7	E2E Public Matrix سرویس	30	0	500000	f	\N
32d53c6d-fa51-4f3c-9457-d55691c6381d	11776d89-31cf-4504-9bb8-c4473fac42d1	E2E Config Matrix سرویس	30	0	500000	f	\N
5cc72e19-bbf6-4428-ac62-18480b7e693f	4dedcfd1-9cee-4826-9fb1-0cfbfa5886ef	E2E Other Tenant سرویس	30	0	500000	f	\N
9f2d5cf6-02e9-4b62-8c1e-7f2972f81331	4dedcfd1-9cee-4826-9fb1-0cfbfa5886ef	Other tenant service	30	0	0	f	\N
8e12ac71-8b0e-430f-bd44-f42dd5094799	ecfd9427-201f-45b4-b995-0c5903186dcf	E2E Booking Matrix سرویس	30	0	500000	f	\N
e2a5c228-635b-4c6e-89bc-e7e0dda33618	ecfd9427-201f-45b4-b995-0c5903186dcf	Booking Matrix Service	30	0	300000	f	\N
46b2c119-af58-4fd8-a8b2-dfc17ca997cd	ecfd9427-201f-45b4-b995-0c5903186dcf	Booking Matrix Deposit Service	30	0	400000	t	100000
05bfd16e-d0ab-4084-9079-8f3658198824	bf46a9e5-b9ad-4b7a-857c-c42a838c5105	E2E Premium Matrix سرویس	30	0	500000	f	\N
99eeded0-7a11-4bad-a4ab-7b4e1d0695a4	a8f9e2e8-b848-487b-a2c4-8b7a01f955a3	E2E Misc Matrix سرویس	30	0	500000	f	\N
c93a77a0-d91e-45c7-995a-b35c9048541f	41fe0795-178c-4762-828d-2bf86d3b7d2b	E2E Notification Other سرویس	30	0	500000	f	\N
43a68ea8-d2f8-4c69-b425-431ffb7928b6	dc36c3db-891c-47ad-a4c1-ecf6f3c4671e	E2E UI سرویس	30	0	500000	f	\N
9be5c3ad-d3c7-4ee6-8342-c28711174a74	3d0794ce-aed8-4b71-b1df-80de2ee1f392	E2E RBAC سرویس	30	0	500000	f	\N
25807141-00a8-4d12-9879-c2933e93c217	e71737ea-c9ab-401c-bd67-8525aa0060fd	E2E Booking سرویس	30	0	500000	f	\N
873db82c-0fc7-43a5-a679-9090fc7345c9	6e338bf0-ec57-44fe-8b1f-7af52ad1d31e	E2E QR Trial سرویس	30	0	500000	f	\N
ad050000-0000-4000-8000-000000000002	aa000005-0000-4000-8000-000000000005	شینیون	90	10	10000000	f	\N
ad050000-0000-4000-8000-000000000003	aa000005-0000-4000-8000-000000000005	مراقبت و تقویت مو	60	5	6000000	f	\N
\.


--
-- Data for Name: service_equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_equipment (service_id, equipment_id) FROM stdin;
\.


--
-- Data for Name: service_staff; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_staff (service_id, staff_member_id) FROM stdin;
44444444-4444-4444-4444-444444444444	22222222-2222-2222-2222-222222222222
55555555-5555-5555-5555-555555555555	22222222-2222-2222-2222-222222222222
44444444-4444-4444-4444-444444444444	dddddddd-3333-3333-3333-333333333333
55555555-5555-5555-5555-555555555555	dddddddd-3333-3333-3333-333333333333
66666666-6666-6666-6666-666666666666	22222222-2222-2222-2222-222222222222
66666666-6666-6666-6666-666666666666	dddddddd-3333-3333-3333-333333333333
77777777-7777-7777-7777-777777777777	22222222-2222-2222-2222-222222222222
ad010000-0000-4000-8000-000000000001	ab010000-0000-4000-8000-000000000002
ad010000-0000-4000-8000-000000000001	ab010000-0000-4000-8000-000000000001
ad010000-0000-4000-8000-000000000002	ab010000-0000-4000-8000-000000000002
ad010000-0000-4000-8000-000000000002	ab010000-0000-4000-8000-000000000001
ad010000-0000-4000-8000-000000000003	ab010000-0000-4000-8000-000000000002
ad010000-0000-4000-8000-000000000003	ab010000-0000-4000-8000-000000000001
ad020000-0000-4000-8000-000000000001	ab020000-0000-4000-8000-000000000001
ad020000-0000-4000-8000-000000000002	ab020000-0000-4000-8000-000000000001
ad030000-0000-4000-8000-000000000001	ab030000-0000-4000-8000-000000000002
ad030000-0000-4000-8000-000000000001	ab030000-0000-4000-8000-000000000001
ad030000-0000-4000-8000-000000000002	ab030000-0000-4000-8000-000000000002
ad030000-0000-4000-8000-000000000002	ab030000-0000-4000-8000-000000000001
ad030000-0000-4000-8000-000000000003	ab030000-0000-4000-8000-000000000002
ad030000-0000-4000-8000-000000000003	ab030000-0000-4000-8000-000000000001
ad040000-0000-4000-8000-000000000001	ab040000-0000-4000-8000-000000000001
ad040000-0000-4000-8000-000000000002	ab040000-0000-4000-8000-000000000001
ad040000-0000-4000-8000-000000000003	ab040000-0000-4000-8000-000000000001
ad050000-0000-4000-8000-000000000001	ab050000-0000-4000-8000-000000000002
ad050000-0000-4000-8000-000000000001	ab050000-0000-4000-8000-000000000001
ad050000-0000-4000-8000-000000000002	ab050000-0000-4000-8000-000000000002
ad050000-0000-4000-8000-000000000002	ab050000-0000-4000-8000-000000000001
ad050000-0000-4000-8000-000000000003	ab050000-0000-4000-8000-000000000002
ad050000-0000-4000-8000-000000000003	ab050000-0000-4000-8000-000000000001
95a9f08d-74d7-4ed0-8c32-48046e148026	82fb208d-5c1d-4937-97b5-b367e3f87f46
497d7969-bf85-4490-9a04-2d991cf1efc2	07f7969e-2964-4ae8-a1c4-305c15e2117f
b737300f-f766-48b1-bb89-72d693b89304	618bbbbb-d814-4b0e-a5ad-83dfab804e2a
ef6f608d-b6bd-4a9f-a622-61dc140da791	618bbbbb-d814-4b0e-a5ad-83dfab804e2a
4ffeda91-e721-4f4a-bb6a-e0d92cc7ffa7	be3bb144-e4f4-4832-82a9-7abe8490d470
a23a88ad-782d-4ced-830f-552da042c1bf	32c3d16d-91a6-4155-8737-ed0effe00a0e
0318bfaf-fe76-4c46-9c46-fb3adfd01304	950277b2-bd06-47fe-a253-9cb412cca69b
faf6ad96-a197-41ab-89c4-cb87d8182098	cb8b8b28-de2e-4594-a893-48edb4873101
8e6e1cbd-82c0-412e-bcad-0115c42a45c3	a11ed08a-2689-4d9d-8bdb-59b62e1c2682
aec1a45f-3066-4f95-8051-b2c44ff37316	85a6a285-dbcc-40b3-a3a3-6a20f2d31926
0361ea0a-cd9f-48b1-9639-55ae549f8eca	f8342806-e26e-4e6c-a26c-97a2be36e71b
ac55b6f0-8d07-42ec-af6d-cf6b78a5e22c	d294abaf-3f1f-4a81-9d3c-23f16687aaf4
4b0edb9c-5799-43b5-b736-fc648a6c9c0a	3dcd50fc-d04f-4cde-9a4f-4be1cbacd9a1
fa6cd82e-ae46-4b63-b3ad-f7ba136d298f	c4cade4d-9489-47ca-840e-340152d894da
19e28e6c-5cd8-4883-af40-d7aadde15327	24d0eeb8-7ccb-4d69-b52d-85211642ae3f
224f917c-4ef3-48a7-9013-80b216989550	31a3e2ab-dbc3-4175-964f-528165e4c467
8ae968e4-99cc-41e0-8e2b-21d43410020d	fc75b105-1531-42ee-85b0-7bf0027240a4
825ca07a-4e5b-4d52-80fd-4880cf1c033c	fa6ac291-9717-42c5-ad86-2f74b4fede1f
3fe2d31e-00e3-46fb-b9f7-d716f590db17	1395b536-0361-4a10-8419-3179ca49e76c
c1d56bbf-2e48-4eaa-846a-75e784505e52	a6162147-3017-49c0-94bc-8ad4a6b45efe
f830ce25-2c57-4f18-964e-e5874b0102f9	7027aca4-8600-4f60-80cd-403089095316
a8ac06ae-eb9a-4c77-a8b6-29f5d7afda12	9e9484c4-b8f4-4772-8c34-1386dea27da5
4ab72951-7f05-4b3e-9c2e-cf900cb1c61f	4aad5407-7568-48b0-98b8-9e47f3c62c56
89369143-f318-408f-979f-32397d98c47b	f51656f2-d836-45ed-8445-71ad1bd2645c
68255968-8e13-45f2-ba55-f1a324546113	0b602742-598d-4d2c-b414-fb497ab0ff4b
87dc1217-8eca-4df2-bf54-5832c6ffbd6d	a982ce4d-722f-4959-866b-8313f8529808
21395461-4627-4dab-b758-584bb5452544	babac6b1-5c81-44cc-8ccf-7540e17c412c
dc6bd3aa-0972-4a41-ac33-ec0436a1d951	f7e45782-fba2-4281-a66e-9caf61791e0b
509b8201-5d9f-4560-be39-140bf5049d0b	993150ad-bcfe-46ba-87cc-aaeae9fb4973
553b6325-58d9-4854-9eb7-44ef14574865	304a4e13-4e55-481c-b995-7111ff56f332
ad71be3b-ea13-40d2-a348-b36cdfc1dfef	2e82dc6b-b50a-4647-aa20-bbb7035ce44a
58df76aa-92df-4a4f-927f-e45b53b29ab3	5c19affc-2f6f-48cc-b8a5-906bc83812f1
06474c8f-c02b-45b2-8f24-d9bb6241c78c	54ee020b-27b0-4d0e-9c4a-ab4cfb6fe257
06474c8f-c02b-45b2-8f24-d9bb6241c78c	79fb9a0e-6a95-4a23-ad1c-650c15f2e0a1
06474c8f-c02b-45b2-8f24-d9bb6241c78c	5c19affc-2f6f-48cc-b8a5-906bc83812f1
0b088f13-26c8-4a75-8f5a-6dfb5d40462a	f5a4d790-5134-4522-8243-36d7f0a70027
ecd54a05-9774-4628-934e-abf783a70b11	9a95c720-d28d-4298-8705-128f9398ea94
ecd54a05-9774-4628-934e-abf783a70b11	4c38b9fb-2918-4a7f-91b1-d959717f3cce
ecd54a05-9774-4628-934e-abf783a70b11	f5a4d790-5134-4522-8243-36d7f0a70027
9c8141c1-1841-420b-8348-74da783cc665	851ea6dd-a22a-4f15-ae0e-3fe99c095a37
63d49f0e-2178-4300-95e8-4f989642dde2	db6cda46-0c20-4e07-8e56-9aa00f532893
1a2d11db-399d-4c34-8794-da3a709de408	ce158a89-eadb-4b48-8e67-53d9f1fbd2f0
e5d573c6-05e1-4637-a1d7-8a383d1ae969	12ad082d-cbde-4cf9-9ed8-b719411b32b9
b57609fb-6d0d-4bbe-9cd1-97bc6ab079ef	255ff837-95df-4758-ab01-a81fd1c90fe9
e2e056a3-8ed7-40e8-84e4-ac06fd4fa634	e02f8363-c079-4740-869e-7182f1a8feba
43a04e11-1214-4932-a9e0-0fc928555e62	d32250ab-ddb0-45ac-b21c-aca77709eab2
06917464-b6ab-4c69-a66c-3a9aebe57995	c6eb0436-6594-4368-9846-10e43c09d5e4
06917464-b6ab-4c69-a66c-3a9aebe57995	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c
06917464-b6ab-4c69-a66c-3a9aebe57995	d32250ab-ddb0-45ac-b21c-aca77709eab2
04d76778-4be4-43d8-b53c-8e812948bb88	55651162-adb0-4938-918d-767d57a00eb9
3b908841-7ffc-4cad-bbfa-aaf28faebe66	b8f357fd-925e-416d-b6aa-1c7f138f967f
26eb8a95-5606-428c-a7e5-2ea1bdeb8418	46c81677-9e6d-45cd-8a0d-937679db012a
dc500c4c-8d92-4651-a883-330129f793e2	8ba71a61-d554-4c11-8394-b6fc34dc94f3
06cb40c6-0469-4b60-8c27-870504c35ba3	753944de-8b7f-40de-880f-32b84429daa1
13adf2bb-4a17-43cf-8356-09a7b067a0f2	650b3df5-9cad-40dd-b403-fe532b2f9e83
658b05db-ad00-4484-8747-c963a4877a8d	a3b2cb93-a39f-4cb4-9872-bec91a7edd69
8213ea5e-0b2b-4950-95eb-53903a8e3991	539af821-6da8-4010-8607-7e1ce771d827
8213ea5e-0b2b-4950-95eb-53903a8e3991	ba7c9524-b0d4-4845-8886-5274ede7fd6a
8213ea5e-0b2b-4950-95eb-53903a8e3991	a3b2cb93-a39f-4cb4-9872-bec91a7edd69
bd3b9730-2f7d-4fd8-b0af-440177d30a6d	b8a2991d-41e8-4be8-bc0d-276fb036260d
1e8d5b7c-644b-4e1e-a664-d40a715ccf5e	30c7ba5b-2085-4124-a6f2-7986e79071f0
522739a3-6aff-4bff-9272-3a680691fda1	3145ba23-2f1c-4100-a3ca-8688523c1de6
e519f693-83f9-4b4c-be19-daf0ab7a26e5	27adc8b0-9d2e-40e9-a663-a6a7ac79adfa
f45d4d3f-1916-4886-855e-f520f32362f9	9370c29a-97b1-4b1d-918a-e54906c7cc52
542046ce-c7df-47d5-9350-b9cf41de228b	be145b3a-a902-46eb-84fa-3b5f66dc7bef
b946e06c-647d-443c-9882-d7f8d05a2773	be145b3a-a902-46eb-84fa-3b5f66dc7bef
9a6f7162-c782-48ab-a32a-43f47e25239a	a8bafa5c-6bf7-4441-97d4-b5fae40a1935
6395a750-12ab-4088-b351-cd0c98d5f404	f0ee5e08-21db-49f9-b8b9-0e49cfa7f784
6395a750-12ab-4088-b351-cd0c98d5f404	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740
6395a750-12ab-4088-b351-cd0c98d5f404	a8bafa5c-6bf7-4441-97d4-b5fae40a1935
7b78719c-efae-4e61-9921-a80916707d4a	f0ee5e08-21db-49f9-b8b9-0e49cfa7f784
7b78719c-efae-4e61-9921-a80916707d4a	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740
7b78719c-efae-4e61-9921-a80916707d4a	a8bafa5c-6bf7-4441-97d4-b5fae40a1935
b2671e77-e91d-4dfe-bc54-7a917ea99dc5	1f57cc2c-1b58-4304-841b-6d1e9ace9918
ab451505-6dcb-491a-a17a-373f66456d31	3f9e4c0c-0bdb-460e-982a-781f1baa2ca1
e1fc5fe1-8dbe-4535-96b8-ec31effc5bbc	84a2f142-e502-43c7-9b33-3ea246f018c9
827deda4-7dfc-45e9-8359-b445d0cbe587	795d9693-3ea4-4ff2-b9e6-20cb6255fb01
556fd105-a1d7-4a65-9a19-27ef5786f090	c55ae5bc-c225-44aa-b2dc-350c9cd7eead
e176a334-debb-4971-a0fa-9ed38e6545d6	fe8403ef-6732-42db-868d-4346f296f49c
a8809db2-3782-4a29-8f86-2c355361a7b3	c3d76a47-47ab-4f5f-bcc2-eddd9477559e
9aca819f-e946-472f-a877-70f324eb6daf	6154b0bb-a33d-4aa1-bb85-e74badea0943
bb14e9a5-c921-4c60-a82c-a6e9ef1d8c18	34d42336-3900-4918-a2d6-9068b8cfe6b0
bb14e9a5-c921-4c60-a82c-a6e9ef1d8c18	41cc11f7-c150-4eb8-bd86-f6361ae27465
bb14e9a5-c921-4c60-a82c-a6e9ef1d8c18	6154b0bb-a33d-4aa1-bb85-e74badea0943
c5a8037d-70c1-4713-aa80-484c8cbb148a	34d42336-3900-4918-a2d6-9068b8cfe6b0
c5a8037d-70c1-4713-aa80-484c8cbb148a	41cc11f7-c150-4eb8-bd86-f6361ae27465
c5a8037d-70c1-4713-aa80-484c8cbb148a	6154b0bb-a33d-4aa1-bb85-e74badea0943
8b2de3f1-b6c9-4ae3-8374-8208769537d4	34d42336-3900-4918-a2d6-9068b8cfe6b0
8b2de3f1-b6c9-4ae3-8374-8208769537d4	41cc11f7-c150-4eb8-bd86-f6361ae27465
8b2de3f1-b6c9-4ae3-8374-8208769537d4	6154b0bb-a33d-4aa1-bb85-e74badea0943
8c4ee414-4de8-43c4-8f94-ba0a57daf086	b6ad00d3-1c8d-45b7-957b-8dc075467d23
8c4ee414-4de8-43c4-8f94-ba0a57daf086	cd9add27-87da-4373-a524-97759e0ae44a
0648a129-f87a-4202-940d-f7ebaacfb103	5c3ee7d7-dc07-4634-b6c4-9304a00d1a86
0648a129-f87a-4202-940d-f7ebaacfb103	5b6096b9-d650-4ba0-a796-be663918104a
e31bfa16-c70f-4f18-b8c0-ea4d49b2566b	a9955774-e41d-4176-aff4-b10e51138abf
d0349234-c535-4898-8845-7bd54a468024	488c3d0d-79fb-4343-9a88-44465fa9a189
852572f5-d7c8-4d81-8b9f-d90456d51ef4	3b0e01c0-8ee7-41d2-8057-f49cb1029722
852572f5-d7c8-4d81-8b9f-d90456d51ef4	f73fc09c-a972-4f71-9811-f0d55d146a1d
0426ff37-6b59-4322-a025-e2a1b02e7416	dfc88ac1-ede6-4b62-a170-63fc5d7dd3d4
0426ff37-6b59-4322-a025-e2a1b02e7416	fe24b70c-b7f6-4b2d-960c-5d6af268b0cb
be237e6d-b053-4a41-8720-4e75b808165b	fbe2b299-5a41-4b36-81e0-700b9aeb80e7
be237e6d-b053-4a41-8720-4e75b808165b	7ea453a7-f534-4afb-a400-3dd71f91c538
1e467c6c-4dee-4710-8ded-6f4c9d75eb42	3799ff0a-0064-4f2a-8717-4d2c35b40060
83789233-6a52-434a-9f52-134282df1a94	4e457734-15ac-4ffc-9a23-fbeb7f75150a
44693791-94a0-410a-8950-4660d9fe8ebf	d103be7a-51b0-4e4f-a608-7350cc921072
3be0cbff-ecef-4702-89dc-4c9e1d003074	a5c68558-e3ac-43c3-98ce-5d0d466d51ab
7fefca24-60e6-4f6c-8b9f-329df82720cd	a4984776-fd5b-43a9-9096-a1e5e2d83cc3
15b15517-e0d5-48fc-bd69-4d867372e5de	9075c684-ae7e-415d-90bb-1c5c67083279
021604ec-fccf-4f49-9891-463546570f8c	09b2f5ef-cd02-491a-bd54-be0c30e9c654
09449c96-eec2-48e5-a133-d724d1b03f3f	7871f6e8-d0f5-45db-84be-9693bfe02b5c
3e65bdc1-8b9c-45db-9d3b-338bd76c14c0	052328d1-4f15-426d-ab6e-c04cde71cb11
3e65bdc1-8b9c-45db-9d3b-338bd76c14c0	133a6ecc-53ba-4f45-a858-9e8df3ce87b2
c7a3bb1f-bb93-42ed-af35-7c8905e32d4d	9e8afae2-1456-42ef-8843-d3ed612706f3
b8530bc0-4766-4fcb-98b6-a6ec273f0895	9e8afae2-1456-42ef-8843-d3ed612706f3
258f6b25-cc1e-4ab3-8424-fb6b856286c1	bee3515c-19e3-454f-922b-8f24d8a75913
258f6b25-cc1e-4ab3-8424-fb6b856286c1	05cf7580-8f7d-433b-a660-ab1b55791e8c
7e6b6901-0c67-43cb-a445-7b2527dfa796	9725338d-2d4c-4799-a426-8a6c9ff509ce
7e6b6901-0c67-43cb-a445-7b2527dfa796	05cf7580-8f7d-433b-a660-ab1b55791e8c
7e6b6901-0c67-43cb-a445-7b2527dfa796	bee3515c-19e3-454f-922b-8f24d8a75913
5031b9c0-272b-4691-a688-6581e4b5fcb2	9725338d-2d4c-4799-a426-8a6c9ff509ce
5031b9c0-272b-4691-a688-6581e4b5fcb2	05cf7580-8f7d-433b-a660-ab1b55791e8c
5031b9c0-272b-4691-a688-6581e4b5fcb2	bee3515c-19e3-454f-922b-8f24d8a75913
1ca405ec-264e-4fd3-a55a-251d169d26b2	e16ebfba-a63f-4728-98ad-b8ee65ac2b47
1ca405ec-264e-4fd3-a55a-251d169d26b2	11d45054-392d-46ea-9af4-6f785af5ebb1
f93348f2-b0aa-4ad1-9e75-f885bf76c8c6	4094637e-5070-4e5e-a1c7-627a2f8cb985
f93348f2-b0aa-4ad1-9e75-f885bf76c8c6	366b1baf-e776-41fb-b606-9b32f7261a03
dc88a250-d31a-482d-a648-2f06f723b8a3	de0edb73-fc1a-4d2e-85c4-fad6ba995838
b297401b-eec9-4ae4-9141-1bbbc7cfcdec	3aa936f8-68be-44d9-af0e-d76003bb58bd
f08e487e-be2b-430e-8172-82f776af55c4	1f4db7a8-06ca-40c5-9665-8290991540ee
f08e487e-be2b-430e-8172-82f776af55c4	c2a7666a-c8e8-4090-bcc0-04d32926eadb
349fccf3-3827-469f-9548-50ab3978576b	b7fd6924-84b4-4c66-a43f-d1c6e08fcbe4
9674a6f3-5137-4920-a5d2-4c1bc3c8b6b2	b7fd6924-84b4-4c66-a43f-d1c6e08fcbe4
885d8be0-b911-4e5d-8970-8b5885be8bd9	f073a0ff-6e6f-43d4-9a63-9ed194b88797
885d8be0-b911-4e5d-8970-8b5885be8bd9	50070078-f099-4cb5-a8ce-c6bde911a49e
bc1545f5-f37b-40bc-82b8-c3d8bc2e6a08	e5e37985-fd50-4773-a36f-6a50e61ca6c5
bc1545f5-f37b-40bc-82b8-c3d8bc2e6a08	50070078-f099-4cb5-a8ce-c6bde911a49e
bc1545f5-f37b-40bc-82b8-c3d8bc2e6a08	f073a0ff-6e6f-43d4-9a63-9ed194b88797
9d4b5af6-6113-4643-9510-6ea488f58cf2	e5e37985-fd50-4773-a36f-6a50e61ca6c5
9d4b5af6-6113-4643-9510-6ea488f58cf2	50070078-f099-4cb5-a8ce-c6bde911a49e
9d4b5af6-6113-4643-9510-6ea488f58cf2	f073a0ff-6e6f-43d4-9a63-9ed194b88797
4e2d229f-0955-4784-8906-602c78a76f19	cbd2f87e-787d-40ee-80ea-9b90b71c298e
4e2d229f-0955-4784-8906-602c78a76f19	544ceb5a-2fea-47d6-acef-76045154881a
a4a0312c-a691-4195-a13a-008c15b41d73	f03e27a5-59d9-4a0d-be4c-9d55c611afa2
a4a0312c-a691-4195-a13a-008c15b41d73	e239ea1d-67db-4e64-aad9-ef9c45200291
774cba4e-6f41-44f7-96ba-d61739fa6b04	8cecfbcd-5e85-410a-b260-665f1caa2eb4
69767dc6-7986-4aec-adb7-f7f3192cac85	e3ecb356-03e8-4d45-85cb-50adc81a474a
3e3f20cf-6a46-4afe-a3ca-1ab534047689	06119660-0ce2-4cd4-b960-67cd0ba0e8ea
3e3f20cf-6a46-4afe-a3ca-1ab534047689	9ff568fe-8383-455f-ac18-18299a003bb6
99272d6c-1f0c-4ed6-8db1-757c9e9777bf	190eec98-4dd0-4ac0-9ad3-31b4b2189239
8183562c-8410-4dd1-aea8-3ab4b4d567b1	f4d81258-d4e4-45c4-9445-eb76a88b6ff9
3bea21cc-652a-44c3-a310-50517f4485e5	c1f439d8-c58d-4ef3-a0f1-51bf34cf3bf5
78983f71-530c-4dfd-8784-d76bf45a01c7	033f2976-aa70-43db-b8b6-b850b66193f8
78983f71-530c-4dfd-8784-d76bf45a01c7	8fcfcba0-a241-4d09-8dad-4160d4f18116
5667f1fb-e2cb-46ce-bf84-b81a18f51f04	9c2bc407-3577-4e1c-9123-65557b53d545
ef90c103-1afd-4b95-a160-00471c0b394c	9c2bc407-3577-4e1c-9123-65557b53d545
48b4ea02-1609-42a8-a584-6a369ae6e4ef	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8
48b4ea02-1609-42a8-a584-6a369ae6e4ef	fd8e1e25-280c-4c6f-bed3-f070bcce4912
1e36221a-ecd2-4d9c-ad49-09c9ec84d1da	1b6c7ffd-a0af-4917-a07a-4520f3145bd3
1e36221a-ecd2-4d9c-ad49-09c9ec84d1da	fd8e1e25-280c-4c6f-bed3-f070bcce4912
1e36221a-ecd2-4d9c-ad49-09c9ec84d1da	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8
1fbd6d71-c504-4139-b538-c704d4be8eab	1b6c7ffd-a0af-4917-a07a-4520f3145bd3
1fbd6d71-c504-4139-b538-c704d4be8eab	fd8e1e25-280c-4c6f-bed3-f070bcce4912
1fbd6d71-c504-4139-b538-c704d4be8eab	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8
59dc0f1e-f4b6-4ac1-85e2-c4f3e0e4fab7	f9caeb69-4985-4a00-92ba-9f4485840efd
59dc0f1e-f4b6-4ac1-85e2-c4f3e0e4fab7	b9e31fd8-d9b4-43e0-ae3e-fe78fe07c56a
2a0c7a09-ccb4-43b4-9628-92083102989c	16d1ba6d-ef25-495d-b7ca-32728de6b6cd
2a0c7a09-ccb4-43b4-9628-92083102989c	1f2dbb13-c832-4c51-ac26-33a5033a9f36
03fd93de-410b-4c63-b3c9-3b2c5f5b205b	32a99ba7-b901-43e1-9064-04292dcd8653
f5848b07-e748-4f51-a571-1aaf9f4af383	4da92dd7-f9c2-487f-a1ae-7170bec48876
c3038973-36a9-490d-a19c-11c0f81d88bc	9721f83e-e980-47ee-a67a-466e2657db37
c3038973-36a9-490d-a19c-11c0f81d88bc	2443d906-bfd5-4337-9ec1-33f957ceac62
614330ab-8879-4a6e-9a21-8d2b5f467039	11210303-546e-44a6-8a49-dd27833042ec
28cab1d8-1cc3-4e50-9a93-b4e28b18a055	11210303-546e-44a6-8a49-dd27833042ec
44881e53-e161-4ad3-9cb7-87e4b688a933	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c
44881e53-e161-4ad3-9cb7-87e4b688a933	e366d7da-0479-44df-bd5a-5a2d666f9313
d46cb866-1e65-45cd-9679-b816fe895535	002d1a78-0ef0-49fc-8b60-f3951949ad5e
d46cb866-1e65-45cd-9679-b816fe895535	e366d7da-0479-44df-bd5a-5a2d666f9313
d46cb866-1e65-45cd-9679-b816fe895535	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c
8320733c-90dd-4501-a57f-dd38216f890c	002d1a78-0ef0-49fc-8b60-f3951949ad5e
8320733c-90dd-4501-a57f-dd38216f890c	e366d7da-0479-44df-bd5a-5a2d666f9313
8320733c-90dd-4501-a57f-dd38216f890c	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c
80b59d18-ee5f-46fd-bb97-b96ab8aff158	9533b3d5-242d-418b-8b8f-29f546d663b3
80b59d18-ee5f-46fd-bb97-b96ab8aff158	ec6b2c18-2cc2-41c9-9165-956cad61d761
3b553df5-2dff-496c-8425-8176e770dffb	e2200c8d-5e09-4149-bea1-d3a6a7f0e421
3b553df5-2dff-496c-8425-8176e770dffb	16da35bd-5216-41c2-a656-5550e901e96f
c86c66ba-e70b-4d4b-a9bb-b5c39822f11f	d30ef226-19d4-4e79-a50c-a15e99f31d14
40056d90-9927-4701-ab00-53aef6e6aa30	199d69f0-cb29-4014-bb76-9984a0190631
40056d90-9927-4701-ab00-53aef6e6aa30	d1bc980a-d262-4c4a-a479-4e213b65da23
99d606ee-033d-466c-8cbb-73310dbd2d13	4737eee4-96e0-484a-bc2c-21fa476cecec
99d606ee-033d-466c-8cbb-73310dbd2d13	d4d83171-36d3-40be-9f3a-d584794db7f4
052aaf78-97c7-4b60-af04-b86c6ca2c5af	274d5221-7f2c-46d4-b797-119ae3f82652
db5e100f-e0e3-4121-a338-b7f30f28ca5d	44c43473-b2c1-487d-9176-157713994ca8
306606f9-0d23-4ae3-8ceb-847639bdf6ed	63446f6a-49e7-431e-868b-33c534155203
32d53c6d-fa51-4f3c-9457-d55691c6381d	f3d31de6-d22e-4d38-a366-f5848e504bfb
32d53c6d-fa51-4f3c-9457-d55691c6381d	7ea40eb1-7057-49a7-a1c5-1b9b04c48018
5cc72e19-bbf6-4428-ac62-18480b7e693f	73e51bbb-8122-4773-ba10-d37fdd063fa5
9f2d5cf6-02e9-4b62-8c1e-7f2972f81331	73e51bbb-8122-4773-ba10-d37fdd063fa5
8e12ac71-8b0e-430f-bd44-f42dd5094799	bb302d69-79ff-4921-86d1-8e6e22ae92cb
8e12ac71-8b0e-430f-bd44-f42dd5094799	d41ffc8a-603b-483a-bfe3-3c7994ef116c
e2a5c228-635b-4c6e-89bc-e7e0dda33618	e53f0e86-7504-4c2f-8c88-64a4fc4b17ab
e2a5c228-635b-4c6e-89bc-e7e0dda33618	d41ffc8a-603b-483a-bfe3-3c7994ef116c
e2a5c228-635b-4c6e-89bc-e7e0dda33618	bb302d69-79ff-4921-86d1-8e6e22ae92cb
46b2c119-af58-4fd8-a8b2-dfc17ca997cd	e53f0e86-7504-4c2f-8c88-64a4fc4b17ab
46b2c119-af58-4fd8-a8b2-dfc17ca997cd	d41ffc8a-603b-483a-bfe3-3c7994ef116c
46b2c119-af58-4fd8-a8b2-dfc17ca997cd	bb302d69-79ff-4921-86d1-8e6e22ae92cb
05bfd16e-d0ab-4084-9079-8f3658198824	0bbae851-7318-4213-8961-75ff34de841f
05bfd16e-d0ab-4084-9079-8f3658198824	3a61b3fd-5024-41f9-af02-4afaff34c331
99eeded0-7a11-4bad-a4ab-7b4e1d0695a4	b25a26a7-eb8d-49a2-b10f-79544277cebb
99eeded0-7a11-4bad-a4ab-7b4e1d0695a4	712bfffd-6e35-4ef4-9259-2bfed0c5e4d6
c93a77a0-d91e-45c7-995a-b35c9048541f	388daaa5-789a-4514-9bc5-511649f2f437
43a68ea8-d2f8-4c69-b425-431ffb7928b6	0780d8d7-804a-4666-89d9-e08d9f17102b
43a68ea8-d2f8-4c69-b425-431ffb7928b6	61b8298d-a97f-4ea6-a255-a95c04d82457
9be5c3ad-d3c7-4ee6-8342-c28711174a74	389aab4c-9d68-4e3e-bc97-a3d7af01f4da
9be5c3ad-d3c7-4ee6-8342-c28711174a74	694a7f83-6458-4401-9505-c25d2a216006
25807141-00a8-4d12-9879-c2933e93c217	51f6dc27-15f5-44a3-9826-0805962f6322
873db82c-0fc7-43a5-a679-9090fc7345c9	50390ddd-1517-4019-bfbe-6818793a54eb
\.


--
-- Data for Name: staff_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff_member (id, salon_id, full_name, role, active, auto_approve, manage_own_availability, phone) FROM stdin;
3aa936f8-68be-44d9-af0e-d76003bb58bd	385375ee-d31c-4ee6-a768-e54d8fd4f59f	E2E Public Matrix مدیر	Owner	t	\N	f	09930081918
1f4db7a8-06ca-40c5-9665-8290991540ee	7449789e-cf83-4783-a40b-462ca8396e0c	E2E Config Matrix مدیر	Owner	t	\N	f	09949436825
07f7969e-2964-4ae8-a1c4-305c15e2117f	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	ضصثبثبص	Owner	t	\N	f	09304116945
618bbbbb-d814-4b0e-a5ad-83dfab804e2a	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	هقتبتصخ	Owner	t	\N	f	09025220923
2e2a4553-82fe-45d7-9e57-907e638c4fa3	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	ححححح	Owner	t	\N	f	\N
69f57590-8a6a-4c6e-b6e5-6d8bf70bd18f	6524f8ac-5aae-4f63-80ca-6cee0c030b20	E2E آرایشگر 1786103567126	Stylist	t	\N	t	09672996037
31a3e2ab-dbc3-4175-964f-528165e4c467	8a91b095-7147-4ff4-9b71-290b72e6de88	E2E RBAC مدیر	Owner	t	\N	f	09951843990
1cbe7662-db99-4eab-8848-5b6a95dd1381	8a91b095-7147-4ff4-9b71-290b72e6de88	RBAC آرایشگر	Stylist	t	\N	f	09557505779
c10f2b18-2355-4be9-b520-cf092c8206da	8a91b095-7147-4ff4-9b71-290b72e6de88	RBAC ادمین	Admin	t	\N	f	09490713428
fc75b105-1531-42ee-85b0-7bf0027240a4	049ff655-e678-4a8a-aa15-dd1d0f082d72	E2E Booking مدیر	Owner	t	\N	f	09958986201
fa6ac291-9717-42c5-ad86-2f74b4fede1f	3ae5cde0-3a8d-4d60-be96-c4c456e161a0	E2E QR مدیر	Owner	t	\N	f	09992690141
1395b536-0361-4a10-8419-3179ca49e76c	83738a22-ac2f-4959-ae1f-31ab6a64d166	E2E QR Trial مدیر	Owner	t	\N	f	09916842675
a6162147-3017-49c0-94bc-8ad4a6b45efe	e539a6f7-3a89-4777-8cc4-356882028d76	E2E QR Trial مدیر	Owner	t	\N	f	09969632109
7027aca4-8600-4f60-80cd-403089095316	b332bbaf-9ab8-45da-a7a3-e27644b594e5	E2E QR Trial مدیر	Owner	t	\N	f	09928243289
9e9484c4-b8f4-4772-8c34-1386dea27da5	94d4a899-f24e-4163-9da6-d42540203798	E2E QR Trial مدیر	Owner	t	\N	f	09903481289
be3bb144-e4f4-4832-82a9-7abe8490d470	b459826c-7585-4616-a22a-665a527778d3	طررطر	Owner	t	\N	f	09304116976
6af4802f-1803-49e9-add7-f01ea26dd8bc	a4288905-c8f2-4797-8922-144befd9dd50	cbcbbc	Owner	t	\N	f	09304516941
4aad5407-7568-48b0-98b8-9e47f3c62c56	37b31e8c-6d49-4cd9-aea2-e27961f8804f	E2E UI مدیر	Owner	t	\N	f	09820516047
650d3737-68bf-4f17-8588-c572a0a07878	37b31e8c-6d49-4cd9-aea2-e27961f8804f	E2E آرایشگر 1786103906345	Stylist	t	\N	t	09635425286
f51656f2-d836-45ed-8445-71ad1bd2645c	ede45a95-710d-4132-8214-e4c2f13f28e0	E2E RBAC مدیر	Owner	t	\N	f	09912568459
6a884cc4-f0a9-4dc6-adb7-4b3bfa4a55a3	ede45a95-710d-4132-8214-e4c2f13f28e0	RBAC آرایشگر	Stylist	t	\N	f	09560929805
6cf77204-36b3-45be-8177-4d666a12d7bd	ede45a95-710d-4132-8214-e4c2f13f28e0	RBAC ادمین	Admin	t	\N	f	09453336656
0b602742-598d-4d2c-b414-fb497ab0ff4b	8d4082de-f9bc-483c-8364-fb5373ecee79	E2E Booking مدیر	Owner	t	\N	f	09930903427
a982ce4d-722f-4959-866b-8313f8529808	d04088e4-0987-405e-a912-9728a30e1fb7	E2E QR Trial مدیر	Owner	t	\N	f	09983473399
329fb9e7-4e20-43dc-ad55-9188bb27c03e	7449789e-cf83-4783-a40b-462ca8396e0c	Config Admin	Admin	t	\N	f	09494155201
c2a7666a-c8e8-4090-bcc0-04d32926eadb	7449789e-cf83-4783-a40b-462ca8396e0c	Config Stylist Updated	Stylist	t	\N	f	09553550915
19b36edf-3c88-42a4-9437-4a8e24e64882	f3f3eb54-0191-4d27-bd54-81fa82f9b40f	rthrthrth	Owner	t	t	f	09304116932
babac6b1-5c81-44cc-8ccf-7540e17c412c	282f2ee7-f778-4f75-8e41-72ee726e2d71	E2E UI مدیر	Owner	t	\N	f	09835475818
66d1ac86-a39a-45ca-b78d-c4e4cc770794	282f2ee7-f778-4f75-8e41-72ee726e2d71	E2E آرایشگر 1786104391169	Stylist	t	\N	t	09620385822
f7e45782-fba2-4281-a66e-9caf61791e0b	3ad3c745-12dc-4dca-9e16-ee4c57bd987b	E2E RBAC مدیر	Owner	t	\N	f	09901871402
82935ae9-bab1-4805-ba62-20e4f6b880e9	3ad3c745-12dc-4dca-9e16-ee4c57bd987b	RBAC آرایشگر	Stylist	t	\N	f	09529334918
15d1648f-da84-4e41-8a69-99ae4b110a55	3ad3c745-12dc-4dca-9e16-ee4c57bd987b	RBAC ادمین	Admin	t	\N	f	09447257187
993150ad-bcfe-46ba-87cc-aaeae9fb4973	6a5b29c2-a8df-467a-8c36-ca49f545625c	E2E Booking مدیر	Owner	t	\N	f	09989803059
304a4e13-4e55-481c-b995-7111ff56f332	36e79989-a20d-4f1e-9b9b-538d101b4014	E2E QR Trial مدیر	Owner	t	\N	f	09965970073
190eec98-4dd0-4ac0-9ad3-31b4b2189239	6734a6d0-2423-4322-8476-bae0d501ab64	E2E Other Tenant مدیر	Owner	t	\N	f	09980574265
f4d81258-d4e4-45c4-9445-eb76a88b6ff9	2874dacc-057b-490d-96e1-51b76f6b2910	E2E Booking Matrix مدیر	Owner	t	\N	f	09927412342
9c2bc407-3577-4e1c-9123-65557b53d545	8f50a98a-5249-46bd-83ad-bcc5493292d1	E2E Other Tenant مدیر	Owner	t	\N	f	09989901094
a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	E2E Booking Matrix مدیر	Owner	t	\N	f	09941295294
5b40d210-a7be-4945-829c-8fccbd87947a	cb8d9d1e-9cfa-42e3-88bf-07b6617ca273	ثقلثقل	Owner	t	\N	f	09304116942
79fb9a0e-6a95-4a23-ad1c-650c15f2e0a1	b6e528ae-c2ac-4579-bd70-4a33806fbcee	Config Stylist Updated	Stylist	t	\N	f	09522587166
f5a4d790-5134-4522-8243-36d7f0a70027	c29ea8c8-5840-4ddb-885c-e70eafb741b5	E2E Booking Matrix مدیر	Owner	t	\N	f	09991784512
4c38b9fb-2918-4a7f-91b1-d959717f3cce	c29ea8c8-5840-4ddb-885c-e70eafb741b5	Booking Stylist	Stylist	t	\N	f	09521417438
fd8e1e25-280c-4c6f-bed3-f070bcce4912	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	Booking Stylist	Stylist	t	\N	f	09589945468
1b6c7ffd-a0af-4917-a07a-4520f3145bd3	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	Booking Admin	Admin	t	\N	f	09494839551
9a95c720-d28d-4298-8705-128f9398ea94	c29ea8c8-5840-4ddb-885c-e70eafb741b5	Booking Admin	Admin	t	\N	f	09477815879
851ea6dd-a22a-4f15-ae0e-3fe99c095a37	48b7b978-caca-4b3d-9996-48178b2a4fb5	E2E Premium Matrix مدیر	Owner	t	\N	f	09990091022
78cec8ca-1e3c-4999-947d-308fbc7665f9	48b7b978-caca-4b3d-9996-48178b2a4fb5	Premium Admin	Admin	t	\N	f	09495382591
f9caeb69-4985-4a00-92ba-9f4485840efd	0acac768-245e-4600-b24d-10357b6a9206	E2E Premium Matrix مدیر	Owner	t	\N	f	09943864519
15be60d1-935e-4fd4-9b57-2a5a2ef05fe5	48b7b978-caca-4b3d-9996-48178b2a4fb5	Premium Stylist	Stylist	t	\N	f	09543138538
db6cda46-0c20-4e07-8e56-9aa00f532893	1bb72fda-9b55-4d92-b5ae-07341a7c9aaf	E2E Misc Matrix مدیر	Owner	t	\N	f	09951628911
2bdc5a14-4692-4897-b099-7a942badcd4a	1bb72fda-9b55-4d92-b5ae-07341a7c9aaf	Misc Stylist	Stylist	t	\N	f	09563455492
32c3d16d-91a6-4155-8737-ed0effe00a0e	82ad3b1b-e80e-4d67-95d4-e934f31934a4	E2E Owner	Owner	t	\N	f	09102041605
950277b2-bd06-47fe-a253-9cb412cca69b	1ba2c5c1-6c6e-4e84-9343-56d66b2d3226	Inspect Owner	Owner	t	\N	f	09102054756
cb8b8b28-de2e-4594-a893-48edb4873101	e54af3fc-d38b-41ad-b517-e558fa0e6cbf	Inspect Owner	Owner	t	\N	f	09102123562
a11ed08a-2689-4d9d-8bdb-59b62e1c2682	c243bba9-2f63-421a-b92f-7e9eee00a7e2	E2E UI مدیر	Owner	t	\N	f	09830505961
85a6a285-dbcc-40b3-a3a3-6a20f2d31926	f7bc45c9-75c1-4443-9dee-3b2183130dc0	E2E RBAC مدیر	Owner	t	\N	f	09930536991
f8342806-e26e-4e6c-a26c-97a2be36e71b	eed48a8d-9014-40d6-903a-955c31140613	E2E Booking مدیر	Owner	t	\N	f	09931102911
82fb208d-5c1d-4937-97b5-b367e3f87f46	b8d1f622-7f06-49a7-aba2-30dcef24f8a7	ثصبثصب	Owner	t	\N	f	09404116941
d294abaf-3f1f-4a81-9d3c-23f16687aaf4	f2b895e3-8eaf-42e4-b3c6-a244fff4934f	E2E QR مدیر	Owner	t	\N	f	09931668411
3dcd50fc-d04f-4cde-9a4f-4be1cbacd9a1	3c84048d-601a-4f55-a989-038efc3ddbd2	test	Owner	t	\N	f	09100001731
c4cade4d-9489-47ca-840e-340152d894da	34c4ebd4-eef3-4225-bcf6-cdaac1521668	E2E UI مدیر	Owner	t	\N	f	09874629930
24d0eeb8-7ccb-4d69-b52d-85211642ae3f	6524f8ac-5aae-4f63-80ca-6cee0c030b20	E2E UI مدیر	Owner	t	\N	f	09817935004
255ff837-95df-4758-ab01-a81fd1c90fe9	3e1a529c-c38c-410a-9147-b0776d2cf387	E2E Config Matrix مدیر	Owner	t	\N	f	09915282008
981e7c35-1b16-4adb-8779-7b223c671172	3e1a529c-c38c-410a-9147-b0776d2cf387	Config Admin	Admin	t	\N	f	09420760746
7cd0ff34-0612-4b8d-bd55-06216ab7d5d0	3e1a529c-c38c-410a-9147-b0776d2cf387	Config Stylist Updated	Stylist	t	\N	f	09538230777
e02f8363-c079-4740-869e-7182f1a8feba	bb22b03a-5d16-4b81-b42a-49e37d27593b	E2E Other Tenant مدیر	Owner	t	\N	f	09924960430
d32250ab-ddb0-45ac-b21c-aca77709eab2	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	E2E Booking Matrix مدیر	Owner	t	\N	f	09916173592
d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	Booking Stylist	Stylist	t	\N	f	09509370830
c6eb0436-6594-4368-9846-10e43c09d5e4	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	Booking Admin	Admin	t	\N	f	09482892726
55651162-adb0-4938-918d-767d57a00eb9	55809d45-8657-47fe-a0e2-ad8116219af4	E2E Premium Matrix مدیر	Owner	t	\N	f	09977581264
2e82dc6b-b50a-4647-aa20-bbb7035ce44a	4c0bfb7e-08bb-4675-9b6c-b7928cbb347e	E2E Public Matrix مدیر	Owner	t	\N	f	09916320562
5c19affc-2f6f-48cc-b8a5-906bc83812f1	b6e528ae-c2ac-4579-bd70-4a33806fbcee	E2E Config Matrix مدیر	Owner	t	\N	f	09976988252
54ee020b-27b0-4d0e-9c4a-ab4cfb6fe257	b6e528ae-c2ac-4579-bd70-4a33806fbcee	Config Admin	Admin	t	\N	f	09411512735
ce158a89-eadb-4b48-8e67-53d9f1fbd2f0	1cb71f4e-7f3f-473c-9ba2-9bf38e6943fa	E2E Notification Other مدیر	Owner	t	\N	f	09927911962
12ad082d-cbde-4cf9-9ed8-b719411b32b9	0ed4db5e-a345-4f57-a5ff-7faf1876853c	E2E Public Matrix مدیر	Owner	t	\N	f	09972692698
2a7f6434-f414-475d-85ff-5534c13d58b8	55809d45-8657-47fe-a0e2-ad8116219af4	Premium Admin	Admin	t	\N	f	09495689725
3e7e0f89-9a69-4b53-a554-d035126cd135	55809d45-8657-47fe-a0e2-ad8116219af4	Premium Stylist	Stylist	t	\N	f	09515481790
b8f357fd-925e-416d-b6aa-1c7f138f967f	c21b3648-38a3-4dde-86ea-cbee7d78165f	E2E Misc Matrix مدیر	Owner	t	\N	f	09901307226
aafbc6b7-ebdd-418f-a932-7c101946b59a	c21b3648-38a3-4dde-86ea-cbee7d78165f	Misc Stylist	Stylist	t	\N	f	09582052075
46c81677-9e6d-45cd-8a0d-937679db012a	8aa546de-8daf-489d-9fe8-8b3118bf9f7a	E2E Notification Other مدیر	Owner	t	\N	f	09971633535
8ba71a61-d554-4c11-8394-b6fc34dc94f3	a32e5e4b-40d7-4635-939c-79fb4b2fdc68	E2E Public Matrix مدیر	Owner	t	\N	f	09921236465
b7fd6924-84b4-4c66-a43f-d1c6e08fcbe4	3e99cb18-41bd-457b-9326-d2889b35cec5	E2E Other Tenant مدیر	Owner	t	\N	f	09913921837
753944de-8b7f-40de-880f-32b84429daa1	83bc9d7c-d555-4961-8c35-215f48b3f8b7	E2E Config Matrix مدیر	Owner	t	\N	f	09977200147
96e9d85e-1deb-4889-a3d2-4edba29b2ed8	83bc9d7c-d555-4961-8c35-215f48b3f8b7	Config Admin	Admin	t	\N	f	09426181167
f073a0ff-6e6f-43d4-9a63-9ed194b88797	ca682117-4612-4948-ae95-9706f3d56404	E2E Booking Matrix مدیر	Owner	t	\N	f	09910729135
50070078-f099-4cb5-a8ce-c6bde911a49e	ca682117-4612-4948-ae95-9706f3d56404	Booking Stylist	Stylist	t	\N	f	09586140863
e5e37985-fd50-4773-a36f-6a50e61ca6c5	ca682117-4612-4948-ae95-9706f3d56404	Booking Admin	Admin	t	\N	f	09406747983
cbd2f87e-787d-40ee-80ea-9b90b71c298e	6546637e-4a35-4c02-a418-8ddf714c6b96	E2E Premium Matrix مدیر	Owner	t	\N	f	09939714736
37c497ba-5975-4270-a54a-e99008ba1f9b	6546637e-4a35-4c02-a418-8ddf714c6b96	Premium Admin	Admin	t	\N	f	09434217528
4f403ce7-15d0-4ec9-b52b-b5e12973e84e	83bc9d7c-d555-4961-8c35-215f48b3f8b7	Config Stylist Updated	Stylist	t	\N	f	09554499615
650b3df5-9cad-40dd-b403-fe532b2f9e83	c3104b98-c5c9-46db-b100-1ad8180b1c11	E2E Other Tenant مدیر	Owner	t	\N	f	09990507380
a3b2cb93-a39f-4cb4-9872-bec91a7edd69	9d965b2a-2b91-456a-92bb-937b05888fa8	E2E Booking Matrix مدیر	Owner	t	\N	f	09944839979
ba7c9524-b0d4-4845-8886-5274ede7fd6a	9d965b2a-2b91-456a-92bb-937b05888fa8	Booking Stylist	Stylist	t	\N	f	09595045946
539af821-6da8-4010-8607-7e1ce771d827	9d965b2a-2b91-456a-92bb-937b05888fa8	Booking Admin	Admin	t	\N	f	09416380655
b8a2991d-41e8-4be8-bc0d-276fb036260d	65b96ada-c840-4a9d-bfbb-5fa5df901d91	E2E Premium Matrix مدیر	Owner	t	\N	f	09933597670
a6bd7f92-dd1a-419e-8961-632743b48093	65b96ada-c840-4a9d-bfbb-5fa5df901d91	Premium Admin	Admin	t	\N	f	09463724631
efe05064-d22c-43cc-bafc-9e80e476f658	65b96ada-c840-4a9d-bfbb-5fa5df901d91	Premium Stylist	Stylist	t	\N	f	09535185963
30c7ba5b-2085-4124-a6f2-7986e79071f0	b9e33109-b47b-40d5-a0ac-2a0d837c6827	E2E Misc Matrix مدیر	Owner	t	\N	f	09969703073
6421b62a-3327-4457-8d4b-d759b0a13b4a	b9e33109-b47b-40d5-a0ac-2a0d837c6827	Misc Stylist	Stylist	t	\N	f	09513059823
3145ba23-2f1c-4100-a3ca-8688523c1de6	1e53029c-8667-4f39-a775-f30d1293f13a	E2E Notification Other مدیر	Owner	t	\N	f	09900683145
27adc8b0-9d2e-40e9-a663-a6a7ac79adfa	21835586-a1de-4990-bb83-8f9cc4373a5c	E2E Public Matrix مدیر	Owner	t	\N	f	09997986003
544ceb5a-2fea-47d6-acef-76045154881a	6546637e-4a35-4c02-a418-8ddf714c6b96	Premium Stylist	Stylist	t	\N	f	09574223587
9370c29a-97b1-4b1d-918a-e54906c7cc52	94d46edb-1124-4428-993f-64b9e456dbfb	E2E Config Matrix مدیر	Owner	t	\N	f	09991096895
1a734b94-3e46-4f77-b8e5-43361839bcad	94d46edb-1124-4428-993f-64b9e456dbfb	Config Admin	Admin	t	\N	f	09491898737
22222222-2222-2222-2222-222222222222	11111111-1111-1111-1111-111111111111	سارا محمدی	Owner	t	\N	f	09120000001
dddddddd-2222-2222-2222-222222222222	11111111-1111-1111-1111-111111111111	مریم احمدی	Admin	t	\N	f	09120000002
c1f439d8-c58d-4ef3-a0f1-51bf34cf3bf5	843b43c9-fbb2-496e-9604-69698c152179	E2E Public Matrix مدیر	Owner	t	\N	f	09956367084
033f2976-aa70-43db-b8b6-b850b66193f8	46b5e7c3-4228-4d05-9724-b4d688e772a3	E2E Config Matrix مدیر	Owner	t	\N	f	09954704851
03bbe15a-45dc-4a28-b013-f74e5a9994fd	46b5e7c3-4228-4d05-9724-b4d688e772a3	Config Admin	Admin	t	\N	f	09418264056
eeeb8ab5-2f29-4edf-9c12-cbdf476848b6	94d46edb-1124-4428-993f-64b9e456dbfb	Config Stylist Updated	Stylist	t	\N	f	09541891178
be145b3a-a902-46eb-84fa-3b5f66dc7bef	9f5bd53c-a3c5-4380-b111-3bcfc11381d3	E2E Other Tenant مدیر	Owner	t	\N	f	09967384452
a8bafa5c-6bf7-4441-97d4-b5fae40a1935	e7f95ac5-5c53-4db7-b274-f0c94730f18c	E2E Booking Matrix مدیر	Owner	t	\N	f	09959513115
ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	e7f95ac5-5c53-4db7-b274-f0c94730f18c	Booking Stylist	Stylist	t	\N	f	09515579643
f0ee5e08-21db-49f9-b8b9-0e49cfa7f784	e7f95ac5-5c53-4db7-b274-f0c94730f18c	Booking Admin	Admin	t	\N	f	09442910165
1f57cc2c-1b58-4304-841b-6d1e9ace9918	5d0f07bd-e701-4d76-8a43-66f370a0fdd6	E2E Premium Matrix مدیر	Owner	t	\N	f	09975211806
539a41af-8f76-4e98-a4f4-425fa7614e92	5d0f07bd-e701-4d76-8a43-66f370a0fdd6	Premium Admin	Admin	t	\N	f	09402873165
7901cb34-8b2e-44b8-972d-98792ecdb564	5d0f07bd-e701-4d76-8a43-66f370a0fdd6	Premium Stylist	Stylist	t	\N	f	09574143751
3f9e4c0c-0bdb-460e-982a-781f1baa2ca1	f9eaed2d-7068-4583-8a46-869324599cc6	E2E Misc Matrix مدیر	Owner	t	\N	f	09960017196
4077f0c8-2550-4fa7-9646-ffdb78ceb62d	f9eaed2d-7068-4583-8a46-869324599cc6	Misc Stylist	Stylist	t	\N	f	09594251630
84a2f142-e502-43c7-9b33-3ea246f018c9	a9ce2f38-b34c-414c-858e-d26135c9d819	E2E Notification Other مدیر	Owner	t	\N	f	09939155852
795d9693-3ea4-4ff2-b9e6-20cb6255fb01	7b0a02d7-7ef3-49fe-af64-cb4da63051ae	E2E UI مدیر	Owner	t	\N	f	09885660883
c1a91ff2-d119-4c56-9529-26b154e3c0b7	7b0a02d7-7ef3-49fe-af64-cb4da63051ae	E2E آرایشگر 1786106972841	Stylist	t	\N	t	09627117598
c55ae5bc-c225-44aa-b2dc-350c9cd7eead	0c3dfb48-5927-4861-864f-a8543c9eb7ac	E2E RBAC مدیر	Owner	t	\N	f	09907035470
3df2c865-dce9-4b08-add1-7dfa3c9d9fee	0c3dfb48-5927-4861-864f-a8543c9eb7ac	RBAC آرایشگر	Stylist	t	\N	f	09592290534
1b012fee-fe6f-43b2-96b3-13af01b23bd1	0c3dfb48-5927-4861-864f-a8543c9eb7ac	RBAC ادمین	Admin	t	\N	f	09420021328
fe8403ef-6732-42db-868d-4346f296f49c	a3b92139-eb81-4a88-a88d-0e4b23e9368c	E2E Booking مدیر	Owner	t	\N	f	09969598914
c3d76a47-47ab-4f5f-bcc2-eddd9477559e	04034eee-0de0-4289-a3db-b3faf17d4ca4	E2E QR Trial مدیر	Owner	t	\N	f	09919458344
6154b0bb-a33d-4aa1-bb85-e74badea0943	d7412cac-b652-4a48-a889-e282a2ed5d55	مالک تست	Owner	t	\N	f	09127969845
41cc11f7-c150-4eb8-bd86-f6361ae27465	d7412cac-b652-4a48-a889-e282a2ed5d55	ادمین تست	Admin	t	\N	f	09137969845
34d42336-3900-4918-a2d6-9068b8cfe6b0	d7412cac-b652-4a48-a889-e282a2ed5d55	آرایشگر تست	Stylist	t	t	t	09147969845
b6ad00d3-1c8d-45b7-957b-8dc075467d23	91117aaf-0c89-4e41-9598-3479ebdb801f	E2E UI مدیر	Owner	t	\N	f	09875557101
cd9add27-87da-4373-a524-97759e0ae44a	91117aaf-0c89-4e41-9598-3479ebdb801f	E2E آرایشگر 1786110742856	Stylist	t	\N	t	09636231531
5c3ee7d7-dc07-4634-b6c4-9304a00d1a86	793c04cb-a78d-46bc-b66d-713f10e3f731	E2E RBAC مدیر	Owner	t	\N	f	09923181418
5b6096b9-d650-4ba0-a796-be663918104a	793c04cb-a78d-46bc-b66d-713f10e3f731	RBAC آرایشگر	Stylist	t	\N	f	09506049621
13b96610-a22f-4176-a49b-3548e0358b65	793c04cb-a78d-46bc-b66d-713f10e3f731	RBAC ادمین	Admin	t	\N	f	09464026107
a9955774-e41d-4176-aff4-b10e51138abf	4acda9b4-b53a-452d-b438-3c01cc8a3ca4	E2E Booking مدیر	Owner	t	\N	f	09932765010
488c3d0d-79fb-4343-9a88-44465fa9a189	ea76f00a-df7d-4ff1-8dc7-82b563279af8	E2E QR Trial مدیر	Owner	t	\N	f	09911329502
3b0e01c0-8ee7-41d2-8057-f49cb1029722	cbcf2e40-16fa-481d-b8da-be5c9642aa5c	E2E UI مدیر	Owner	t	\N	f	09887853376
f73fc09c-a972-4f71-9811-f0d55d146a1d	cbcf2e40-16fa-481d-b8da-be5c9642aa5c	E2E آرایشگر 1786110877167	Stylist	t	\N	t	09622834500
dfc88ac1-ede6-4b62-a170-63fc5d7dd3d4	4ee90b92-1681-4046-b42d-50582aaf3c55	E2E UI مدیر	Owner	t	\N	f	09803664272
fe24b70c-b7f6-4b2d-960c-5d6af268b0cb	4ee90b92-1681-4046-b42d-50582aaf3c55	E2E آرایشگر 1786110955743	Stylist	t	\N	t	09605325630
fbe2b299-5a41-4b36-81e0-700b9aeb80e7	8fddf0bd-1345-4f94-9277-ce0abe54fc86	E2E RBAC مدیر	Owner	t	\N	f	09984218203
7ea453a7-f534-4afb-a400-3dd71f91c538	8fddf0bd-1345-4f94-9277-ce0abe54fc86	RBAC آرایشگر	Stylist	t	\N	f	09582726221
a068dc21-fa06-4a13-b527-1bd9ef708d70	8fddf0bd-1345-4f94-9277-ce0abe54fc86	RBAC ادمین	Admin	t	\N	f	09428663627
3799ff0a-0064-4f2a-8717-4d2c35b40060	d86a4f90-7ef3-477a-b928-3804c9bd1bca	E2E Booking مدیر	Owner	t	\N	f	09986475629
4e457734-15ac-4ffc-9a23-fbeb7f75150a	ecdda28c-34cf-47e1-bb64-35433730951f	E2E QR Trial مدیر	Owner	t	\N	f	09963216717
d103be7a-51b0-4e4f-a608-7350cc921072	47a7b865-c608-462c-84b6-37268be1b96c	E2E Public Matrix مدیر	Owner	t	\N	f	09908245870
a5c68558-e3ac-43c3-98ce-5d0d466d51ab	4a680e73-4c54-4523-a9e2-e0d52299eb58	E2E Config Matrix مدیر	Owner	t	\N	f	09962872334
a4984776-fd5b-43a9-9096-a1e5e2d83cc3	f6b026fa-c4e3-4be6-a2be-796fe9abbe57	E2E Booking Matrix مدیر	Owner	t	\N	f	09923756911
9075c684-ae7e-415d-90bb-1c5c67083279	7cb82de5-0177-4be1-999c-fd7ef40af41b	E2E Premium Matrix مدیر	Owner	t	\N	f	09914328150
09b2f5ef-cd02-491a-bd54-be0c30e9c654	b578c0dd-6919-4d23-b7f2-efa770c47aca	E2E Misc Matrix مدیر	Owner	t	\N	f	09903495878
7871f6e8-d0f5-45db-84be-9693bfe02b5c	4f7ed53f-8383-4517-bd6f-8e71b351ce89	E2E Public Matrix مدیر	Owner	t	\N	f	09901109792
f03e27a5-59d9-4a0d-be4c-9d55c611afa2	9ce67759-ee69-4264-a07f-891b3f9805e2	E2E Misc Matrix مدیر	Owner	t	\N	f	09966253741
052328d1-4f15-426d-ab6e-c04cde71cb11	a8fbfe27-1784-4a99-bf74-6c560de51016	E2E Config Matrix مدیر	Owner	t	\N	f	09979966822
57da11d8-0d8e-4e60-a48e-328c6368a480	a8fbfe27-1784-4a99-bf74-6c560de51016	Config Admin	Admin	t	\N	f	09413915894
e239ea1d-67db-4e64-aad9-ef9c45200291	9ce67759-ee69-4264-a07f-891b3f9805e2	Misc Stylist	Stylist	t	\N	f	09591358342
8cecfbcd-5e85-410a-b260-665f1caa2eb4	f57024e7-1bbb-4d66-b3e8-3e7007f205c9	E2E Notification Other مدیر	Owner	t	\N	f	09937274934
e3ecb356-03e8-4d45-85cb-50adc81a474a	a03997c7-c54e-4856-9c2c-f84a6a7c7092	E2E Public Matrix مدیر	Owner	t	\N	f	09942898011
06119660-0ce2-4cd4-b960-67cd0ba0e8ea	e3fa9cc9-4249-426a-8a5e-bdfea48ab30e	E2E Config Matrix مدیر	Owner	t	\N	f	09922928279
5fc5b48d-1854-4065-8d6e-dc57dc999a2d	e3fa9cc9-4249-426a-8a5e-bdfea48ab30e	Config Admin	Admin	t	\N	f	09435867300
133a6ecc-53ba-4f45-a858-9e8df3ce87b2	a8fbfe27-1784-4a99-bf74-6c560de51016	Config Stylist Updated	Stylist	t	\N	f	09517111469
9e8afae2-1456-42ef-8843-d3ed612706f3	d1c9c1e8-22db-4add-814e-be04ecc51faf	E2E Other Tenant مدیر	Owner	t	\N	f	09901951017
bee3515c-19e3-454f-922b-8f24d8a75913	c66e014b-5299-4f9f-bc65-195fbad0cd99	E2E Booking Matrix مدیر	Owner	t	\N	f	09992984304
05cf7580-8f7d-433b-a660-ab1b55791e8c	c66e014b-5299-4f9f-bc65-195fbad0cd99	Booking Stylist	Stylist	t	\N	f	09556213208
9725338d-2d4c-4799-a426-8a6c9ff509ce	c66e014b-5299-4f9f-bc65-195fbad0cd99	Booking Admin	Admin	t	\N	f	09434171490
e16ebfba-a63f-4728-98ad-b8ee65ac2b47	ce2ffe75-4e1d-4e06-9f8d-8ea2ab35b605	E2E Premium Matrix مدیر	Owner	t	\N	f	09963498529
cdf9fcd2-ed8b-4e66-9562-c9486cdddc11	ce2ffe75-4e1d-4e06-9f8d-8ea2ab35b605	Premium Admin	Admin	t	\N	f	09419149438
11d45054-392d-46ea-9af4-6f785af5ebb1	ce2ffe75-4e1d-4e06-9f8d-8ea2ab35b605	Premium Stylist	Stylist	t	\N	f	09547914046
4094637e-5070-4e5e-a1c7-627a2f8cb985	33b55265-4e46-4dfc-8e22-22fd32ccd0f2	E2E Misc Matrix مدیر	Owner	t	\N	f	09979655003
366b1baf-e776-41fb-b606-9b32f7261a03	33b55265-4e46-4dfc-8e22-22fd32ccd0f2	Misc Stylist	Stylist	t	\N	f	09558245740
de0edb73-fc1a-4d2e-85c4-fad6ba995838	f4131cfd-52ad-46ee-9c9b-c6d358ed5f10	E2E Notification Other مدیر	Owner	t	\N	f	09912120868
4da92dd7-f9c2-487f-a1ae-7170bec48876	f5152ef5-f532-47f7-9ac9-ddc21a287cba	E2E Public Matrix مدیر	Owner	t	\N	f	09952072090
9721f83e-e980-47ee-a67a-466e2657db37	114d6cf5-f9d5-4cb5-ab7a-89b2facecadf	E2E Config Matrix مدیر	Owner	t	\N	f	09904541869
cb308fb6-a90b-48ad-a1cf-2e2ad2ab0e08	114d6cf5-f9d5-4cb5-ab7a-89b2facecadf	Config Admin	Admin	t	\N	f	09463231917
d1bc980a-d262-4c4a-a479-4e213b65da23	8acc033d-9bdc-4a9b-a0f2-a7c8f7a8e80d	E2E آرایشگر 1786111265916	Stylist	t	\N	t	09682195104
4737eee4-96e0-484a-bc2c-21fa476cecec	e7b2abf5-4d80-4d5f-a96e-c42395401a4c	E2E RBAC مدیر	Owner	t	\N	f	09914306841
d4d83171-36d3-40be-9f3a-d584794db7f4	e7b2abf5-4d80-4d5f-a96e-c42395401a4c	RBAC آرایشگر	Stylist	t	\N	f	09581221509
667278f7-1b2c-4686-874d-61954a79b5c8	e7b2abf5-4d80-4d5f-a96e-c42395401a4c	RBAC ادمین	Admin	t	\N	f	09479062351
274d5221-7f2c-46d4-b797-119ae3f82652	e66c3ae5-4fe0-48ef-a5f8-e2226df0ed55	E2E Booking مدیر	Owner	t	\N	f	09931869789
44c43473-b2c1-487d-9176-157713994ca8	0fbab0e1-6447-4455-bde7-412a6154819d	E2E QR Trial مدیر	Owner	t	\N	f	09930411220
2443d906-bfd5-4337-9ec1-33f957ceac62	114d6cf5-f9d5-4cb5-ab7a-89b2facecadf	Config Stylist Updated	Stylist	t	\N	f	09557906403
11210303-546e-44a6-8a49-dd27833042ec	75615eb1-bd39-4831-897f-4b6a23901cb7	E2E Other Tenant مدیر	Owner	t	\N	f	09960744548
7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	41945155-8295-4ffe-9fca-a051aec9d85c	E2E Booking Matrix مدیر	Owner	t	\N	f	09966900876
9ff568fe-8383-455f-ac18-18299a003bb6	e3fa9cc9-4249-426a-8a5e-bdfea48ab30e	Config Stylist Updated	Stylist	t	\N	f	09554353058
e366d7da-0479-44df-bd5a-5a2d666f9313	41945155-8295-4ffe-9fca-a051aec9d85c	Booking Stylist	Stylist	t	\N	f	09593178546
002d1a78-0ef0-49fc-8b60-f3951949ad5e	41945155-8295-4ffe-9fca-a051aec9d85c	Booking Admin	Admin	t	\N	f	09470850073
9533b3d5-242d-418b-8b8f-29f546d663b3	7ecbf7b9-4944-4750-858d-c838c1fb60db	E2E Premium Matrix مدیر	Owner	t	\N	f	09931868744
1f051767-13a6-4117-80f4-58bf6dbfda16	7ecbf7b9-4944-4750-858d-c838c1fb60db	Premium Admin	Admin	t	\N	f	09410146828
ec6b2c18-2cc2-41c9-9165-956cad61d761	7ecbf7b9-4944-4750-858d-c838c1fb60db	Premium Stylist	Stylist	t	\N	f	09515223287
8fcfcba0-a241-4d09-8dad-4160d4f18116	46b5e7c3-4228-4d05-9724-b4d688e772a3	Config Stylist Updated	Stylist	t	\N	f	09507358582
79f59f3e-7c26-4eb0-ab52-b56447aaa03f	0acac768-245e-4600-b24d-10357b6a9206	Premium Admin	Admin	t	\N	f	09424404169
b9e31fd8-d9b4-43e0-ae3e-fe78fe07c56a	0acac768-245e-4600-b24d-10357b6a9206	Premium Stylist	Stylist	t	\N	f	09544687707
16d1ba6d-ef25-495d-b7ca-32728de6b6cd	daaee930-a32d-41c2-8e2d-d59946feb22b	E2E Misc Matrix مدیر	Owner	t	\N	f	09944637431
1f2dbb13-c832-4c51-ac26-33a5033a9f36	daaee930-a32d-41c2-8e2d-d59946feb22b	Misc Stylist	Stylist	t	\N	f	09537743215
32a99ba7-b901-43e1-9064-04292dcd8653	9fb475fe-8cac-4fd3-8f89-b522a84d2edf	E2E Notification Other مدیر	Owner	t	\N	f	09917280447
23598377-45d4-4232-be87-88619be1b077	11776d89-31cf-4504-9bb8-c4473fac42d1	Config Admin	Admin	t	\N	f	09430195788
bb302d69-79ff-4921-86d1-8e6e22ae92cb	ecfd9427-201f-45b4-b995-0c5903186dcf	E2E Booking Matrix مدیر	Owner	t	\N	f	09916809095
d41ffc8a-603b-483a-bfe3-3c7994ef116c	ecfd9427-201f-45b4-b995-0c5903186dcf	Booking Stylist	Stylist	t	\N	f	09548691083
e53f0e86-7504-4c2f-8c88-64a4fc4b17ab	ecfd9427-201f-45b4-b995-0c5903186dcf	Booking Admin	Admin	t	\N	f	09413458686
0bbae851-7318-4213-8961-75ff34de841f	bf46a9e5-b9ad-4b7a-857c-c42a838c5105	E2E Premium Matrix مدیر	Owner	t	\N	f	09911569556
5cd5fc65-6491-4496-af6a-01f411be6063	bf46a9e5-b9ad-4b7a-857c-c42a838c5105	Premium Admin	Admin	t	\N	f	09406999955
3a61b3fd-5024-41f9-af02-4afaff34c331	bf46a9e5-b9ad-4b7a-857c-c42a838c5105	Premium Stylist	Stylist	t	\N	f	09522515935
e2200c8d-5e09-4149-bea1-d3a6a7f0e421	d5fb54d8-3c89-493d-8edd-48fb3f04ef42	E2E Misc Matrix مدیر	Owner	t	\N	f	09935518279
16da35bd-5216-41c2-a656-5550e901e96f	d5fb54d8-3c89-493d-8edd-48fb3f04ef42	Misc Stylist	Stylist	t	\N	f	09545904586
d30ef226-19d4-4e79-a50c-a15e99f31d14	b32a6626-2517-4496-b611-8221818a64cd	E2E Notification Other مدیر	Owner	t	\N	f	09922017271
199d69f0-cb29-4014-bb76-9984a0190631	8acc033d-9bdc-4a9b-a0f2-a7c8f7a8e80d	E2E UI مدیر	Owner	t	\N	f	09804098653
63446f6a-49e7-431e-868b-33c534155203	1301ed82-4e76-447e-b9b2-203e4ab5e6b7	E2E Public Matrix مدیر	Owner	t	\N	f	09977444382
f3d31de6-d22e-4d38-a366-f5848e504bfb	11776d89-31cf-4504-9bb8-c4473fac42d1	E2E Config Matrix مدیر	Owner	t	\N	f	09990134579
7ea40eb1-7057-49a7-a1c5-1b9b04c48018	11776d89-31cf-4504-9bb8-c4473fac42d1	Config Stylist Updated	Stylist	t	\N	f	09537695622
73e51bbb-8122-4773-ba10-d37fdd063fa5	4dedcfd1-9cee-4826-9fb1-0cfbfa5886ef	E2E Other Tenant مدیر	Owner	t	\N	f	09904974140
b25a26a7-eb8d-49a2-b10f-79544277cebb	a8f9e2e8-b848-487b-a2c4-8b7a01f955a3	E2E Misc Matrix مدیر	Owner	t	\N	f	09944269814
712bfffd-6e35-4ef4-9259-2bfed0c5e4d6	a8f9e2e8-b848-487b-a2c4-8b7a01f955a3	Misc Stylist	Stylist	t	\N	f	09571847982
388daaa5-789a-4514-9bc5-511649f2f437	41fe0795-178c-4762-828d-2bf86d3b7d2b	E2E Notification Other مدیر	Owner	t	\N	f	09960851531
0780d8d7-804a-4666-89d9-e08d9f17102b	dc36c3db-891c-47ad-a4c1-ecf6f3c4671e	E2E UI مدیر	Owner	t	\N	f	09893550237
61b8298d-a97f-4ea6-a255-a95c04d82457	dc36c3db-891c-47ad-a4c1-ecf6f3c4671e	E2E آرایشگر 1786111324447	Stylist	t	\N	t	09685093258
389aab4c-9d68-4e3e-bc97-a3d7af01f4da	3d0794ce-aed8-4b71-b1df-80de2ee1f392	E2E RBAC مدیر	Owner	t	\N	f	09961895488
694a7f83-6458-4401-9505-c25d2a216006	3d0794ce-aed8-4b71-b1df-80de2ee1f392	RBAC آرایشگر	Stylist	t	\N	f	09567386178
4b4bac84-2abc-41eb-bdf5-d2c6d88e572e	3d0794ce-aed8-4b71-b1df-80de2ee1f392	RBAC ادمین	Admin	t	\N	f	09414075144
51f6dc27-15f5-44a3-9826-0805962f6322	e71737ea-c9ab-401c-bd67-8525aa0060fd	E2E Booking مدیر	Owner	t	\N	f	09929334805
50390ddd-1517-4019-bfbe-6818793a54eb	6e338bf0-ec57-44fe-8b1f-7af52ad1d31e	E2E QR Trial مدیر	Owner	t	\N	f	09982231956
dddddddd-3333-3333-3333-333333333333	11111111-1111-1111-1111-111111111111	زهرا رضایی	Stylist	t	\N	f	09120000003
ab050000-0000-4000-8000-000000000002	aa000005-0000-4000-8000-000000000005	شبنم راد	Stylist	t	\N	f	09120000502
ab020000-0000-4000-8000-000000000001	aa000002-0000-4000-8000-000000000002	شاهین قاسمی	Owner	t	\N	f	09120000201
ab030000-0000-4000-8000-000000000001	aa000003-0000-4000-8000-000000000003	نیلوفر صادقی	Owner	t	\N	f	09120000301
ab040000-0000-4000-8000-000000000001	aa000004-0000-4000-8000-000000000004	آرش کمالی	Owner	t	\N	f	09120000401
ab010000-0000-4000-8000-000000000002	aa000001-0000-4000-8000-000000000001	آیدا شریفی	Stylist	t	\N	f	09120000102
ab030000-0000-4000-8000-000000000002	aa000003-0000-4000-8000-000000000003	مینا جلالی	Stylist	t	\N	f	09120000302
ab010000-0000-4000-8000-000000000001	aa000001-0000-4000-8000-000000000001	مریم رضوی	Owner	t	\N	f	09120000101
ab050000-0000-4000-8000-000000000001	aa000005-0000-4000-8000-000000000005	پریسا نعمتی	Owner	t	\N	f	09120000501
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription (id, salon_id, status, plan_kind, started_at, expires_at, grace_until, created_at) FROM stdin;
9c7dd60f-33bc-4c15-9faf-30775bef6ca3	282f2ee7-f778-4f75-8e41-72ee726e2d71	trial	trial	2026-08-07 12:06:30.45+00	2026-08-21 12:06:30.45+00	2026-08-28 12:06:30.45+00	2026-08-07 12:06:30.451+00
5678329d-5a06-4300-8e06-d1418d890b43	3ad3c745-12dc-4dca-9e16-ee4c57bd987b	trial	trial	2026-08-07 12:06:33.146+00	2026-08-21 12:06:33.146+00	2026-08-28 12:06:33.146+00	2026-08-07 12:06:33.146+00
93743d2d-8fb6-4643-84a5-b75aa9016f27	6a5b29c2-a8df-467a-8c36-ca49f545625c	trial	trial	2026-08-07 12:06:36.351+00	2026-08-21 12:06:36.351+00	2026-08-28 12:06:36.351+00	2026-08-07 12:06:36.352+00
f1af7582-5e67-4fe0-bb9d-ad5c62ca79cf	36e79989-a20d-4f1e-9b9b-538d101b4014	trial	trial	2026-08-07 12:06:41.375+00	2026-08-21 12:06:41.375+00	2026-08-28 12:06:41.375+00	2026-08-07 12:06:41.376+00
54e27d9c-36f9-4e50-826f-c789e56ab142	f3f3eb54-0191-4d27-bd54-81fa82f9b40f	active	monthly	2026-07-25 18:59:02.757+00	2026-09-07 18:59:02.757+00	2026-09-14 18:59:02.757+00	2026-07-25 18:59:02.757+00
b28e5ea7-0f66-4bd6-b443-405df013b991	cb8d9d1e-9cfa-42e3-88bf-07b6617ca273	trial	trial	2026-07-26 19:37:46.395+00	2026-08-09 19:37:46.395+00	2026-08-16 19:37:46.395+00	2026-07-26 19:37:46.396+00
17462081-26dc-447c-aefd-f08aca36b3b0	5d0f07bd-e701-4d76-8a43-66f370a0fdd6	active	monthly	2026-08-07 12:49:23.907+00	2026-09-20 12:49:23.907+00	2026-09-27 12:49:23.907+00	2026-08-07 12:49:23.908+00
6bffdc23-4976-4598-8ac1-14839b6afe4f	4c0bfb7e-08bb-4675-9b6c-b7928cbb347e	trial	trial	2026-08-07 12:23:37.415+00	2026-08-21 12:23:37.415+00	2026-08-28 12:23:37.415+00	2026-08-07 12:23:37.416+00
8399b1ce-3f22-4f1c-95a0-6039e3d2fb1c	b6e528ae-c2ac-4579-bd70-4a33806fbcee	trial	trial	2026-08-07 12:23:38.058+00	2026-08-21 12:23:38.058+00	2026-08-28 12:23:38.058+00	2026-08-07 12:23:38.058+00
618e6cb6-fab3-4f0b-8b3f-4d411d8da466	c29ea8c8-5840-4ddb-885c-e70eafb741b5	trial	trial	2026-08-07 12:23:38.804+00	2026-08-21 12:23:38.804+00	2026-08-28 12:23:38.804+00	2026-08-07 12:23:38.805+00
67cd119d-8155-4641-a64c-ef4173c2d6e9	b8d1f622-7f06-49a7-aba2-30dcef24f8a7	active	monthly	2026-07-30 22:11:57.945+00	2026-09-12 22:11:57.945+00	2026-09-19 22:11:57.945+00	2026-07-30 22:11:57.946+00
1431164d-2462-49b2-a9ab-f7a7f986d71e	48b7b978-caca-4b3d-9996-48178b2a4fb5	active	monthly	2026-08-07 12:23:39.818+00	2026-09-20 12:23:39.818+00	2026-09-27 12:23:39.818+00	2026-08-07 12:23:39.819+00
6028b1a2-4a1b-435b-8fbc-dddd6a000d50	1bb72fda-9b55-4d92-b5ae-07341a7c9aaf	trial	trial	2026-08-07 12:23:40.175+00	2026-08-21 12:23:40.175+00	2026-08-28 12:23:40.175+00	2026-08-07 12:23:40.175+00
e27f6624-2af8-402e-b104-b124ab33ee61	1cb71f4e-7f3f-473c-9ba2-9bf38e6943fa	trial	trial	2026-08-07 12:23:40.38+00	2026-08-21 12:23:40.38+00	2026-08-28 12:23:40.38+00	2026-08-07 12:23:40.381+00
ded3108c-2191-43d6-9918-1e02cd757562	0ed4db5e-a345-4f57-a5ff-7faf1876853c	trial	trial	2026-08-07 12:25:57.317+00	2026-08-21 12:25:57.317+00	2026-08-28 12:25:57.317+00	2026-08-07 12:25:57.318+00
4dad8938-56a5-4f74-966d-c5199236eb28	3e1a529c-c38c-410a-9147-b0776d2cf387	trial	trial	2026-08-07 12:25:58.014+00	2026-08-21 12:25:58.014+00	2026-08-28 12:25:58.014+00	2026-08-07 12:25:58.015+00
38cb2332-bdc4-4ae5-9807-b3e0d7899ed3	bb22b03a-5d16-4b81-b42a-49e37d27593b	trial	trial	2026-08-07 12:25:58.659+00	2026-08-21 12:25:58.659+00	2026-08-28 12:25:58.659+00	2026-08-07 12:25:58.66+00
0f9e8d3e-1d83-4ffd-87da-bbdfd6b016bb	11a5ba43-60ac-45c0-84de-ff438ddbd3dc	trial	trial	2026-08-07 12:25:58.72+00	2026-08-21 12:25:58.72+00	2026-08-28 12:25:58.72+00	2026-08-07 12:25:58.72+00
2d579897-7251-44ef-9189-eba4a7648f1a	6eea0700-5a52-4b70-8a74-ff81d3ecceb0	active	monthly	2026-08-04 13:35:25.428+00	2026-09-17 13:35:25.428+00	2026-09-24 13:35:25.428+00	2026-08-04 13:35:25.429+00
7adbdb9e-792e-4775-8124-c25b4398325b	0f4db935-3ff2-426f-a8cf-16fd66dbd7da	active	monthly	2026-08-04 13:48:42.062+00	2026-09-17 13:48:42.062+00	2026-09-24 13:48:42.062+00	2026-08-04 13:48:42.063+00
2e3de7c2-7ed3-40e6-814a-0d42606a4c19	55809d45-8657-47fe-a0e2-ad8116219af4	active	monthly	2026-08-07 12:25:59.346+00	2026-09-20 12:25:59.346+00	2026-09-27 12:25:59.346+00	2026-08-07 12:25:59.347+00
f26cd55e-a3cc-4044-b27d-0934a7f495ec	c21b3648-38a3-4dde-86ea-cbee7d78165f	trial	trial	2026-08-07 12:25:59.628+00	2026-08-21 12:25:59.628+00	2026-08-28 12:25:59.628+00	2026-08-07 12:25:59.629+00
17dff1c0-ebb3-464d-b2f9-81b0f9e98dd1	8aa546de-8daf-489d-9fe8-8b3118bf9f7a	trial	trial	2026-08-07 12:25:59.826+00	2026-08-21 12:25:59.826+00	2026-08-28 12:25:59.826+00	2026-08-07 12:25:59.827+00
30c4b64f-dc1d-4dd2-9799-f1ace0f6f7cd	a32e5e4b-40d7-4635-939c-79fb4b2fdc68	trial	trial	2026-08-07 12:26:12.96+00	2026-08-21 12:26:12.96+00	2026-08-28 12:26:12.96+00	2026-08-07 12:26:12.961+00
d5834b0e-e16d-4aa0-819c-e62da494c1be	83bc9d7c-d555-4961-8c35-215f48b3f8b7	trial	trial	2026-08-07 12:26:13.141+00	2026-08-21 12:26:13.141+00	2026-08-28 12:26:13.141+00	2026-08-07 12:26:13.142+00
99a07fa8-925c-48b2-bb35-024e922f3461	c3104b98-c5c9-46db-b100-1ad8180b1c11	trial	trial	2026-08-07 12:26:13.775+00	2026-08-21 12:26:13.775+00	2026-08-28 12:26:13.775+00	2026-08-07 12:26:13.776+00
0cb8b71f-14a5-4f70-b539-fad0ac74016a	9d965b2a-2b91-456a-92bb-937b05888fa8	trial	trial	2026-08-07 12:26:13.857+00	2026-08-21 12:26:13.857+00	2026-08-28 12:26:13.857+00	2026-08-07 12:26:13.858+00
889bd40e-9afa-4da8-86cc-3018f6b73c63	65b96ada-c840-4a9d-bfbb-5fa5df901d91	active	monthly	2026-08-07 12:26:14.653+00	2026-09-20 12:26:14.653+00	2026-09-27 12:26:14.653+00	2026-08-07 12:26:14.654+00
bdf6357a-a475-46b1-82a8-042a855564ff	b9e33109-b47b-40d5-a0ac-2a0d837c6827	trial	trial	2026-08-07 12:26:14.974+00	2026-08-21 12:26:14.974+00	2026-08-28 12:26:14.974+00	2026-08-07 12:26:14.974+00
d5f744b9-b6c9-40cb-bfdd-2865943d3b2a	1e53029c-8667-4f39-a775-f30d1293f13a	trial	trial	2026-08-07 12:26:15.249+00	2026-08-21 12:26:15.249+00	2026-08-28 12:26:15.249+00	2026-08-07 12:26:15.25+00
056c2861-0472-4e84-80b3-2828ccb94cf0	b459826c-7585-4616-a22a-665a527778d3	active	monthly	2026-08-07 03:25:00.263+00	2026-09-20 03:25:00.263+00	2026-09-27 03:25:00.263+00	2026-08-07 03:25:00.263+00
2dc97867-fea2-417e-b4a5-5bcdb38a4480	a4288905-c8f2-4797-8922-144befd9dd50	trial	trial	2026-08-07 03:37:05.007+00	2026-08-21 03:37:05.007+00	2026-08-28 03:37:05.007+00	2026-08-07 03:37:05.008+00
11a27c2b-11ff-48ba-98c1-be651c0ddf16	21835586-a1de-4990-bb83-8f9cc4373a5c	trial	trial	2026-08-07 12:49:22.296+00	2026-08-21 12:49:22.296+00	2026-08-28 12:49:22.296+00	2026-08-07 12:49:22.297+00
3a45b040-5c24-4aba-892b-dda2bf5d9a4e	f9eaed2d-7068-4583-8a46-869324599cc6	trial	trial	2026-08-07 12:49:24.189+00	2026-08-21 12:49:24.189+00	2026-08-28 12:49:24.189+00	2026-08-07 12:49:24.19+00
bc098349-78c9-438f-b647-98ead368a504	82ad3b1b-e80e-4d67-95d4-e934f31934a4	trial	trial	2026-08-07 11:27:21.671+00	2026-08-21 11:27:21.671+00	2026-08-28 11:27:21.671+00	2026-08-07 11:27:21.672+00
81a6bac7-195f-4f6a-8f7e-12f71d780736	1ba2c5c1-6c6e-4e84-9343-56d66b2d3226	trial	trial	2026-08-07 11:28:02.804+00	2026-08-21 11:28:02.804+00	2026-08-28 11:28:02.804+00	2026-08-07 11:28:02.805+00
63dbb12c-10e2-49df-b93b-7daa398fe778	e54af3fc-d38b-41ad-b517-e558fa0e6cbf	trial	trial	2026-08-07 11:29:11.606+00	2026-08-21 11:29:11.606+00	2026-08-28 11:29:11.606+00	2026-08-07 11:29:11.607+00
c0a5e558-ae5a-43ed-9889-b2d4bafff1c0	c243bba9-2f63-421a-b92f-7e9eee00a7e2	trial	trial	2026-08-07 11:44:12.888+00	2026-08-21 11:44:12.888+00	2026-08-28 11:44:12.888+00	2026-08-07 11:44:12.889+00
01fcda75-7e0a-4ad0-8ea1-e43b38fa0744	f7bc45c9-75c1-4443-9dee-3b2183130dc0	trial	trial	2026-08-07 11:44:41.748+00	2026-08-21 11:44:41.748+00	2026-08-28 11:44:41.748+00	2026-08-07 11:44:41.749+00
c5509b2e-b922-4cd0-9755-667701040b70	eed48a8d-9014-40d6-903a-955c31140613	trial	trial	2026-08-07 11:45:38.338+00	2026-08-21 11:45:38.338+00	2026-08-28 11:45:38.338+00	2026-08-07 11:45:38.339+00
9eb42efa-58b7-4ce6-9ea0-70013366ff4c	f2b895e3-8eaf-42e4-b3c6-a244fff4934f	trial	trial	2026-08-07 11:46:34.902+00	2026-08-21 11:46:34.902+00	2026-08-28 11:46:34.902+00	2026-08-07 11:46:34.903+00
244ffe8e-aae7-4d9f-ab8a-c75273e6f8b8	3c84048d-601a-4f55-a989-038efc3ddbd2	trial	trial	2026-08-07 11:47:09.503+00	2026-08-21 11:47:09.503+00	2026-08-28 11:47:09.503+00	2026-08-07 11:47:09.504+00
fd55eb06-5e1d-4b65-8a2b-7a2739efaa99	34c4ebd4-eef3-4225-bcf6-cdaac1521668	trial	trial	2026-08-07 11:50:18.773+00	2026-08-21 11:50:18.773+00	2026-08-28 11:50:18.773+00	2026-08-07 11:50:18.774+00
a4158ecc-5b1c-41ff-b782-4cd7a67f93f3	6524f8ac-5aae-4f63-80ca-6cee0c030b20	trial	trial	2026-08-07 11:52:46.401+00	2026-08-21 11:52:46.401+00	2026-08-28 11:52:46.401+00	2026-08-07 11:52:46.402+00
796a282b-b7e6-47fc-841a-833905fe9684	8a91b095-7147-4ff4-9b71-290b72e6de88	trial	trial	2026-08-07 11:52:54.517+00	2026-08-21 11:52:54.517+00	2026-08-28 11:52:54.517+00	2026-08-07 11:52:54.518+00
80b80e7f-08ae-48df-88aa-413b6edecc9c	049ff655-e678-4a8a-aa15-dd1d0f082d72	trial	trial	2026-08-07 11:53:00.857+00	2026-08-21 11:53:00.857+00	2026-08-28 11:53:00.857+00	2026-08-07 11:53:00.858+00
415d922f-804d-429b-98c6-22cd264153b2	3ae5cde0-3a8d-4d60-be96-c4c456e161a0	trial	trial	2026-08-07 11:53:09.371+00	2026-08-21 11:53:09.371+00	2026-08-28 11:53:09.371+00	2026-08-07 11:53:09.372+00
df021f51-d226-4ec0-9939-4afe1280d4c3	83738a22-ac2f-4959-ae1f-31ab6a64d166	trial	trial	2026-08-07 11:54:00.309+00	2026-08-21 11:54:00.309+00	2026-08-28 11:54:00.309+00	2026-08-07 11:54:00.31+00
40cf49dc-1f4f-47c3-870a-c8d36a7d3e6f	e539a6f7-3a89-4777-8cc4-356882028d76	trial	trial	2026-08-07 11:54:27.85+00	2026-08-21 11:54:27.85+00	2026-08-28 11:54:27.85+00	2026-08-07 11:54:27.85+00
375ff10c-0edf-4ce2-818a-ed6bc969f79c	b332bbaf-9ab8-45da-a7a3-e27644b594e5	trial	trial	2026-08-07 11:57:40.013+00	2026-08-21 11:57:40.013+00	2026-08-28 11:57:40.013+00	2026-08-07 11:57:40.014+00
98c68dab-38ad-487f-8c59-9705dddff2af	94d4a899-f24e-4163-9da6-d42540203798	trial	trial	2026-08-07 11:58:07.517+00	2026-08-21 11:58:07.517+00	2026-08-28 11:58:07.517+00	2026-08-07 11:58:07.518+00
7ead1034-9673-4ceb-a11c-3f48825dbd40	37b31e8c-6d49-4cd9-aea2-e27961f8804f	trial	trial	2026-08-07 11:58:25.727+00	2026-08-21 11:58:25.727+00	2026-08-28 11:58:25.727+00	2026-08-07 11:58:25.727+00
aac23fb7-df1f-4f84-a49c-248888402e80	ede45a95-710d-4132-8214-e4c2f13f28e0	trial	trial	2026-08-07 11:58:28.38+00	2026-08-21 11:58:28.38+00	2026-08-28 11:58:28.38+00	2026-08-07 11:58:28.381+00
c28999e9-fc9b-4a99-b491-9f6d2deb85fc	8d4082de-f9bc-483c-8364-fb5373ecee79	trial	trial	2026-08-07 11:58:31.254+00	2026-08-21 11:58:31.254+00	2026-08-28 11:58:31.254+00	2026-08-07 11:58:31.255+00
e32d4493-b9a8-4e5b-b1ab-2ccb9bde1983	d04088e4-0987-405e-a912-9728a30e1fb7	trial	trial	2026-08-07 11:58:36.143+00	2026-08-21 11:58:36.143+00	2026-08-28 11:58:36.143+00	2026-08-07 11:58:36.144+00
1c0aac6c-d293-4808-bb98-2e66d7bc531f	94d46edb-1124-4428-993f-64b9e456dbfb	trial	trial	2026-08-07 12:49:22.55+00	2026-08-21 12:49:22.55+00	2026-08-28 12:49:22.55+00	2026-08-07 12:49:22.551+00
18495be1-d19e-466b-b484-cb514a118e0b	9f5bd53c-a3c5-4380-b111-3bcfc11381d3	trial	trial	2026-08-07 12:49:23.146+00	2026-08-21 12:49:23.146+00	2026-08-28 12:49:23.146+00	2026-08-07 12:49:23.146+00
e0b609a0-517a-4904-9a89-031bd65bdfba	e7f95ac5-5c53-4db7-b274-f0c94730f18c	trial	trial	2026-08-07 12:49:23.243+00	2026-08-21 12:49:23.243+00	2026-08-28 12:49:23.243+00	2026-08-07 12:49:23.243+00
d97908ab-a01f-4753-a07a-e9c799f16033	a9ce2f38-b34c-414c-858e-d26135c9d819	trial	trial	2026-08-07 12:49:24.375+00	2026-08-21 12:49:24.375+00	2026-08-28 12:49:24.375+00	2026-08-07 12:49:24.375+00
72aab74c-193e-4fc7-bc99-97f77aeed977	7b0a02d7-7ef3-49fe-af64-cb4da63051ae	trial	trial	2026-08-07 12:49:32.033+00	2026-08-21 12:49:32.033+00	2026-08-28 12:49:32.033+00	2026-08-07 12:49:32.033+00
c54773c1-5e3e-4fe8-b93a-7ca95e39bf62	0c3dfb48-5927-4861-864f-a8543c9eb7ac	trial	trial	2026-08-07 12:49:34.717+00	2026-08-21 12:49:34.717+00	2026-08-28 12:49:34.717+00	2026-08-07 12:49:34.718+00
a5ee8712-a8b0-4bad-8db2-fa4fea6db3a2	a3b92139-eb81-4a88-a88d-0e4b23e9368c	trial	trial	2026-08-07 12:49:37.524+00	2026-08-21 12:49:37.524+00	2026-08-28 12:49:37.524+00	2026-08-07 12:49:37.525+00
e5364a44-418d-44c0-83ab-c0f74e66221f	04034eee-0de0-4289-a3db-b3faf17d4ca4	trial	trial	2026-08-07 12:49:42.455+00	2026-08-21 12:49:42.455+00	2026-08-28 12:49:42.455+00	2026-08-07 12:49:42.456+00
1ef1b125-401f-4c1b-a935-33730e098f95	d7412cac-b652-4a48-a889-e282a2ed5d55	active	annual	2026-07-28 13:12:49.454468+00	2027-07-28 13:12:49.454468+00	2027-08-04 13:12:49.454468+00	2026-08-07 13:06:09.882+00
eeeeeeee-1111-1111-1111-111111111111	11111111-1111-1111-1111-111111111111	active	annual	2026-07-23 16:52:07.108502+00	2027-08-07 14:48:35.458336+00	2027-08-14 14:48:35.458336+00	2026-07-23 16:52:07.108502+00
09b76ed3-3f54-4b1f-a3b4-6143ece86c9c	91117aaf-0c89-4e41-9598-3479ebdb801f	trial	trial	2026-08-07 13:52:22.132+00	2026-08-21 13:52:22.132+00	2026-08-28 13:52:22.132+00	2026-08-07 13:52:22.133+00
69801faf-253c-48b9-a443-9bbbe0c8b9fb	793c04cb-a78d-46bc-b66d-713f10e3f731	trial	trial	2026-08-07 13:52:24.854+00	2026-08-21 13:52:24.854+00	2026-08-28 13:52:24.854+00	2026-08-07 13:52:24.855+00
875ddda1-8427-4fdf-b96f-3fec2b4cde7c	4acda9b4-b53a-452d-b438-3c01cc8a3ca4	trial	trial	2026-08-07 13:52:27.72+00	2026-08-21 13:52:27.72+00	2026-08-28 13:52:27.72+00	2026-08-07 13:52:27.721+00
082ae072-cf9b-408e-9c42-9ebbea94bbb7	ea76f00a-df7d-4ff1-8dc7-82b563279af8	trial	trial	2026-08-07 13:52:32.576+00	2026-08-21 13:52:32.576+00	2026-08-28 13:52:32.576+00	2026-08-07 13:52:32.576+00
bd0739b3-6503-4d06-94ea-92b1a3d40eff	cbcf2e40-16fa-481d-b8da-be5c9642aa5c	trial	trial	2026-08-07 13:54:36.424+00	2026-08-21 13:54:36.424+00	2026-08-28 13:54:36.424+00	2026-08-07 13:54:36.425+00
6562eee1-d730-4207-acf0-79df0e7a2f62	4ee90b92-1681-4046-b42d-50582aaf3c55	trial	trial	2026-08-07 13:55:55.043+00	2026-08-21 13:55:55.043+00	2026-08-28 13:55:55.043+00	2026-08-07 13:55:55.044+00
5d97baaf-ea62-461a-9566-a0d63ccf3179	8fddf0bd-1345-4f94-9277-ce0abe54fc86	trial	trial	2026-08-07 13:55:57.803+00	2026-08-21 13:55:57.803+00	2026-08-28 13:55:57.803+00	2026-08-07 13:55:57.804+00
8d310508-6715-499e-a0f2-b57c1e252dcb	d86a4f90-7ef3-477a-b928-3804c9bd1bca	trial	trial	2026-08-07 13:56:01.055+00	2026-08-21 13:56:01.055+00	2026-08-28 13:56:01.055+00	2026-08-07 13:56:01.056+00
b884e712-08ed-4b51-becf-e091d7ca45eb	ecdda28c-34cf-47e1-bb64-35433730951f	trial	trial	2026-08-07 13:56:06.086+00	2026-08-21 13:56:06.086+00	2026-08-28 13:56:06.086+00	2026-08-07 13:56:06.087+00
88c4c210-42f6-4a41-a01f-722099fc25c2	47a7b865-c608-462c-84b6-37268be1b96c	trial	trial	2026-08-07 13:56:12.48+00	2026-08-21 13:56:12.48+00	2026-08-28 13:56:12.48+00	2026-08-07 13:56:12.48+00
bf2c76ad-a844-41f6-8fd9-61495443395c	4a680e73-4c54-4523-a9e2-e0d52299eb58	trial	trial	2026-08-07 13:56:13.065+00	2026-08-21 13:56:13.065+00	2026-08-28 13:56:13.065+00	2026-08-07 13:56:13.066+00
245c1487-b861-4f02-ac1e-392d201ad7cf	f6b026fa-c4e3-4be6-a2be-796fe9abbe57	trial	trial	2026-08-07 13:56:13.56+00	2026-08-21 13:56:13.56+00	2026-08-28 13:56:13.56+00	2026-08-07 13:56:13.561+00
78380c32-5742-43d0-be3c-1ded11dc4ce2	7cb82de5-0177-4be1-999c-fd7ef40af41b	trial	trial	2026-08-07 13:56:14.078+00	2026-08-21 13:56:14.078+00	2026-08-28 13:56:14.078+00	2026-08-07 13:56:14.078+00
d58bb690-678a-4505-8d58-d37ec3c6f730	b578c0dd-6919-4d23-b7f2-efa770c47aca	trial	trial	2026-08-07 13:56:14.587+00	2026-08-21 13:56:14.587+00	2026-08-28 13:56:14.587+00	2026-08-07 13:56:14.588+00
f3090b6c-4b49-4e6a-82ad-2aadc0cdeba5	4f7ed53f-8383-4517-bd6f-8e71b351ce89	trial	trial	2026-08-07 13:56:55.119+00	2026-08-21 13:56:55.119+00	2026-08-28 13:56:55.119+00	2026-08-07 13:56:55.12+00
e9aae495-9ce8-4255-a788-b9f49913fdc0	a8fbfe27-1784-4a99-bf74-6c560de51016	trial	trial	2026-08-07 13:56:55.428+00	2026-08-21 13:56:55.428+00	2026-08-28 13:56:55.428+00	2026-08-07 13:56:55.429+00
a72b1054-cdb1-4cc9-b4a7-7da4a2950279	d1c9c1e8-22db-4add-814e-be04ecc51faf	trial	trial	2026-08-07 13:56:56.116+00	2026-08-21 13:56:56.116+00	2026-08-28 13:56:56.116+00	2026-08-07 13:56:56.117+00
c73eeb75-90c3-42aa-9b33-34e223e7eb91	c66e014b-5299-4f9f-bc65-195fbad0cd99	trial	trial	2026-08-07 13:56:56.261+00	2026-08-21 13:56:56.261+00	2026-08-28 13:56:56.261+00	2026-08-07 13:56:56.262+00
019187b7-2d84-4ae7-b615-aad6db0278bc	ce2ffe75-4e1d-4e06-9f8d-8ea2ab35b605	active	monthly	2026-08-07 13:56:57.312+00	2026-09-20 13:56:57.312+00	2026-09-27 13:56:57.312+00	2026-08-07 13:56:57.313+00
c785beb3-3bdb-4c22-b999-4e0ef5f732b7	33b55265-4e46-4dfc-8e22-22fd32ccd0f2	trial	trial	2026-08-07 13:56:57.658+00	2026-08-21 13:56:57.658+00	2026-08-28 13:56:57.658+00	2026-08-07 13:56:57.659+00
8de3bd4c-3f02-4bc7-8ed3-7556e87a9311	f4131cfd-52ad-46ee-9c9b-c6d358ed5f10	trial	trial	2026-08-07 13:56:57.858+00	2026-08-21 13:56:57.858+00	2026-08-28 13:56:57.858+00	2026-08-07 13:56:57.859+00
b5d1107a-32d2-48df-a262-4c06c46c2e74	385375ee-d31c-4ee6-a768-e54d8fd4f59f	trial	trial	2026-08-07 13:58:31.9+00	2026-08-21 13:58:31.9+00	2026-08-28 13:58:31.9+00	2026-08-07 13:58:31.901+00
aa96c9f4-ea12-4da0-8b3b-a02e0d6d7e7e	7449789e-cf83-4783-a40b-462ca8396e0c	trial	trial	2026-08-07 13:58:32.194+00	2026-08-21 13:58:32.194+00	2026-08-28 13:58:32.194+00	2026-08-07 13:58:32.195+00
36efa8bf-8580-4b75-abc8-bc303a6fa5b8	3e99cb18-41bd-457b-9326-d2889b35cec5	trial	trial	2026-08-07 13:58:32.808+00	2026-08-21 13:58:32.808+00	2026-08-28 13:58:32.808+00	2026-08-07 13:58:32.809+00
03cbe4fb-9083-4454-bf27-7a68dbca6f4a	ca682117-4612-4948-ae95-9706f3d56404	trial	trial	2026-08-07 13:58:32.915+00	2026-08-21 13:58:32.915+00	2026-08-28 13:58:32.915+00	2026-08-07 13:58:32.915+00
7bae4013-d183-47a1-8b12-027989b3852c	6546637e-4a35-4c02-a418-8ddf714c6b96	active	monthly	2026-08-07 13:58:33.916+00	2026-09-20 13:58:33.916+00	2026-09-27 13:58:33.916+00	2026-08-07 13:58:33.917+00
e4ba62a1-753c-4c20-8ac2-ca2fd7abee36	9ce67759-ee69-4264-a07f-891b3f9805e2	trial	trial	2026-08-07 13:58:34.264+00	2026-08-21 13:58:34.264+00	2026-08-28 13:58:34.264+00	2026-08-07 13:58:34.264+00
ce481e48-77d6-48c3-a87d-1060c3fa2f32	f57024e7-1bbb-4d66-b3e8-3e7007f205c9	trial	trial	2026-08-07 13:58:34.51+00	2026-08-21 13:58:34.51+00	2026-08-28 13:58:34.51+00	2026-08-07 13:58:34.511+00
4e895efb-4050-426f-8554-749356661b77	a03997c7-c54e-4856-9c2c-f84a6a7c7092	trial	trial	2026-08-07 13:59:01.241+00	2026-08-21 13:59:01.241+00	2026-08-28 13:59:01.241+00	2026-08-07 13:59:01.241+00
ddeb3663-2534-4fb2-9735-c5548560e412	e3fa9cc9-4249-426a-8a5e-bdfea48ab30e	trial	trial	2026-08-07 13:59:01.428+00	2026-08-21 13:59:01.428+00	2026-08-28 13:59:01.428+00	2026-08-07 13:59:01.429+00
c2608a8d-b4a6-4314-8dc8-a91b6a209e8c	6734a6d0-2423-4322-8476-bae0d501ab64	trial	trial	2026-08-07 13:59:02.059+00	2026-08-21 13:59:02.059+00	2026-08-28 13:59:02.059+00	2026-08-07 13:59:02.06+00
7b0abe68-0833-4d92-9003-6a0f1f2acfa7	2874dacc-057b-490d-96e1-51b76f6b2910	trial	trial	2026-08-07 13:59:02.58+00	2026-08-21 13:59:02.58+00	2026-08-28 13:59:02.58+00	2026-08-07 13:59:02.58+00
6e2a2285-2fc4-415e-9c33-16635be7b9c2	843b43c9-fbb2-496e-9604-69698c152179	trial	trial	2026-08-07 14:00:05.703+00	2026-08-21 14:00:05.703+00	2026-08-28 14:00:05.703+00	2026-08-07 14:00:05.704+00
c62442f4-e406-4b25-9e9d-73620281f55d	46b5e7c3-4228-4d05-9724-b4d688e772a3	trial	trial	2026-08-07 14:00:06.009+00	2026-08-21 14:00:06.009+00	2026-08-28 14:00:06.009+00	2026-08-07 14:00:06.01+00
70ecef5d-3b43-4716-abde-d2eee9fd261b	8f50a98a-5249-46bd-83ad-bcc5493292d1	trial	trial	2026-08-07 14:00:06.607+00	2026-08-21 14:00:06.607+00	2026-08-28 14:00:06.607+00	2026-08-07 14:00:06.608+00
eb958b15-e122-4996-b889-194319ec392c	2f2e99c0-7a75-40eb-aeb1-720ca7e52cff	trial	trial	2026-08-07 14:00:06.717+00	2026-08-21 14:00:06.717+00	2026-08-28 14:00:06.717+00	2026-08-07 14:00:06.718+00
dfe29d4a-d47a-452a-868d-f0d4fb18fd45	0acac768-245e-4600-b24d-10357b6a9206	active	monthly	2026-08-07 14:00:07.463+00	2026-09-20 14:00:07.463+00	2026-09-27 14:00:07.463+00	2026-08-07 14:00:07.463+00
2a9bd9bc-65c2-4bad-b9f1-eb82144e4958	daaee930-a32d-41c2-8e2d-d59946feb22b	trial	trial	2026-08-07 14:00:07.767+00	2026-08-21 14:00:07.767+00	2026-08-28 14:00:07.767+00	2026-08-07 14:00:07.767+00
cf497ee9-6365-4752-a1a8-3e8c41f434e7	9fb475fe-8cac-4fd3-8f89-b522a84d2edf	trial	trial	2026-08-07 14:00:07.988+00	2026-08-21 14:00:07.988+00	2026-08-28 14:00:07.988+00	2026-08-07 14:00:07.989+00
97d3b468-b609-4903-96f9-5e24ac24ffbe	f5152ef5-f532-47f7-9ac9-ddc21a287cba	trial	trial	2026-08-07 14:00:53.398+00	2026-08-21 14:00:53.398+00	2026-08-28 14:00:53.398+00	2026-08-07 14:00:53.399+00
e5189bd6-1d3c-4ad9-b929-16ccda368f55	114d6cf5-f9d5-4cb5-ab7a-89b2facecadf	trial	trial	2026-08-07 14:00:53.78+00	2026-08-21 14:00:53.78+00	2026-08-28 14:00:53.78+00	2026-08-07 14:00:53.781+00
ddebd1bc-64fd-4e7c-a964-77efe2c454c4	75615eb1-bd39-4831-897f-4b6a23901cb7	trial	trial	2026-08-07 14:00:54.533+00	2026-08-21 14:00:54.533+00	2026-08-28 14:00:54.533+00	2026-08-07 14:00:54.534+00
8a1d6120-832d-42c1-ad8a-fd6409572897	41945155-8295-4ffe-9fca-a051aec9d85c	trial	trial	2026-08-07 14:00:54.65+00	2026-08-21 14:00:54.65+00	2026-08-28 14:00:54.65+00	2026-08-07 14:00:54.651+00
671bbb1b-8817-4259-bdb3-23955d1bf651	7ecbf7b9-4944-4750-858d-c838c1fb60db	active	monthly	2026-08-07 14:00:55.519+00	2026-09-20 14:00:55.519+00	2026-09-27 14:00:55.519+00	2026-08-07 14:00:55.52+00
51647eef-f64a-403a-8cb2-f4459bc93540	d5fb54d8-3c89-493d-8edd-48fb3f04ef42	trial	trial	2026-08-07 14:00:55.887+00	2026-08-21 14:00:55.887+00	2026-08-28 14:00:55.887+00	2026-08-07 14:00:55.888+00
da3d818f-7c93-4ff2-b5f3-d53174e0a394	b32a6626-2517-4496-b611-8221818a64cd	trial	trial	2026-08-07 14:00:56.122+00	2026-08-21 14:00:56.122+00	2026-08-28 14:00:56.122+00	2026-08-07 14:00:56.123+00
f7583b1a-2803-466b-8b00-e0e1fc6f9cbd	8acc033d-9bdc-4a9b-a0f2-a7c8f7a8e80d	trial	trial	2026-08-07 14:01:05.113+00	2026-08-21 14:01:05.113+00	2026-08-28 14:01:05.113+00	2026-08-07 14:01:05.113+00
9f29e3ec-7800-481b-a434-035237abd299	e7b2abf5-4d80-4d5f-a96e-c42395401a4c	trial	trial	2026-08-07 14:01:08.264+00	2026-08-21 14:01:08.264+00	2026-08-28 14:01:08.264+00	2026-08-07 14:01:08.265+00
6404c149-bc99-4580-be9c-90276fec4f05	e66c3ae5-4fe0-48ef-a5f8-e2226df0ed55	trial	trial	2026-08-07 14:01:12.595+00	2026-08-21 14:01:12.595+00	2026-08-28 14:01:12.595+00	2026-08-07 14:01:12.596+00
2806f81c-284e-44ec-88e6-e250aabecf97	0fbab0e1-6447-4455-bde7-412a6154819d	trial	trial	2026-08-07 14:01:18.135+00	2026-08-21 14:01:18.135+00	2026-08-28 14:01:18.135+00	2026-08-07 14:01:18.135+00
256b8f3d-c43d-4a70-86fc-0d459524b005	1301ed82-4e76-447e-b9b2-203e4ab5e6b7	trial	trial	2026-08-07 14:01:53.615+00	2026-08-21 14:01:53.615+00	2026-08-28 14:01:53.615+00	2026-08-07 14:01:53.616+00
a7cac586-b6be-4a0f-8f1f-d2c0a579b58f	11776d89-31cf-4504-9bb8-c4473fac42d1	trial	trial	2026-08-07 14:01:53.92+00	2026-08-21 14:01:53.92+00	2026-08-28 14:01:53.92+00	2026-08-07 14:01:53.921+00
0584ec46-326a-485b-8477-f6a91eca9806	4dedcfd1-9cee-4826-9fb1-0cfbfa5886ef	trial	trial	2026-08-07 14:01:54.586+00	2026-08-21 14:01:54.586+00	2026-08-28 14:01:54.586+00	2026-08-07 14:01:54.586+00
182ef714-c7f1-4a19-acf4-e024e45ca689	ecfd9427-201f-45b4-b995-0c5903186dcf	trial	trial	2026-08-07 14:01:54.692+00	2026-08-21 14:01:54.692+00	2026-08-28 14:01:54.692+00	2026-08-07 14:01:54.693+00
52f9bc90-1971-4666-a674-33b087e85e17	bf46a9e5-b9ad-4b7a-857c-c42a838c5105	active	monthly	2026-08-07 14:01:55.45+00	2026-09-20 14:01:55.45+00	2026-09-27 14:01:55.45+00	2026-08-07 14:01:55.451+00
9b9e1602-9432-4b78-b9c0-1abed14072b0	a8f9e2e8-b848-487b-a2c4-8b7a01f955a3	trial	trial	2026-08-07 14:01:55.772+00	2026-08-21 14:01:55.772+00	2026-08-28 14:01:55.772+00	2026-08-07 14:01:55.773+00
d1ec8504-9171-48df-ae33-452f2d453157	41fe0795-178c-4762-828d-2bf86d3b7d2b	trial	trial	2026-08-07 14:01:56.003+00	2026-08-21 14:01:56.003+00	2026-08-28 14:01:56.003+00	2026-08-07 14:01:56.004+00
d247fb91-0571-486f-91e3-3118b5436fb4	dc36c3db-891c-47ad-a4c1-ecf6f3c4671e	trial	trial	2026-08-07 14:02:03.705+00	2026-08-21 14:02:03.705+00	2026-08-28 14:02:03.705+00	2026-08-07 14:02:03.706+00
805a3ab1-e923-4677-b3c0-7d1777b408b6	3d0794ce-aed8-4b71-b1df-80de2ee1f392	trial	trial	2026-08-07 14:02:06.582+00	2026-08-21 14:02:06.582+00	2026-08-28 14:02:06.582+00	2026-08-07 14:02:06.582+00
2740d3d3-55d8-4c09-bab2-c316c9bff723	e71737ea-c9ab-401c-bd67-8525aa0060fd	trial	trial	2026-08-07 14:02:09.785+00	2026-08-21 14:02:09.785+00	2026-08-28 14:02:09.785+00	2026-08-07 14:02:09.786+00
6b60c417-5d0b-4bba-ae8f-341bc18d1dd8	6e338bf0-ec57-44fe-8b1f-7af52ad1d31e	trial	trial	2026-08-07 14:02:14.858+00	2026-08-21 14:02:14.858+00	2026-08-28 14:02:14.858+00	2026-08-07 14:02:14.859+00
\.


--
-- Data for Name: subscription_payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_payment (id, subscription_id, plan_kind, amount_rial, status, gateway, authority, ref_id, created_at) FROM stdin;
e67b7b46-ba7d-4a41-a50a-53e388d02e61	54e27d9c-36f9-4e50-826f-c789e56ab142	monthly	2000000	paid	unknown	mock-1785006038291-fns035	mock-ref-1785006038305	2026-07-25 19:00:38.287+00
57250ef7-c29b-4766-8747-f771be95b875	67cd119d-8155-4641-a64c-ef4173c2d6e9	monthly	2000000	paid	unknown	mock-1785449541460-m0sdz2	mock-ref-1785449541477	2026-07-30 22:12:21.456+00
da5a524b-5ec9-4581-8489-a5cf9e3d6e76	2d579897-7251-44ef-9189-eba4a7648f1a	monthly	2000000	paid	unknown	mock-1785850554821-euza13	mock-ref-1785850554848	2026-08-04 13:35:54.815+00
260696c1-c173-4777-b675-036041923142	7adbdb9e-792e-4775-8124-c25b4398325b	monthly	2000000	paid	unknown	mock-1785851398232-wm8jnp	mock-ref-1785851398253	2026-08-04 13:49:58.229+00
e466af7f-0dfd-483b-84a8-486492134e4c	056c2861-0472-4e84-80b3-2828ccb94cf0	monthly	2000000	paid	unknown	mock-1786073120141-o19dxh	mock-ref-1786073120168	2026-08-07 03:25:20.133+00
57b429f8-d30c-4d9d-9021-197fe7eaef65	1431164d-2462-49b2-a9ab-f7a7f986d71e	monthly	2000000	paid	unknown	mock-1786105420018-gjrqhh	mock-ref-1786105420033	2026-08-07 12:23:40.014+00
c4563fc7-0c3c-42a3-a366-658100c3e09e	2e3de7c2-7ed3-40e6-814a-0d42606a4c19	monthly	2000000	paid	unknown	mock-1786105559512-bcg02g	mock-ref-1786105559522	2026-08-07 12:25:59.508+00
0014c473-5052-4596-ad8e-fd00850e17c4	889bd40e-9afa-4da8-86cc-3018f6b73c63	monthly	2000000	paid	unknown	mock-1786105574834-yw4mzl	mock-ref-1786105574844	2026-08-07 12:26:14.826+00
907d4649-dcc7-4ed7-af4c-51b8c0481f97	17462081-26dc-447c-aefd-f08aca36b3b0	monthly	2000000	paid	unknown	mock-1786106964073-tkzbs6	mock-ref-1786106964083	2026-08-07 12:49:24.069+00
f6000000-0000-4000-8000-000000000001	1ef1b125-401f-4c1b-a935-33730e098f95	annual	120000000	paid	zarinpal	MOCK-SUB-AUTH-001	MOCK-SUB-REF-001	2026-07-28 13:12:49.454468+00
f6000000-0000-4000-8000-000000000002	1ef1b125-401f-4c1b-a935-33730e098f95	monthly	15000000	pending	idpay	MOCK-SUB-AUTH-002	\N	2026-08-07 11:12:49.454468+00
195b4a96-b4bc-4cf6-8774-b7b8a5b5d826	019187b7-2d84-4ae7-b615-aad6db0278bc	monthly	2000000	paid	unknown	mock-1786111017530-28m6ta	mock-ref-1786111017542	2026-08-07 13:56:57.527+00
8c0bb663-123b-4b54-aa6d-653f88278dee	7bae4013-d183-47a1-8b12-027989b3852c	monthly	2000000	paid	unknown	mock-1786111114134-3vr54d	mock-ref-1786111114146	2026-08-07 13:58:34.13+00
3f7311ae-65c9-433a-ade1-50d09d5e8500	dfe29d4a-d47a-452a-868d-f0d4fb18fd45	monthly	2000000	paid	unknown	mock-1786111207652-ctfsih	mock-ref-1786111207662	2026-08-07 14:00:07.648+00
080f41e0-4956-46d3-9e45-f87a418991ad	671bbb1b-8817-4259-bdb3-23955d1bf651	monthly	2000000	paid	unknown	mock-1786111255755-bf9gyi	mock-ref-1786111255765	2026-08-07 14:00:55.75+00
36c3320b-d7d7-4b6d-a68c-624cc1742d7d	52f9bc90-1971-4666-a674-33b087e85e17	monthly	2000000	paid	unknown	mock-1786111315644-r1kx29	mock-ref-1786111315656	2026-08-07 14:01:55.641+00
\.


--
-- Data for Name: waitlist_entry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.waitlist_entry (id, salon_id, customer_id, service_id, window_start, window_end, status, created_at) FROM stdin;
\.


--
-- Data for Name: working_hours; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.working_hours (id, owner_kind, owner_id, weekday, start_time, end_time) FROM stdin;
6d118bc0-7fa8-47b9-869b-bf69c1918157	staff	19b36edf-3c88-42a4-9437-4a8e24e64882	0	09:00:00	20:00:00
24951439-98df-4cfd-bbcd-2047c1ba5504	staff	19b36edf-3c88-42a4-9437-4a8e24e64882	1	09:00:00	20:00:00
cb815649-c463-4509-a567-4e3b2ea8a967	staff	19b36edf-3c88-42a4-9437-4a8e24e64882	2	09:00:00	20:00:00
238ef2e1-963e-48a7-8a1c-4d24b33c278d	staff	19b36edf-3c88-42a4-9437-4a8e24e64882	3	09:00:00	20:00:00
4562f53a-a716-4a0b-bae2-0b50e0e023a6	staff	19b36edf-3c88-42a4-9437-4a8e24e64882	4	09:00:00	20:00:00
f17e7c32-9404-47db-8263-2c66d4eb2d66	staff	19b36edf-3c88-42a4-9437-4a8e24e64882	5	09:00:00	20:00:00
77888392-d620-463c-9391-c6f0a2ed22d2	staff	19b36edf-3c88-42a4-9437-4a8e24e64882	6	09:00:00	20:00:00
8f3b710e-fae1-4475-ad4f-18ff245c2803	chair	1e636710-d093-45be-869a-2d331d3d3c49	0	09:00:00	20:00:00
a66d58ac-408e-409a-996f-770c45ff91cd	chair	1e636710-d093-45be-869a-2d331d3d3c49	1	09:00:00	20:00:00
6dd4c7d1-fc2d-452f-9b93-816a97ca780d	chair	1e636710-d093-45be-869a-2d331d3d3c49	2	09:00:00	20:00:00
10424940-1fe9-4c7a-9306-054668ceb1d9	chair	1e636710-d093-45be-869a-2d331d3d3c49	3	09:00:00	20:00:00
fa0982dc-b70c-478c-9443-ef39c579da66	chair	1e636710-d093-45be-869a-2d331d3d3c49	4	09:00:00	20:00:00
09d81170-943a-4d13-b45a-9cef2c712821	chair	1e636710-d093-45be-869a-2d331d3d3c49	5	09:00:00	20:00:00
fd0e9bbf-bc7b-40e5-9a44-c316b9aa9cb3	chair	1e636710-d093-45be-869a-2d331d3d3c49	6	09:00:00	20:00:00
49928619-5cb4-4beb-a020-78aa6a4d4798	chair	59dd296e-9d8c-4dee-bfe3-759bf6184875	0	09:00:00	20:00:00
8a923f4e-7dc8-4a09-a5fc-f57e20140eef	chair	59dd296e-9d8c-4dee-bfe3-759bf6184875	1	09:00:00	20:00:00
4e85b186-6952-43f6-9a7b-7c8cf6581c03	chair	59dd296e-9d8c-4dee-bfe3-759bf6184875	2	09:00:00	20:00:00
78527674-1aa0-419f-9d28-ca8e7e9882a6	chair	59dd296e-9d8c-4dee-bfe3-759bf6184875	3	09:00:00	20:00:00
c656242c-e9a5-49d1-9b17-d8d537762d98	chair	59dd296e-9d8c-4dee-bfe3-759bf6184875	4	09:00:00	20:00:00
3a06a54f-64e7-4d30-a4c2-e24ee631759c	chair	59dd296e-9d8c-4dee-bfe3-759bf6184875	5	09:00:00	20:00:00
1f896900-0b6f-40c9-b856-a8eeca2b8cc8	chair	59dd296e-9d8c-4dee-bfe3-759bf6184875	6	09:00:00	20:00:00
f464b813-4cde-41d4-b1e9-58220a8d6320	chair	36ec0484-0b59-4659-8ef4-85a52c6e39f4	0	09:00:00	20:00:00
612bef3b-ffac-4eb5-bc85-173277ba4ac2	chair	36ec0484-0b59-4659-8ef4-85a52c6e39f4	1	09:00:00	20:00:00
aa7010f1-90e4-4145-9452-3c331637c515	chair	36ec0484-0b59-4659-8ef4-85a52c6e39f4	2	09:00:00	20:00:00
84e6fa80-d4af-44bc-9754-d5a5fb437415	chair	36ec0484-0b59-4659-8ef4-85a52c6e39f4	3	09:00:00	20:00:00
d9e33166-a9b8-4b5d-8cdf-d82eba2201f9	chair	36ec0484-0b59-4659-8ef4-85a52c6e39f4	4	09:00:00	20:00:00
43477906-39ee-449a-940e-52b41f9b59c1	chair	36ec0484-0b59-4659-8ef4-85a52c6e39f4	5	09:00:00	20:00:00
9eb08c7c-ba6d-4976-884f-082358f3a6d4	chair	36ec0484-0b59-4659-8ef4-85a52c6e39f4	6	09:00:00	20:00:00
17d55ad2-6747-45a6-8d39-94d76cee7992	chair	03492156-dfdc-4442-b706-f994911e1c09	0	09:00:00	20:00:00
5c0163af-dfe4-4c94-90d6-6fdd2a4d49ea	chair	03492156-dfdc-4442-b706-f994911e1c09	1	09:00:00	20:00:00
f97ab8f6-414c-4a43-a02e-320e34499410	chair	03492156-dfdc-4442-b706-f994911e1c09	2	09:00:00	20:00:00
c5c53c34-64ce-4770-8d17-7846f99ba0dd	chair	03492156-dfdc-4442-b706-f994911e1c09	3	09:00:00	20:00:00
0d095cc0-51c3-4c24-be03-6dae7afdfbfa	chair	03492156-dfdc-4442-b706-f994911e1c09	4	09:00:00	20:00:00
16f20d0a-c420-4147-92a6-2a5303913c64	chair	03492156-dfdc-4442-b706-f994911e1c09	5	09:00:00	20:00:00
7828633a-dc71-409c-8c85-cbcbe89f5697	chair	03492156-dfdc-4442-b706-f994911e1c09	6	09:00:00	20:00:00
1bc7c709-b2d4-4ae7-ac34-76f9577bdf9b	staff	27adc8b0-9d2e-40e9-a663-a6a7ac79adfa	0	09:00:00	20:00:00
8bd639f9-b85a-4cf7-9f8a-77e70acf9644	staff	27adc8b0-9d2e-40e9-a663-a6a7ac79adfa	1	09:00:00	20:00:00
b26ae574-4778-4e25-9058-416e905a1c3b	staff	27adc8b0-9d2e-40e9-a663-a6a7ac79adfa	2	09:00:00	20:00:00
a8177d33-b3ce-43a4-a569-530f50f379b9	staff	27adc8b0-9d2e-40e9-a663-a6a7ac79adfa	3	09:00:00	20:00:00
a3ab6e3d-7f06-4633-aa14-a8753f52e7c7	staff	27adc8b0-9d2e-40e9-a663-a6a7ac79adfa	4	09:00:00	20:00:00
a463eba2-cbf0-431b-adbd-c2ad97f1d65e	staff	27adc8b0-9d2e-40e9-a663-a6a7ac79adfa	5	09:00:00	20:00:00
36d53856-4253-47ce-9827-b47d7c42049f	staff	27adc8b0-9d2e-40e9-a663-a6a7ac79adfa	6	09:00:00	20:00:00
8e08fb3b-fbc9-4f9a-8a05-e0730eebddfd	chair	4836283a-3fef-4278-87a6-e0dd9f952489	0	09:00:00	20:00:00
6c833ee4-3d33-42ec-975b-5fb9a7d87b0a	chair	4836283a-3fef-4278-87a6-e0dd9f952489	1	09:00:00	20:00:00
09ab487a-b0e1-4ea4-a3e3-4384937197ae	chair	4836283a-3fef-4278-87a6-e0dd9f952489	2	09:00:00	20:00:00
269772a3-7acb-4f8b-a88d-3a0640aa35db	chair	4836283a-3fef-4278-87a6-e0dd9f952489	3	09:00:00	20:00:00
77cf3f97-113d-4c36-a45c-be491b5be6f2	chair	4836283a-3fef-4278-87a6-e0dd9f952489	4	09:00:00	20:00:00
46ef88ca-7e35-44f8-8da0-94769b90092e	chair	4836283a-3fef-4278-87a6-e0dd9f952489	5	09:00:00	20:00:00
a4d3f85b-22eb-45fa-8ce9-787c90a4222e	chair	4836283a-3fef-4278-87a6-e0dd9f952489	6	09:00:00	20:00:00
2067e4a0-d669-4546-954c-71de73cbf054	staff	5b40d210-a7be-4945-829c-8fccbd87947a	0	09:00:00	20:00:00
ccf9b6fe-4e2b-408f-a018-c7b6240215cb	staff	5b40d210-a7be-4945-829c-8fccbd87947a	1	09:00:00	20:00:00
f52d2215-cc8e-4265-946e-7bba3005c1e0	staff	5b40d210-a7be-4945-829c-8fccbd87947a	2	09:00:00	20:00:00
dd104c7c-a322-4a7d-9910-e4f8eeb6b41e	staff	5b40d210-a7be-4945-829c-8fccbd87947a	3	09:00:00	20:00:00
d1f27fed-dc21-4939-818f-6414b93d7de4	staff	5b40d210-a7be-4945-829c-8fccbd87947a	4	09:00:00	20:00:00
f500f49b-67a2-436d-8f11-866a2a380fe2	staff	5b40d210-a7be-4945-829c-8fccbd87947a	5	09:00:00	20:00:00
3363e11b-6ded-4a62-bd16-8a6a6875a496	staff	5b40d210-a7be-4945-829c-8fccbd87947a	6	09:00:00	20:00:00
e2c8d368-44ae-4ec7-93d1-11d840d35868	staff	9370c29a-97b1-4b1d-918a-e54906c7cc52	0	09:00:00	20:00:00
1c95becd-92e6-449a-af61-ad0588ee14d8	staff	9370c29a-97b1-4b1d-918a-e54906c7cc52	1	09:00:00	20:00:00
2d0f5f09-2309-4c23-a07a-2d05b7b1df61	staff	9370c29a-97b1-4b1d-918a-e54906c7cc52	2	09:00:00	20:00:00
51545792-0ae3-4dc1-af3c-d135aa9e005e	staff	9370c29a-97b1-4b1d-918a-e54906c7cc52	3	09:00:00	20:00:00
dc86382e-b6f3-4f97-bee5-3d9cc0fafcff	staff	9370c29a-97b1-4b1d-918a-e54906c7cc52	4	09:00:00	20:00:00
9fb43e3b-a46b-4e7f-9b14-3bcded59b7f7	staff	9370c29a-97b1-4b1d-918a-e54906c7cc52	5	09:00:00	20:00:00
2f0602f3-78cc-4ad6-b5d9-b343ef062b92	staff	9370c29a-97b1-4b1d-918a-e54906c7cc52	6	09:00:00	20:00:00
2813bf95-756d-4536-b656-298dcca7da96	chair	d5e35d0a-f860-4607-92e7-8d2f9a2787b8	0	09:00:00	20:00:00
4f5e2df0-a349-4add-8206-4ac4b03a2e3b	chair	d5e35d0a-f860-4607-92e7-8d2f9a2787b8	1	09:00:00	20:00:00
9ec57f94-1c2e-4cfa-8eda-c2addf483d2a	chair	d5e35d0a-f860-4607-92e7-8d2f9a2787b8	2	09:00:00	20:00:00
f06894e7-678d-4775-b30c-fea0f8935f0c	chair	d5e35d0a-f860-4607-92e7-8d2f9a2787b8	3	09:00:00	20:00:00
c0cb5915-9f18-4981-953f-970a1da6fc59	chair	d5e35d0a-f860-4607-92e7-8d2f9a2787b8	4	09:00:00	20:00:00
0693d2f4-c8f2-4c99-8f4d-e60c51b5876e	chair	d5e35d0a-f860-4607-92e7-8d2f9a2787b8	5	09:00:00	20:00:00
1969518e-475b-4255-a935-51ebf5809afc	chair	d5e35d0a-f860-4607-92e7-8d2f9a2787b8	6	09:00:00	20:00:00
719c6ba1-146c-4a9a-ae98-31c4607c4860	staff	3b0e01c0-8ee7-41d2-8057-f49cb1029722	0	09:00:00	20:00:00
30ad5ca4-fef3-4ef5-8ca2-6d40314c6314	staff	3b0e01c0-8ee7-41d2-8057-f49cb1029722	1	09:00:00	20:00:00
9405c224-3afd-41b5-913b-bd611db1e81d	staff	3b0e01c0-8ee7-41d2-8057-f49cb1029722	2	09:00:00	20:00:00
91f2f5b9-322a-4feb-be7f-e1d05bdb4820	staff	3b0e01c0-8ee7-41d2-8057-f49cb1029722	3	09:00:00	20:00:00
d2d2eaff-e2a4-442b-8d36-da978b197de9	staff	3b0e01c0-8ee7-41d2-8057-f49cb1029722	4	09:00:00	20:00:00
d8462289-7528-4bd6-b2c3-f6023c3d942a	staff	3b0e01c0-8ee7-41d2-8057-f49cb1029722	5	09:00:00	20:00:00
ebe5e2b3-56be-42b6-a1ae-36c44f2f8a42	staff	3b0e01c0-8ee7-41d2-8057-f49cb1029722	6	09:00:00	20:00:00
05a01217-caa5-47f8-aa88-659fc703e217	chair	09430ba9-e7f6-42b1-a7f1-749fa07df2a2	0	09:00:00	20:00:00
d93c5225-6940-4074-9fb7-dfce03ad703d	chair	09430ba9-e7f6-42b1-a7f1-749fa07df2a2	1	09:00:00	20:00:00
b733c2a2-afb1-4eea-b883-9424eec1831e	chair	09430ba9-e7f6-42b1-a7f1-749fa07df2a2	2	09:00:00	20:00:00
b06b7490-139a-4f8b-a11b-15db2121f440	chair	09430ba9-e7f6-42b1-a7f1-749fa07df2a2	3	09:00:00	20:00:00
7c2c4407-c7a5-4f32-8057-12fcf8c14e0d	chair	09430ba9-e7f6-42b1-a7f1-749fa07df2a2	4	09:00:00	20:00:00
1d127f0f-72cb-4b8f-8275-e7996cad5d0a	chair	09430ba9-e7f6-42b1-a7f1-749fa07df2a2	5	09:00:00	20:00:00
489d3cc6-dbb6-4ba9-860d-708e64849ace	chair	09430ba9-e7f6-42b1-a7f1-749fa07df2a2	6	09:00:00	20:00:00
8a543eb0-0172-4ee8-b406-a9205c28a563	staff	f73fc09c-a972-4f71-9811-f0d55d146a1d	0	09:00:00	20:00:00
a3721cd5-2804-48b3-9496-173f5e13d9b8	staff	f73fc09c-a972-4f71-9811-f0d55d146a1d	1	09:00:00	20:00:00
a7a9dcfc-0f98-43e8-b081-60e007176914	staff	f73fc09c-a972-4f71-9811-f0d55d146a1d	2	09:00:00	20:00:00
af845139-fd2a-4fe9-8773-a3eda6fd1e12	staff	f73fc09c-a972-4f71-9811-f0d55d146a1d	3	09:00:00	20:00:00
3ccc3bf1-1066-4cf5-bde3-eae4c1c7ba3e	staff	f73fc09c-a972-4f71-9811-f0d55d146a1d	4	09:00:00	20:00:00
312f98f3-fb69-4770-a628-e607f9841200	staff	f73fc09c-a972-4f71-9811-f0d55d146a1d	5	09:00:00	20:00:00
2bf1905d-2de8-412e-b2e0-aa0c67c03d3b	staff	f73fc09c-a972-4f71-9811-f0d55d146a1d	6	09:00:00	20:00:00
3adf85b9-668c-40f5-b545-e37064eb32b0	chair	24579732-0b21-4e16-8343-182a6b61a96d	0	09:00:00	20:00:00
ac097bdd-a4b3-498f-82d2-5d6e1d58ce9b	chair	24579732-0b21-4e16-8343-182a6b61a96d	1	09:00:00	20:00:00
25410c6d-35aa-42b6-a8df-fe67452ece61	chair	24579732-0b21-4e16-8343-182a6b61a96d	2	09:00:00	20:00:00
c43e0d9c-fcdd-4923-94d3-1efe05c58724	chair	24579732-0b21-4e16-8343-182a6b61a96d	3	09:00:00	20:00:00
ab2b91b2-e7d4-4f80-944a-f2994212eb34	chair	24579732-0b21-4e16-8343-182a6b61a96d	4	09:00:00	20:00:00
398ab97e-fcc6-47cd-bffd-1355e55dead3	chair	24579732-0b21-4e16-8343-182a6b61a96d	5	09:00:00	20:00:00
034cccb8-ae93-4a89-86cb-50fc0f0516d5	chair	24579732-0b21-4e16-8343-182a6b61a96d	6	09:00:00	20:00:00
8289e1e9-f1d9-4bdb-9a1a-99e48ab55beb	staff	82fb208d-5c1d-4937-97b5-b367e3f87f46	0	09:00:00	20:00:00
50433924-5f22-4356-aa54-73b7f956be41	staff	82fb208d-5c1d-4937-97b5-b367e3f87f46	1	09:00:00	20:00:00
1cdb601f-89b8-4de1-872a-d81048828274	staff	82fb208d-5c1d-4937-97b5-b367e3f87f46	2	09:00:00	20:00:00
25ae63c3-fac6-49de-8ecc-0c377a9ba589	staff	82fb208d-5c1d-4937-97b5-b367e3f87f46	3	09:00:00	20:00:00
aeb74943-daf0-4fbf-a2e6-e9e5a58c9120	staff	82fb208d-5c1d-4937-97b5-b367e3f87f46	4	09:00:00	20:00:00
c3e1db3c-615e-4fc2-a50c-0dbe8e739b8f	staff	82fb208d-5c1d-4937-97b5-b367e3f87f46	5	09:00:00	20:00:00
24a90934-0c1e-44e6-80e9-0199b9ecb474	staff	82fb208d-5c1d-4937-97b5-b367e3f87f46	6	09:00:00	20:00:00
d3f5cc1e-4d26-4314-a49f-5314c55485f9	staff	618bbbbb-d814-4b0e-a5ad-83dfab804e2a	0	09:00:00	20:00:00
2feaf224-ff8b-4640-899f-e81d371d725f	staff	618bbbbb-d814-4b0e-a5ad-83dfab804e2a	1	09:00:00	20:00:00
85845d8a-5711-479a-896e-6e64a7eecb35	staff	618bbbbb-d814-4b0e-a5ad-83dfab804e2a	2	09:00:00	20:00:00
0d52f33c-1b2f-4229-ad18-10df3f3ab584	staff	618bbbbb-d814-4b0e-a5ad-83dfab804e2a	3	09:00:00	20:00:00
12e5ceb7-11f7-41a4-b04f-5ca879a7d0d5	staff	618bbbbb-d814-4b0e-a5ad-83dfab804e2a	4	09:00:00	20:00:00
1c289004-9e71-42e1-acbe-488ca15c2d10	staff	618bbbbb-d814-4b0e-a5ad-83dfab804e2a	5	09:00:00	20:00:00
75988a04-8ea8-4b49-adbc-1aabf7b9c275	staff	618bbbbb-d814-4b0e-a5ad-83dfab804e2a	6	09:00:00	20:00:00
c461cce0-6970-4c86-9158-5f0647fc23eb	chair	adf80c3a-8830-49ab-8010-f48f0cd913d6	0	09:00:00	20:00:00
3d39461d-9fee-43de-a6ef-239f480082a5	chair	adf80c3a-8830-49ab-8010-f48f0cd913d6	1	09:00:00	20:00:00
e8dda0d7-902a-41f8-9f87-5c71be9aac8b	chair	adf80c3a-8830-49ab-8010-f48f0cd913d6	2	09:00:00	20:00:00
c26cfb9b-6260-4b8b-9a95-a06ac20faca5	chair	adf80c3a-8830-49ab-8010-f48f0cd913d6	3	09:00:00	20:00:00
554323a8-9611-4f47-b5d7-df0f5a0141c7	chair	adf80c3a-8830-49ab-8010-f48f0cd913d6	4	09:00:00	20:00:00
66c46fcc-abb8-4084-badd-dab16b8d457c	chair	adf80c3a-8830-49ab-8010-f48f0cd913d6	5	09:00:00	20:00:00
6d4e2e61-6037-41f9-b360-98cc1b2c30cc	chair	adf80c3a-8830-49ab-8010-f48f0cd913d6	6	09:00:00	20:00:00
ae3b8dde-8780-4489-902b-368b26340062	chair	f5941d30-215a-40e9-8571-15bc9b9fe8f7	0	09:00:00	20:00:00
90c92037-c6bd-413e-af04-15a9c12eb786	chair	f5941d30-215a-40e9-8571-15bc9b9fe8f7	1	09:00:00	20:00:00
337ef8ff-f8e4-43a2-9a44-66f5af7f4fff	chair	f5941d30-215a-40e9-8571-15bc9b9fe8f7	2	09:00:00	20:00:00
1538be6a-bf4b-4dee-9d87-e7b574dfd3de	chair	f5941d30-215a-40e9-8571-15bc9b9fe8f7	3	09:00:00	20:00:00
6c93d70c-9861-4455-9890-389776c0f831	chair	f5941d30-215a-40e9-8571-15bc9b9fe8f7	4	09:00:00	20:00:00
4f8e725b-939d-4b79-acb9-2d45e8ad30a1	chair	f5941d30-215a-40e9-8571-15bc9b9fe8f7	5	09:00:00	20:00:00
94b5efa3-ba08-4315-98c5-774806766335	chair	f5941d30-215a-40e9-8571-15bc9b9fe8f7	6	09:00:00	20:00:00
d7d1845a-1aba-4730-b20c-1c0f53c5caff	chair	5db2dd43-962a-46eb-b4ae-0646785b565c	0	09:00:00	20:00:00
2d43909e-b993-41e8-a422-548304e33adb	chair	5db2dd43-962a-46eb-b4ae-0646785b565c	1	09:00:00	20:00:00
c3c042bb-d782-42b2-b3c2-89897f5f3004	chair	5db2dd43-962a-46eb-b4ae-0646785b565c	2	09:00:00	20:00:00
c654ba40-a392-44b8-8c0a-50f756edf59f	chair	5db2dd43-962a-46eb-b4ae-0646785b565c	3	09:00:00	20:00:00
73a711b5-7484-4598-a453-c4f54c170bc6	chair	5db2dd43-962a-46eb-b4ae-0646785b565c	4	09:00:00	20:00:00
76804012-64bb-4119-a5a7-45b16946e718	chair	5db2dd43-962a-46eb-b4ae-0646785b565c	5	09:00:00	20:00:00
331002dc-6b9b-4a79-92ae-e096e88a390d	chair	5db2dd43-962a-46eb-b4ae-0646785b565c	6	09:00:00	20:00:00
5fd3b77f-86c9-4ca4-8e8f-906366bd2626	chair	4acdc609-c025-4458-8aa2-2fd082f85e3d	0	09:00:00	20:00:00
d510b29b-8a59-49ae-a03f-820cf2267902	chair	4acdc609-c025-4458-8aa2-2fd082f85e3d	1	09:00:00	20:00:00
8cb1cead-e055-4b48-bac7-4eb67bcd6e8e	chair	4acdc609-c025-4458-8aa2-2fd082f85e3d	2	09:00:00	20:00:00
2aac8ac3-a70e-4dce-b63f-4ba01e81a34f	chair	4acdc609-c025-4458-8aa2-2fd082f85e3d	3	09:00:00	20:00:00
91339cb1-5920-4376-bf76-46eca03fc864	chair	4acdc609-c025-4458-8aa2-2fd082f85e3d	4	09:00:00	20:00:00
c9f71373-9f2d-4880-b07a-af5b994cd9b1	chair	4acdc609-c025-4458-8aa2-2fd082f85e3d	5	09:00:00	20:00:00
592ecf2c-7e04-46fa-a6ac-f565233d0c1b	chair	4acdc609-c025-4458-8aa2-2fd082f85e3d	6	09:00:00	20:00:00
4e60873d-ae92-4fe9-a36a-a024b36dd2be	chair	7341a8e0-64e5-442e-a15d-9b69f0a065c2	0	09:00:00	20:00:00
8cfb9a08-07a3-4454-bd68-7b621fc63882	chair	7341a8e0-64e5-442e-a15d-9b69f0a065c2	1	09:00:00	20:00:00
d7f2427d-8612-4fed-bd71-9725cda80453	chair	7341a8e0-64e5-442e-a15d-9b69f0a065c2	2	09:00:00	20:00:00
139186ef-1935-4242-9573-e694780213db	chair	7341a8e0-64e5-442e-a15d-9b69f0a065c2	3	09:00:00	20:00:00
b3a885ff-5d95-40b4-b069-0bbb06d55de3	chair	7341a8e0-64e5-442e-a15d-9b69f0a065c2	4	09:00:00	20:00:00
af598778-404d-4674-8022-c13faeceab68	chair	7341a8e0-64e5-442e-a15d-9b69f0a065c2	5	09:00:00	20:00:00
15736434-ee18-4f13-a4cc-b57a92474447	chair	7341a8e0-64e5-442e-a15d-9b69f0a065c2	6	09:00:00	20:00:00
f8980848-425a-4512-8751-021049a188e4	chair	44efbbd7-5146-495f-bdcc-5b8b9fb9ca8d	0	09:00:00	20:00:00
5990bdc1-3152-49de-8032-bc74aade0011	chair	44efbbd7-5146-495f-bdcc-5b8b9fb9ca8d	1	09:00:00	20:00:00
65707587-50e2-4e5d-9a88-9c74d992a73f	chair	44efbbd7-5146-495f-bdcc-5b8b9fb9ca8d	2	09:00:00	20:00:00
aec95757-88ce-4efa-a900-9e9555d6fbd3	chair	44efbbd7-5146-495f-bdcc-5b8b9fb9ca8d	3	09:00:00	20:00:00
d45807ec-fff7-4786-bb4e-fba063baaa30	chair	44efbbd7-5146-495f-bdcc-5b8b9fb9ca8d	4	09:00:00	20:00:00
9f5f4fad-86c8-40db-8675-7b9de55300b7	chair	44efbbd7-5146-495f-bdcc-5b8b9fb9ca8d	5	09:00:00	20:00:00
abad000c-eb8a-473b-a91f-11bb679b5a06	chair	44efbbd7-5146-495f-bdcc-5b8b9fb9ca8d	6	09:00:00	20:00:00
d66da1be-95bd-4f2e-88cf-37cdc999080d	chair	ea09a6e2-8fb7-4192-92f9-773631f5a193	0	09:00:00	20:00:00
06107df7-0a2f-48c3-9214-4415b4ee7641	chair	ea09a6e2-8fb7-4192-92f9-773631f5a193	1	09:00:00	20:00:00
5b8e9698-c953-4a48-9d4c-207adbb3cef5	chair	ea09a6e2-8fb7-4192-92f9-773631f5a193	2	09:00:00	20:00:00
294b5143-2f7e-477b-9cfe-1b23aba75209	chair	ea09a6e2-8fb7-4192-92f9-773631f5a193	3	09:00:00	20:00:00
71901502-1f59-480d-997f-6de7359ef108	chair	ea09a6e2-8fb7-4192-92f9-773631f5a193	4	09:00:00	20:00:00
3e936c04-c592-41f2-a776-d1fb39e4c1ab	chair	ea09a6e2-8fb7-4192-92f9-773631f5a193	5	09:00:00	20:00:00
2a81a0c2-a956-4e23-b010-8e55f4dd946f	chair	ea09a6e2-8fb7-4192-92f9-773631f5a193	6	09:00:00	20:00:00
85bf29da-b1a6-4c3f-a8f7-5fdcdbc82d1a	chair	ff38dd2e-5f2c-4d6d-9b97-51a885e7bb90	0	09:00:00	20:00:00
2b53078d-5fe5-4b2d-a8de-bacfcd0bd981	chair	ff38dd2e-5f2c-4d6d-9b97-51a885e7bb90	1	09:00:00	20:00:00
ba111b09-2f55-4bc5-bab2-576c75da21da	chair	ff38dd2e-5f2c-4d6d-9b97-51a885e7bb90	2	09:00:00	20:00:00
b70247ed-1e5e-4d9c-b047-564182d45813	chair	ff38dd2e-5f2c-4d6d-9b97-51a885e7bb90	3	09:00:00	20:00:00
79c0ad44-ea66-4ce7-a291-c6badd9d5ea0	chair	ff38dd2e-5f2c-4d6d-9b97-51a885e7bb90	4	09:00:00	20:00:00
811a46db-00f5-4db0-a875-fa2789fcf379	chair	ff38dd2e-5f2c-4d6d-9b97-51a885e7bb90	5	09:00:00	20:00:00
0a96bffc-5ac0-4e8e-af24-b091b6eb75e5	chair	ff38dd2e-5f2c-4d6d-9b97-51a885e7bb90	6	09:00:00	20:00:00
aee2babe-71ec-4edc-8aaf-fa2d044330ce	chair	df024c6d-58d3-46e8-9399-c323b0f0a8ca	0	09:00:00	20:00:00
c3fcef8e-9208-4798-9d56-4c755efa8c9a	chair	df024c6d-58d3-46e8-9399-c323b0f0a8ca	1	09:00:00	20:00:00
db66967f-6c08-44f6-95d5-4702eb074186	chair	df024c6d-58d3-46e8-9399-c323b0f0a8ca	2	09:00:00	20:00:00
4735f8df-a78e-4870-b22b-d414c315786e	chair	df024c6d-58d3-46e8-9399-c323b0f0a8ca	3	09:00:00	20:00:00
4a1124c2-5bed-4f0a-9f99-6f67522fe371	chair	df024c6d-58d3-46e8-9399-c323b0f0a8ca	4	09:00:00	20:00:00
377e7d6b-ea15-4623-8ebd-7f9a533993e2	chair	df024c6d-58d3-46e8-9399-c323b0f0a8ca	5	09:00:00	20:00:00
664b34d2-18e2-428f-a917-482d376f5da2	chair	df024c6d-58d3-46e8-9399-c323b0f0a8ca	6	09:00:00	20:00:00
500d251c-87d2-4adf-811f-7352fe563b49	chair	f6769c38-6269-41fc-9c0e-39c7f2396bde	0	09:00:00	20:00:00
0cba60c0-9593-474c-976a-502e2e1bc267	chair	f6769c38-6269-41fc-9c0e-39c7f2396bde	1	09:00:00	20:00:00
70fc7b11-56fa-4bc0-89c9-2ac29a23bd54	chair	f6769c38-6269-41fc-9c0e-39c7f2396bde	2	09:00:00	20:00:00
a78e468d-61d6-479b-8a15-4ab3833b5642	chair	f6769c38-6269-41fc-9c0e-39c7f2396bde	3	09:00:00	20:00:00
017c14bf-1b95-4644-b049-be9ec11e43c7	chair	f6769c38-6269-41fc-9c0e-39c7f2396bde	4	09:00:00	20:00:00
88cb7079-e668-4997-ada0-c46927b3bf9e	chair	f6769c38-6269-41fc-9c0e-39c7f2396bde	5	09:00:00	20:00:00
d6537580-3a32-472f-98c7-83f9f988cb06	chair	f6769c38-6269-41fc-9c0e-39c7f2396bde	6	09:00:00	20:00:00
d1e614f9-ec39-4eeb-9d99-0535d1c07701	staff	07f7969e-2964-4ae8-a1c4-305c15e2117f	0	09:00:00	20:00:00
e93c67c7-e119-4f73-989f-2ba6cab3ed9f	staff	07f7969e-2964-4ae8-a1c4-305c15e2117f	1	09:00:00	20:00:00
80470c94-fdf3-4234-8fbb-9ff396322c58	staff	07f7969e-2964-4ae8-a1c4-305c15e2117f	2	09:00:00	20:00:00
db4de452-2772-4288-aead-59c25b7673f1	staff	07f7969e-2964-4ae8-a1c4-305c15e2117f	3	09:00:00	20:00:00
6e3804b3-2104-4d65-b1fe-e534f0997b01	staff	07f7969e-2964-4ae8-a1c4-305c15e2117f	4	09:00:00	20:00:00
6c95238c-c224-4cd6-8cbe-4de1804a7a6e	staff	07f7969e-2964-4ae8-a1c4-305c15e2117f	5	09:00:00	20:00:00
ea0cd1bb-adce-43fd-be77-1c71387d81c7	staff	07f7969e-2964-4ae8-a1c4-305c15e2117f	6	09:00:00	20:00:00
98eb2a79-6b70-42be-abce-fd98fc046eba	staff	be3bb144-e4f4-4832-82a9-7abe8490d470	0	09:00:00	20:00:00
dc961491-6fae-49f3-ac41-ed8822897037	staff	be3bb144-e4f4-4832-82a9-7abe8490d470	1	09:00:00	20:00:00
06c1b74f-ecf5-4968-88e7-988fcc258edf	staff	be3bb144-e4f4-4832-82a9-7abe8490d470	2	09:00:00	20:00:00
3d7552b8-f7d1-4f94-975a-e965a1723223	staff	be3bb144-e4f4-4832-82a9-7abe8490d470	3	09:00:00	20:00:00
4eea2749-945a-4844-a77f-4f7011ba8eea	staff	be3bb144-e4f4-4832-82a9-7abe8490d470	4	09:00:00	20:00:00
9f32cef1-1c32-4f8a-8757-d8d6d02daca4	staff	be3bb144-e4f4-4832-82a9-7abe8490d470	5	09:00:00	20:00:00
8755968e-2ede-4bec-ba18-9d40474cf511	staff	be3bb144-e4f4-4832-82a9-7abe8490d470	6	09:00:00	20:00:00
c2332b64-4756-4002-ae73-29b7ad004f49	chair	231cb19e-f41c-4cbe-b658-ea5bb05291e3	0	09:00:00	20:00:00
e4251e47-7c53-4dd0-8896-00bf2a946c8e	chair	231cb19e-f41c-4cbe-b658-ea5bb05291e3	1	09:00:00	20:00:00
2f69f48e-0c47-4d22-9d14-de0988237c4f	chair	231cb19e-f41c-4cbe-b658-ea5bb05291e3	2	09:00:00	20:00:00
4ba3c9a4-7901-4710-b6b4-4227cdfc4dcf	chair	231cb19e-f41c-4cbe-b658-ea5bb05291e3	3	09:00:00	20:00:00
77763fea-a831-4e90-9592-5c2583b4651c	chair	231cb19e-f41c-4cbe-b658-ea5bb05291e3	4	09:00:00	20:00:00
43c07fa9-8e71-46e0-ade8-41c5d7c81a75	chair	231cb19e-f41c-4cbe-b658-ea5bb05291e3	5	09:00:00	20:00:00
50e92406-2bad-4a48-81d6-ee46abfc1ebc	chair	231cb19e-f41c-4cbe-b658-ea5bb05291e3	6	09:00:00	20:00:00
344d5742-9f95-48b2-a603-628de2bdeea1	chair	67c2adc8-ec75-4edd-a37a-3d5e1b46f4af	0	09:00:00	20:00:00
5ea2d308-03a0-436c-b593-bff84fec2cb1	chair	67c2adc8-ec75-4edd-a37a-3d5e1b46f4af	1	09:00:00	20:00:00
04231376-746d-4dcf-b80f-55f4e5953921	chair	67c2adc8-ec75-4edd-a37a-3d5e1b46f4af	2	09:00:00	20:00:00
34e39c60-e66d-48a3-a4b4-5ab73ef79f1e	chair	67c2adc8-ec75-4edd-a37a-3d5e1b46f4af	3	09:00:00	20:00:00
576e1cec-6819-44e4-aab4-e0b3db7ddf02	chair	67c2adc8-ec75-4edd-a37a-3d5e1b46f4af	4	09:00:00	20:00:00
dc9fb1ac-5e44-40cd-a56f-4f0fbb215592	chair	67c2adc8-ec75-4edd-a37a-3d5e1b46f4af	5	09:00:00	20:00:00
47fc9592-23aa-430c-a647-871fda5ecfee	chair	67c2adc8-ec75-4edd-a37a-3d5e1b46f4af	6	09:00:00	20:00:00
99139865-659f-43e9-bc1a-6ed8158ab918	chair	392b72c3-0526-4897-a2b3-cedd1af26f01	0	09:00:00	20:00:00
2547ea09-9e47-4ee0-8c6c-4b55bb3f046f	chair	392b72c3-0526-4897-a2b3-cedd1af26f01	1	09:00:00	20:00:00
29b858bd-a7e0-4cb5-aa63-5aaa0d2874ec	chair	392b72c3-0526-4897-a2b3-cedd1af26f01	2	09:00:00	20:00:00
942dd8fa-3fa9-4c1c-8b62-8c25909d0046	chair	392b72c3-0526-4897-a2b3-cedd1af26f01	3	09:00:00	20:00:00
6251c672-5cf6-4cba-804a-e969c8c05136	chair	392b72c3-0526-4897-a2b3-cedd1af26f01	4	09:00:00	20:00:00
15d53414-1961-4a55-a3b1-994f7cd77e22	chair	392b72c3-0526-4897-a2b3-cedd1af26f01	5	09:00:00	20:00:00
205290b8-7c02-48a3-8efe-607aad46279c	chair	392b72c3-0526-4897-a2b3-cedd1af26f01	6	09:00:00	20:00:00
fb476958-47d5-4d6f-b62a-e77f59aec24a	staff	32c3d16d-91a6-4155-8737-ed0effe00a0e	0	09:00:00	20:00:00
abb33253-fa72-4db5-b44c-b8b07661cd5f	staff	32c3d16d-91a6-4155-8737-ed0effe00a0e	1	09:00:00	20:00:00
b1b15df1-4569-43ac-8cdb-dc9706810030	staff	32c3d16d-91a6-4155-8737-ed0effe00a0e	2	09:00:00	20:00:00
161047c6-98e7-4686-8653-a56c998d741b	staff	32c3d16d-91a6-4155-8737-ed0effe00a0e	3	09:00:00	20:00:00
cb2de98c-c116-47bc-932f-750123763463	staff	32c3d16d-91a6-4155-8737-ed0effe00a0e	4	09:00:00	20:00:00
333392d7-1697-4a74-912b-1cd03acf2700	staff	32c3d16d-91a6-4155-8737-ed0effe00a0e	5	09:00:00	20:00:00
8fe01e00-29a2-42a8-b15a-be6aa99adcb0	staff	32c3d16d-91a6-4155-8737-ed0effe00a0e	6	09:00:00	20:00:00
7d4653df-4846-4535-9e09-25a42e8a7a38	chair	3a164365-6f53-4d44-a2a2-13cc93237064	0	09:00:00	20:00:00
ef41678b-f275-4e89-85fb-9577d03b4ef3	chair	3a164365-6f53-4d44-a2a2-13cc93237064	1	09:00:00	20:00:00
e0161c6f-5a09-465b-8ad0-232ea29a82ee	chair	3a164365-6f53-4d44-a2a2-13cc93237064	2	09:00:00	20:00:00
a6e8c62d-d150-41aa-8ce3-ae622a226787	chair	3a164365-6f53-4d44-a2a2-13cc93237064	3	09:00:00	20:00:00
5123f746-eb1f-4a1e-b05f-e8e27cedae34	chair	3a164365-6f53-4d44-a2a2-13cc93237064	4	09:00:00	20:00:00
cca145be-6521-4b45-8d9e-ce55786c7981	chair	3a164365-6f53-4d44-a2a2-13cc93237064	5	09:00:00	20:00:00
fee86ddc-bdff-437d-9785-9498a6e8e9d5	chair	3a164365-6f53-4d44-a2a2-13cc93237064	6	09:00:00	20:00:00
17f2cc3c-d259-4c87-b85c-3341692fa197	staff	950277b2-bd06-47fe-a253-9cb412cca69b	0	09:00:00	20:00:00
bdf11798-7448-4662-85dc-821304141958	staff	950277b2-bd06-47fe-a253-9cb412cca69b	1	09:00:00	20:00:00
566145f9-b8de-41b5-ba21-dbf299742cd6	staff	950277b2-bd06-47fe-a253-9cb412cca69b	2	09:00:00	20:00:00
af30d0dc-e958-423b-b925-0acd03a88c27	staff	950277b2-bd06-47fe-a253-9cb412cca69b	3	09:00:00	20:00:00
b0b913db-63d9-4e5f-9bfa-bfcc08f91680	staff	950277b2-bd06-47fe-a253-9cb412cca69b	4	09:00:00	20:00:00
cb592ec9-051b-4905-98b8-9a2eab73c80e	staff	950277b2-bd06-47fe-a253-9cb412cca69b	5	09:00:00	20:00:00
0e980935-dd0f-44da-83bf-af7bcc53b5e8	staff	950277b2-bd06-47fe-a253-9cb412cca69b	6	09:00:00	20:00:00
88038c15-dd2b-405f-9f06-e8a429920507	chair	471ceace-2ff4-4229-b13d-d2b66bd9bcb8	0	09:00:00	20:00:00
73628872-d128-4453-a55b-408e667b9d54	chair	471ceace-2ff4-4229-b13d-d2b66bd9bcb8	1	09:00:00	20:00:00
1edd8a4c-2b9b-4e74-b541-8193317e4c69	chair	471ceace-2ff4-4229-b13d-d2b66bd9bcb8	2	09:00:00	20:00:00
952aa07c-0eca-476f-8510-73e5648978b8	chair	471ceace-2ff4-4229-b13d-d2b66bd9bcb8	3	09:00:00	20:00:00
ac919857-7488-446c-afb7-bd0d84235c98	chair	471ceace-2ff4-4229-b13d-d2b66bd9bcb8	4	09:00:00	20:00:00
08ab2993-2d5d-4a46-a6f5-1a05691b596c	chair	471ceace-2ff4-4229-b13d-d2b66bd9bcb8	5	09:00:00	20:00:00
24a1f0f0-ed26-4ac7-bf3f-9502a160bb75	chair	471ceace-2ff4-4229-b13d-d2b66bd9bcb8	6	09:00:00	20:00:00
953b3fb1-70ff-41b6-887b-e85e526694e3	staff	cb8b8b28-de2e-4594-a893-48edb4873101	0	09:00:00	20:00:00
0d9201c4-c394-4380-b3d7-e29ac493a9da	staff	cb8b8b28-de2e-4594-a893-48edb4873101	1	09:00:00	20:00:00
f779073f-dc40-4a06-bafa-e1f790540446	staff	cb8b8b28-de2e-4594-a893-48edb4873101	2	09:00:00	20:00:00
6e64e1c8-7ce6-421f-bcc3-70ec9bb939a3	staff	cb8b8b28-de2e-4594-a893-48edb4873101	3	09:00:00	20:00:00
e76b4232-c3df-4c6f-9d67-0a1a94c586ad	staff	cb8b8b28-de2e-4594-a893-48edb4873101	4	09:00:00	20:00:00
4c2a8d01-4d6f-42a8-8d58-5f0dbed7c4d8	staff	cb8b8b28-de2e-4594-a893-48edb4873101	5	09:00:00	20:00:00
b938dd83-98a1-4e69-8924-794466fe549b	staff	cb8b8b28-de2e-4594-a893-48edb4873101	6	09:00:00	20:00:00
45dfbfed-16ab-4c66-8c79-8773d664f97a	chair	5d8fa48c-6bd7-4ff3-8c06-f9b84553ca4c	0	09:00:00	20:00:00
f8261fc3-c479-4dc2-b755-14a8828c91a2	chair	5d8fa48c-6bd7-4ff3-8c06-f9b84553ca4c	1	09:00:00	20:00:00
002b4f96-b96e-4b31-be26-c32ef2b151fd	chair	5d8fa48c-6bd7-4ff3-8c06-f9b84553ca4c	2	09:00:00	20:00:00
6e7bf62b-cbc4-40bb-98b6-06f18c5594f8	chair	5d8fa48c-6bd7-4ff3-8c06-f9b84553ca4c	3	09:00:00	20:00:00
bc1d1312-31f1-429f-9bf8-9ade5e5d5351	chair	5d8fa48c-6bd7-4ff3-8c06-f9b84553ca4c	4	09:00:00	20:00:00
fac20433-ce40-4104-b805-c99b5264699a	chair	5d8fa48c-6bd7-4ff3-8c06-f9b84553ca4c	5	09:00:00	20:00:00
b4eb7079-cafb-4e17-9a25-743970fdc99e	chair	5d8fa48c-6bd7-4ff3-8c06-f9b84553ca4c	6	09:00:00	20:00:00
869206cf-d176-4609-84de-f6869cf7ff8d	staff	d294abaf-3f1f-4a81-9d3c-23f16687aaf4	0	09:00:00	20:00:00
8ee8a209-b179-42f6-9c1c-67d30f30e0ed	staff	d294abaf-3f1f-4a81-9d3c-23f16687aaf4	1	09:00:00	20:00:00
a3c33fda-b44c-4ac2-be58-9610728e797c	staff	d294abaf-3f1f-4a81-9d3c-23f16687aaf4	2	09:00:00	20:00:00
0eef6262-8ad6-454e-868c-f62973b69291	staff	d294abaf-3f1f-4a81-9d3c-23f16687aaf4	3	09:00:00	20:00:00
a143bf52-d3c3-4537-a3c0-a108b5f7fdc2	staff	d294abaf-3f1f-4a81-9d3c-23f16687aaf4	4	09:00:00	20:00:00
e0dfee75-fda5-4ce0-ad0d-f001ce105fe3	staff	d294abaf-3f1f-4a81-9d3c-23f16687aaf4	5	09:00:00	20:00:00
4f065d66-33d5-4d6b-bc36-ddc8e40dd8f1	staff	d294abaf-3f1f-4a81-9d3c-23f16687aaf4	6	09:00:00	20:00:00
a2ab6af4-a103-4d44-81fa-b67aacf1a934	chair	2970159a-cab4-492d-a3fa-a76f12c64b96	0	09:00:00	20:00:00
f36c6e5d-5b15-4e92-a138-5f3cd9a4375c	chair	2970159a-cab4-492d-a3fa-a76f12c64b96	1	09:00:00	20:00:00
80c259fd-3cd5-43d2-8962-ec6ef8c01491	chair	2970159a-cab4-492d-a3fa-a76f12c64b96	2	09:00:00	20:00:00
fbcb7ea2-2f7a-4742-8466-1a329d7b649b	staff	eeeb8ab5-2f29-4edf-9c12-cbdf476848b6	0	09:00:00	20:00:00
749bce99-2d9b-4894-bd35-d106cea9df9f	staff	eeeb8ab5-2f29-4edf-9c12-cbdf476848b6	1	09:00:00	20:00:00
e18c4be4-13aa-4628-940c-02f52aab988b	staff	eeeb8ab5-2f29-4edf-9c12-cbdf476848b6	2	09:00:00	20:00:00
e6979706-b5aa-4c0d-a1d3-84cc78d36793	staff	eeeb8ab5-2f29-4edf-9c12-cbdf476848b6	3	09:00:00	20:00:00
ccc6f5af-d710-4386-be06-fef0cfdc994b	staff	eeeb8ab5-2f29-4edf-9c12-cbdf476848b6	4	09:00:00	20:00:00
b330cf9a-6d63-41ad-bb77-d687c7b9fce1	staff	eeeb8ab5-2f29-4edf-9c12-cbdf476848b6	5	09:00:00	20:00:00
8b94c772-e50d-4a5b-9b13-31e3c01d9948	staff	eeeb8ab5-2f29-4edf-9c12-cbdf476848b6	6	09:00:00	20:00:00
dcef94e6-ea55-45f3-a05f-1ec48f59a4d4	chair	2970159a-cab4-492d-a3fa-a76f12c64b96	3	09:00:00	20:00:00
ebf412ef-867f-403e-bf2c-9f484d5b46ed	chair	2970159a-cab4-492d-a3fa-a76f12c64b96	4	09:00:00	20:00:00
26c7673a-d011-4e0b-9512-12be5fa324c9	chair	2970159a-cab4-492d-a3fa-a76f12c64b96	5	09:00:00	20:00:00
29ee3a36-a31b-4104-ba5a-054461fa184d	chair	2970159a-cab4-492d-a3fa-a76f12c64b96	6	09:00:00	20:00:00
f6492dec-2681-4045-a337-d5a84d6f7694	staff	24d0eeb8-7ccb-4d69-b52d-85211642ae3f	0	09:00:00	20:00:00
5b4d7f3c-2732-413a-935a-388c9606b02d	staff	24d0eeb8-7ccb-4d69-b52d-85211642ae3f	1	09:00:00	20:00:00
85dad6c3-6a15-4d61-846f-48536b9b8970	staff	24d0eeb8-7ccb-4d69-b52d-85211642ae3f	2	09:00:00	20:00:00
2ef77265-262d-453c-8bae-6437e17837cf	staff	24d0eeb8-7ccb-4d69-b52d-85211642ae3f	3	09:00:00	20:00:00
75aa2800-0fed-44fd-b534-27a49e07874b	staff	24d0eeb8-7ccb-4d69-b52d-85211642ae3f	4	09:00:00	20:00:00
361e1796-e45b-46f3-b90a-6c87d7178acf	staff	24d0eeb8-7ccb-4d69-b52d-85211642ae3f	5	09:00:00	20:00:00
6d7f8f41-4f44-47e0-afb6-e0242f491275	staff	24d0eeb8-7ccb-4d69-b52d-85211642ae3f	6	09:00:00	20:00:00
384990b5-dbb1-49bc-87cd-54ed9ab2be80	chair	c2ce68f0-6f97-4dde-88a5-c8740f9af106	0	09:00:00	20:00:00
b5783640-ff59-4625-9497-f26746a4071c	chair	c2ce68f0-6f97-4dde-88a5-c8740f9af106	1	09:00:00	20:00:00
12d5968e-fda3-483b-adf5-8fb8f2d27b87	chair	c2ce68f0-6f97-4dde-88a5-c8740f9af106	2	09:00:00	20:00:00
7807030b-53b6-4099-9848-002273f73628	chair	c2ce68f0-6f97-4dde-88a5-c8740f9af106	3	09:00:00	20:00:00
1bc8f901-1fa7-43c4-8b4e-8331b30ae081	chair	c2ce68f0-6f97-4dde-88a5-c8740f9af106	4	09:00:00	20:00:00
fdd5d0bc-f6da-4c16-8847-edd5977f6791	chair	c2ce68f0-6f97-4dde-88a5-c8740f9af106	5	09:00:00	20:00:00
e583eb00-8d2f-477e-8480-f22b2d164165	chair	c2ce68f0-6f97-4dde-88a5-c8740f9af106	6	09:00:00	20:00:00
8227de3c-a90c-4521-bcb3-450214e78385	staff	69f57590-8a6a-4c6e-b6e5-6d8bf70bd18f	4	09:00:00	20:00:00
b920abaa-777c-4812-b3a0-11bb30d456b6	staff	69f57590-8a6a-4c6e-b6e5-6d8bf70bd18f	5	09:00:00	20:00:00
3a40d30b-7db3-4981-91d9-ec7e09a92ab1	staff	6af4802f-1803-49e9-add7-f01ea26dd8bc	0	09:00:00	20:00:00
a37b9401-5604-4ce1-842b-f8db8d74a0a7	staff	6af4802f-1803-49e9-add7-f01ea26dd8bc	1	09:00:00	20:00:00
d63e9b0f-3b71-48e9-ab7d-1177934d1562	staff	6af4802f-1803-49e9-add7-f01ea26dd8bc	2	09:00:00	20:00:00
8e41548c-3a2e-449c-ae55-caeb62b1f776	staff	6af4802f-1803-49e9-add7-f01ea26dd8bc	3	09:00:00	20:00:00
0383baf1-7d2c-4a2f-bf5a-b3266d957806	staff	6af4802f-1803-49e9-add7-f01ea26dd8bc	4	09:00:00	20:00:00
7e4aca96-ead8-4510-80e3-86d8a57bc4c8	staff	6af4802f-1803-49e9-add7-f01ea26dd8bc	5	09:00:00	20:00:00
ae38cbb5-a9a5-419e-a162-fbc4a800944f	staff	6af4802f-1803-49e9-add7-f01ea26dd8bc	6	09:00:00	20:00:00
d8dda262-ceee-4a42-84b8-34028123540d	chair	fc97462e-b8b8-4d08-b537-7960aacd9755	0	09:00:00	20:00:00
5ce28ffb-fff0-4b00-8e22-941e35c53259	chair	fc97462e-b8b8-4d08-b537-7960aacd9755	1	09:00:00	20:00:00
9606d723-91ad-43ae-bf6b-c3b983ccf7a1	chair	fc97462e-b8b8-4d08-b537-7960aacd9755	2	09:00:00	20:00:00
fac901cf-b6d0-4404-b4c6-480732c6475c	chair	fc97462e-b8b8-4d08-b537-7960aacd9755	3	09:00:00	20:00:00
1f57a2a7-42f8-4dd6-ab9d-2d4926c90076	chair	fc97462e-b8b8-4d08-b537-7960aacd9755	4	09:00:00	20:00:00
833d61e6-11fd-4af2-8a24-627ebc7e3bb6	staff	a11ed08a-2689-4d9d-8bdb-59b62e1c2682	0	09:00:00	20:00:00
079325de-a86c-4481-be6f-92e0e54c215a	staff	a11ed08a-2689-4d9d-8bdb-59b62e1c2682	1	09:00:00	20:00:00
1b2ee1ad-fc3d-4d7b-aced-059c4873c928	staff	a11ed08a-2689-4d9d-8bdb-59b62e1c2682	2	09:00:00	20:00:00
d078f4e2-621c-41a9-85e2-3dc80a10af6d	staff	a11ed08a-2689-4d9d-8bdb-59b62e1c2682	3	09:00:00	20:00:00
784faf29-0264-44b7-9c65-3bfd2a07c93c	staff	a11ed08a-2689-4d9d-8bdb-59b62e1c2682	4	09:00:00	20:00:00
d160b59e-5220-450f-ac7f-cab12fc2f5dd	staff	a11ed08a-2689-4d9d-8bdb-59b62e1c2682	5	09:00:00	20:00:00
9a4f3dbf-63b2-4ceb-8809-0bbeff1f6e5e	staff	a11ed08a-2689-4d9d-8bdb-59b62e1c2682	6	09:00:00	20:00:00
fb63f994-896b-496b-9359-827a65c282cb	chair	fc97462e-b8b8-4d08-b537-7960aacd9755	5	09:00:00	20:00:00
2de8007b-6265-4f50-a5c3-bb06064dcfa6	chair	fc97462e-b8b8-4d08-b537-7960aacd9755	6	09:00:00	20:00:00
3034ea3e-9073-4d92-b62a-23bd4c99e7b6	chair	0e531f56-7d5f-4ba0-9dec-276fb3d4b47e	0	09:00:00	20:00:00
2d820eac-29d6-4726-ac12-d6f27067c615	chair	0e531f56-7d5f-4ba0-9dec-276fb3d4b47e	1	09:00:00	20:00:00
aefc9c9f-3349-428b-9970-4d1c2b0f96ed	chair	0e531f56-7d5f-4ba0-9dec-276fb3d4b47e	2	09:00:00	20:00:00
076a0b77-6429-4b5b-91bc-b2173dd4db23	chair	0e531f56-7d5f-4ba0-9dec-276fb3d4b47e	3	09:00:00	20:00:00
95a0e637-8cef-4e1f-b21c-4d90fdec8785	chair	0e531f56-7d5f-4ba0-9dec-276fb3d4b47e	4	09:00:00	20:00:00
4497193a-deae-4c05-8290-8fc1db81f3d3	chair	0e531f56-7d5f-4ba0-9dec-276fb3d4b47e	5	09:00:00	20:00:00
8613d65b-89be-4eef-86a8-6c87cc9d07f2	chair	0e531f56-7d5f-4ba0-9dec-276fb3d4b47e	6	09:00:00	20:00:00
3f878ae7-e1bf-4722-86f8-a9d743d2787a	staff	85a6a285-dbcc-40b3-a3a3-6a20f2d31926	0	09:00:00	20:00:00
54cd8220-c491-48a5-93f1-3b2b5bcdeaf0	staff	85a6a285-dbcc-40b3-a3a3-6a20f2d31926	1	09:00:00	20:00:00
ddb95dc6-020c-451b-823f-7f4a9dedd20f	staff	85a6a285-dbcc-40b3-a3a3-6a20f2d31926	2	09:00:00	20:00:00
405aafc8-4d6d-4d11-885b-e59d6c9c99c5	staff	85a6a285-dbcc-40b3-a3a3-6a20f2d31926	3	09:00:00	20:00:00
4882c400-3d77-4e2e-9cab-cdd7af29b7ca	staff	85a6a285-dbcc-40b3-a3a3-6a20f2d31926	4	09:00:00	20:00:00
2285a054-cbba-480b-aeae-61136128b9fe	staff	85a6a285-dbcc-40b3-a3a3-6a20f2d31926	5	09:00:00	20:00:00
e495d4ed-f101-4c8d-b4bf-be95cbc48efe	staff	85a6a285-dbcc-40b3-a3a3-6a20f2d31926	6	09:00:00	20:00:00
6ade92e3-8b0e-455f-bbb2-283fbb64b001	chair	3a4a92df-91bb-4e7a-8a50-ea5c6a381a13	0	09:00:00	20:00:00
7b5dcc15-635d-4376-a58b-28536f7d427b	chair	3a4a92df-91bb-4e7a-8a50-ea5c6a381a13	1	09:00:00	20:00:00
1ca0079f-0098-49aa-b9ae-724a7a9a4c00	chair	3a4a92df-91bb-4e7a-8a50-ea5c6a381a13	2	09:00:00	20:00:00
93f812dd-aa2b-4e53-9cdb-1d679f070ee4	chair	3a4a92df-91bb-4e7a-8a50-ea5c6a381a13	3	09:00:00	20:00:00
42bb6fe9-f446-4716-8673-0711eb3ed255	chair	3a4a92df-91bb-4e7a-8a50-ea5c6a381a13	4	09:00:00	20:00:00
32d5a2fd-1b5b-4048-8df6-74266500e482	chair	3a4a92df-91bb-4e7a-8a50-ea5c6a381a13	5	09:00:00	20:00:00
6fe620ae-a4cf-41dc-a31f-9836e9766152	chair	3a4a92df-91bb-4e7a-8a50-ea5c6a381a13	6	09:00:00	20:00:00
63e60cc2-3884-4c72-817f-713e99bbbe5f	staff	f8342806-e26e-4e6c-a26c-97a2be36e71b	0	09:00:00	20:00:00
1d9dd2ce-929d-4e86-bc93-512d7789e961	staff	f8342806-e26e-4e6c-a26c-97a2be36e71b	1	09:00:00	20:00:00
a3a8b119-cd44-4247-b67f-1f8f560dff0f	staff	f8342806-e26e-4e6c-a26c-97a2be36e71b	2	09:00:00	20:00:00
e5295eca-b669-4f38-b9f5-f05889976667	staff	f8342806-e26e-4e6c-a26c-97a2be36e71b	3	09:00:00	20:00:00
4a26d3fe-358b-4dd5-8b50-933fa321c407	staff	f8342806-e26e-4e6c-a26c-97a2be36e71b	4	09:00:00	20:00:00
16a37f49-de8f-403d-8293-ce62cb342b34	staff	f8342806-e26e-4e6c-a26c-97a2be36e71b	5	09:00:00	20:00:00
9825fca2-8275-49f5-9e7c-ea38d4dfa35d	staff	f8342806-e26e-4e6c-a26c-97a2be36e71b	6	09:00:00	20:00:00
257a7027-b04b-483e-ae82-8cbd20e6420c	chair	a155ffe7-df04-44cc-b091-8027dd7f0598	0	09:00:00	20:00:00
d63ff939-69f5-42b9-b443-e9130d08324f	chair	a155ffe7-df04-44cc-b091-8027dd7f0598	1	09:00:00	20:00:00
3361c88c-6726-4f80-b1bc-dc4c0e8af3bd	chair	a155ffe7-df04-44cc-b091-8027dd7f0598	2	09:00:00	20:00:00
eb0d88ec-50e3-4d93-befd-5eb7ed7fed61	chair	a155ffe7-df04-44cc-b091-8027dd7f0598	3	09:00:00	20:00:00
ce54b038-498a-4437-8f36-19e0365b76b7	chair	a155ffe7-df04-44cc-b091-8027dd7f0598	4	09:00:00	20:00:00
8c567a53-f5a4-4e9f-8930-ee6ca70703e4	chair	a155ffe7-df04-44cc-b091-8027dd7f0598	5	09:00:00	20:00:00
138b4570-4db0-47ac-9d34-0173333b50b7	chair	a155ffe7-df04-44cc-b091-8027dd7f0598	6	09:00:00	20:00:00
633f4803-fdba-4c88-b031-345306b45fe2	staff	3dcd50fc-d04f-4cde-9a4f-4be1cbacd9a1	0	09:00:00	20:00:00
7703a241-6d4a-470c-bc3d-2e3469d3e369	staff	3dcd50fc-d04f-4cde-9a4f-4be1cbacd9a1	1	09:00:00	20:00:00
2494d459-0c55-4525-9cac-1a78f9d6ad6b	staff	3dcd50fc-d04f-4cde-9a4f-4be1cbacd9a1	2	09:00:00	20:00:00
7210e349-0e80-4939-9c0c-6e5dc02e8bd9	staff	3dcd50fc-d04f-4cde-9a4f-4be1cbacd9a1	3	09:00:00	20:00:00
9eaa853c-f393-4da5-9197-2547f6eb0ecc	staff	3dcd50fc-d04f-4cde-9a4f-4be1cbacd9a1	4	09:00:00	20:00:00
7eb0cc5d-222d-41e7-a264-fae06dc2867d	staff	3dcd50fc-d04f-4cde-9a4f-4be1cbacd9a1	5	09:00:00	20:00:00
f858eec2-5a45-42cb-9e2b-4aeaa38425c0	staff	3dcd50fc-d04f-4cde-9a4f-4be1cbacd9a1	6	09:00:00	20:00:00
89e5fdca-a1c1-430d-8dfc-9f18e7cb3a77	chair	baa02a3a-93d6-48c5-a21b-77f8f71fc98f	0	09:00:00	20:00:00
37832b5b-6696-435f-b18e-bd57a4ef1d74	chair	baa02a3a-93d6-48c5-a21b-77f8f71fc98f	1	09:00:00	20:00:00
7e75d585-e71b-4846-9fc9-02589d8fa0bb	chair	baa02a3a-93d6-48c5-a21b-77f8f71fc98f	2	09:00:00	20:00:00
b4584e2e-4220-49f6-a094-05c3f28c5e00	chair	baa02a3a-93d6-48c5-a21b-77f8f71fc98f	3	09:00:00	20:00:00
2d506f2b-1697-4dff-98d6-2849dcc79a58	chair	baa02a3a-93d6-48c5-a21b-77f8f71fc98f	4	09:00:00	20:00:00
e34193b7-b1f0-4263-a531-12542b75bf01	chair	baa02a3a-93d6-48c5-a21b-77f8f71fc98f	5	09:00:00	20:00:00
19e0a3a5-b594-41a6-a565-058771d4ca71	chair	baa02a3a-93d6-48c5-a21b-77f8f71fc98f	6	09:00:00	20:00:00
e4b6fdfe-43c2-4e07-8523-f6642817ec78	staff	c4cade4d-9489-47ca-840e-340152d894da	0	09:00:00	20:00:00
8bed9ee1-ccdb-493a-9407-23038017bd32	staff	c4cade4d-9489-47ca-840e-340152d894da	1	09:00:00	20:00:00
e2c3eb42-c121-4365-833f-5d54012195b1	staff	c4cade4d-9489-47ca-840e-340152d894da	2	09:00:00	20:00:00
008340fd-045b-42cb-bbaf-29634334f2f9	staff	c4cade4d-9489-47ca-840e-340152d894da	3	09:00:00	20:00:00
40bae3d3-a0a4-49e6-ba16-8068fb2fea4f	staff	c4cade4d-9489-47ca-840e-340152d894da	4	09:00:00	20:00:00
7f56b6e9-7eaa-40ce-8bb7-23f6ce0ca1d4	staff	c4cade4d-9489-47ca-840e-340152d894da	5	09:00:00	20:00:00
d7c458ba-d37c-4f16-83f0-d074515dfbf2	staff	c4cade4d-9489-47ca-840e-340152d894da	6	09:00:00	20:00:00
3eaf322c-71f5-4e85-a533-9a5f5ae20f38	chair	0ad27df7-3dc1-4be9-bc8c-612152df469c	0	09:00:00	20:00:00
e2ffddc7-ae41-4104-8e5f-e1528741f356	chair	0ad27df7-3dc1-4be9-bc8c-612152df469c	1	09:00:00	20:00:00
eddfe2a2-6199-450b-8676-bfc29a3c3633	chair	0ad27df7-3dc1-4be9-bc8c-612152df469c	2	09:00:00	20:00:00
175cf859-614c-4824-bd48-845e72b467b7	chair	0ad27df7-3dc1-4be9-bc8c-612152df469c	3	09:00:00	20:00:00
5be94aa3-12cb-4eaa-95df-a6b2dca75b6e	chair	0ad27df7-3dc1-4be9-bc8c-612152df469c	4	09:00:00	20:00:00
09f3365f-abda-48ed-b3b4-f3ab44214b74	chair	0ad27df7-3dc1-4be9-bc8c-612152df469c	5	09:00:00	20:00:00
6d05e3b5-3078-469d-95cd-a9683ee17605	chair	0ad27df7-3dc1-4be9-bc8c-612152df469c	6	09:00:00	20:00:00
42634bf6-b607-4d4c-bc90-a7dada3fa1cf	staff	69f57590-8a6a-4c6e-b6e5-6d8bf70bd18f	0	09:00:00	20:00:00
a5e136da-597c-4528-a9a4-e9ece4502a92	staff	69f57590-8a6a-4c6e-b6e5-6d8bf70bd18f	1	09:00:00	20:00:00
19a8564c-e3c7-4f7d-a018-39c9b4b23c48	staff	69f57590-8a6a-4c6e-b6e5-6d8bf70bd18f	2	09:00:00	20:00:00
46d9457d-d1e9-4737-a185-bd984b060e76	staff	69f57590-8a6a-4c6e-b6e5-6d8bf70bd18f	3	09:00:00	20:00:00
b9a87913-b73f-4a2b-a774-2914356c3f14	staff	69f57590-8a6a-4c6e-b6e5-6d8bf70bd18f	6	09:00:00	20:00:00
05ef2a96-7f59-43f3-8b9c-797679fd80d2	chair	f1d783d4-6ec7-4595-ac54-e8db52f6df77	0	09:00:00	20:00:00
fddda102-b9dc-4cf9-a383-704bdb8fe75a	chair	f1d783d4-6ec7-4595-ac54-e8db52f6df77	1	09:00:00	20:00:00
64d6625c-40b8-40a6-9736-b1f971ee19cf	chair	f1d783d4-6ec7-4595-ac54-e8db52f6df77	2	09:00:00	20:00:00
6fe89638-d4da-4425-aec5-8cc9fe1b3c40	chair	f1d783d4-6ec7-4595-ac54-e8db52f6df77	3	09:00:00	20:00:00
bf807efc-e322-4f1d-b57b-3cdf6979730b	chair	f1d783d4-6ec7-4595-ac54-e8db52f6df77	4	09:00:00	20:00:00
fa3572b0-ad0c-4a30-8df1-d634670086e9	chair	f1d783d4-6ec7-4595-ac54-e8db52f6df77	5	09:00:00	20:00:00
02f1859f-56c7-4ee6-9393-b43a9b21fdb8	chair	f1d783d4-6ec7-4595-ac54-e8db52f6df77	6	09:00:00	20:00:00
ab7ff5aa-3902-400c-9ae3-1009a90399f7	staff	31a3e2ab-dbc3-4175-964f-528165e4c467	0	09:00:00	20:00:00
ffb8f925-6086-40ed-bd96-6f4f9f8fbe1d	staff	31a3e2ab-dbc3-4175-964f-528165e4c467	1	09:00:00	20:00:00
a11a1c94-088a-42a3-ac00-747da157dfc2	staff	31a3e2ab-dbc3-4175-964f-528165e4c467	2	09:00:00	20:00:00
b0b770a3-7ad3-494d-88f2-021822c9734e	staff	31a3e2ab-dbc3-4175-964f-528165e4c467	3	09:00:00	20:00:00
6fcd6157-6f73-4c04-81fa-a6b3dbfc16e4	staff	31a3e2ab-dbc3-4175-964f-528165e4c467	4	09:00:00	20:00:00
a96681af-90cc-4600-8628-7d15c658e05e	staff	31a3e2ab-dbc3-4175-964f-528165e4c467	5	09:00:00	20:00:00
a6f5c268-2bf5-431d-9043-6fd783f55c7f	staff	31a3e2ab-dbc3-4175-964f-528165e4c467	6	09:00:00	20:00:00
1e8a47aa-2b2d-4791-9042-d7cff9bbac45	chair	016ef339-c6f8-4c11-9055-f5b31b05acc6	0	09:00:00	20:00:00
d1f2ec4b-bb39-485f-81a4-703f8939043d	chair	016ef339-c6f8-4c11-9055-f5b31b05acc6	1	09:00:00	20:00:00
ab036368-9c16-4c91-9649-de6a20b51afc	chair	016ef339-c6f8-4c11-9055-f5b31b05acc6	2	09:00:00	20:00:00
0567b8c1-c813-4c04-a883-7fb5d0ecdaca	chair	016ef339-c6f8-4c11-9055-f5b31b05acc6	3	09:00:00	20:00:00
1d739e7a-b768-4d64-ad69-313e1cc6ccd3	chair	016ef339-c6f8-4c11-9055-f5b31b05acc6	4	09:00:00	20:00:00
69fcaa47-987a-4057-9012-9be57efe7dc1	chair	016ef339-c6f8-4c11-9055-f5b31b05acc6	5	09:00:00	20:00:00
e551cadc-e020-4807-b89c-c2ee12e2f1b9	chair	016ef339-c6f8-4c11-9055-f5b31b05acc6	6	09:00:00	20:00:00
2de70bb9-184d-45a8-babc-5006b787416c	staff	1cbe7662-db99-4eab-8848-5b6a95dd1381	0	09:00:00	20:00:00
93096b91-1ccd-4b11-a14b-f27103017a21	staff	1cbe7662-db99-4eab-8848-5b6a95dd1381	1	09:00:00	20:00:00
2e51d7b3-6e1a-43b7-ac4c-93a280790b6c	staff	1cbe7662-db99-4eab-8848-5b6a95dd1381	2	09:00:00	20:00:00
062d0c43-f141-49cd-8052-bc9a12fb5fc5	staff	1cbe7662-db99-4eab-8848-5b6a95dd1381	3	09:00:00	20:00:00
b2243a5c-a0de-43f3-82b9-799c5ae2c66a	staff	1cbe7662-db99-4eab-8848-5b6a95dd1381	4	09:00:00	20:00:00
303e3347-b6c4-4506-bf31-0e979a916048	staff	1cbe7662-db99-4eab-8848-5b6a95dd1381	5	09:00:00	20:00:00
7ea0659f-a34b-4db5-a09d-2f45ccafcbc5	staff	1cbe7662-db99-4eab-8848-5b6a95dd1381	6	09:00:00	20:00:00
d64eca71-30e8-413b-a957-d77ef99bbfc0	chair	19b6bff0-ce2a-4670-9bee-dc094ec4ea49	0	09:00:00	20:00:00
f6859575-7f36-4a7c-9179-15005d565a33	chair	19b6bff0-ce2a-4670-9bee-dc094ec4ea49	1	09:00:00	20:00:00
e49c99fb-8836-44a4-bedb-95720667218e	chair	19b6bff0-ce2a-4670-9bee-dc094ec4ea49	2	09:00:00	20:00:00
a2aca0ea-fb6f-4c0c-ae8c-0f20508bf512	chair	19b6bff0-ce2a-4670-9bee-dc094ec4ea49	3	09:00:00	20:00:00
031958ce-7142-492c-a5f4-6bb9c690fc10	chair	19b6bff0-ce2a-4670-9bee-dc094ec4ea49	4	09:00:00	20:00:00
792a2f6d-d1b5-416c-9578-d21f19e60ad7	chair	19b6bff0-ce2a-4670-9bee-dc094ec4ea49	5	09:00:00	20:00:00
6c44eec8-f7f5-4758-be93-1b0b1f443b62	chair	19b6bff0-ce2a-4670-9bee-dc094ec4ea49	6	09:00:00	20:00:00
4e487dc9-91a5-4c2c-b848-1da45e73e15c	staff	fc75b105-1531-42ee-85b0-7bf0027240a4	0	09:00:00	20:00:00
21baf63b-7865-44cf-ad87-2094bf366ddd	staff	fc75b105-1531-42ee-85b0-7bf0027240a4	1	09:00:00	20:00:00
81ab8a1e-f952-482b-8bec-51f85bdc4309	staff	fc75b105-1531-42ee-85b0-7bf0027240a4	2	09:00:00	20:00:00
415977d0-0a99-4329-8fe9-6936c3de8fc0	staff	fc75b105-1531-42ee-85b0-7bf0027240a4	3	09:00:00	20:00:00
84e5d401-4ef7-4559-8c6e-2e054a5953e1	staff	fc75b105-1531-42ee-85b0-7bf0027240a4	4	09:00:00	20:00:00
2470738f-6ea3-44ed-b5e5-ede76fd6cc84	staff	fc75b105-1531-42ee-85b0-7bf0027240a4	5	09:00:00	20:00:00
af740bd4-7d7e-4cd1-8b3b-2eafb3663f50	staff	fc75b105-1531-42ee-85b0-7bf0027240a4	6	09:00:00	20:00:00
f2a66763-bf7b-4ccd-b19e-b2f0171d6a2d	chair	d30dd962-14de-4ef0-94ae-e99ea8fca2b8	0	09:00:00	20:00:00
4f9fc486-f478-488d-8fe2-bfe2725a1b98	chair	d30dd962-14de-4ef0-94ae-e99ea8fca2b8	1	09:00:00	20:00:00
f5fa39eb-a3b3-4877-816d-887c60e02c24	chair	d30dd962-14de-4ef0-94ae-e99ea8fca2b8	2	09:00:00	20:00:00
4fbbe55b-7f8e-407d-836a-8b2f76f94d36	chair	d30dd962-14de-4ef0-94ae-e99ea8fca2b8	3	09:00:00	20:00:00
2e9f15ba-4f5b-484a-a826-f7bad94147af	chair	d30dd962-14de-4ef0-94ae-e99ea8fca2b8	4	09:00:00	20:00:00
66e28d39-2328-44b5-82bd-d9ffdf095fb3	chair	d30dd962-14de-4ef0-94ae-e99ea8fca2b8	5	09:00:00	20:00:00
4a1706ed-b97e-4bd4-8035-a6cec871bf1f	chair	d30dd962-14de-4ef0-94ae-e99ea8fca2b8	6	09:00:00	20:00:00
7d1461f6-6e5a-4ba1-abaf-7f6d8b666f75	chair	2014b3ea-9336-4072-9fd5-7d5599065c8c	0	09:00:00	20:00:00
d1471c3b-baba-4b67-bd78-16e23a64256f	chair	2014b3ea-9336-4072-9fd5-7d5599065c8c	1	09:00:00	20:00:00
535a95ee-c0f4-4480-9bcd-7985e601d8b8	chair	2014b3ea-9336-4072-9fd5-7d5599065c8c	2	09:00:00	20:00:00
682c759d-5f76-457d-8509-7bcf5ca9894f	chair	2014b3ea-9336-4072-9fd5-7d5599065c8c	3	09:00:00	20:00:00
6a808a5f-c33a-4646-a3b1-e9efb8409d18	chair	2014b3ea-9336-4072-9fd5-7d5599065c8c	4	09:00:00	20:00:00
e37f553b-66e8-4885-a893-c588c8879684	chair	2014b3ea-9336-4072-9fd5-7d5599065c8c	5	09:00:00	20:00:00
1771357a-ed69-4d11-97af-6f3e511232d1	chair	2014b3ea-9336-4072-9fd5-7d5599065c8c	6	09:00:00	20:00:00
16268d78-d5a2-456d-a595-7ef152235430	staff	3f9e4c0c-0bdb-460e-982a-781f1baa2ca1	0	09:00:00	20:00:00
7c3c7167-11eb-48fb-b00c-f453f3699a6b	staff	3f9e4c0c-0bdb-460e-982a-781f1baa2ca1	1	09:00:00	20:00:00
48b15800-5243-4cac-b2b8-fee96c14efa4	staff	3f9e4c0c-0bdb-460e-982a-781f1baa2ca1	2	09:00:00	20:00:00
d0f4d845-4829-429b-bbfd-8e78c046c88f	staff	3f9e4c0c-0bdb-460e-982a-781f1baa2ca1	3	09:00:00	20:00:00
f90f7baf-e5b9-4123-9b8c-357113991877	staff	3f9e4c0c-0bdb-460e-982a-781f1baa2ca1	4	09:00:00	20:00:00
aa5a641d-96f0-45c6-a331-212d41ad2bb2	staff	3f9e4c0c-0bdb-460e-982a-781f1baa2ca1	5	09:00:00	20:00:00
d24f6ece-da91-4478-b80c-7cd831b5ce00	staff	3f9e4c0c-0bdb-460e-982a-781f1baa2ca1	6	09:00:00	20:00:00
2a8daeea-28ca-42be-bd28-76721a65925a	chair	f5372a28-1db2-4007-ba0f-d7ae09762a23	0	09:00:00	20:00:00
15f61f98-9679-4734-abda-b32d9f3d7e61	chair	f5372a28-1db2-4007-ba0f-d7ae09762a23	1	09:00:00	20:00:00
68be1cbb-4611-451f-af32-5ef33524b79c	chair	f5372a28-1db2-4007-ba0f-d7ae09762a23	2	09:00:00	20:00:00
62231968-3dd9-40ba-92fa-de0db0afb045	chair	f5372a28-1db2-4007-ba0f-d7ae09762a23	3	09:00:00	20:00:00
7eab5156-ca9e-4663-aec2-a826f35d4c1a	chair	f5372a28-1db2-4007-ba0f-d7ae09762a23	4	09:00:00	20:00:00
b1f9dd38-03dd-4de8-a842-af0bcd8e5689	chair	f5372a28-1db2-4007-ba0f-d7ae09762a23	5	09:00:00	20:00:00
a615fad4-c8c5-4771-be96-d3cfb5fe3d61	chair	f5372a28-1db2-4007-ba0f-d7ae09762a23	6	09:00:00	20:00:00
9df44d76-9861-4186-804f-a4386a21839b	staff	4077f0c8-2550-4fa7-9646-ffdb78ceb62d	0	09:00:00	20:00:00
336991e7-6fdc-4f9d-b35e-da3dcb7abc9a	staff	4077f0c8-2550-4fa7-9646-ffdb78ceb62d	1	09:00:00	20:00:00
d98dd6aa-6c61-42fb-83f9-2d8992a5a822	staff	4077f0c8-2550-4fa7-9646-ffdb78ceb62d	2	09:00:00	20:00:00
5eb12837-dee0-4472-ac4f-2853340211f0	staff	4077f0c8-2550-4fa7-9646-ffdb78ceb62d	3	09:00:00	20:00:00
5ba3f1f3-f089-4ae4-b83a-68357f9458c1	staff	4077f0c8-2550-4fa7-9646-ffdb78ceb62d	4	09:00:00	20:00:00
c0dd4602-88b8-4dcd-ab88-78fb76dfb4d5	staff	4077f0c8-2550-4fa7-9646-ffdb78ceb62d	5	09:00:00	20:00:00
04ac1ebf-ac8e-4701-abb3-434de1c842ca	staff	4077f0c8-2550-4fa7-9646-ffdb78ceb62d	6	09:00:00	20:00:00
790a940a-7c70-40c3-bbff-8c4feca3c4a8	chair	4ae84ba7-1789-4b69-a3f4-a15479ce45dd	0	09:00:00	20:00:00
44dff52b-f4bd-4788-9443-7529f2c82c28	chair	4ae84ba7-1789-4b69-a3f4-a15479ce45dd	1	09:00:00	20:00:00
c7f675a9-d965-4c2f-bd00-9df1e1966d3c	chair	4ae84ba7-1789-4b69-a3f4-a15479ce45dd	2	09:00:00	20:00:00
7bb99546-4f67-4a4f-95d5-33dbc3f12d64	chair	4ae84ba7-1789-4b69-a3f4-a15479ce45dd	3	09:00:00	20:00:00
1cf20de1-c71a-4a03-8275-2078ea99f0be	chair	4ae84ba7-1789-4b69-a3f4-a15479ce45dd	4	09:00:00	20:00:00
40bd88bd-fb73-4ed7-bcf7-062cda8d31cf	chair	4ae84ba7-1789-4b69-a3f4-a15479ce45dd	5	09:00:00	20:00:00
7847a8e9-1b34-40eb-b48a-b4843b1bea5d	chair	4ae84ba7-1789-4b69-a3f4-a15479ce45dd	6	09:00:00	20:00:00
9725d095-509f-4ecd-bbd8-a64fa4998f3d	staff	84a2f142-e502-43c7-9b33-3ea246f018c9	0	09:00:00	20:00:00
c4465bf6-aabe-487d-802b-cf1375bef77e	staff	84a2f142-e502-43c7-9b33-3ea246f018c9	1	09:00:00	20:00:00
261f2311-6c05-4896-933e-54035b3d7e99	staff	84a2f142-e502-43c7-9b33-3ea246f018c9	2	09:00:00	20:00:00
9b876f3a-73bd-4ad9-aa7e-0299eea07e51	staff	fa6ac291-9717-42c5-ad86-2f74b4fede1f	0	09:00:00	20:00:00
0ae85343-be1b-4a10-9da8-cdb1f7bf9696	staff	fa6ac291-9717-42c5-ad86-2f74b4fede1f	1	09:00:00	20:00:00
8a31115b-9fdb-475e-aa43-22d0ec3b8045	staff	fa6ac291-9717-42c5-ad86-2f74b4fede1f	2	09:00:00	20:00:00
bea88efc-9530-4004-9853-49315fed3979	staff	fa6ac291-9717-42c5-ad86-2f74b4fede1f	3	09:00:00	20:00:00
125aea21-86fd-4ee8-bc0a-aade385343c3	staff	fa6ac291-9717-42c5-ad86-2f74b4fede1f	4	09:00:00	20:00:00
0d822bb2-0660-439f-80a0-6d987b517b38	staff	fa6ac291-9717-42c5-ad86-2f74b4fede1f	5	09:00:00	20:00:00
f1e2ad87-bf49-4ca5-ab4a-11716470fd26	staff	fa6ac291-9717-42c5-ad86-2f74b4fede1f	6	09:00:00	20:00:00
ce12f51d-159f-4c32-8cc8-96528985c478	chair	7d488cac-2911-4bab-bf57-c138c664683a	0	09:00:00	20:00:00
3acef33a-6e21-4a98-a6fb-721583998e5c	chair	7d488cac-2911-4bab-bf57-c138c664683a	1	09:00:00	20:00:00
6d41a282-98e6-4ebd-89f4-b354ddf459bf	chair	7d488cac-2911-4bab-bf57-c138c664683a	2	09:00:00	20:00:00
6ad22281-f6d8-47c2-8163-2547415fe251	chair	7d488cac-2911-4bab-bf57-c138c664683a	3	09:00:00	20:00:00
8c33de6d-fb52-4b80-8997-2fd8cb2fee00	chair	7d488cac-2911-4bab-bf57-c138c664683a	4	09:00:00	20:00:00
ff0b25e7-e27f-4ce0-990c-70c0933a8241	chair	7d488cac-2911-4bab-bf57-c138c664683a	5	09:00:00	20:00:00
4a30f56b-1caa-496d-b9ac-c49a5c1456f3	chair	7d488cac-2911-4bab-bf57-c138c664683a	6	09:00:00	20:00:00
af189787-a5e6-4a0c-bf2a-5e4d44b610bd	staff	1395b536-0361-4a10-8419-3179ca49e76c	0	09:00:00	20:00:00
3ceb5d05-5a33-4982-a5e9-2665e8b3f738	staff	1395b536-0361-4a10-8419-3179ca49e76c	1	09:00:00	20:00:00
05cd7034-f72a-4e46-8a18-e91980284af7	staff	1395b536-0361-4a10-8419-3179ca49e76c	2	09:00:00	20:00:00
c35cffcb-fdde-4c44-8ef8-a2f930bd15c3	staff	1395b536-0361-4a10-8419-3179ca49e76c	3	09:00:00	20:00:00
a0db7c30-066a-4b0d-b928-7be7475f4c98	staff	1395b536-0361-4a10-8419-3179ca49e76c	4	09:00:00	20:00:00
e5f08ead-e0ae-44b3-8d26-2e65be2e607e	staff	1395b536-0361-4a10-8419-3179ca49e76c	5	09:00:00	20:00:00
f572316d-8261-43fe-bdaa-27da19baf343	staff	1395b536-0361-4a10-8419-3179ca49e76c	6	09:00:00	20:00:00
f433d2e2-8219-451e-89bd-30a60ff3fb16	chair	4ff6487b-8c36-4bca-b5aa-891220ea1473	0	09:00:00	20:00:00
e244181b-5f72-4aa2-8819-e590dbfb1145	chair	4ff6487b-8c36-4bca-b5aa-891220ea1473	1	09:00:00	20:00:00
891559ac-996e-4e62-9528-bba98f20fe19	chair	4ff6487b-8c36-4bca-b5aa-891220ea1473	2	09:00:00	20:00:00
366220df-d83a-4863-9558-75986e2651cf	chair	4ff6487b-8c36-4bca-b5aa-891220ea1473	3	09:00:00	20:00:00
c0a8873a-1eaa-4e50-99d1-7c579b4a5263	chair	4ff6487b-8c36-4bca-b5aa-891220ea1473	4	09:00:00	20:00:00
6e755e79-9104-431a-8ccd-8beb31d39c6e	chair	4ff6487b-8c36-4bca-b5aa-891220ea1473	5	09:00:00	20:00:00
d1dd9a49-6210-43d1-8758-f4c08e13b71f	chair	4ff6487b-8c36-4bca-b5aa-891220ea1473	6	09:00:00	20:00:00
9dc62b72-80ce-4339-ab28-060b78dd86e6	staff	a6162147-3017-49c0-94bc-8ad4a6b45efe	0	09:00:00	20:00:00
a3f9d0bc-8101-40a2-9114-b283bac2fbe3	staff	a6162147-3017-49c0-94bc-8ad4a6b45efe	1	09:00:00	20:00:00
427d1514-9731-41d6-bcc4-086ff917d376	staff	a6162147-3017-49c0-94bc-8ad4a6b45efe	2	09:00:00	20:00:00
f0191abe-a6e0-4c1b-891c-e35afe6bb18a	staff	a6162147-3017-49c0-94bc-8ad4a6b45efe	3	09:00:00	20:00:00
0cf4f2f6-5aa2-478a-9a2d-fd53e5b13669	staff	a6162147-3017-49c0-94bc-8ad4a6b45efe	4	09:00:00	20:00:00
543dfe2f-4f16-47bc-bed4-202382c05b21	staff	a6162147-3017-49c0-94bc-8ad4a6b45efe	5	09:00:00	20:00:00
516711ee-70fd-432e-bf7d-2a550396510a	staff	a6162147-3017-49c0-94bc-8ad4a6b45efe	6	09:00:00	20:00:00
80f8f9a1-b0ff-4dfa-8a5f-0cf6cdd37db3	chair	33fe5c2c-3241-48ae-b17c-20ab36783f0e	0	09:00:00	20:00:00
1619a391-eaf3-45dd-89f8-e0325dde6fc2	chair	33fe5c2c-3241-48ae-b17c-20ab36783f0e	1	09:00:00	20:00:00
056911f5-b8d3-48c0-b7e1-33e81c583d16	chair	33fe5c2c-3241-48ae-b17c-20ab36783f0e	2	09:00:00	20:00:00
988146eb-45b0-47a0-9e81-e4d3910bb9e5	chair	33fe5c2c-3241-48ae-b17c-20ab36783f0e	3	09:00:00	20:00:00
09c1e2b5-f124-424e-9189-fe31f3404b96	chair	33fe5c2c-3241-48ae-b17c-20ab36783f0e	4	09:00:00	20:00:00
9a172001-4d45-48d4-8f66-81d002f63c9f	chair	33fe5c2c-3241-48ae-b17c-20ab36783f0e	5	09:00:00	20:00:00
e3369e74-9189-4d00-86cc-889b65f458d8	chair	33fe5c2c-3241-48ae-b17c-20ab36783f0e	6	09:00:00	20:00:00
8c79e8af-905f-4967-9012-c8cc1dbc334d	staff	7027aca4-8600-4f60-80cd-403089095316	0	09:00:00	20:00:00
38eab226-dbe5-474c-ab2f-4c2f051e6568	staff	7027aca4-8600-4f60-80cd-403089095316	1	09:00:00	20:00:00
41265f13-c313-43bb-a86a-ef4ec2004d42	staff	7027aca4-8600-4f60-80cd-403089095316	2	09:00:00	20:00:00
691993eb-a500-456a-9614-ed03a46073f0	staff	7027aca4-8600-4f60-80cd-403089095316	3	09:00:00	20:00:00
695a7dd5-2093-4a09-8786-e8e501b8b83f	staff	7027aca4-8600-4f60-80cd-403089095316	4	09:00:00	20:00:00
17718c6d-a13a-4117-a10b-925bb07e7e33	staff	7027aca4-8600-4f60-80cd-403089095316	5	09:00:00	20:00:00
8aa3ebc9-72e6-4ef1-9d88-e1ef566338e1	staff	7027aca4-8600-4f60-80cd-403089095316	6	09:00:00	20:00:00
3db87b09-dcc8-4fcd-bf38-9526838dbeb6	chair	29e4dae1-ae20-42e7-9f6a-fb9ab686f6bb	0	09:00:00	20:00:00
2c7f8b63-96b1-4ae1-a5b3-c11a70295362	chair	29e4dae1-ae20-42e7-9f6a-fb9ab686f6bb	1	09:00:00	20:00:00
c07e4893-be32-41d8-a85c-52c0c7579dc7	chair	29e4dae1-ae20-42e7-9f6a-fb9ab686f6bb	2	09:00:00	20:00:00
9c2e6233-ff06-4e5b-a3d1-fa91058686a4	chair	29e4dae1-ae20-42e7-9f6a-fb9ab686f6bb	3	09:00:00	20:00:00
331e490c-4471-45b7-bf0c-b628b840300e	chair	29e4dae1-ae20-42e7-9f6a-fb9ab686f6bb	4	09:00:00	20:00:00
d5eda2b3-16fe-42b9-bed9-f2fc96e1d188	chair	29e4dae1-ae20-42e7-9f6a-fb9ab686f6bb	5	09:00:00	20:00:00
fa1bbe98-8e4b-4288-a5b8-d4f4831d6fa0	chair	29e4dae1-ae20-42e7-9f6a-fb9ab686f6bb	6	09:00:00	20:00:00
3ef6549e-26f9-4efa-a1d1-97e4ca8f82ee	staff	9e9484c4-b8f4-4772-8c34-1386dea27da5	0	09:00:00	20:00:00
9d326222-81ef-49cc-aee2-a5df63aadb56	staff	9e9484c4-b8f4-4772-8c34-1386dea27da5	1	09:00:00	20:00:00
69c54858-52f2-4452-9a1e-e6ed9afb5249	staff	9e9484c4-b8f4-4772-8c34-1386dea27da5	2	09:00:00	20:00:00
d372da60-dda1-49db-a067-d05a36843f36	staff	9e9484c4-b8f4-4772-8c34-1386dea27da5	3	09:00:00	20:00:00
11d60fd1-f73a-4915-9367-fd28e09d38ae	staff	9e9484c4-b8f4-4772-8c34-1386dea27da5	4	09:00:00	20:00:00
877e7496-dd00-485a-a149-362d602ba607	staff	9e9484c4-b8f4-4772-8c34-1386dea27da5	5	09:00:00	20:00:00
747cc2b5-10df-48e9-982e-a7afc17517e3	staff	9e9484c4-b8f4-4772-8c34-1386dea27da5	6	09:00:00	20:00:00
6cf581bf-cd52-4567-990c-998fd1e597bb	chair	5d19f810-97dc-4267-8793-dbca1f162b37	0	09:00:00	20:00:00
9e573d52-96d6-4d2b-8f33-4839b2d0a14d	chair	5d19f810-97dc-4267-8793-dbca1f162b37	1	09:00:00	20:00:00
953eb4ef-853b-43c9-9e61-ee856fb5102a	chair	5d19f810-97dc-4267-8793-dbca1f162b37	2	09:00:00	20:00:00
6faefa43-6bfe-406b-9006-885fb96cbe3b	chair	5d19f810-97dc-4267-8793-dbca1f162b37	3	09:00:00	20:00:00
81990d3e-ffe4-44e4-a690-abeae0fe051b	chair	5d19f810-97dc-4267-8793-dbca1f162b37	4	09:00:00	20:00:00
9bf80d3e-525a-4b54-8f68-970d836d6251	chair	5d19f810-97dc-4267-8793-dbca1f162b37	5	09:00:00	20:00:00
46edb65d-6e99-4663-93ca-0e0b937b127b	chair	5d19f810-97dc-4267-8793-dbca1f162b37	6	09:00:00	20:00:00
1e3dd124-e103-4ba8-be78-7dc2058d99b2	staff	4aad5407-7568-48b0-98b8-9e47f3c62c56	0	09:00:00	20:00:00
68c2817f-205e-48d0-b583-4f9498cc93c3	staff	4aad5407-7568-48b0-98b8-9e47f3c62c56	1	09:00:00	20:00:00
65bbafc5-4a68-4540-b2cb-ae234601b66f	staff	4aad5407-7568-48b0-98b8-9e47f3c62c56	2	09:00:00	20:00:00
e581b15b-ad6b-4093-b018-3a44c9cfa698	staff	4aad5407-7568-48b0-98b8-9e47f3c62c56	3	09:00:00	20:00:00
62e31482-1c10-4ba0-911a-60c00ada39fe	staff	4aad5407-7568-48b0-98b8-9e47f3c62c56	4	09:00:00	20:00:00
2210a6c1-2847-43d7-b8fa-872568f16b9a	staff	4aad5407-7568-48b0-98b8-9e47f3c62c56	5	09:00:00	20:00:00
0977e596-f49e-47d0-bc99-0f4756fc37ca	staff	4aad5407-7568-48b0-98b8-9e47f3c62c56	6	09:00:00	20:00:00
e99d581b-9dfd-4cc7-8e59-a2189c0b72f8	chair	bbf6d9b6-728c-4d75-a2a8-a7abe3c77372	0	09:00:00	20:00:00
17bafc81-a45c-4c00-8abe-0a7c261edb03	chair	bbf6d9b6-728c-4d75-a2a8-a7abe3c77372	1	09:00:00	20:00:00
296bc433-6c87-4c60-95e5-29f105aa9a44	chair	bbf6d9b6-728c-4d75-a2a8-a7abe3c77372	2	09:00:00	20:00:00
46fa6600-f0c6-476a-bdcb-1f41f4230abe	chair	bbf6d9b6-728c-4d75-a2a8-a7abe3c77372	3	09:00:00	20:00:00
e1e704f5-9e31-48d1-8077-d45c5c7ce82a	chair	bbf6d9b6-728c-4d75-a2a8-a7abe3c77372	4	09:00:00	20:00:00
f76c63bf-00a4-4a0a-8358-0e5b4cf8e5b0	chair	bbf6d9b6-728c-4d75-a2a8-a7abe3c77372	5	09:00:00	20:00:00
6edec3dd-09ce-4a3b-9a41-b2b5c14f0eff	chair	bbf6d9b6-728c-4d75-a2a8-a7abe3c77372	6	09:00:00	20:00:00
c48f5197-e67e-44cf-802b-9dca577fb595	staff	650d3737-68bf-4f17-8588-c572a0a07878	0	09:00:00	20:00:00
45f18afd-ec49-4189-a60a-298cadaf0151	staff	650d3737-68bf-4f17-8588-c572a0a07878	1	09:00:00	20:00:00
7a7ab4a9-ae66-43aa-818b-acaed3adbda9	staff	650d3737-68bf-4f17-8588-c572a0a07878	2	09:00:00	20:00:00
10f26a80-9532-46d8-ba7e-b06e6f13f307	staff	650d3737-68bf-4f17-8588-c572a0a07878	3	09:00:00	20:00:00
f612b703-bb9a-4b67-8895-e18382e87e73	staff	650d3737-68bf-4f17-8588-c572a0a07878	4	09:00:00	20:00:00
9f5a8ba9-171c-4709-a197-97f0dcc7763b	staff	650d3737-68bf-4f17-8588-c572a0a07878	5	09:00:00	20:00:00
5b9be712-e2f6-4056-9ea5-7f301b6a7cc3	staff	650d3737-68bf-4f17-8588-c572a0a07878	6	09:00:00	20:00:00
28450498-d87c-4a49-b5a5-627de570da64	chair	07f4e02f-2563-4504-a2f3-56347f813b39	0	09:00:00	20:00:00
6d68e3e5-01c9-41e3-b4f9-2a5b2d68c008	chair	07f4e02f-2563-4504-a2f3-56347f813b39	1	09:00:00	20:00:00
0dbd6b15-17e9-43d5-aa45-8aa1406447b1	chair	07f4e02f-2563-4504-a2f3-56347f813b39	2	09:00:00	20:00:00
e55cb871-8d3d-4d41-b61c-c992a032b8f6	chair	07f4e02f-2563-4504-a2f3-56347f813b39	3	09:00:00	20:00:00
a23a596c-a510-451f-9834-31fb0c40e894	chair	07f4e02f-2563-4504-a2f3-56347f813b39	4	09:00:00	20:00:00
be9bdd86-4e2e-420c-a6dc-96f2d7907a94	chair	07f4e02f-2563-4504-a2f3-56347f813b39	5	09:00:00	20:00:00
512ff0ff-4df2-43f2-9235-19e8b74464e2	chair	07f4e02f-2563-4504-a2f3-56347f813b39	6	09:00:00	20:00:00
8bebd61e-3bec-4028-8886-40b3e2095b7b	chair	caa377db-dabe-4ec6-aeff-3b1339fd21d8	0	09:00:00	20:00:00
289d181c-0009-4b7f-b172-3de5cc960919	chair	caa377db-dabe-4ec6-aeff-3b1339fd21d8	1	09:00:00	20:00:00
88c46627-3c8c-484a-bde0-d5e0b8c3e750	chair	caa377db-dabe-4ec6-aeff-3b1339fd21d8	2	09:00:00	20:00:00
1b08c329-bb90-4811-8c1e-b083e6164fd6	chair	caa377db-dabe-4ec6-aeff-3b1339fd21d8	3	09:00:00	20:00:00
31b38be7-bde8-4e1a-97b1-afebaa9a132b	chair	caa377db-dabe-4ec6-aeff-3b1339fd21d8	4	09:00:00	20:00:00
6c465c89-39f2-4180-a5cf-4af56b518ad7	chair	caa377db-dabe-4ec6-aeff-3b1339fd21d8	5	09:00:00	20:00:00
684e37fd-8527-4a38-94f3-5ac5d7a7e804	chair	caa377db-dabe-4ec6-aeff-3b1339fd21d8	6	09:00:00	20:00:00
8336196c-77f3-4be4-99e6-183d70f00ad5	staff	c3d76a47-47ab-4f5f-bcc2-eddd9477559e	0	09:00:00	20:00:00
ec7f07f2-f0d4-42ee-b844-4c5594c65ceb	staff	c3d76a47-47ab-4f5f-bcc2-eddd9477559e	1	09:00:00	20:00:00
a7867bb1-a2c4-45b3-8106-fa7b8728ddc4	staff	c3d76a47-47ab-4f5f-bcc2-eddd9477559e	2	09:00:00	20:00:00
da12b2b1-a3b3-4205-a8dd-40fc69e41646	staff	c3d76a47-47ab-4f5f-bcc2-eddd9477559e	3	09:00:00	20:00:00
b0dface8-e6b0-40c0-8074-69c3f2c1be33	staff	c3d76a47-47ab-4f5f-bcc2-eddd9477559e	4	09:00:00	20:00:00
36bab535-8889-4de4-a37c-4ce71c43b70d	staff	c3d76a47-47ab-4f5f-bcc2-eddd9477559e	5	09:00:00	20:00:00
4d5f2c30-6942-4b74-9346-f80c9b8081ff	staff	c3d76a47-47ab-4f5f-bcc2-eddd9477559e	6	09:00:00	20:00:00
b6f24467-27eb-4e5a-ada3-0ef91038dd5b	chair	7491c8e1-7f0f-4fd0-b659-9dcadc6cb92a	0	09:00:00	20:00:00
4b2e4ab7-54e0-47d6-9019-c5ea4d9b34f7	chair	7491c8e1-7f0f-4fd0-b659-9dcadc6cb92a	1	09:00:00	20:00:00
4abce274-3e19-45f7-82be-894fd61b6004	chair	7491c8e1-7f0f-4fd0-b659-9dcadc6cb92a	2	09:00:00	20:00:00
f4347e06-afc7-451c-b1e8-139bc44d6bb1	chair	7491c8e1-7f0f-4fd0-b659-9dcadc6cb92a	3	09:00:00	20:00:00
c0ab8b6e-1a93-4012-862d-0652a8864281	chair	7491c8e1-7f0f-4fd0-b659-9dcadc6cb92a	4	09:00:00	20:00:00
39ca2074-69d4-4f36-879b-a5fa3d3584c8	chair	7491c8e1-7f0f-4fd0-b659-9dcadc6cb92a	5	09:00:00	20:00:00
111243e8-4d0a-418e-a468-11869e1e63a7	chair	7491c8e1-7f0f-4fd0-b659-9dcadc6cb92a	6	09:00:00	20:00:00
fc788797-8779-4477-9c5d-71ed462b101a	staff	b6ad00d3-1c8d-45b7-957b-8dc075467d23	0	09:00:00	20:00:00
1b6e7e5b-adae-4728-9b69-cd352b918741	staff	b6ad00d3-1c8d-45b7-957b-8dc075467d23	1	09:00:00	20:00:00
71738a21-4315-40a6-8461-9d359ebc219e	staff	b6ad00d3-1c8d-45b7-957b-8dc075467d23	2	09:00:00	20:00:00
c5de2e8a-896d-4bf3-8a38-835010fe15f3	staff	b6ad00d3-1c8d-45b7-957b-8dc075467d23	3	09:00:00	20:00:00
d8ea8c32-a771-4135-b7e3-28bbda9b35bb	staff	b6ad00d3-1c8d-45b7-957b-8dc075467d23	4	09:00:00	20:00:00
ad821d09-b5cc-40f5-acd8-980454cb1453	staff	b6ad00d3-1c8d-45b7-957b-8dc075467d23	5	09:00:00	20:00:00
dcdffc7d-0804-49c3-a30f-be2c5ae4500d	staff	b6ad00d3-1c8d-45b7-957b-8dc075467d23	6	09:00:00	20:00:00
2d15fcd4-1667-46b1-8bcd-2bd46a76d5da	chair	8f248581-4277-42ba-9233-0e1887a7f425	0	09:00:00	20:00:00
be754e6a-08ae-4d85-81d9-58a8c901af03	chair	8f248581-4277-42ba-9233-0e1887a7f425	1	09:00:00	20:00:00
4eef6874-0965-4993-86dd-ac462b210db9	chair	8f248581-4277-42ba-9233-0e1887a7f425	2	09:00:00	20:00:00
5f004657-0e86-49ae-92fb-cf9cacd37aa2	chair	8f248581-4277-42ba-9233-0e1887a7f425	3	09:00:00	20:00:00
b337eea6-d600-48e9-a972-b33c59ca7ca5	chair	8f248581-4277-42ba-9233-0e1887a7f425	4	09:00:00	20:00:00
c5236e1c-c466-4cd3-a548-6e918d5ea73c	chair	8f248581-4277-42ba-9233-0e1887a7f425	5	09:00:00	20:00:00
56c72a4c-e9eb-4082-bc66-5a30e00aaf74	chair	8f248581-4277-42ba-9233-0e1887a7f425	6	09:00:00	20:00:00
1e3523b0-005e-4ccc-b056-04bbd2065c29	staff	cd9add27-87da-4373-a524-97759e0ae44a	0	09:00:00	20:00:00
89f70c1d-9060-406b-be5f-d0d2fbe1491a	staff	cd9add27-87da-4373-a524-97759e0ae44a	1	09:00:00	20:00:00
42b55f00-64a0-401b-a6fa-61c904b57740	staff	cd9add27-87da-4373-a524-97759e0ae44a	2	09:00:00	20:00:00
ea7d2f7e-0d6b-4516-b50b-3f79bdfa4ff6	staff	cd9add27-87da-4373-a524-97759e0ae44a	3	09:00:00	20:00:00
18a8da0d-154c-417b-97e6-86ce3e20b93e	staff	cd9add27-87da-4373-a524-97759e0ae44a	4	09:00:00	20:00:00
1528e441-d1ef-436e-97da-d35dbc2bca8e	staff	cd9add27-87da-4373-a524-97759e0ae44a	5	09:00:00	20:00:00
65090804-deca-4af0-8944-6a43aec281f6	staff	cd9add27-87da-4373-a524-97759e0ae44a	6	09:00:00	20:00:00
6b84a6f0-b75a-4450-b7c3-ca29c5e9cc9d	chair	bf2f3d12-7844-42ae-ac7c-2d6d0cccc210	0	09:00:00	20:00:00
73223ecd-3f7d-4524-aa17-e5cfedcea60f	chair	bf2f3d12-7844-42ae-ac7c-2d6d0cccc210	1	09:00:00	20:00:00
71014ddd-0a39-4a74-9f7a-69dff9806b2e	chair	bf2f3d12-7844-42ae-ac7c-2d6d0cccc210	2	09:00:00	20:00:00
254ad8a3-1a59-4948-9bb1-343b1d97b753	chair	bf2f3d12-7844-42ae-ac7c-2d6d0cccc210	3	09:00:00	20:00:00
b8b1b7f2-6f70-4f9f-bacb-4d1033371ca3	chair	bf2f3d12-7844-42ae-ac7c-2d6d0cccc210	4	09:00:00	20:00:00
853b42ae-8a47-4fc3-812e-6690ba2c541e	chair	bf2f3d12-7844-42ae-ac7c-2d6d0cccc210	5	09:00:00	20:00:00
4039d66c-c376-46b7-acbf-8b2859fff6a1	chair	bf2f3d12-7844-42ae-ac7c-2d6d0cccc210	6	09:00:00	20:00:00
a5039161-e8e8-4e35-b57c-076c943639a0	staff	a9955774-e41d-4176-aff4-b10e51138abf	0	09:00:00	20:00:00
99b9b6c8-de9c-46f5-85f6-2be1e15cdce0	staff	a9955774-e41d-4176-aff4-b10e51138abf	1	09:00:00	20:00:00
28755b6a-4644-40c7-ae59-6ec438c45af8	staff	a9955774-e41d-4176-aff4-b10e51138abf	2	09:00:00	20:00:00
9d89388b-216e-4508-94de-bed4eb7b05fd	staff	a9955774-e41d-4176-aff4-b10e51138abf	3	09:00:00	20:00:00
5aefca28-e9e7-4957-b16d-c4d08ff23480	staff	a9955774-e41d-4176-aff4-b10e51138abf	4	09:00:00	20:00:00
0096d9ca-e76c-4099-ae31-fc14c893fd55	staff	a9955774-e41d-4176-aff4-b10e51138abf	5	09:00:00	20:00:00
c5804c82-d6f1-4006-b32a-e649248ee323	staff	a9955774-e41d-4176-aff4-b10e51138abf	6	09:00:00	20:00:00
394aceca-5789-46ec-83a4-c20a7a29c11f	chair	f26d6dd6-26a1-49fc-8d09-762d3e46432d	0	09:00:00	20:00:00
53aa1a50-9b2b-443e-8498-0729d3c72fc1	chair	f26d6dd6-26a1-49fc-8d09-762d3e46432d	1	09:00:00	20:00:00
4e71d7f5-6411-4463-9ee6-a52a9b431da2	chair	f26d6dd6-26a1-49fc-8d09-762d3e46432d	2	09:00:00	20:00:00
7ac7f579-b3f0-4552-b3bf-26d5a8a1696c	chair	f26d6dd6-26a1-49fc-8d09-762d3e46432d	3	09:00:00	20:00:00
24a6c784-771b-4b40-84c8-f7ea16544b36	chair	f26d6dd6-26a1-49fc-8d09-762d3e46432d	4	09:00:00	20:00:00
3d02e9f6-6555-43b9-80ad-584a146bef36	chair	f26d6dd6-26a1-49fc-8d09-762d3e46432d	5	09:00:00	20:00:00
ca6946b8-8d6a-48ad-b887-ce649490c1ea	chair	f26d6dd6-26a1-49fc-8d09-762d3e46432d	6	09:00:00	20:00:00
859ea656-3aa3-4912-b0a3-4b442ff4f153	staff	f51656f2-d836-45ed-8445-71ad1bd2645c	0	09:00:00	20:00:00
395ab065-5e45-49bc-b72d-76b3fb87e9eb	staff	f51656f2-d836-45ed-8445-71ad1bd2645c	1	09:00:00	20:00:00
31406a9b-fca5-464c-8cf2-25ea82b97b71	staff	f51656f2-d836-45ed-8445-71ad1bd2645c	2	09:00:00	20:00:00
c2bd25a2-23da-4d0f-8ebb-ff42674053ce	staff	f51656f2-d836-45ed-8445-71ad1bd2645c	3	09:00:00	20:00:00
3bb2c476-d329-4af0-8d6b-aadb8d92538c	staff	f51656f2-d836-45ed-8445-71ad1bd2645c	4	09:00:00	20:00:00
53adf038-7493-4c38-897a-9778b0a5986c	staff	f51656f2-d836-45ed-8445-71ad1bd2645c	5	09:00:00	20:00:00
9572d2b6-b171-4ef2-a64c-171596746990	staff	f51656f2-d836-45ed-8445-71ad1bd2645c	6	09:00:00	20:00:00
4c26ad02-4991-4390-82be-26a76a48a0e2	chair	2f3706f2-fad9-4665-a5f4-821ebae3b5a4	0	09:00:00	20:00:00
09a950e4-4e2d-43aa-b461-e8e64a451715	chair	2f3706f2-fad9-4665-a5f4-821ebae3b5a4	1	09:00:00	20:00:00
7fb40cc0-2ef0-4525-b010-efac00872739	chair	2f3706f2-fad9-4665-a5f4-821ebae3b5a4	2	09:00:00	20:00:00
64726e61-1d73-44db-a548-89312fed8bab	chair	2f3706f2-fad9-4665-a5f4-821ebae3b5a4	3	09:00:00	20:00:00
0987c397-3005-463e-b745-9f68b50fb995	chair	2f3706f2-fad9-4665-a5f4-821ebae3b5a4	4	09:00:00	20:00:00
dd357e64-be77-4ec1-ac6b-ffb8de52e359	chair	2f3706f2-fad9-4665-a5f4-821ebae3b5a4	5	09:00:00	20:00:00
a4916a29-77ad-40e5-bda9-3a7dfbed252e	chair	2f3706f2-fad9-4665-a5f4-821ebae3b5a4	6	09:00:00	20:00:00
c2a0b5b6-8922-4150-a500-7a7f993d47ea	staff	6a884cc4-f0a9-4dc6-adb7-4b3bfa4a55a3	0	09:00:00	20:00:00
9ca3b4cb-4c8c-4899-8226-bfdaa8b932de	staff	6a884cc4-f0a9-4dc6-adb7-4b3bfa4a55a3	1	09:00:00	20:00:00
1b67f107-2fae-44ba-9966-cea3bad731b7	staff	6a884cc4-f0a9-4dc6-adb7-4b3bfa4a55a3	2	09:00:00	20:00:00
c57f0b67-8245-4b22-8b88-145ebc3dc2ba	staff	6a884cc4-f0a9-4dc6-adb7-4b3bfa4a55a3	3	09:00:00	20:00:00
a2f15a37-cce6-4499-90a1-00efc4a46bd7	staff	6a884cc4-f0a9-4dc6-adb7-4b3bfa4a55a3	4	09:00:00	20:00:00
d2e01725-7790-4c45-9fa1-a3b39e563020	staff	6a884cc4-f0a9-4dc6-adb7-4b3bfa4a55a3	5	09:00:00	20:00:00
6b796ea8-3165-47a4-9ad9-bf9df87e9a80	staff	6a884cc4-f0a9-4dc6-adb7-4b3bfa4a55a3	6	09:00:00	20:00:00
bfc4b060-73e2-45bb-85b6-7c4f2c33f1b9	chair	e7ef16aa-d2c4-4c72-a6a4-cabbe448fa19	0	09:00:00	20:00:00
d913985a-194d-40e0-9d6b-17093764bde2	chair	e7ef16aa-d2c4-4c72-a6a4-cabbe448fa19	1	09:00:00	20:00:00
992b0fb0-c97d-4cf0-8b49-57ba706d119b	chair	e7ef16aa-d2c4-4c72-a6a4-cabbe448fa19	2	09:00:00	20:00:00
4afcf212-b8ef-48cf-bd0f-07d01639eda9	chair	e7ef16aa-d2c4-4c72-a6a4-cabbe448fa19	3	09:00:00	20:00:00
d6c3a282-9dac-48cf-abbf-7442a498fac9	chair	e7ef16aa-d2c4-4c72-a6a4-cabbe448fa19	4	09:00:00	20:00:00
01629bbd-9744-4c82-97a5-c07b330abc34	chair	e7ef16aa-d2c4-4c72-a6a4-cabbe448fa19	5	09:00:00	20:00:00
733b08cc-0bdd-4dd6-83ae-fd5f6fd52f3d	chair	e7ef16aa-d2c4-4c72-a6a4-cabbe448fa19	6	09:00:00	20:00:00
21f4e2a1-56f5-4167-beb4-2e8bc2885e13	staff	0b602742-598d-4d2c-b414-fb497ab0ff4b	0	09:00:00	20:00:00
42ae9ff9-fc7b-437e-b3ad-ed990bfe05b7	staff	0b602742-598d-4d2c-b414-fb497ab0ff4b	1	09:00:00	20:00:00
ef019aa7-b136-4b14-9ce1-139fd0b7fd4c	staff	0b602742-598d-4d2c-b414-fb497ab0ff4b	2	09:00:00	20:00:00
1d169c63-661b-41ff-afb5-0bde1879deca	staff	0b602742-598d-4d2c-b414-fb497ab0ff4b	3	09:00:00	20:00:00
a18b8b51-ba2d-4b2d-bebf-ac541e5d9fa1	staff	0b602742-598d-4d2c-b414-fb497ab0ff4b	4	09:00:00	20:00:00
62129bba-8860-47fc-ae63-194ae416e1ad	staff	0b602742-598d-4d2c-b414-fb497ab0ff4b	5	09:00:00	20:00:00
afd00f95-2ff7-4561-be8d-a1035ace073e	staff	0b602742-598d-4d2c-b414-fb497ab0ff4b	6	09:00:00	20:00:00
b5b0487a-e3a0-4590-a049-11b21fd1161e	chair	088c9625-be10-48f4-9ecc-12016efc8946	0	09:00:00	20:00:00
c2b6fb6e-f798-404a-a323-ff975fc5fc79	chair	088c9625-be10-48f4-9ecc-12016efc8946	1	09:00:00	20:00:00
2194a6dc-6a20-4e5e-b91e-adab046b6f2e	chair	088c9625-be10-48f4-9ecc-12016efc8946	2	09:00:00	20:00:00
ba82d5d4-f5ea-4c73-8c6b-fcfa9b4e6be7	chair	088c9625-be10-48f4-9ecc-12016efc8946	3	09:00:00	20:00:00
ff35c72e-76f6-46c2-96e0-9376a8117d9a	chair	088c9625-be10-48f4-9ecc-12016efc8946	4	09:00:00	20:00:00
6c4e11bd-e2f8-4ea2-b080-448e5924abc6	chair	088c9625-be10-48f4-9ecc-12016efc8946	5	09:00:00	20:00:00
a8d52880-9519-4d9e-be27-679b878647ec	chair	088c9625-be10-48f4-9ecc-12016efc8946	6	09:00:00	20:00:00
dd672767-fec5-48ff-b355-73808d305b85	staff	a982ce4d-722f-4959-866b-8313f8529808	0	09:00:00	20:00:00
f4cee31b-10a1-4aeb-bac9-1303c915f710	staff	a982ce4d-722f-4959-866b-8313f8529808	1	09:00:00	20:00:00
3f5a4acc-488e-41e2-960a-84aa2e128b22	staff	a982ce4d-722f-4959-866b-8313f8529808	2	09:00:00	20:00:00
aa9bdbe1-ad5c-4a48-86dd-a9e373436e1e	staff	a982ce4d-722f-4959-866b-8313f8529808	3	09:00:00	20:00:00
e2ef3e6a-7e96-4917-87f3-960c95af1433	staff	a982ce4d-722f-4959-866b-8313f8529808	4	09:00:00	20:00:00
4da2f8c9-e875-4e30-b4f7-9be5785fc478	staff	a982ce4d-722f-4959-866b-8313f8529808	5	09:00:00	20:00:00
5f29de29-40f5-49bc-86c1-762d2ff6f397	staff	a982ce4d-722f-4959-866b-8313f8529808	6	09:00:00	20:00:00
0ef16cff-01e3-488a-b6c1-32964ce5018f	chair	35ba7219-9242-4bef-bca2-c8c25232bbc2	0	09:00:00	20:00:00
87243a97-0f0b-42d0-8159-332956234ece	chair	35ba7219-9242-4bef-bca2-c8c25232bbc2	1	09:00:00	20:00:00
fc18b90f-9800-4861-a9d2-ba37225a123d	chair	35ba7219-9242-4bef-bca2-c8c25232bbc2	2	09:00:00	20:00:00
34cd4e69-72b6-4adf-be8c-c0ea67c004a1	chair	35ba7219-9242-4bef-bca2-c8c25232bbc2	3	09:00:00	20:00:00
d673fc58-6df8-470f-9fc7-c6808b162abe	chair	35ba7219-9242-4bef-bca2-c8c25232bbc2	4	09:00:00	20:00:00
4c94d328-6619-4702-8cc0-ce1dbcb0a4ac	chair	35ba7219-9242-4bef-bca2-c8c25232bbc2	5	09:00:00	20:00:00
2a39b4d1-dd58-496d-a670-a50ef9027fe2	chair	35ba7219-9242-4bef-bca2-c8c25232bbc2	6	09:00:00	20:00:00
94a552b8-738f-4dc1-a1ee-43c20c853f1e	staff	babac6b1-5c81-44cc-8ccf-7540e17c412c	0	09:00:00	20:00:00
a1a22d8f-58a3-4996-9aaa-ad85cdeed637	staff	babac6b1-5c81-44cc-8ccf-7540e17c412c	1	09:00:00	20:00:00
6d74e099-8a5c-4134-ad51-813346c89b19	staff	babac6b1-5c81-44cc-8ccf-7540e17c412c	2	09:00:00	20:00:00
8ee59643-3743-4cd1-808a-35b1bb32c13c	staff	babac6b1-5c81-44cc-8ccf-7540e17c412c	3	09:00:00	20:00:00
c7c9863b-e0ce-4540-a274-ef6966b5562d	staff	babac6b1-5c81-44cc-8ccf-7540e17c412c	4	09:00:00	20:00:00
fb3c1d4e-2e71-4afc-b147-05540d12d454	staff	babac6b1-5c81-44cc-8ccf-7540e17c412c	5	09:00:00	20:00:00
bb3143db-b9f6-4f24-a728-5c091c37134e	staff	babac6b1-5c81-44cc-8ccf-7540e17c412c	6	09:00:00	20:00:00
631d0f8e-f6c8-48ff-951e-d1639acbf111	chair	c2d90014-ae59-44c5-8bee-eed3ce7b0190	0	09:00:00	20:00:00
2395d162-d86f-47c1-a81a-bf065f505271	chair	c2d90014-ae59-44c5-8bee-eed3ce7b0190	1	09:00:00	20:00:00
8b5a8d60-b876-4e46-8770-d86e4e074948	chair	c2d90014-ae59-44c5-8bee-eed3ce7b0190	2	09:00:00	20:00:00
71efffe6-e421-4908-a841-2194386b1be9	chair	c2d90014-ae59-44c5-8bee-eed3ce7b0190	3	09:00:00	20:00:00
176f8f75-9b84-47a1-826f-17394434f7b5	chair	c2d90014-ae59-44c5-8bee-eed3ce7b0190	4	09:00:00	20:00:00
ac809d03-0a39-40e7-9e81-f99592f9c806	chair	c2d90014-ae59-44c5-8bee-eed3ce7b0190	5	09:00:00	20:00:00
78c8fccc-29a1-49d4-83ee-1560a6444c40	chair	c2d90014-ae59-44c5-8bee-eed3ce7b0190	6	09:00:00	20:00:00
27c50e99-9bc9-4b75-9834-4484f624dfc4	staff	66d1ac86-a39a-45ca-b78d-c4e4cc770794	0	09:00:00	20:00:00
20b5a02f-b0b8-4b1a-babe-b909f21009b9	staff	66d1ac86-a39a-45ca-b78d-c4e4cc770794	1	09:00:00	20:00:00
7f3fdef0-ee97-4e5f-b1ea-cf12809f33a6	staff	66d1ac86-a39a-45ca-b78d-c4e4cc770794	2	09:00:00	20:00:00
c02c7cc2-7744-401d-b665-747fe69a9b3b	staff	66d1ac86-a39a-45ca-b78d-c4e4cc770794	3	09:00:00	20:00:00
a7343944-0634-4cf8-9523-71b8d3a7c26a	staff	66d1ac86-a39a-45ca-b78d-c4e4cc770794	4	09:00:00	20:00:00
46cbaa2e-edbe-4147-931d-b2a819777a6b	staff	66d1ac86-a39a-45ca-b78d-c4e4cc770794	5	09:00:00	20:00:00
42e40a7f-1996-49a0-a5af-40656df7888d	staff	66d1ac86-a39a-45ca-b78d-c4e4cc770794	6	09:00:00	20:00:00
9681e278-f7a3-474d-92ab-761a424971d9	chair	39df6082-dfdb-46d0-94b7-4698bd30feda	0	09:00:00	20:00:00
97951702-b8b3-410c-8fe6-2c95f7c380f4	chair	39df6082-dfdb-46d0-94b7-4698bd30feda	1	09:00:00	20:00:00
d996e9aa-c5e6-41e5-8e2a-a45af927d912	chair	39df6082-dfdb-46d0-94b7-4698bd30feda	2	09:00:00	20:00:00
704f5be2-9474-4dc2-9c08-a415c7f9a4b1	chair	39df6082-dfdb-46d0-94b7-4698bd30feda	3	09:00:00	20:00:00
33e9cd8a-a6b7-4425-8bf5-dd9e304d317f	chair	39df6082-dfdb-46d0-94b7-4698bd30feda	4	09:00:00	20:00:00
e585e1a1-4c25-47ac-a622-837a38906990	chair	39df6082-dfdb-46d0-94b7-4698bd30feda	5	09:00:00	20:00:00
6a5f0ed9-b773-4fe4-b325-c6402aa9e9be	chair	39df6082-dfdb-46d0-94b7-4698bd30feda	6	09:00:00	20:00:00
a82c54b4-7dd6-40ff-9031-7ef494e5bf54	staff	f7e45782-fba2-4281-a66e-9caf61791e0b	0	09:00:00	20:00:00
8b7af7b9-fc46-48a0-b122-af23e644d70a	staff	f7e45782-fba2-4281-a66e-9caf61791e0b	1	09:00:00	20:00:00
b76f5d9a-41e5-4048-82c7-955d3ec55d87	staff	f7e45782-fba2-4281-a66e-9caf61791e0b	2	09:00:00	20:00:00
06168f9d-c4c3-4362-8be8-01e314844537	staff	f7e45782-fba2-4281-a66e-9caf61791e0b	3	09:00:00	20:00:00
9cb99f66-92cb-4f7f-8c78-6dfaff3113ca	staff	f7e45782-fba2-4281-a66e-9caf61791e0b	4	09:00:00	20:00:00
a9894a3c-60f0-4901-84fa-f470d1ffa4b8	staff	f7e45782-fba2-4281-a66e-9caf61791e0b	5	09:00:00	20:00:00
50c6f123-027b-44f4-a70c-b21cfe50af5f	staff	f7e45782-fba2-4281-a66e-9caf61791e0b	6	09:00:00	20:00:00
38778900-784a-4956-8342-a5d23b75c772	chair	b86878bc-d76d-4303-9ab4-7780a23c1e17	0	09:00:00	20:00:00
a2978e59-f104-45f0-83bb-6bfc171f2900	chair	b86878bc-d76d-4303-9ab4-7780a23c1e17	1	09:00:00	20:00:00
f4cc4a5a-aa86-443c-ab12-f4655a4730d9	chair	b86878bc-d76d-4303-9ab4-7780a23c1e17	2	09:00:00	20:00:00
8d798016-819b-4af1-b351-b315e5b2cc6a	chair	b86878bc-d76d-4303-9ab4-7780a23c1e17	3	09:00:00	20:00:00
ccaaf3ec-0bcd-415d-9971-4e5e061c3372	chair	b86878bc-d76d-4303-9ab4-7780a23c1e17	4	09:00:00	20:00:00
0cb23738-091d-4028-85ff-d5a3290a63e1	chair	b86878bc-d76d-4303-9ab4-7780a23c1e17	5	09:00:00	20:00:00
3872784e-2260-409d-acc2-98ab96c99d13	chair	b86878bc-d76d-4303-9ab4-7780a23c1e17	6	09:00:00	20:00:00
22bcc520-6b35-446c-9563-e68c022d2ceb	staff	82935ae9-bab1-4805-ba62-20e4f6b880e9	0	09:00:00	20:00:00
5bbaaa6f-c05a-45a7-96ba-ab446d1f05f4	staff	82935ae9-bab1-4805-ba62-20e4f6b880e9	1	09:00:00	20:00:00
fdd2d936-d590-4e8d-ad49-fe99b80b51e5	staff	82935ae9-bab1-4805-ba62-20e4f6b880e9	2	09:00:00	20:00:00
1ec130c3-9093-4e9d-bad5-3e06a999e91d	staff	82935ae9-bab1-4805-ba62-20e4f6b880e9	3	09:00:00	20:00:00
a0203daf-d3cd-4d67-afd7-9ba90a3117a5	staff	82935ae9-bab1-4805-ba62-20e4f6b880e9	4	09:00:00	20:00:00
50e52b59-25d0-4d7b-8720-86b2fefba6b1	staff	82935ae9-bab1-4805-ba62-20e4f6b880e9	5	09:00:00	20:00:00
a179d634-a9c4-4444-bdb2-3763dbc5db86	staff	82935ae9-bab1-4805-ba62-20e4f6b880e9	6	09:00:00	20:00:00
42af73e5-9df7-423a-95bc-2aadc3957595	chair	7f7f9c56-8bc8-4eaf-9d1a-50a302270d88	0	09:00:00	20:00:00
33b81da3-ef50-4425-a45a-031c96232e0b	chair	7f7f9c56-8bc8-4eaf-9d1a-50a302270d88	1	09:00:00	20:00:00
82ad1584-76a0-4e98-83e5-91524a8b24e2	chair	7f7f9c56-8bc8-4eaf-9d1a-50a302270d88	2	09:00:00	20:00:00
573b7587-e813-46c3-bdf5-be0d8f61e044	chair	7f7f9c56-8bc8-4eaf-9d1a-50a302270d88	3	09:00:00	20:00:00
764d3fd8-2333-4ae8-b0b5-2d1c2a44a84d	chair	7f7f9c56-8bc8-4eaf-9d1a-50a302270d88	4	09:00:00	20:00:00
650c0ea8-485f-4fa7-8575-301e06a97dc9	chair	7f7f9c56-8bc8-4eaf-9d1a-50a302270d88	5	09:00:00	20:00:00
ad2077bf-59d3-4aa3-9759-c747660cd84e	chair	7f7f9c56-8bc8-4eaf-9d1a-50a302270d88	6	09:00:00	20:00:00
1a7ea1a4-0f26-4e3b-8e64-ada96a1f120d	staff	993150ad-bcfe-46ba-87cc-aaeae9fb4973	0	09:00:00	20:00:00
34f7a9d2-b0f5-4660-ba22-fbe8ee1baaf9	staff	993150ad-bcfe-46ba-87cc-aaeae9fb4973	1	09:00:00	20:00:00
8f4ad73d-0f37-4b04-b8f6-8591e4f2584c	staff	993150ad-bcfe-46ba-87cc-aaeae9fb4973	2	09:00:00	20:00:00
4a1ea23c-f27b-4abc-b2ae-18e505c814fc	staff	993150ad-bcfe-46ba-87cc-aaeae9fb4973	3	09:00:00	20:00:00
3dceef35-811e-443e-b124-f2cccf1bb9b5	staff	993150ad-bcfe-46ba-87cc-aaeae9fb4973	4	09:00:00	20:00:00
a6856cbf-9c8c-4789-90a7-74607540e7a7	staff	993150ad-bcfe-46ba-87cc-aaeae9fb4973	5	09:00:00	20:00:00
b904acfc-cfa4-49d1-8f46-333d05dfbaf7	staff	993150ad-bcfe-46ba-87cc-aaeae9fb4973	6	09:00:00	20:00:00
e8bf7bff-dd9c-4fd3-9159-cada9d902cda	chair	a5cb361d-e2e2-43fd-96bc-eabf65d79f16	0	09:00:00	20:00:00
e523da57-392b-44a4-861a-0667f780f582	chair	a5cb361d-e2e2-43fd-96bc-eabf65d79f16	1	09:00:00	20:00:00
0e9969f4-bb35-4c15-9009-03b016845cf4	chair	a5cb361d-e2e2-43fd-96bc-eabf65d79f16	2	09:00:00	20:00:00
35a3796a-40fa-4942-93d3-5d47903c5b27	chair	a5cb361d-e2e2-43fd-96bc-eabf65d79f16	3	09:00:00	20:00:00
36ced3d8-66e3-41c5-a2c6-1e36e7f981b9	chair	a5cb361d-e2e2-43fd-96bc-eabf65d79f16	4	09:00:00	20:00:00
64682663-56cc-4bc5-88fd-65a8660e08ca	chair	a5cb361d-e2e2-43fd-96bc-eabf65d79f16	5	09:00:00	20:00:00
1954fc76-5738-4485-a1a6-581c70c97b8e	chair	a5cb361d-e2e2-43fd-96bc-eabf65d79f16	6	09:00:00	20:00:00
43012bff-4eee-41b9-9674-c732d66d244b	staff	304a4e13-4e55-481c-b995-7111ff56f332	0	09:00:00	20:00:00
86222163-cb54-4e92-ad71-e1897247d82e	staff	304a4e13-4e55-481c-b995-7111ff56f332	1	09:00:00	20:00:00
df58be15-4cc6-4453-a1cd-8d0ca8b66c62	staff	304a4e13-4e55-481c-b995-7111ff56f332	2	09:00:00	20:00:00
b31355d5-b050-46a7-9720-f30e5b61f812	staff	304a4e13-4e55-481c-b995-7111ff56f332	3	09:00:00	20:00:00
66277c8f-01c0-4575-baec-c0abcaf2ffea	staff	304a4e13-4e55-481c-b995-7111ff56f332	4	09:00:00	20:00:00
cf450cb1-feec-4a79-9ac3-843a226a3acf	staff	304a4e13-4e55-481c-b995-7111ff56f332	5	09:00:00	20:00:00
310023d4-a345-49c6-98e4-e44d4225c875	staff	304a4e13-4e55-481c-b995-7111ff56f332	6	09:00:00	20:00:00
cd328b6e-74c9-431e-aca3-f257450e8f16	chair	1aa5c02d-ecd5-40c0-b4c7-8318312759ef	0	09:00:00	20:00:00
d4627e18-ad7a-4897-9249-0effb1638ccc	chair	1aa5c02d-ecd5-40c0-b4c7-8318312759ef	1	09:00:00	20:00:00
dcfb8df1-6fcd-405c-8d12-c845e63a1a45	chair	1aa5c02d-ecd5-40c0-b4c7-8318312759ef	2	09:00:00	20:00:00
1d187770-866d-4b0e-8b9f-e5206d84c3ab	chair	1aa5c02d-ecd5-40c0-b4c7-8318312759ef	3	09:00:00	20:00:00
57f6adef-552b-4942-8cce-edd38c792f81	chair	1aa5c02d-ecd5-40c0-b4c7-8318312759ef	4	09:00:00	20:00:00
243ea3e2-f13e-4b6e-a825-0ca3d5a40a37	chair	1aa5c02d-ecd5-40c0-b4c7-8318312759ef	5	09:00:00	20:00:00
6f897d3b-f1b3-4ca0-9aec-97f445a0cfcd	chair	1aa5c02d-ecd5-40c0-b4c7-8318312759ef	6	09:00:00	20:00:00
8e634fa4-9aaa-4bf7-a0ab-a4179c932c0e	chair	beb49418-82de-4957-9b26-7b747db08739	0	09:00:00	20:00:00
2084033a-95fa-4e60-9965-95311cecce1d	chair	beb49418-82de-4957-9b26-7b747db08739	1	09:00:00	20:00:00
356f9cc5-f9c5-49a7-a06e-b6b3e00dc3b0	chair	beb49418-82de-4957-9b26-7b747db08739	2	09:00:00	20:00:00
bd5d47bf-f01d-4032-b746-ada093fe5d7e	chair	beb49418-82de-4957-9b26-7b747db08739	3	09:00:00	20:00:00
078f91ad-85fc-4767-a075-1024788878ca	chair	beb49418-82de-4957-9b26-7b747db08739	4	09:00:00	20:00:00
875d3c2f-3c75-4e46-a682-b002772759fa	chair	beb49418-82de-4957-9b26-7b747db08739	5	09:00:00	20:00:00
efda8c99-5081-4185-a065-7a01f17f5649	chair	beb49418-82de-4957-9b26-7b747db08739	6	09:00:00	20:00:00
8fab8f67-1516-4550-a257-c00dbabc873d	staff	be145b3a-a902-46eb-84fa-3b5f66dc7bef	0	09:00:00	20:00:00
9ccd83bd-4808-4fc0-a957-7d6c3edd67d6	staff	be145b3a-a902-46eb-84fa-3b5f66dc7bef	1	09:00:00	20:00:00
43d37abd-2664-4b8d-9420-5ea712c70c2a	staff	be145b3a-a902-46eb-84fa-3b5f66dc7bef	2	09:00:00	20:00:00
4683fd0e-48ce-4b92-92d7-3b0587c40ecd	staff	be145b3a-a902-46eb-84fa-3b5f66dc7bef	3	09:00:00	20:00:00
759d0ed0-d5f3-4705-a80c-ba2c201d8e59	staff	be145b3a-a902-46eb-84fa-3b5f66dc7bef	4	09:00:00	20:00:00
89e8eaf8-4b1b-46b0-9d21-d74a7c6b58e8	staff	be145b3a-a902-46eb-84fa-3b5f66dc7bef	5	09:00:00	20:00:00
3b625817-1f4c-43e7-a0cf-b93f03bc0f1e	staff	be145b3a-a902-46eb-84fa-3b5f66dc7bef	6	09:00:00	20:00:00
7933cdfe-e5d7-4e6f-9c24-c27e0a2424cc	chair	9fcf1365-b760-455c-af6e-d7670ab4e073	0	09:00:00	20:00:00
0d71e980-77ad-4a51-a93b-3216514817ca	chair	9fcf1365-b760-455c-af6e-d7670ab4e073	1	09:00:00	20:00:00
120c62f3-9d8f-48a1-8063-d26f38827193	chair	9fcf1365-b760-455c-af6e-d7670ab4e073	2	09:00:00	20:00:00
83887a1d-1ab2-4bc2-81fa-2bc2d9173d27	chair	9fcf1365-b760-455c-af6e-d7670ab4e073	3	09:00:00	20:00:00
b8c826b9-8414-4f01-b88c-4497032d9669	chair	9fcf1365-b760-455c-af6e-d7670ab4e073	4	09:00:00	20:00:00
5baef52e-5bb2-4484-8385-063ac098a430	chair	9fcf1365-b760-455c-af6e-d7670ab4e073	5	09:00:00	20:00:00
61ab3904-7af0-4633-9151-5f0f3159e58d	chair	9fcf1365-b760-455c-af6e-d7670ab4e073	6	09:00:00	20:00:00
f4ad9fd7-25ab-4fab-b80d-8edcb3b09719	staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	0	09:00:00	20:00:00
fbdd2e10-a315-428f-93f4-0507d4e251e8	staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	1	09:00:00	20:00:00
6c515e4d-8be9-4164-9ddc-afa6c6e38a2b	staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	2	09:00:00	20:00:00
77c1c4a8-b8cc-4bf7-a5f4-b86199da6505	staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	3	09:00:00	20:00:00
e34ac84f-0490-4566-b8d3-e92e7c88ff40	staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	4	09:00:00	20:00:00
cbfda973-a57a-42a0-935b-03eae32012ec	staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	5	09:00:00	20:00:00
8d5f41fa-57a2-4008-8cae-46ba984160d1	staff	a8bafa5c-6bf7-4441-97d4-b5fae40a1935	6	09:00:00	20:00:00
fe99cbbb-89ec-46f6-a0e9-135135cae1e4	chair	827e26f5-d1ce-45cc-8b99-2078891e1ef0	0	09:00:00	20:00:00
86e87280-a7ce-4215-99a0-7aa864027867	chair	827e26f5-d1ce-45cc-8b99-2078891e1ef0	1	09:00:00	20:00:00
0fd6634b-7288-432c-b797-8f30c24bc8cb	chair	827e26f5-d1ce-45cc-8b99-2078891e1ef0	2	09:00:00	20:00:00
ca03f1b4-533a-4571-9485-e694f3c43807	chair	827e26f5-d1ce-45cc-8b99-2078891e1ef0	3	09:00:00	20:00:00
862698d8-3f09-4d19-9b7d-191a593230e8	chair	827e26f5-d1ce-45cc-8b99-2078891e1ef0	4	09:00:00	20:00:00
a692b74a-a86b-4e44-9553-7e38bcbe42f3	chair	827e26f5-d1ce-45cc-8b99-2078891e1ef0	5	09:00:00	20:00:00
d959ea57-5861-4c0a-8ad2-5cdce262f7d0	chair	827e26f5-d1ce-45cc-8b99-2078891e1ef0	6	09:00:00	20:00:00
9a4c3034-1f89-4911-a609-7986a49668f3	staff	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	0	09:00:00	20:00:00
5360750c-1046-4947-818a-86ec9eb5b36a	staff	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	1	09:00:00	20:00:00
1b7ecf03-3f63-496d-b0f2-b4e41a07f835	staff	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	2	09:00:00	20:00:00
c5208319-d16e-4415-aca0-fc40e5443620	staff	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	3	09:00:00	20:00:00
1e13c31c-8c89-408a-928c-206a0da927b2	staff	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	4	09:00:00	20:00:00
5a54186d-8d25-4219-a2bb-8026c45133a2	staff	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	5	09:00:00	20:00:00
b9294110-2168-44b4-975c-1aae051d9eb4	staff	ac99d3fa-4ffc-4ed8-8d3a-a1443e65c740	6	09:00:00	20:00:00
50b2da98-308f-44d5-875f-20c088b7bcd6	chair	9b31cc2b-489e-47eb-ba25-973e86cb6f85	0	09:00:00	20:00:00
f1b0a606-0076-4640-bf8e-af5a55317541	chair	9b31cc2b-489e-47eb-ba25-973e86cb6f85	1	09:00:00	20:00:00
9bb82999-4c5a-4972-a222-9fa402ba819b	chair	9b31cc2b-489e-47eb-ba25-973e86cb6f85	2	09:00:00	20:00:00
9ef0a5e4-ed6f-4449-9b75-c72ad25e2bb3	chair	9b31cc2b-489e-47eb-ba25-973e86cb6f85	3	09:00:00	20:00:00
61271cb0-7995-4b2d-8fdd-f4eeff1026cc	chair	9b31cc2b-489e-47eb-ba25-973e86cb6f85	4	09:00:00	20:00:00
72fa5758-c2dd-491f-a92a-5a4ab80bb85b	chair	9b31cc2b-489e-47eb-ba25-973e86cb6f85	5	09:00:00	20:00:00
7f5ab7f9-7596-43a9-8678-1edeb51bbc6f	chair	9b31cc2b-489e-47eb-ba25-973e86cb6f85	6	09:00:00	20:00:00
1f9e32a1-617a-4807-84a6-9933123fa803	staff	1f57cc2c-1b58-4304-841b-6d1e9ace9918	0	09:00:00	20:00:00
03f336f7-bf0d-449b-8b33-225d6584e224	staff	1f57cc2c-1b58-4304-841b-6d1e9ace9918	1	09:00:00	20:00:00
2979682a-e0c5-4442-87f7-caf739ccd537	staff	1f57cc2c-1b58-4304-841b-6d1e9ace9918	2	09:00:00	20:00:00
994023b8-ff6d-44ec-821e-f978a97a59ce	staff	1f57cc2c-1b58-4304-841b-6d1e9ace9918	3	09:00:00	20:00:00
f8eff80f-70c4-4fc3-9d62-c048ce81ce0a	staff	1f57cc2c-1b58-4304-841b-6d1e9ace9918	4	09:00:00	20:00:00
bfc949b5-aa4a-4253-a981-1ccfe73694da	staff	1f57cc2c-1b58-4304-841b-6d1e9ace9918	5	09:00:00	20:00:00
2821eb60-af0b-40a3-9f7b-f4f4d3d8b691	staff	1f57cc2c-1b58-4304-841b-6d1e9ace9918	6	09:00:00	20:00:00
44b34d8e-8075-49a8-a635-7a005b8ee2e5	chair	6665e72d-56b8-4077-afe9-9792d28ba2c0	0	09:00:00	20:00:00
6eca0d45-b51d-4ed2-bd21-44f6ada48a3a	chair	6665e72d-56b8-4077-afe9-9792d28ba2c0	1	09:00:00	20:00:00
762087a5-e361-4646-9c2c-ebde69941b9c	chair	6665e72d-56b8-4077-afe9-9792d28ba2c0	2	09:00:00	20:00:00
2850f42c-09df-4157-9435-fd1c5ab8fe63	chair	6665e72d-56b8-4077-afe9-9792d28ba2c0	3	09:00:00	20:00:00
e750c007-5f54-4ff7-83b8-7fc801c0d1ed	chair	6665e72d-56b8-4077-afe9-9792d28ba2c0	4	09:00:00	20:00:00
1a04b646-d792-4130-9493-0b029d20b8f0	chair	6665e72d-56b8-4077-afe9-9792d28ba2c0	5	09:00:00	20:00:00
bb94986c-f221-4b36-815e-ae88cbc78fed	chair	6665e72d-56b8-4077-afe9-9792d28ba2c0	6	09:00:00	20:00:00
bb200efb-52d9-4735-a0a9-1d89128ac23c	staff	7901cb34-8b2e-44b8-972d-98792ecdb564	0	09:00:00	20:00:00
16fdcc99-f36a-4a43-89f6-af68fcdb7599	staff	7901cb34-8b2e-44b8-972d-98792ecdb564	1	09:00:00	20:00:00
02402687-3f7e-419f-bc6a-0383787092f9	staff	7901cb34-8b2e-44b8-972d-98792ecdb564	2	09:00:00	20:00:00
6c50c6a7-59c5-45a9-92ec-5b7da63fb7da	staff	7901cb34-8b2e-44b8-972d-98792ecdb564	3	09:00:00	20:00:00
e7237694-b68f-4e01-9bf1-e2ffa350aa55	staff	7901cb34-8b2e-44b8-972d-98792ecdb564	4	09:00:00	20:00:00
4505bbb5-e1d9-4ce7-9fab-3e6e30e2ccb2	staff	7901cb34-8b2e-44b8-972d-98792ecdb564	5	09:00:00	20:00:00
8aab91f2-de52-47d1-a7a1-2a87ad0b4b7f	staff	7901cb34-8b2e-44b8-972d-98792ecdb564	6	09:00:00	20:00:00
15566ea6-7151-4d83-b6c9-3b59784cb7b5	chair	0b127c72-e6af-4991-b8a8-39cebf222edc	0	09:00:00	20:00:00
eb8c0750-fbfa-47cc-80cd-f1a0c5c56dad	chair	0b127c72-e6af-4991-b8a8-39cebf222edc	1	09:00:00	20:00:00
59dbc015-6cc9-4ff8-9037-fb8267f3bda0	chair	0b127c72-e6af-4991-b8a8-39cebf222edc	2	09:00:00	20:00:00
1461bf1d-ef1b-4d88-a407-e5d9abb8239e	chair	0b127c72-e6af-4991-b8a8-39cebf222edc	3	09:00:00	20:00:00
16a86183-a347-48d1-b6b4-723571a6a589	chair	0b127c72-e6af-4991-b8a8-39cebf222edc	4	09:00:00	20:00:00
d939b0f9-3746-499b-8904-17b77fbcbb76	chair	0b127c72-e6af-4991-b8a8-39cebf222edc	5	09:00:00	20:00:00
1de35350-b308-4e6e-85f0-624288aaceb6	chair	0b127c72-e6af-4991-b8a8-39cebf222edc	6	09:00:00	20:00:00
99ff383a-5069-434c-8254-7fafaff4b075	staff	c1a91ff2-d119-4c56-9529-26b154e3c0b7	0	09:00:00	20:00:00
1aceb281-3b77-4cb5-9d52-3072ebccb70f	staff	c1a91ff2-d119-4c56-9529-26b154e3c0b7	1	09:00:00	20:00:00
d9dca5bd-37fc-4233-8bc2-fed15cafaa56	staff	c1a91ff2-d119-4c56-9529-26b154e3c0b7	2	09:00:00	20:00:00
0be8c2c8-1a96-448f-b198-ad2886f3e8b1	staff	c1a91ff2-d119-4c56-9529-26b154e3c0b7	3	09:00:00	20:00:00
e3bacf50-380f-4118-9584-3e13b0ce339c	staff	c1a91ff2-d119-4c56-9529-26b154e3c0b7	4	09:00:00	20:00:00
73b51b7a-6b3e-460f-bc54-431ba7e05b8a	staff	c1a91ff2-d119-4c56-9529-26b154e3c0b7	5	09:00:00	20:00:00
3e9438b2-b698-4cb9-b339-dbadb9dc01ff	staff	c1a91ff2-d119-4c56-9529-26b154e3c0b7	6	09:00:00	20:00:00
ade1402c-26f5-4ae0-ac39-68cce418d9d7	chair	194dad8c-2c13-4da8-b7af-78859a8245b0	0	09:00:00	20:00:00
461bebae-cf7f-4025-9bf6-558cc85edd8f	chair	194dad8c-2c13-4da8-b7af-78859a8245b0	1	09:00:00	20:00:00
c557393f-958e-4e50-b76c-33b2c7fcaddc	chair	194dad8c-2c13-4da8-b7af-78859a8245b0	2	09:00:00	20:00:00
da9a038b-939b-4318-8760-e42fe1ad9a1e	chair	194dad8c-2c13-4da8-b7af-78859a8245b0	3	09:00:00	20:00:00
618deefe-1422-42bd-b724-80d25b9fbd89	chair	194dad8c-2c13-4da8-b7af-78859a8245b0	4	09:00:00	20:00:00
19df3d7f-9ae7-40ef-bc6b-0fbd205a76cc	chair	194dad8c-2c13-4da8-b7af-78859a8245b0	5	09:00:00	20:00:00
bac63306-f4bc-4400-8f39-6f616a0c2492	chair	194dad8c-2c13-4da8-b7af-78859a8245b0	6	09:00:00	20:00:00
adae035f-eacc-4562-96c0-36de01f232a6	staff	c55ae5bc-c225-44aa-b2dc-350c9cd7eead	0	09:00:00	20:00:00
2137fb7d-d885-4244-bbcb-0b3c4c3542b1	staff	c55ae5bc-c225-44aa-b2dc-350c9cd7eead	1	09:00:00	20:00:00
95ba2487-c012-4742-8191-0b43107e757a	staff	c55ae5bc-c225-44aa-b2dc-350c9cd7eead	2	09:00:00	20:00:00
434ab5d3-fc19-431c-9f69-7c080b4a388a	staff	c55ae5bc-c225-44aa-b2dc-350c9cd7eead	3	09:00:00	20:00:00
4a86f667-3ce4-4b2c-a4ef-de7e6aee6b40	staff	c55ae5bc-c225-44aa-b2dc-350c9cd7eead	4	09:00:00	20:00:00
7312ca4b-38fc-416e-bda0-1a9101da392c	staff	c55ae5bc-c225-44aa-b2dc-350c9cd7eead	5	09:00:00	20:00:00
6f6f4fc2-dcc6-4e17-8f20-6f66ac2b96d7	staff	c55ae5bc-c225-44aa-b2dc-350c9cd7eead	6	09:00:00	20:00:00
34efd8d0-4951-4559-a49e-e04ec1ba154a	chair	b8aa3402-b5b8-4f61-9634-41e5dcd483eb	0	09:00:00	20:00:00
cd84ac30-f07d-4571-957d-27b7ac77dc19	chair	b8aa3402-b5b8-4f61-9634-41e5dcd483eb	1	09:00:00	20:00:00
8c2d097f-ef50-455b-83c5-770ff901040d	chair	b8aa3402-b5b8-4f61-9634-41e5dcd483eb	2	09:00:00	20:00:00
7962a605-25c8-41bd-92f9-0f57aa666813	chair	b8aa3402-b5b8-4f61-9634-41e5dcd483eb	3	09:00:00	20:00:00
c5d7b779-45f5-4626-99aa-8f2591c34d78	chair	b8aa3402-b5b8-4f61-9634-41e5dcd483eb	4	09:00:00	20:00:00
9b61ff98-aeb8-4fe2-8450-4df998f3f883	chair	b8aa3402-b5b8-4f61-9634-41e5dcd483eb	5	09:00:00	20:00:00
c78044e5-1b47-482c-8af0-470b11d5dd60	chair	b8aa3402-b5b8-4f61-9634-41e5dcd483eb	6	09:00:00	20:00:00
d5c1c418-8e06-4158-a3e5-f777c09f9be5	staff	3df2c865-dce9-4b08-add1-7dfa3c9d9fee	0	09:00:00	20:00:00
f14fe82d-b0a5-4bbe-8adc-991d31f0177c	staff	3df2c865-dce9-4b08-add1-7dfa3c9d9fee	1	09:00:00	20:00:00
75c88efa-faf4-4c67-84b7-93f35e6d0160	staff	3df2c865-dce9-4b08-add1-7dfa3c9d9fee	2	09:00:00	20:00:00
6a7f0a29-5241-407f-91b3-2fe6055a5278	staff	3df2c865-dce9-4b08-add1-7dfa3c9d9fee	3	09:00:00	20:00:00
3db5ce76-b465-4331-bb9a-397e61a8408c	staff	3df2c865-dce9-4b08-add1-7dfa3c9d9fee	4	09:00:00	20:00:00
12ad1b1c-25cc-44c8-9564-0a6678c0e232	staff	3df2c865-dce9-4b08-add1-7dfa3c9d9fee	5	09:00:00	20:00:00
5c10c202-572a-4ce3-bd17-2815516e9ff6	staff	3df2c865-dce9-4b08-add1-7dfa3c9d9fee	6	09:00:00	20:00:00
a5f9ad23-3a77-497a-a808-1366da824afe	chair	f9b95507-e43f-42bc-ab13-e0dcddafa18a	0	09:00:00	20:00:00
a33c90c9-c454-4205-9808-09d463b837ad	chair	f9b95507-e43f-42bc-ab13-e0dcddafa18a	1	09:00:00	20:00:00
6a42d28c-1bab-416b-99fd-b7202e9fc5ad	chair	f9b95507-e43f-42bc-ab13-e0dcddafa18a	2	09:00:00	20:00:00
7a9d8d7a-47e5-4e2f-ab7c-bb7e9f7946f8	chair	f9b95507-e43f-42bc-ab13-e0dcddafa18a	3	09:00:00	20:00:00
99d8c46e-e169-488c-a521-42a9d0be068d	chair	f9b95507-e43f-42bc-ab13-e0dcddafa18a	4	09:00:00	20:00:00
f787141e-66a8-4c5b-9260-13908444190e	chair	f9b95507-e43f-42bc-ab13-e0dcddafa18a	5	09:00:00	20:00:00
9b66835c-507a-4889-8e5b-d3e9549becb8	chair	f9b95507-e43f-42bc-ab13-e0dcddafa18a	6	09:00:00	20:00:00
6d4a9d95-8d5c-4ccc-a0f5-76a40b0d40d2	staff	2e82dc6b-b50a-4647-aa20-bbb7035ce44a	0	09:00:00	20:00:00
d4030585-0f5b-446f-8901-6eb017b0f949	staff	2e82dc6b-b50a-4647-aa20-bbb7035ce44a	1	09:00:00	20:00:00
1d43abe0-5e8a-4c18-976c-95348bb06489	staff	2e82dc6b-b50a-4647-aa20-bbb7035ce44a	2	09:00:00	20:00:00
38aeec9b-8df8-4e79-9bfe-e65e7844771b	staff	2e82dc6b-b50a-4647-aa20-bbb7035ce44a	3	09:00:00	20:00:00
49dfff92-bc46-4661-9f91-fd1f6eee48e0	staff	2e82dc6b-b50a-4647-aa20-bbb7035ce44a	4	09:00:00	20:00:00
f077a3e9-4253-41b0-b4df-01d552d3e1bf	staff	2e82dc6b-b50a-4647-aa20-bbb7035ce44a	5	09:00:00	20:00:00
a65f2e05-d739-4564-acca-59ae4e0ce7a0	staff	2e82dc6b-b50a-4647-aa20-bbb7035ce44a	6	09:00:00	20:00:00
71e52cc2-2521-4447-bc43-ebd939554b42	chair	d28b6c43-9429-42f4-9cf4-56a219bf09b0	0	09:00:00	20:00:00
58e4b435-4ea1-4e6b-82a4-939d072096cb	chair	d28b6c43-9429-42f4-9cf4-56a219bf09b0	1	09:00:00	20:00:00
4b793c1c-2a1f-4709-a1df-76aa0353d4d3	chair	d28b6c43-9429-42f4-9cf4-56a219bf09b0	2	09:00:00	20:00:00
28600e7a-3b75-4009-86cc-86c64b0511ea	chair	d28b6c43-9429-42f4-9cf4-56a219bf09b0	3	09:00:00	20:00:00
a10cb366-1bd2-4669-a36d-3e3e72a75eef	chair	d28b6c43-9429-42f4-9cf4-56a219bf09b0	4	09:00:00	20:00:00
af802a8c-6788-4def-be7b-a883d8ddd38f	chair	d28b6c43-9429-42f4-9cf4-56a219bf09b0	5	09:00:00	20:00:00
570037ff-b6df-454d-ac1b-79d0df4b26f9	chair	d28b6c43-9429-42f4-9cf4-56a219bf09b0	6	09:00:00	20:00:00
02de1917-b3c9-49e2-8504-f696c2731876	staff	5c19affc-2f6f-48cc-b8a5-906bc83812f1	0	09:00:00	20:00:00
4cd99d57-12ca-4df5-8efd-77d55a7e7add	staff	5c19affc-2f6f-48cc-b8a5-906bc83812f1	1	09:00:00	20:00:00
82a52f6c-b0c0-466f-8a55-3e684672cefe	staff	5c19affc-2f6f-48cc-b8a5-906bc83812f1	2	09:00:00	20:00:00
7d47277a-cfdf-429a-a672-d65b362ab7d9	staff	5c19affc-2f6f-48cc-b8a5-906bc83812f1	3	09:00:00	20:00:00
be23c8e1-d700-4ba8-b4ca-447f7bc0fcb5	staff	5c19affc-2f6f-48cc-b8a5-906bc83812f1	4	09:00:00	20:00:00
863239d5-d217-4b25-887a-2f5997e35254	staff	5c19affc-2f6f-48cc-b8a5-906bc83812f1	5	09:00:00	20:00:00
ba8dfe6b-ace1-440a-85e0-980040530a27	staff	5c19affc-2f6f-48cc-b8a5-906bc83812f1	6	09:00:00	20:00:00
90c28231-c278-498a-a5b8-7d39b4b36b19	chair	b55f3be5-c01f-481f-91f1-9eb6ebbf3a90	0	09:00:00	20:00:00
5db972e4-df10-44d2-b36d-95b354807db8	chair	b55f3be5-c01f-481f-91f1-9eb6ebbf3a90	1	09:00:00	20:00:00
4d87e39b-a19a-4ffd-9249-bf1b23cc40cf	chair	b55f3be5-c01f-481f-91f1-9eb6ebbf3a90	2	09:00:00	20:00:00
b75541ad-c406-4427-9f36-413c6d7451f8	chair	b55f3be5-c01f-481f-91f1-9eb6ebbf3a90	3	09:00:00	20:00:00
675f6a76-8887-4de6-8bb1-fb30eb0b11b0	chair	b55f3be5-c01f-481f-91f1-9eb6ebbf3a90	4	09:00:00	20:00:00
ef6ed767-d217-4853-b984-1fc3c23ba1e8	chair	b55f3be5-c01f-481f-91f1-9eb6ebbf3a90	5	09:00:00	20:00:00
9b347576-2f07-40d4-b528-2a5459f2e22a	chair	b55f3be5-c01f-481f-91f1-9eb6ebbf3a90	6	09:00:00	20:00:00
63a209ff-2cc7-4db8-bc95-f167f500e4d6	staff	79fb9a0e-6a95-4a23-ad1c-650c15f2e0a1	0	09:00:00	20:00:00
d147b5c2-2df4-4306-970a-896d01c00684	staff	79fb9a0e-6a95-4a23-ad1c-650c15f2e0a1	1	09:00:00	20:00:00
692f3819-ed34-4f47-8b5a-8801717c865f	staff	79fb9a0e-6a95-4a23-ad1c-650c15f2e0a1	2	09:00:00	20:00:00
d021ef47-52fe-4af0-a8e3-87c37e75d96d	staff	79fb9a0e-6a95-4a23-ad1c-650c15f2e0a1	3	09:00:00	20:00:00
ab78fc1b-1e9e-4b4c-acd9-291851f35a04	staff	79fb9a0e-6a95-4a23-ad1c-650c15f2e0a1	4	09:00:00	20:00:00
e11269a7-2c2a-4bb5-8811-3f8cecd85400	staff	79fb9a0e-6a95-4a23-ad1c-650c15f2e0a1	5	09:00:00	20:00:00
d2477446-aa5e-4ad5-9dca-6bd7f3c3202e	staff	79fb9a0e-6a95-4a23-ad1c-650c15f2e0a1	6	09:00:00	20:00:00
8305a201-bb2e-4f4a-b909-852166ecb94c	chair	ce3a04f7-3d22-4263-ad71-37e751013436	0	09:00:00	20:00:00
c18b5710-9a89-4e40-8697-1479ad0d917b	chair	ce3a04f7-3d22-4263-ad71-37e751013436	1	09:00:00	20:00:00
e10e68df-9aef-40bc-82c9-992f6b450c68	chair	ce3a04f7-3d22-4263-ad71-37e751013436	2	09:00:00	20:00:00
03a08f1a-dfd6-4916-b19d-6414618f1ac6	chair	ce3a04f7-3d22-4263-ad71-37e751013436	3	09:00:00	20:00:00
32af2322-e89f-4a5b-972f-032a3499d7c8	chair	ce3a04f7-3d22-4263-ad71-37e751013436	4	09:00:00	20:00:00
2e57725f-114b-4f06-9f43-bdc6f4d62544	chair	ce3a04f7-3d22-4263-ad71-37e751013436	5	09:00:00	20:00:00
0751a485-5ea7-424a-a0e1-7b9d4b0af03f	chair	ce3a04f7-3d22-4263-ad71-37e751013436	6	09:00:00	20:00:00
5ef317c2-578e-4880-a8d8-4f243387ab81	chair	8803710a-b0de-435d-a0cf-9a9d897678c1	0	09:00:00	20:00:00
8929eb42-46ca-4c67-bb9d-78905f160a2a	chair	8803710a-b0de-435d-a0cf-9a9d897678c1	1	09:00:00	20:00:00
d3aa8cd0-0571-4ac1-b1a2-aa5f8d6915a4	chair	8803710a-b0de-435d-a0cf-9a9d897678c1	2	09:00:00	20:00:00
7618b2d1-548c-4c5c-84a1-d82c4147318a	chair	8803710a-b0de-435d-a0cf-9a9d897678c1	3	09:00:00	20:00:00
51117086-0724-4521-a16f-bbec2da83cbb	chair	8803710a-b0de-435d-a0cf-9a9d897678c1	4	09:00:00	20:00:00
d43404f4-93fc-49dc-9e7f-d0b89f3a6b50	chair	8803710a-b0de-435d-a0cf-9a9d897678c1	5	09:00:00	20:00:00
0e716b09-b0c7-4863-98e7-f83f43466fec	chair	8803710a-b0de-435d-a0cf-9a9d897678c1	6	09:00:00	20:00:00
99a2cef2-e64e-4b8d-a570-97bcc0eb1e48	staff	f5a4d790-5134-4522-8243-36d7f0a70027	0	09:00:00	20:00:00
4932b191-a612-4c55-b6d3-3e960a8912f2	staff	f5a4d790-5134-4522-8243-36d7f0a70027	1	09:00:00	20:00:00
3add3098-13b7-4ddf-8cc8-81673d8c7265	staff	f5a4d790-5134-4522-8243-36d7f0a70027	2	09:00:00	20:00:00
c990f08c-2f9b-4878-b7cb-125c8206dca6	staff	f5a4d790-5134-4522-8243-36d7f0a70027	3	09:00:00	20:00:00
602fede1-516e-4c46-9559-ea877b371fba	staff	f5a4d790-5134-4522-8243-36d7f0a70027	4	09:00:00	20:00:00
d8919ec6-a811-48c1-810b-ff3a3e70acbe	staff	f5a4d790-5134-4522-8243-36d7f0a70027	5	09:00:00	20:00:00
4db5c0e0-18b2-460e-aacb-528a6b5cbe5a	staff	f5a4d790-5134-4522-8243-36d7f0a70027	6	09:00:00	20:00:00
483cf8ef-61e7-4b45-b7fc-44d6c9aaffc1	chair	1c5dad57-b2d6-4fcb-a1c4-677f9ed40062	0	09:00:00	20:00:00
4d2cb323-2091-4c08-8e8c-990e587fc736	chair	1c5dad57-b2d6-4fcb-a1c4-677f9ed40062	1	09:00:00	20:00:00
55aa10b9-f1a5-4ead-b0b6-262c966eb6a5	chair	1c5dad57-b2d6-4fcb-a1c4-677f9ed40062	2	09:00:00	20:00:00
c3467228-4e37-4f9d-baf0-13d16312d4e7	chair	1c5dad57-b2d6-4fcb-a1c4-677f9ed40062	3	09:00:00	20:00:00
fc03098b-b590-419b-804f-a438e5e80f1e	chair	1c5dad57-b2d6-4fcb-a1c4-677f9ed40062	4	09:00:00	20:00:00
1befd6a6-84a1-4774-bd62-2ff51a056599	chair	1c5dad57-b2d6-4fcb-a1c4-677f9ed40062	5	09:00:00	20:00:00
41ca81d1-f121-46f3-a525-0c9d607cec5f	chair	1c5dad57-b2d6-4fcb-a1c4-677f9ed40062	6	09:00:00	20:00:00
78825dd2-0c78-4f9a-bde6-833a679e953e	staff	4c38b9fb-2918-4a7f-91b1-d959717f3cce	0	09:00:00	20:00:00
0867497f-b1bd-4f29-81c8-186b3ff0ff6d	staff	4c38b9fb-2918-4a7f-91b1-d959717f3cce	1	09:00:00	20:00:00
73a37e2c-514a-429d-a56b-15c9509064c6	staff	4c38b9fb-2918-4a7f-91b1-d959717f3cce	2	09:00:00	20:00:00
332d1ccb-1c04-41e7-bdd8-07f0adcdc114	staff	4c38b9fb-2918-4a7f-91b1-d959717f3cce	3	09:00:00	20:00:00
d74a553d-2a2a-4b43-9320-34dda2708644	staff	4c38b9fb-2918-4a7f-91b1-d959717f3cce	4	09:00:00	20:00:00
b4dd276f-b2ac-4335-b1e7-4bbf0c8cc249	staff	4c38b9fb-2918-4a7f-91b1-d959717f3cce	5	09:00:00	20:00:00
894b0c4a-06f9-414e-bbac-c9d88aef4e0e	staff	4c38b9fb-2918-4a7f-91b1-d959717f3cce	6	09:00:00	20:00:00
4c78ef38-ac98-4e15-bb05-6be33810121e	chair	739269fc-7daa-44ff-aa8c-ee779905e61a	0	09:00:00	20:00:00
a56d3dc9-03e8-4643-8bfb-aeed8a9ae680	chair	739269fc-7daa-44ff-aa8c-ee779905e61a	1	09:00:00	20:00:00
dfffdbae-2e86-4bbf-af49-0f4612d37322	chair	739269fc-7daa-44ff-aa8c-ee779905e61a	2	09:00:00	20:00:00
ff30740a-a53b-4506-b74e-ed4d0df99301	chair	739269fc-7daa-44ff-aa8c-ee779905e61a	3	09:00:00	20:00:00
8367f463-bd06-46d3-b220-59a08063d3bb	chair	739269fc-7daa-44ff-aa8c-ee779905e61a	4	09:00:00	20:00:00
2cd4ab13-a966-4fb0-a6e3-3e5ac448caee	chair	739269fc-7daa-44ff-aa8c-ee779905e61a	5	09:00:00	20:00:00
8b911e0b-5fd9-450b-a56d-6bdf33a1b7a8	chair	739269fc-7daa-44ff-aa8c-ee779905e61a	6	09:00:00	20:00:00
e5d38e02-b7f3-4caf-ac77-07b9e636e7b8	staff	851ea6dd-a22a-4f15-ae0e-3fe99c095a37	0	09:00:00	20:00:00
142374c3-25f3-413d-b5af-cdd7ce123734	staff	851ea6dd-a22a-4f15-ae0e-3fe99c095a37	1	09:00:00	20:00:00
6c69128c-7f89-4693-a5e0-9e9ca1c8daf1	staff	851ea6dd-a22a-4f15-ae0e-3fe99c095a37	2	09:00:00	20:00:00
916f4454-62b2-4119-87a3-75211e8c6c63	staff	851ea6dd-a22a-4f15-ae0e-3fe99c095a37	3	09:00:00	20:00:00
416c6a01-229c-40d5-aad0-e591a31ff805	staff	851ea6dd-a22a-4f15-ae0e-3fe99c095a37	4	09:00:00	20:00:00
8b446aa6-401b-41f0-8186-1bedd7460667	staff	851ea6dd-a22a-4f15-ae0e-3fe99c095a37	5	09:00:00	20:00:00
e420e072-c83b-49dc-af9e-e3ec41638778	staff	851ea6dd-a22a-4f15-ae0e-3fe99c095a37	6	09:00:00	20:00:00
3173d94c-6935-434a-8bdf-52938b55b401	chair	7778910e-0e92-43c9-9030-7376e5fc5a89	0	09:00:00	20:00:00
c3e32db4-f670-4ca9-89c9-232d3ea702ff	chair	7778910e-0e92-43c9-9030-7376e5fc5a89	1	09:00:00	20:00:00
87728fe7-0b31-469e-877a-36c9cf33e6d7	chair	7778910e-0e92-43c9-9030-7376e5fc5a89	2	09:00:00	20:00:00
aee7d304-6123-4016-90b0-278b89c2d11b	chair	7778910e-0e92-43c9-9030-7376e5fc5a89	3	09:00:00	20:00:00
80ebd868-a2a6-4eb9-bf60-8154043cd286	chair	7778910e-0e92-43c9-9030-7376e5fc5a89	4	09:00:00	20:00:00
802e17da-3d91-46c7-a504-9a85d09059e9	chair	7778910e-0e92-43c9-9030-7376e5fc5a89	5	09:00:00	20:00:00
0dc65b7a-ae0b-4ba9-bbb6-09dc4bd89efc	chair	7778910e-0e92-43c9-9030-7376e5fc5a89	6	09:00:00	20:00:00
18bd25ed-87c6-405a-934b-06c191ea3d58	staff	15be60d1-935e-4fd4-9b57-2a5a2ef05fe5	0	09:00:00	20:00:00
00f1c288-34b4-4175-aea9-ac8d785feb58	staff	15be60d1-935e-4fd4-9b57-2a5a2ef05fe5	1	09:00:00	20:00:00
87ac5168-31a0-49b6-a44f-fcbaed860245	staff	15be60d1-935e-4fd4-9b57-2a5a2ef05fe5	2	09:00:00	20:00:00
656d6c27-8c6f-4495-9adb-b5b3e09d15c1	staff	15be60d1-935e-4fd4-9b57-2a5a2ef05fe5	3	09:00:00	20:00:00
e620a6a2-18b5-4171-8361-df3d316d7809	staff	15be60d1-935e-4fd4-9b57-2a5a2ef05fe5	4	09:00:00	20:00:00
f1329222-523c-436c-b266-db8cb8b5fe94	staff	15be60d1-935e-4fd4-9b57-2a5a2ef05fe5	5	09:00:00	20:00:00
3c1453cd-19bc-4d55-ac51-210ffab3bf82	staff	15be60d1-935e-4fd4-9b57-2a5a2ef05fe5	6	09:00:00	20:00:00
4e30c297-0199-4cbc-b45f-06019e31ce73	chair	342e5b11-492d-4021-bf7c-12697600a2ee	0	09:00:00	20:00:00
15e8e163-13c1-4fd0-87e5-df4a9592dda1	chair	342e5b11-492d-4021-bf7c-12697600a2ee	1	09:00:00	20:00:00
f49ecd80-efda-44e9-b27f-73627c94ddc5	chair	342e5b11-492d-4021-bf7c-12697600a2ee	2	09:00:00	20:00:00
29880022-e107-48f2-9fa4-36fcbf657c57	chair	342e5b11-492d-4021-bf7c-12697600a2ee	3	09:00:00	20:00:00
f6a419a0-d650-4584-ac01-66f7354df212	chair	342e5b11-492d-4021-bf7c-12697600a2ee	4	09:00:00	20:00:00
592f5d1d-c0fb-4e71-89b0-d006b01425a1	chair	342e5b11-492d-4021-bf7c-12697600a2ee	5	09:00:00	20:00:00
baf78881-f958-48b0-8e53-018b72d3a1dc	chair	342e5b11-492d-4021-bf7c-12697600a2ee	6	09:00:00	20:00:00
63a5ce99-df1b-4830-80d2-ebcdc35a666d	staff	db6cda46-0c20-4e07-8e56-9aa00f532893	0	09:00:00	20:00:00
3af34883-0e45-451b-9b29-bcfbad4b5fd3	staff	db6cda46-0c20-4e07-8e56-9aa00f532893	1	09:00:00	20:00:00
685aa622-a089-4740-8533-2aebc7fbc251	staff	db6cda46-0c20-4e07-8e56-9aa00f532893	2	09:00:00	20:00:00
ecc6e7f3-ef72-4788-a227-9c6bdc2664cb	staff	db6cda46-0c20-4e07-8e56-9aa00f532893	3	09:00:00	20:00:00
bfad8aec-7ce1-4656-8452-aeb4f93c0bdc	staff	db6cda46-0c20-4e07-8e56-9aa00f532893	4	09:00:00	20:00:00
3c60ead1-f86d-499e-98ec-d7cf88b95f76	staff	db6cda46-0c20-4e07-8e56-9aa00f532893	5	09:00:00	20:00:00
ca72c049-7425-4f5f-b074-435064c31b70	staff	db6cda46-0c20-4e07-8e56-9aa00f532893	6	09:00:00	20:00:00
9b3c3c73-5784-4496-959e-db2f7a6e5575	chair	05bcc3c8-d781-4866-b412-c691a6844950	0	09:00:00	20:00:00
e41fb88e-40fa-43f2-b730-118d279692eb	chair	05bcc3c8-d781-4866-b412-c691a6844950	1	09:00:00	20:00:00
6bd62374-0d2c-4921-8b87-f0c81b117397	chair	05bcc3c8-d781-4866-b412-c691a6844950	2	09:00:00	20:00:00
d6389ff8-b18f-4591-824f-2176cc5902ea	chair	05bcc3c8-d781-4866-b412-c691a6844950	3	09:00:00	20:00:00
5724a1fb-29a1-41bb-8a0a-b13adec8ec7c	chair	05bcc3c8-d781-4866-b412-c691a6844950	4	09:00:00	20:00:00
b7e422f1-017e-4d13-b408-7384d0e59829	chair	05bcc3c8-d781-4866-b412-c691a6844950	5	09:00:00	20:00:00
4ee0b49e-18cd-497d-9236-42b4f78bb6ed	chair	05bcc3c8-d781-4866-b412-c691a6844950	6	09:00:00	20:00:00
49f77b99-423c-4082-88b1-762ed118d404	staff	2bdc5a14-4692-4897-b099-7a942badcd4a	0	09:00:00	20:00:00
6904b5db-7482-482f-b525-a61c7ece15fd	staff	2bdc5a14-4692-4897-b099-7a942badcd4a	1	09:00:00	20:00:00
1228f8bb-2702-4ec6-999f-da19ce9c0625	staff	2bdc5a14-4692-4897-b099-7a942badcd4a	2	09:00:00	20:00:00
a5234917-3dee-4b8f-9804-71fb296f28fb	staff	2bdc5a14-4692-4897-b099-7a942badcd4a	3	09:00:00	20:00:00
56390ce5-3729-49c7-a5a6-d94dd2da954c	staff	2bdc5a14-4692-4897-b099-7a942badcd4a	4	09:00:00	20:00:00
eb2bf12b-b1bb-4833-a142-76f0079396a6	staff	2bdc5a14-4692-4897-b099-7a942badcd4a	5	09:00:00	20:00:00
7090e9a4-f75d-4c3a-90e1-01901cb60438	staff	2bdc5a14-4692-4897-b099-7a942badcd4a	6	09:00:00	20:00:00
5ed7e3ed-b1a0-4248-9d78-21c17a81280a	chair	98d1cb82-2436-4528-a7a7-f38abe109bfd	0	09:00:00	20:00:00
41347d78-23ee-4a72-9774-4dbf1541c49b	chair	98d1cb82-2436-4528-a7a7-f38abe109bfd	1	09:00:00	20:00:00
8ae1ce16-ccb6-4f98-83bb-2d1b8d69a930	chair	98d1cb82-2436-4528-a7a7-f38abe109bfd	2	09:00:00	20:00:00
18f1336d-d986-4a02-ab9f-e140e9d008c4	chair	98d1cb82-2436-4528-a7a7-f38abe109bfd	3	09:00:00	20:00:00
cc74d23c-c7c1-4c37-8682-50f150200e9c	chair	98d1cb82-2436-4528-a7a7-f38abe109bfd	4	09:00:00	20:00:00
403ce2d2-5737-49c7-9fdf-a226ebdf1238	chair	98d1cb82-2436-4528-a7a7-f38abe109bfd	5	09:00:00	20:00:00
e76897cd-5e45-43cb-ac2f-965f36382390	chair	98d1cb82-2436-4528-a7a7-f38abe109bfd	6	09:00:00	20:00:00
84aa9a3c-ceaa-468e-b2e6-11872e4dbb30	staff	ce158a89-eadb-4b48-8e67-53d9f1fbd2f0	0	09:00:00	20:00:00
e3dfca68-4289-45cf-a242-defd4f3d6a63	staff	ce158a89-eadb-4b48-8e67-53d9f1fbd2f0	1	09:00:00	20:00:00
e92bb174-a02b-44b8-b711-5cd5bb2aa247	staff	ce158a89-eadb-4b48-8e67-53d9f1fbd2f0	2	09:00:00	20:00:00
343777b9-fd9c-4d04-bd45-9c13ec4e31b5	staff	ce158a89-eadb-4b48-8e67-53d9f1fbd2f0	3	09:00:00	20:00:00
7d99c59f-7873-4790-9f87-5cb2f6af2c4a	staff	ce158a89-eadb-4b48-8e67-53d9f1fbd2f0	4	09:00:00	20:00:00
9dae3cf1-b8e9-4911-b5cb-6775b2f17ebe	staff	ce158a89-eadb-4b48-8e67-53d9f1fbd2f0	5	09:00:00	20:00:00
54182dae-ab1d-44e6-b6bd-c8a6c1ef5528	staff	ce158a89-eadb-4b48-8e67-53d9f1fbd2f0	6	09:00:00	20:00:00
c33c91ce-4f44-4ebe-96d8-55bfc3821680	chair	36d5fceb-fe61-47c7-9293-079eddefac1b	0	09:00:00	20:00:00
42d2ec03-da0d-4507-b718-2c9eb20169b6	chair	36d5fceb-fe61-47c7-9293-079eddefac1b	1	09:00:00	20:00:00
aada3989-cd6d-4277-8303-3db3e40680a4	chair	36d5fceb-fe61-47c7-9293-079eddefac1b	2	09:00:00	20:00:00
90d262a1-8965-45c2-9bcd-889f40071a63	chair	36d5fceb-fe61-47c7-9293-079eddefac1b	3	09:00:00	20:00:00
3625e1dd-68a1-46e3-a466-4d55294ac0be	chair	36d5fceb-fe61-47c7-9293-079eddefac1b	4	09:00:00	20:00:00
bd63b847-d94b-4ef3-96c9-8b9430f07062	chair	36d5fceb-fe61-47c7-9293-079eddefac1b	5	09:00:00	20:00:00
db875786-a14c-4239-9a26-9e50a6fc2596	chair	36d5fceb-fe61-47c7-9293-079eddefac1b	6	09:00:00	20:00:00
4b69b606-bdb8-4b87-bec5-8704bd5982f0	staff	06119660-0ce2-4cd4-b960-67cd0ba0e8ea	0	09:00:00	20:00:00
26d15708-ebe2-4e1a-a3cd-3d997af77a2a	staff	06119660-0ce2-4cd4-b960-67cd0ba0e8ea	1	09:00:00	20:00:00
7bfac056-d56a-49a4-b098-39c6505829d7	staff	06119660-0ce2-4cd4-b960-67cd0ba0e8ea	2	09:00:00	20:00:00
650448b0-9b72-4960-9ec7-e556c30e1d0e	staff	06119660-0ce2-4cd4-b960-67cd0ba0e8ea	3	09:00:00	20:00:00
bae00011-69a7-4888-99c1-2e88e77e62a6	staff	06119660-0ce2-4cd4-b960-67cd0ba0e8ea	4	09:00:00	20:00:00
918bdcc6-8e66-42f4-a012-f9d2f12a7929	staff	06119660-0ce2-4cd4-b960-67cd0ba0e8ea	5	09:00:00	20:00:00
5a7ada3f-82de-450a-baba-deb529497c19	staff	06119660-0ce2-4cd4-b960-67cd0ba0e8ea	6	09:00:00	20:00:00
fb7c1b7a-647d-415a-bfc4-26bbbe523fb3	staff	12ad082d-cbde-4cf9-9ed8-b719411b32b9	0	09:00:00	20:00:00
c4fcaa8b-217f-4bd1-acac-db60291931ab	staff	12ad082d-cbde-4cf9-9ed8-b719411b32b9	1	09:00:00	20:00:00
3a4a0ddc-d1f9-4671-892a-652d83683369	staff	12ad082d-cbde-4cf9-9ed8-b719411b32b9	2	09:00:00	20:00:00
743cbef3-0f08-4381-8db1-ef0505867603	staff	12ad082d-cbde-4cf9-9ed8-b719411b32b9	3	09:00:00	20:00:00
363e7cc2-5d22-4839-8a5b-ec3fd3fc174c	staff	12ad082d-cbde-4cf9-9ed8-b719411b32b9	4	09:00:00	20:00:00
081aa427-ae26-4ada-a6f8-01c75276e54c	staff	12ad082d-cbde-4cf9-9ed8-b719411b32b9	5	09:00:00	20:00:00
22acaf14-56f6-48d4-a0ae-9cba463a574f	staff	12ad082d-cbde-4cf9-9ed8-b719411b32b9	6	09:00:00	20:00:00
20479882-f5df-4c2b-9d03-b6c97a9a9f0e	chair	30bd2c29-ad59-463e-af7d-fccd0d9c9123	0	09:00:00	20:00:00
0efca1e3-fa5c-4ae2-b97b-6d6a3c0d7f9b	chair	30bd2c29-ad59-463e-af7d-fccd0d9c9123	1	09:00:00	20:00:00
49e62354-f924-411b-bcf4-ccae339c9508	chair	30bd2c29-ad59-463e-af7d-fccd0d9c9123	2	09:00:00	20:00:00
6dc569ca-6469-4e21-ac99-8961cffadee2	chair	30bd2c29-ad59-463e-af7d-fccd0d9c9123	3	09:00:00	20:00:00
78095d88-51ec-40b3-a95f-32ecc2317826	chair	30bd2c29-ad59-463e-af7d-fccd0d9c9123	4	09:00:00	20:00:00
b482d5c7-5119-40e6-aefc-104366b3bc76	chair	30bd2c29-ad59-463e-af7d-fccd0d9c9123	5	09:00:00	20:00:00
a29efb29-a59a-42ba-982f-3aa73de6e0ac	chair	30bd2c29-ad59-463e-af7d-fccd0d9c9123	6	09:00:00	20:00:00
808a5b7b-b42a-458c-9d75-40a8de65145b	staff	7cd0ff34-0612-4b8d-bd55-06216ab7d5d0	0	09:00:00	20:00:00
0ddf7bb2-eeae-435a-a294-fbe8a11ab175	staff	7cd0ff34-0612-4b8d-bd55-06216ab7d5d0	1	09:00:00	20:00:00
7a3fb071-e894-41e1-9adb-dcd76a729cb4	staff	7cd0ff34-0612-4b8d-bd55-06216ab7d5d0	2	09:00:00	20:00:00
6d75edbb-8c71-4bf8-8622-801e0c2440dd	staff	7cd0ff34-0612-4b8d-bd55-06216ab7d5d0	3	09:00:00	20:00:00
9e9c8c53-7fe0-4c7d-bfe3-044610f839dc	staff	7cd0ff34-0612-4b8d-bd55-06216ab7d5d0	4	09:00:00	20:00:00
9577aca2-dead-49d1-a964-82e24553c962	staff	7cd0ff34-0612-4b8d-bd55-06216ab7d5d0	5	09:00:00	20:00:00
f22a489c-3d2a-4d98-b0d5-914e56e1b5b3	staff	7cd0ff34-0612-4b8d-bd55-06216ab7d5d0	6	09:00:00	20:00:00
3bc407ce-ee86-4996-bd5f-f57bb19c6f70	staff	255ff837-95df-4758-ab01-a81fd1c90fe9	0	09:00:00	20:00:00
14eea883-b6fa-4cdd-b81d-e781918631b7	staff	255ff837-95df-4758-ab01-a81fd1c90fe9	1	09:00:00	20:00:00
8fd52dd8-a69b-4324-82c0-44faf9d7bf2f	staff	255ff837-95df-4758-ab01-a81fd1c90fe9	2	09:00:00	20:00:00
e898de1e-eff7-4c31-b2d5-dabcd89f65fd	staff	255ff837-95df-4758-ab01-a81fd1c90fe9	3	09:00:00	20:00:00
c22b4260-fb80-41bc-8dbf-c46477787eb9	staff	255ff837-95df-4758-ab01-a81fd1c90fe9	4	09:00:00	20:00:00
8117608b-1546-423a-a306-6d2410cbf342	staff	255ff837-95df-4758-ab01-a81fd1c90fe9	5	09:00:00	20:00:00
6deadb54-971f-4a58-9625-a8cbd77e9554	staff	255ff837-95df-4758-ab01-a81fd1c90fe9	6	09:00:00	20:00:00
53d91d44-a6c9-482c-be4e-d7c97771a09d	chair	1c57aa8c-3ff7-4f51-a0da-1c068139913a	0	09:00:00	20:00:00
d463ec1f-b62b-4616-9e21-0bfa6d55e1e9	chair	1c57aa8c-3ff7-4f51-a0da-1c068139913a	1	09:00:00	20:00:00
acc79353-86f0-40d6-a25e-44c70b97a646	chair	1c57aa8c-3ff7-4f51-a0da-1c068139913a	2	09:00:00	20:00:00
4499c7d0-84c0-4ad3-ab4a-367a899e8ba0	chair	1c57aa8c-3ff7-4f51-a0da-1c068139913a	3	09:00:00	20:00:00
361afc57-8df7-4640-a0e0-7cb8fc56d80f	chair	1c57aa8c-3ff7-4f51-a0da-1c068139913a	4	09:00:00	20:00:00
752e89f8-53a2-48db-8630-ba0beee49b6d	chair	1c57aa8c-3ff7-4f51-a0da-1c068139913a	5	09:00:00	20:00:00
d8bdaa59-3d4a-43a2-bd34-f90858e8b7dc	chair	1c57aa8c-3ff7-4f51-a0da-1c068139913a	6	09:00:00	20:00:00
8464b1a3-a988-44c7-9507-682c7b676966	chair	1bdc6c63-46b5-4c70-8e12-ea2ac1cceddc	0	09:00:00	20:00:00
fa45b734-b369-4398-bac1-a74f81f4868b	chair	1bdc6c63-46b5-4c70-8e12-ea2ac1cceddc	1	09:00:00	20:00:00
f01d8f6a-5904-438b-906c-99f1ae3e7fe0	chair	1bdc6c63-46b5-4c70-8e12-ea2ac1cceddc	2	09:00:00	20:00:00
12e413d9-1694-4769-926f-532880120051	chair	1bdc6c63-46b5-4c70-8e12-ea2ac1cceddc	3	09:00:00	20:00:00
65921cd7-261e-4ce2-a87f-a905c053ebc3	chair	1bdc6c63-46b5-4c70-8e12-ea2ac1cceddc	4	09:00:00	20:00:00
6b717b36-6ecf-4be3-a7a4-47a6c147919c	chair	1bdc6c63-46b5-4c70-8e12-ea2ac1cceddc	5	09:00:00	20:00:00
0a59bc69-d46b-476c-bc2e-4d91f5110a11	chair	1bdc6c63-46b5-4c70-8e12-ea2ac1cceddc	6	09:00:00	20:00:00
ea0fadeb-e177-4b69-ace5-b5b507418cdd	chair	9cda35a9-33b7-4489-a82a-dc396f16df97	0	09:00:00	20:00:00
9d2b3f56-ed4f-4c13-97fe-3423a6b60bc2	chair	9cda35a9-33b7-4489-a82a-dc396f16df97	1	09:00:00	20:00:00
a1a3cc53-7471-4ab9-ace9-f24b9fe25eaf	chair	9cda35a9-33b7-4489-a82a-dc396f16df97	2	09:00:00	20:00:00
4dabac67-73f1-4981-9ab6-a1a2dace1b31	chair	9cda35a9-33b7-4489-a82a-dc396f16df97	3	09:00:00	20:00:00
8389004b-a0cd-4c28-a140-75bf4d7eafa6	chair	9cda35a9-33b7-4489-a82a-dc396f16df97	4	09:00:00	20:00:00
a7fbbf39-128e-4783-a15d-b423bb99c156	chair	9cda35a9-33b7-4489-a82a-dc396f16df97	5	09:00:00	20:00:00
8ff95a06-c0b9-420a-88b6-1b0d3d3c8162	chair	9cda35a9-33b7-4489-a82a-dc396f16df97	6	09:00:00	20:00:00
7fa89215-4d0b-4401-b51d-cc0c92ea7508	staff	e02f8363-c079-4740-869e-7182f1a8feba	0	09:00:00	20:00:00
01433f20-8678-4728-8080-6d06d06d9e34	staff	e02f8363-c079-4740-869e-7182f1a8feba	1	09:00:00	20:00:00
1498f3af-d9ea-4f5d-9f0e-d6857386cd18	staff	e02f8363-c079-4740-869e-7182f1a8feba	2	09:00:00	20:00:00
1e0df6f8-2f48-409f-a77b-1b1e0997b156	staff	e02f8363-c079-4740-869e-7182f1a8feba	3	09:00:00	20:00:00
435460e6-d235-491d-b298-ec83803f7e93	staff	e02f8363-c079-4740-869e-7182f1a8feba	4	09:00:00	20:00:00
2ee1c30a-7c23-469a-ad07-8d0855069c9c	staff	e02f8363-c079-4740-869e-7182f1a8feba	5	09:00:00	20:00:00
c851aa3a-d314-4a4b-9d2f-2c9abc16fb17	staff	e02f8363-c079-4740-869e-7182f1a8feba	6	09:00:00	20:00:00
1ea80305-f09f-42f5-9b52-ebb8a7b6ecb2	chair	79bdfb29-1cfb-46a0-aad6-ac690d9be91b	0	09:00:00	20:00:00
f4ced5ea-2393-40c4-92b3-7411558358d3	chair	79bdfb29-1cfb-46a0-aad6-ac690d9be91b	1	09:00:00	20:00:00
9e1b7a05-1c4a-4a52-ba0c-610e856bf04f	chair	79bdfb29-1cfb-46a0-aad6-ac690d9be91b	2	09:00:00	20:00:00
7edd7cef-e82d-4d75-9491-c3a3590c0733	chair	79bdfb29-1cfb-46a0-aad6-ac690d9be91b	3	09:00:00	20:00:00
62a1cd22-b48e-4191-a1e6-25f0ed6e561b	chair	79bdfb29-1cfb-46a0-aad6-ac690d9be91b	4	09:00:00	20:00:00
f7b6e390-5c0f-40ba-827a-36283c599bac	chair	79bdfb29-1cfb-46a0-aad6-ac690d9be91b	5	09:00:00	20:00:00
948da3c8-3145-4e15-bf4d-2997c1fe6e32	chair	79bdfb29-1cfb-46a0-aad6-ac690d9be91b	6	09:00:00	20:00:00
a16c7528-38d2-49c4-8a3e-2170f837d630	staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	0	09:00:00	20:00:00
4b6e5867-d8c9-46f6-8ad0-5c4d3de403d4	staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	1	09:00:00	20:00:00
529b4af9-7a42-4196-9e1f-9c025ba2d447	staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	2	09:00:00	20:00:00
38dc5ef3-b49e-4931-9fa1-738147065335	staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	3	09:00:00	20:00:00
72abc2ad-b73f-4ed0-8593-d7320aa1babf	staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	4	09:00:00	20:00:00
e3e63dad-60f2-4c3b-833d-a654533573d4	staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	5	09:00:00	20:00:00
73d3d88b-f041-4355-8302-1e300c080acf	staff	d32250ab-ddb0-45ac-b21c-aca77709eab2	6	09:00:00	20:00:00
8369abc3-3c9b-4209-a741-6bd679df4bb6	staff	b8f357fd-925e-416d-b6aa-1c7f138f967f	0	09:00:00	20:00:00
7ebc7883-499c-4107-adcd-9abd0eacb19e	staff	b8f357fd-925e-416d-b6aa-1c7f138f967f	1	09:00:00	20:00:00
83513383-b586-4176-ab30-8ae872a07b65	staff	b8f357fd-925e-416d-b6aa-1c7f138f967f	2	09:00:00	20:00:00
ae2c1a3f-6f71-4e34-bcaf-6b46c2c373b3	staff	b8f357fd-925e-416d-b6aa-1c7f138f967f	3	09:00:00	20:00:00
fed27a8c-a497-4b0b-87b8-1d8b02eeffac	staff	b8f357fd-925e-416d-b6aa-1c7f138f967f	4	09:00:00	20:00:00
9ab11cae-a22d-4d08-af35-9b188d8f6fac	staff	b8f357fd-925e-416d-b6aa-1c7f138f967f	5	09:00:00	20:00:00
7aab2d25-3480-49b8-a50a-6a75c445f1ab	staff	b8f357fd-925e-416d-b6aa-1c7f138f967f	6	09:00:00	20:00:00
9675fdc2-28eb-48b6-9fd2-e75971041811	chair	0b563da0-a8a4-439d-bb7a-ccf7e32b6823	0	09:00:00	20:00:00
8a676d5d-4da3-44a6-a994-3ec4369bed04	chair	0b563da0-a8a4-439d-bb7a-ccf7e32b6823	1	09:00:00	20:00:00
b695b51f-8f57-434e-9a07-ca34071355ee	chair	0b563da0-a8a4-439d-bb7a-ccf7e32b6823	2	09:00:00	20:00:00
a8c08a8e-b36d-4201-b858-088a5aae0973	chair	0b563da0-a8a4-439d-bb7a-ccf7e32b6823	3	09:00:00	20:00:00
756a8712-ddda-4f9a-887b-13eb91a80adb	chair	0b563da0-a8a4-439d-bb7a-ccf7e32b6823	4	09:00:00	20:00:00
5bf87a63-3184-4e85-8c90-7525ea70a876	chair	0b563da0-a8a4-439d-bb7a-ccf7e32b6823	5	09:00:00	20:00:00
b05624d5-8a9d-4430-bbed-708d7234a521	chair	0b563da0-a8a4-439d-bb7a-ccf7e32b6823	6	09:00:00	20:00:00
5506439e-837b-4cbe-999a-d2ad19c80982	staff	aafbc6b7-ebdd-418f-a932-7c101946b59a	0	09:00:00	20:00:00
10f026b4-0281-4126-a2d6-69abc421ccec	staff	aafbc6b7-ebdd-418f-a932-7c101946b59a	1	09:00:00	20:00:00
f80fadad-2348-477d-9b06-ba1824a0533d	staff	aafbc6b7-ebdd-418f-a932-7c101946b59a	2	09:00:00	20:00:00
01226ad8-1b94-4f21-83f9-003c9b999c10	staff	aafbc6b7-ebdd-418f-a932-7c101946b59a	3	09:00:00	20:00:00
0851493a-809a-4662-a0c6-13dfdba082ad	staff	aafbc6b7-ebdd-418f-a932-7c101946b59a	4	09:00:00	20:00:00
978816f0-d321-47f0-b185-a826595164ac	staff	aafbc6b7-ebdd-418f-a932-7c101946b59a	5	09:00:00	20:00:00
bf18d13e-330d-4ffd-a88a-01f77fa70252	chair	f9b3e60a-9c0f-47ca-82e3-f7f43ee32280	0	09:00:00	20:00:00
1a9faa03-3582-409c-8d90-52fe528d7e08	chair	f9b3e60a-9c0f-47ca-82e3-f7f43ee32280	1	09:00:00	20:00:00
0880b4e2-e69f-434f-9752-dceac1ad984d	chair	f9b3e60a-9c0f-47ca-82e3-f7f43ee32280	2	09:00:00	20:00:00
78f60e38-5540-47fd-8fe5-aa338830f9c9	chair	f9b3e60a-9c0f-47ca-82e3-f7f43ee32280	3	09:00:00	20:00:00
9ae641cf-8826-41b6-b7b6-6b35a8e725f3	chair	f9b3e60a-9c0f-47ca-82e3-f7f43ee32280	4	09:00:00	20:00:00
f5c68d54-8990-4f18-8e55-b80654023c03	chair	f9b3e60a-9c0f-47ca-82e3-f7f43ee32280	5	09:00:00	20:00:00
15d6c568-4fa2-4c9d-8480-41cc17cd8082	chair	f9b3e60a-9c0f-47ca-82e3-f7f43ee32280	6	09:00:00	20:00:00
8910d838-9fcd-4a26-bb00-b8d0c2a8e34b	staff	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	0	09:00:00	20:00:00
2d3b94fc-b375-4261-bb3e-b5f073a5183b	staff	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	1	09:00:00	20:00:00
f1c14c72-c082-43b0-9d3b-fafac2fafd55	staff	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	2	09:00:00	20:00:00
0958a204-aa00-4d9c-ae6f-30f2b4584ba9	staff	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	3	09:00:00	20:00:00
0a684a72-621f-418f-9537-d11a70758ba0	staff	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	4	09:00:00	20:00:00
aae6de79-79c9-4075-911a-fa2451fe43f0	staff	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	5	09:00:00	20:00:00
0c5d11b3-6e0d-4343-8710-0d6e2dc0c775	staff	d36a99a4-d938-45b0-9d9c-90f6ebe8a19c	6	09:00:00	20:00:00
184f19d9-608c-4280-a4b6-eaed0e4607f7	chair	5daa0943-aca5-438d-a279-213321d089b4	0	09:00:00	20:00:00
a1f61ac1-9545-4e9b-be29-f6a927788833	chair	5daa0943-aca5-438d-a279-213321d089b4	1	09:00:00	20:00:00
6dfcc36a-8401-4c33-a3b2-ed591e5c5fcd	chair	5daa0943-aca5-438d-a279-213321d089b4	2	09:00:00	20:00:00
931493dd-562e-4886-8648-e4fe864b5168	chair	5daa0943-aca5-438d-a279-213321d089b4	3	09:00:00	20:00:00
8115f0bf-1eca-478c-b232-4e7abac6f447	chair	5daa0943-aca5-438d-a279-213321d089b4	4	09:00:00	20:00:00
84d9ab0c-dfba-42ef-a61b-214d55c1a3b9	chair	5daa0943-aca5-438d-a279-213321d089b4	5	09:00:00	20:00:00
91cef33f-ebf2-4466-add4-b108e411d7fb	chair	5daa0943-aca5-438d-a279-213321d089b4	6	09:00:00	20:00:00
b29b59e5-dcd7-4d20-b119-2d4fc353c9a8	staff	55651162-adb0-4938-918d-767d57a00eb9	0	09:00:00	20:00:00
4c647cf8-a560-41ba-8a29-140f96e5ddd1	staff	55651162-adb0-4938-918d-767d57a00eb9	1	09:00:00	20:00:00
cee774d7-fd87-4b4d-adac-50d2318321d6	staff	55651162-adb0-4938-918d-767d57a00eb9	2	09:00:00	20:00:00
92cd2cc0-8ca1-4564-adcb-3537fbfe156a	staff	55651162-adb0-4938-918d-767d57a00eb9	3	09:00:00	20:00:00
b511635a-9367-4ac6-819a-f7896783dce4	staff	55651162-adb0-4938-918d-767d57a00eb9	4	09:00:00	20:00:00
66cfacb4-7caa-4605-8fb9-f636af8943db	staff	55651162-adb0-4938-918d-767d57a00eb9	5	09:00:00	20:00:00
ce3c804e-86c7-440f-9b7e-790d212a8798	staff	55651162-adb0-4938-918d-767d57a00eb9	6	09:00:00	20:00:00
432fd8ff-65e7-4541-8cec-41a550876bec	chair	22f696d2-8e44-403d-8a31-d00f9f28ed85	0	09:00:00	20:00:00
aa08636c-3f5c-4b76-9574-8696ffe6067b	chair	22f696d2-8e44-403d-8a31-d00f9f28ed85	1	09:00:00	20:00:00
8616c44e-0206-4643-8910-f670b0f839f7	chair	22f696d2-8e44-403d-8a31-d00f9f28ed85	2	09:00:00	20:00:00
ab9b7601-bcc3-4b4e-87ab-05b63cf27b70	chair	22f696d2-8e44-403d-8a31-d00f9f28ed85	3	09:00:00	20:00:00
67461d67-963d-459c-9d0b-741bd0dbf805	chair	22f696d2-8e44-403d-8a31-d00f9f28ed85	4	09:00:00	20:00:00
f9dd0587-abf4-4e98-9259-e4b1fdafd3dc	chair	22f696d2-8e44-403d-8a31-d00f9f28ed85	5	09:00:00	20:00:00
33d32491-f6e3-4f65-9544-797b172c81c0	chair	22f696d2-8e44-403d-8a31-d00f9f28ed85	6	09:00:00	20:00:00
f2a94c1b-9de9-48ec-a10c-12d3740cba23	staff	3e7e0f89-9a69-4b53-a554-d035126cd135	0	09:00:00	20:00:00
e44f91d4-eb58-4cd9-bdd6-25e2a15bd444	staff	3e7e0f89-9a69-4b53-a554-d035126cd135	1	09:00:00	20:00:00
56eecc03-139b-44c7-963c-b609131388cb	staff	3e7e0f89-9a69-4b53-a554-d035126cd135	2	09:00:00	20:00:00
aeaac234-c6b0-4183-a54c-78d05d40b43e	staff	3e7e0f89-9a69-4b53-a554-d035126cd135	3	09:00:00	20:00:00
4e7df46d-4216-4d88-87f1-44ca08732320	staff	3e7e0f89-9a69-4b53-a554-d035126cd135	4	09:00:00	20:00:00
7efbb394-3e04-4a28-b070-051480a6d411	staff	3e7e0f89-9a69-4b53-a554-d035126cd135	5	09:00:00	20:00:00
4832c20f-46e0-46ab-8394-2241c5915598	staff	3e7e0f89-9a69-4b53-a554-d035126cd135	6	09:00:00	20:00:00
97441bd9-98bc-4e6c-bf98-5b4f15169133	chair	cd2fbb4c-8cc6-4c2e-b319-c244fdc849de	0	09:00:00	20:00:00
858e4d04-d26a-4dde-9f59-73e816bce6d4	chair	cd2fbb4c-8cc6-4c2e-b319-c244fdc849de	1	09:00:00	20:00:00
7adc3a94-1fcc-4fe9-88aa-160b0c7c9fff	chair	cd2fbb4c-8cc6-4c2e-b319-c244fdc849de	2	09:00:00	20:00:00
f91155a1-79b1-4eb7-91e7-d9b1ae411239	chair	cd2fbb4c-8cc6-4c2e-b319-c244fdc849de	3	09:00:00	20:00:00
0c370271-086d-4d65-a99b-e41c572f81d4	chair	cd2fbb4c-8cc6-4c2e-b319-c244fdc849de	4	09:00:00	20:00:00
5110f3ac-2ec2-41a2-af3b-e3d4291ea84b	chair	cd2fbb4c-8cc6-4c2e-b319-c244fdc849de	5	09:00:00	20:00:00
7f5c1ca7-dcbd-4903-8bf5-77528d1dc2cd	chair	cd2fbb4c-8cc6-4c2e-b319-c244fdc849de	6	09:00:00	20:00:00
0334949a-07bf-4c31-a77e-2fcbaf1a34f8	staff	4f403ce7-15d0-4ec9-b52b-b5e12973e84e	0	09:00:00	20:00:00
01db32d3-a5e8-473f-960d-6e9e4e407a7f	staff	4f403ce7-15d0-4ec9-b52b-b5e12973e84e	1	09:00:00	20:00:00
56a9bac6-56ad-472c-a9e4-97bb5b79d94a	staff	4f403ce7-15d0-4ec9-b52b-b5e12973e84e	2	09:00:00	20:00:00
99bfb98e-6f56-4a57-a0e2-83ac2919f14a	staff	4f403ce7-15d0-4ec9-b52b-b5e12973e84e	3	09:00:00	20:00:00
95578205-66fa-4800-96c1-ea3b9da4ecd4	staff	4f403ce7-15d0-4ec9-b52b-b5e12973e84e	4	09:00:00	20:00:00
71dbbff6-28a1-4286-b905-ebf6530c1661	staff	4f403ce7-15d0-4ec9-b52b-b5e12973e84e	5	09:00:00	20:00:00
977061a8-7979-4d3a-8d9c-c2c68f676141	staff	4f403ce7-15d0-4ec9-b52b-b5e12973e84e	6	09:00:00	20:00:00
2d602718-e092-4675-ac43-2535405f136a	staff	84a2f142-e502-43c7-9b33-3ea246f018c9	3	09:00:00	20:00:00
418cfb13-558b-4251-a7d1-e39ed9b12aac	staff	84a2f142-e502-43c7-9b33-3ea246f018c9	4	09:00:00	20:00:00
25033506-cdf7-4964-9f55-358989c25b3e	staff	84a2f142-e502-43c7-9b33-3ea246f018c9	5	09:00:00	20:00:00
cf4296d2-f01c-4fe5-abc5-b6578774b041	staff	84a2f142-e502-43c7-9b33-3ea246f018c9	6	09:00:00	20:00:00
12ef6b9e-daa2-4f79-9072-a884ca1d855b	chair	512ba19e-72ff-4100-b589-41817019052f	0	09:00:00	20:00:00
f6c35e99-fbd8-4252-8157-ce02a1e58e60	chair	512ba19e-72ff-4100-b589-41817019052f	1	09:00:00	20:00:00
83cecb29-48b8-464e-8595-cfc971e5cd4c	chair	512ba19e-72ff-4100-b589-41817019052f	2	09:00:00	20:00:00
fb3f0ada-8e88-40f4-856b-f5f99858f88b	chair	512ba19e-72ff-4100-b589-41817019052f	3	09:00:00	20:00:00
17ba9886-9c19-4493-bcb1-5e3011fdceae	chair	512ba19e-72ff-4100-b589-41817019052f	4	09:00:00	20:00:00
d9b96fcc-42cd-494b-8546-498e0ef1ac80	chair	512ba19e-72ff-4100-b589-41817019052f	5	09:00:00	20:00:00
7450e586-0484-40d2-885d-5c338f6c17c5	chair	512ba19e-72ff-4100-b589-41817019052f	6	09:00:00	20:00:00
c685ce60-f4fe-4492-8b11-0952f9c0d0c9	staff	795d9693-3ea4-4ff2-b9e6-20cb6255fb01	0	09:00:00	20:00:00
53243110-0df2-4f8b-93c9-baa2a7a280e2	staff	795d9693-3ea4-4ff2-b9e6-20cb6255fb01	1	09:00:00	20:00:00
7b10e85c-df5a-4e3f-8ca6-dfc799d33daa	staff	795d9693-3ea4-4ff2-b9e6-20cb6255fb01	2	09:00:00	20:00:00
7ae3ebae-60ac-4a7f-9baa-74fc2739cc17	staff	795d9693-3ea4-4ff2-b9e6-20cb6255fb01	3	09:00:00	20:00:00
2b353e8e-bbe8-4900-94e0-f371308cc7e3	staff	795d9693-3ea4-4ff2-b9e6-20cb6255fb01	4	09:00:00	20:00:00
6c710165-d454-44ca-a579-fcda18b2e60f	staff	795d9693-3ea4-4ff2-b9e6-20cb6255fb01	5	09:00:00	20:00:00
df2b46d1-a40c-4097-86cf-6eeb099ab315	staff	795d9693-3ea4-4ff2-b9e6-20cb6255fb01	6	09:00:00	20:00:00
4d7f904c-a154-4ea3-a247-a7bf9819f8f3	chair	81b7e517-ebd1-45b0-ac76-499796224248	0	09:00:00	20:00:00
a5397914-561e-4a1c-a716-f1b4777fad93	chair	81b7e517-ebd1-45b0-ac76-499796224248	1	09:00:00	20:00:00
e12a3f96-b5eb-4960-b49b-bd462157de6b	chair	81b7e517-ebd1-45b0-ac76-499796224248	2	09:00:00	20:00:00
ea58d147-1d86-4e78-ab6f-abdf07bd8522	chair	81b7e517-ebd1-45b0-ac76-499796224248	3	09:00:00	20:00:00
cb7613a6-f6ef-45f0-94f7-bccf30633023	chair	81b7e517-ebd1-45b0-ac76-499796224248	4	09:00:00	20:00:00
410561dd-89a3-48a9-b5b2-ffd4b86588d9	chair	81b7e517-ebd1-45b0-ac76-499796224248	5	09:00:00	20:00:00
49ef8911-3afd-4f83-868a-10699a7b96fe	chair	81b7e517-ebd1-45b0-ac76-499796224248	6	09:00:00	20:00:00
6e0ce134-ef26-4a81-a361-1eddca4589f8	staff	5c3ee7d7-dc07-4634-b6c4-9304a00d1a86	0	09:00:00	20:00:00
50d2914a-8fc3-456e-bd9c-d326a31e753b	staff	5c3ee7d7-dc07-4634-b6c4-9304a00d1a86	1	09:00:00	20:00:00
7271353e-2baa-4d14-b663-c39443ce648d	staff	5c3ee7d7-dc07-4634-b6c4-9304a00d1a86	2	09:00:00	20:00:00
55c5f0d3-f6a7-48f0-b1b6-d2a18f81b57d	staff	5c3ee7d7-dc07-4634-b6c4-9304a00d1a86	3	09:00:00	20:00:00
266053d4-4886-4259-b3d6-6a88fe116c00	staff	5c3ee7d7-dc07-4634-b6c4-9304a00d1a86	4	09:00:00	20:00:00
bf752f4e-7214-4f63-8f12-3160f642474d	staff	5c3ee7d7-dc07-4634-b6c4-9304a00d1a86	5	09:00:00	20:00:00
85b90a1b-b623-4c23-abce-0fd27b25c24d	staff	5c3ee7d7-dc07-4634-b6c4-9304a00d1a86	6	09:00:00	20:00:00
f3d9c6c6-b5bf-4281-9fb1-9b7a197b0276	staff	aafbc6b7-ebdd-418f-a932-7c101946b59a	6	09:00:00	20:00:00
e8b6d186-13cd-4720-9d88-87b833b9755a	chair	8203a5e5-02d6-4103-86d4-941fadc45b77	0	09:00:00	20:00:00
af5e589e-906b-4ce4-b78c-73b5789c908d	chair	8203a5e5-02d6-4103-86d4-941fadc45b77	1	09:00:00	20:00:00
d08df436-1473-4c41-a94d-cb972ecfdda2	chair	8203a5e5-02d6-4103-86d4-941fadc45b77	2	09:00:00	20:00:00
306faa7f-e4a4-4c90-b31d-ac1b62c27b4c	chair	8203a5e5-02d6-4103-86d4-941fadc45b77	3	09:00:00	20:00:00
6f044351-2e90-4c67-b103-4a7ba9d74a08	chair	8203a5e5-02d6-4103-86d4-941fadc45b77	4	09:00:00	20:00:00
02101dd3-4031-452c-83a6-a23bb8d25eca	chair	8203a5e5-02d6-4103-86d4-941fadc45b77	5	09:00:00	20:00:00
aef5072d-1bc3-4751-ae5b-65c8ac4d7158	chair	8203a5e5-02d6-4103-86d4-941fadc45b77	6	09:00:00	20:00:00
2dcb5463-5d5b-4634-a357-efe99075e85a	staff	46c81677-9e6d-45cd-8a0d-937679db012a	0	09:00:00	20:00:00
f04af666-edd1-4d22-9c3a-5ba42ab960ea	staff	46c81677-9e6d-45cd-8a0d-937679db012a	1	09:00:00	20:00:00
a10bc0dd-7008-4fcd-b9b8-42fc952d53df	staff	46c81677-9e6d-45cd-8a0d-937679db012a	2	09:00:00	20:00:00
783f7562-46c7-4faf-b5ae-6d1fd18505b8	staff	46c81677-9e6d-45cd-8a0d-937679db012a	3	09:00:00	20:00:00
7f639345-ceb8-4df5-bb09-aa602c6047ca	staff	46c81677-9e6d-45cd-8a0d-937679db012a	4	09:00:00	20:00:00
9348041f-bbbe-4545-89ac-110e45aa17c0	staff	46c81677-9e6d-45cd-8a0d-937679db012a	5	09:00:00	20:00:00
85478b33-32d7-4b61-99f5-19b0b6b6927b	staff	46c81677-9e6d-45cd-8a0d-937679db012a	6	09:00:00	20:00:00
0b3f38f5-eff6-4fe2-a615-a16fe74782c3	chair	44f64b0b-ce04-4d75-b36b-999245141658	0	09:00:00	20:00:00
44b88f07-5eb4-4d56-a629-243c7b5a9f5d	chair	44f64b0b-ce04-4d75-b36b-999245141658	1	09:00:00	20:00:00
55f403c4-bca1-409d-9d8d-e9cc97038b0c	chair	44f64b0b-ce04-4d75-b36b-999245141658	2	09:00:00	20:00:00
588c0306-1ac5-46d5-9d11-1499497c4296	chair	44f64b0b-ce04-4d75-b36b-999245141658	3	09:00:00	20:00:00
38377238-d5d1-4609-b54f-d9f980169a13	chair	44f64b0b-ce04-4d75-b36b-999245141658	4	09:00:00	20:00:00
042c467c-f14e-4f57-96a1-5284a18cbbf6	chair	44f64b0b-ce04-4d75-b36b-999245141658	5	09:00:00	20:00:00
e3bbfdeb-3b39-4122-9f7d-d6538a5ea83e	chair	44f64b0b-ce04-4d75-b36b-999245141658	6	09:00:00	20:00:00
44e77e94-fcf3-43ec-8802-09fb58e16962	staff	8ba71a61-d554-4c11-8394-b6fc34dc94f3	0	09:00:00	20:00:00
eb9d038d-3c55-4ea3-b5cc-83212b7b8421	staff	8ba71a61-d554-4c11-8394-b6fc34dc94f3	1	09:00:00	20:00:00
dedd6298-ffe1-489c-a729-fee6a84a11b3	staff	8ba71a61-d554-4c11-8394-b6fc34dc94f3	2	09:00:00	20:00:00
cf4879c2-1f4d-4376-a413-62e334a509fd	staff	8ba71a61-d554-4c11-8394-b6fc34dc94f3	3	09:00:00	20:00:00
e327aec2-3eb7-44d7-8414-ace55d765936	staff	8ba71a61-d554-4c11-8394-b6fc34dc94f3	4	09:00:00	20:00:00
60d25904-d9a1-406a-8fd4-836036356313	staff	8ba71a61-d554-4c11-8394-b6fc34dc94f3	5	09:00:00	20:00:00
f0e0b097-f3c6-4deb-a109-70f64eb65ec0	staff	8ba71a61-d554-4c11-8394-b6fc34dc94f3	6	09:00:00	20:00:00
a180b854-a6c8-4b5c-bd3c-187b82626c01	chair	75718851-1089-4940-b865-d2d1585bae37	0	09:00:00	20:00:00
d411b647-bfaa-43b1-9699-211cbe5a613e	chair	75718851-1089-4940-b865-d2d1585bae37	1	09:00:00	20:00:00
3d86cd8c-c840-4322-8955-3b3b46115fd3	chair	75718851-1089-4940-b865-d2d1585bae37	2	09:00:00	20:00:00
72a17b22-8d11-4a2d-a441-e93fec7c9bb7	chair	75718851-1089-4940-b865-d2d1585bae37	3	09:00:00	20:00:00
1a7a41ff-94f4-4d12-99ab-f2e4c4f6f274	chair	75718851-1089-4940-b865-d2d1585bae37	4	09:00:00	20:00:00
92345581-5da6-41f7-b888-40fd2aa5b9d6	chair	75718851-1089-4940-b865-d2d1585bae37	5	09:00:00	20:00:00
b8535be0-d385-4f01-84e9-413bd5de4243	chair	75718851-1089-4940-b865-d2d1585bae37	6	09:00:00	20:00:00
6a4d7174-a022-48fe-a4d8-d68b49e45ecf	staff	fe8403ef-6732-42db-868d-4346f296f49c	0	09:00:00	20:00:00
52cf2802-3528-4051-ba23-de15d5c0c317	staff	fe8403ef-6732-42db-868d-4346f296f49c	1	09:00:00	20:00:00
47217ab9-e481-4823-a12b-2099424e04eb	staff	fe8403ef-6732-42db-868d-4346f296f49c	2	09:00:00	20:00:00
21d8c2ed-3162-4772-b4b1-b485ebf958f8	staff	fe8403ef-6732-42db-868d-4346f296f49c	3	09:00:00	20:00:00
16b51c3c-8456-4766-a90d-722fadeb2dfc	staff	fe8403ef-6732-42db-868d-4346f296f49c	4	09:00:00	20:00:00
9978e55c-3dd1-4143-b3e2-92080506961c	staff	fe8403ef-6732-42db-868d-4346f296f49c	5	09:00:00	20:00:00
80e54dfb-2b79-4416-9b02-63a3ba61f4d5	staff	fe8403ef-6732-42db-868d-4346f296f49c	6	09:00:00	20:00:00
52c575e3-fab5-403f-8a26-1064a2475a72	chair	673165a3-1070-4069-8aec-3d86ddf8a2cd	0	09:00:00	20:00:00
37130b8d-b062-4d70-a68b-3f1c825db346	chair	673165a3-1070-4069-8aec-3d86ddf8a2cd	1	09:00:00	20:00:00
16ebde2a-83f9-4d1a-ad19-adb9bb1981f5	chair	673165a3-1070-4069-8aec-3d86ddf8a2cd	2	09:00:00	20:00:00
1e7b2f69-f9a3-44b9-9f2c-2dd8cd651da6	chair	673165a3-1070-4069-8aec-3d86ddf8a2cd	3	09:00:00	20:00:00
7acfb955-5024-4ebe-a593-3521ca601cd0	chair	673165a3-1070-4069-8aec-3d86ddf8a2cd	4	09:00:00	20:00:00
23f1b824-8ac1-44c1-a339-1fcde37dd2ea	chair	673165a3-1070-4069-8aec-3d86ddf8a2cd	5	09:00:00	20:00:00
e715fdc8-a744-46f9-aba8-459a65f7e6c3	chair	673165a3-1070-4069-8aec-3d86ddf8a2cd	6	09:00:00	20:00:00
51964a8e-e6df-4a41-b671-65038ddfb816	staff	3aa936f8-68be-44d9-af0e-d76003bb58bd	0	09:00:00	20:00:00
0bbdd666-0df9-4981-881c-c6dc0ea4ce2f	staff	3aa936f8-68be-44d9-af0e-d76003bb58bd	1	09:00:00	20:00:00
a4ec9ae5-aeff-4ecc-a590-b4040ebd59d6	chair	4ddc657a-b4f8-4cf8-a5e3-3bf91dcf691d	0	09:00:00	20:00:00
ed8364db-4897-4b0f-8761-307237fc96aa	chair	4ddc657a-b4f8-4cf8-a5e3-3bf91dcf691d	1	09:00:00	20:00:00
bbaeec9a-798e-4b40-b954-2b40cef375da	chair	4ddc657a-b4f8-4cf8-a5e3-3bf91dcf691d	2	09:00:00	20:00:00
e313f421-b273-49a2-944e-a09baffba5b7	chair	4ddc657a-b4f8-4cf8-a5e3-3bf91dcf691d	3	09:00:00	20:00:00
77078c0e-4e66-476d-8b8e-da2cf98cf4b0	chair	4ddc657a-b4f8-4cf8-a5e3-3bf91dcf691d	4	09:00:00	20:00:00
c44d569e-1103-4105-b7e5-f1b54cd580a7	chair	4ddc657a-b4f8-4cf8-a5e3-3bf91dcf691d	5	09:00:00	20:00:00
8ebfc935-bbad-47cb-827a-cf8d777af31d	chair	4ddc657a-b4f8-4cf8-a5e3-3bf91dcf691d	6	09:00:00	20:00:00
11508757-8f73-4ddd-9fd6-89ddbf0241a2	staff	5b6096b9-d650-4ba0-a796-be663918104a	0	09:00:00	20:00:00
2ba90352-d9ef-463d-9dfa-15034c8da9c6	staff	5b6096b9-d650-4ba0-a796-be663918104a	1	09:00:00	20:00:00
8232d2c6-8468-46bb-940d-976125ef369f	staff	5b6096b9-d650-4ba0-a796-be663918104a	2	09:00:00	20:00:00
413b46fa-b7ab-411c-9293-2457f6687220	staff	5b6096b9-d650-4ba0-a796-be663918104a	3	09:00:00	20:00:00
4d03850a-fb60-44bb-8c1b-97532ce24fd0	staff	5b6096b9-d650-4ba0-a796-be663918104a	4	09:00:00	20:00:00
16a7b6aa-d7bd-406e-ae66-c9d0a1fe6e76	staff	5b6096b9-d650-4ba0-a796-be663918104a	5	09:00:00	20:00:00
3ffd4e12-aba3-406d-89f5-27c00c260739	staff	5b6096b9-d650-4ba0-a796-be663918104a	6	09:00:00	20:00:00
d4d9ae33-483a-45b1-916e-d0013729b802	chair	8cfbb616-4388-4302-8964-903e7570386e	0	09:00:00	20:00:00
229b4c9f-f851-4904-96fc-0c2f1679df43	chair	8cfbb616-4388-4302-8964-903e7570386e	1	09:00:00	20:00:00
3ab8a4da-47e2-406d-a3e7-f5ac3126f946	chair	8cfbb616-4388-4302-8964-903e7570386e	2	09:00:00	20:00:00
66fa7f19-b379-479d-8aad-645b73b5b5b5	chair	8cfbb616-4388-4302-8964-903e7570386e	3	09:00:00	20:00:00
35595411-7102-4886-9107-39c71308eaae	chair	8cfbb616-4388-4302-8964-903e7570386e	4	09:00:00	20:00:00
0d5483ff-0cae-4ce0-ba3e-a1a6321be677	staff	753944de-8b7f-40de-880f-32b84429daa1	0	09:00:00	20:00:00
4b9ee4f3-2880-40b6-91dc-39be2aabb22e	staff	753944de-8b7f-40de-880f-32b84429daa1	1	09:00:00	20:00:00
1bdff376-8436-4360-a749-6b3560c5a30a	staff	753944de-8b7f-40de-880f-32b84429daa1	2	09:00:00	20:00:00
4c76f5cd-6f9c-4580-a3bb-6a4566392604	staff	753944de-8b7f-40de-880f-32b84429daa1	3	09:00:00	20:00:00
49a09c9a-9993-4fe9-8987-82097f84d9ce	staff	753944de-8b7f-40de-880f-32b84429daa1	4	09:00:00	20:00:00
78f26f08-b5f7-48c5-80be-380cd39abbdf	staff	753944de-8b7f-40de-880f-32b84429daa1	5	09:00:00	20:00:00
bb38b23d-07d3-43c1-9789-ce9bd277ce15	staff	753944de-8b7f-40de-880f-32b84429daa1	6	09:00:00	20:00:00
66956d8e-74d1-4caa-9629-49b819761c1d	chair	8cfbb616-4388-4302-8964-903e7570386e	5	09:00:00	20:00:00
5bc8235b-5175-4303-bcda-e82977e4a6b9	chair	8cfbb616-4388-4302-8964-903e7570386e	6	09:00:00	20:00:00
e7502a35-8609-45ad-a4ae-a5b504154ab5	staff	3aa936f8-68be-44d9-af0e-d76003bb58bd	2	09:00:00	20:00:00
076795fd-ee58-4682-b318-1794192a1cf6	staff	3aa936f8-68be-44d9-af0e-d76003bb58bd	3	09:00:00	20:00:00
403dd5a6-7203-44ee-a2c2-85b590901ac2	staff	3aa936f8-68be-44d9-af0e-d76003bb58bd	4	09:00:00	20:00:00
db51c3f0-8b43-4f09-bfe4-9c787dcdb6fe	staff	3aa936f8-68be-44d9-af0e-d76003bb58bd	5	09:00:00	20:00:00
43e3f986-57d1-4a9c-8cb4-217da16d3f58	staff	3aa936f8-68be-44d9-af0e-d76003bb58bd	6	09:00:00	20:00:00
fe6fc36c-5267-4b0d-8744-9661cc6e2f78	chair	3e9d0a59-525b-4726-8533-9ade944d46d4	0	09:00:00	20:00:00
c61d11e1-f947-4276-9205-7c4b4916993d	chair	3e9d0a59-525b-4726-8533-9ade944d46d4	1	09:00:00	20:00:00
7bf808d3-316d-48ce-9ae0-53f33112af1f	chair	3e9d0a59-525b-4726-8533-9ade944d46d4	2	09:00:00	20:00:00
289227b4-b6b1-4068-8291-5f2e771a6038	chair	99aa6936-59d7-4002-b3ff-041f1a0d5395	0	09:00:00	20:00:00
c80dddfa-266f-41a6-843e-a5f3c2fed9dd	chair	99aa6936-59d7-4002-b3ff-041f1a0d5395	1	09:00:00	20:00:00
df1b73c7-d7ab-4f96-bc1b-64ea1599a6d4	chair	99aa6936-59d7-4002-b3ff-041f1a0d5395	2	09:00:00	20:00:00
f38ce365-3326-4b39-b614-ecb7d45e9295	chair	99aa6936-59d7-4002-b3ff-041f1a0d5395	3	09:00:00	20:00:00
ec3388a4-537e-4ed7-8c41-a5ab676b839e	chair	99aa6936-59d7-4002-b3ff-041f1a0d5395	4	09:00:00	20:00:00
de5d6495-c7f7-4aee-9ed1-8c0a19b66c38	chair	99aa6936-59d7-4002-b3ff-041f1a0d5395	5	09:00:00	20:00:00
57253b66-6b56-4d08-97ca-f0c6df5093e1	chair	99aa6936-59d7-4002-b3ff-041f1a0d5395	6	09:00:00	20:00:00
cda51c3e-4768-496a-8925-692bd8043929	chair	3e9d0a59-525b-4726-8533-9ade944d46d4	3	09:00:00	20:00:00
5db428e8-c367-4a65-99b1-46590961ec6e	chair	3e9d0a59-525b-4726-8533-9ade944d46d4	4	09:00:00	20:00:00
0d9620f1-7bf2-439d-802c-f80bfcf7fa8c	chair	3e9d0a59-525b-4726-8533-9ade944d46d4	5	09:00:00	20:00:00
e3ac409e-9d39-45fa-8f4a-2840995b6b79	chair	3e9d0a59-525b-4726-8533-9ade944d46d4	6	09:00:00	20:00:00
a2355ca5-2a8b-4b59-b218-56e45f5f90bc	staff	488c3d0d-79fb-4343-9a88-44465fa9a189	0	09:00:00	20:00:00
1e3a87e1-425b-42eb-b1d6-560da5fbe1e4	staff	488c3d0d-79fb-4343-9a88-44465fa9a189	1	09:00:00	20:00:00
cc0f1bd3-8e1c-4569-97b7-ca367c709e17	staff	488c3d0d-79fb-4343-9a88-44465fa9a189	2	09:00:00	20:00:00
3196c7ad-a4ff-41c1-a311-3c73b4fbdb1b	staff	488c3d0d-79fb-4343-9a88-44465fa9a189	3	09:00:00	20:00:00
fb4278b0-e162-4e83-b583-52de126972cc	staff	488c3d0d-79fb-4343-9a88-44465fa9a189	4	09:00:00	20:00:00
f8f001ce-368b-437c-b46e-3528709d09a3	staff	488c3d0d-79fb-4343-9a88-44465fa9a189	5	09:00:00	20:00:00
4746fc7c-8663-46c8-803d-46d148d60ea6	staff	488c3d0d-79fb-4343-9a88-44465fa9a189	6	09:00:00	20:00:00
a69e4716-8090-4b11-b263-254c9da89818	chair	2daa9168-7197-4b7d-8ca1-46dd79316812	0	09:00:00	20:00:00
9b103605-c7b8-4248-a66f-04778a6f1fa0	chair	2daa9168-7197-4b7d-8ca1-46dd79316812	1	09:00:00	20:00:00
79c6e946-7581-4b1f-b835-2d978004fa21	chair	2daa9168-7197-4b7d-8ca1-46dd79316812	2	09:00:00	20:00:00
09e9f443-fba0-4c19-b107-c5f8b713b8c0	chair	2daa9168-7197-4b7d-8ca1-46dd79316812	3	09:00:00	20:00:00
1a7e13f7-0099-4aaa-93ca-96753dde93b0	chair	2daa9168-7197-4b7d-8ca1-46dd79316812	4	09:00:00	20:00:00
f045dd97-2d07-410f-8724-56b12790e557	chair	2daa9168-7197-4b7d-8ca1-46dd79316812	5	09:00:00	20:00:00
449f6b04-fec7-4e71-8a37-6a27a5b9b4cb	chair	2daa9168-7197-4b7d-8ca1-46dd79316812	6	09:00:00	20:00:00
009ddb42-40b7-4f7e-a106-c873eb97b02a	staff	1f4db7a8-06ca-40c5-9665-8290991540ee	0	09:00:00	20:00:00
5bd456d4-56f9-4a06-a719-ecc340017fc4	staff	1f4db7a8-06ca-40c5-9665-8290991540ee	1	09:00:00	20:00:00
5f8563ed-4475-4c4c-9e15-600343f8f638	staff	1f4db7a8-06ca-40c5-9665-8290991540ee	2	09:00:00	20:00:00
bc8bf5d7-3805-467e-8554-48e9d0adcda1	staff	1f4db7a8-06ca-40c5-9665-8290991540ee	3	09:00:00	20:00:00
8d0b21a5-e8ad-405c-b506-2adf71a4aa8d	staff	1f4db7a8-06ca-40c5-9665-8290991540ee	4	09:00:00	20:00:00
c0a243b3-7351-4bbf-be71-34e53434e5d0	staff	1f4db7a8-06ca-40c5-9665-8290991540ee	5	09:00:00	20:00:00
6219427f-f17b-47a5-9b84-197495c4ff7e	staff	1f4db7a8-06ca-40c5-9665-8290991540ee	6	09:00:00	20:00:00
aebca29f-fcfa-4a5c-8648-0022bdf76ca6	chair	03fb9614-ae11-4924-8f77-5cbaf8466683	0	09:00:00	20:00:00
ca98de94-f216-40d2-8099-37f524c5d153	chair	03fb9614-ae11-4924-8f77-5cbaf8466683	1	09:00:00	20:00:00
59cf2eed-ecd0-4133-bac1-cc7d9a93ecf2	chair	03fb9614-ae11-4924-8f77-5cbaf8466683	2	09:00:00	20:00:00
bdee462f-2eca-4c71-983a-dc07b7967d0f	chair	03fb9614-ae11-4924-8f77-5cbaf8466683	3	09:00:00	20:00:00
0c86021f-7ced-4cff-9f62-8cafe1c11fb2	chair	03fb9614-ae11-4924-8f77-5cbaf8466683	4	09:00:00	20:00:00
f3bebfb0-39ef-49d5-ba55-609475da4d2e	chair	03fb9614-ae11-4924-8f77-5cbaf8466683	5	09:00:00	20:00:00
1a19a098-ef7c-4eaa-8de4-711172d75b9a	chair	03fb9614-ae11-4924-8f77-5cbaf8466683	6	09:00:00	20:00:00
38bc5cb5-6574-4ac3-ab8b-6f7778aee1a6	chair	3502e9d8-865c-4dbe-b819-7e9af7ff70ca	2	09:00:00	20:00:00
c40d1304-f306-4dac-9264-47cb0829a347	chair	3502e9d8-865c-4dbe-b819-7e9af7ff70ca	3	09:00:00	20:00:00
74b4be68-cbce-4f99-bb7f-939779b5ad50	chair	3502e9d8-865c-4dbe-b819-7e9af7ff70ca	4	09:00:00	20:00:00
31890279-3bc0-4af6-bbdb-88ceff73f190	chair	3502e9d8-865c-4dbe-b819-7e9af7ff70ca	5	09:00:00	20:00:00
d9931e3b-92bd-42b3-a67b-04631a9bd8d7	chair	3502e9d8-865c-4dbe-b819-7e9af7ff70ca	6	09:00:00	20:00:00
17e30aef-d074-48ab-93b7-e18c9cbde4ae	staff	f4d81258-d4e4-45c4-9445-eb76a88b6ff9	0	09:00:00	20:00:00
250adeb0-838d-43bf-bd62-5c407ea981d0	staff	f4d81258-d4e4-45c4-9445-eb76a88b6ff9	1	09:00:00	20:00:00
1421359f-f7ba-493c-b35b-96fd29fa5805	staff	f4d81258-d4e4-45c4-9445-eb76a88b6ff9	2	09:00:00	20:00:00
2d5a698e-5485-4e13-bad9-429c5cf55973	staff	f4d81258-d4e4-45c4-9445-eb76a88b6ff9	3	09:00:00	20:00:00
781bca30-e767-4d7d-abc7-ee721743ce96	staff	f4d81258-d4e4-45c4-9445-eb76a88b6ff9	4	09:00:00	20:00:00
bf22397a-e5e2-49a8-bebf-34520ce5f259	staff	f4d81258-d4e4-45c4-9445-eb76a88b6ff9	5	09:00:00	20:00:00
984358b5-600c-43f2-87d9-13bb3cdb7b77	staff	f4d81258-d4e4-45c4-9445-eb76a88b6ff9	6	09:00:00	20:00:00
a6025203-f1b1-459a-bc7e-3c4f3b0b5d01	chair	9c5b49dc-2855-475e-8cfc-ce8be6aaa6bc	0	09:00:00	20:00:00
c41af733-b07a-4390-8fb5-f95f66758a28	chair	9c5b49dc-2855-475e-8cfc-ce8be6aaa6bc	1	09:00:00	20:00:00
14464a78-f8f4-4203-8ffa-7c30ff5c884b	chair	1945e54b-19d9-4988-ad4c-c4345f840274	0	09:00:00	20:00:00
94c740ff-1c44-4983-8066-86d19f7ed558	chair	1945e54b-19d9-4988-ad4c-c4345f840274	1	09:00:00	20:00:00
46b4bf2d-285a-4c96-b21c-bc6750b23c08	chair	1945e54b-19d9-4988-ad4c-c4345f840274	2	09:00:00	20:00:00
e404f008-da42-4217-aed4-f985dc6234d2	chair	1945e54b-19d9-4988-ad4c-c4345f840274	3	09:00:00	20:00:00
3901e569-5142-4b15-a37e-79a566e610f5	chair	1945e54b-19d9-4988-ad4c-c4345f840274	4	09:00:00	20:00:00
2fdb7c53-57f1-4613-bbf9-5fdadaea9f50	chair	1945e54b-19d9-4988-ad4c-c4345f840274	5	09:00:00	20:00:00
f4b07ce1-1986-4d37-81a8-99fbeea059e8	chair	1945e54b-19d9-4988-ad4c-c4345f840274	6	09:00:00	20:00:00
3d0a561b-fd46-4a9b-8f5d-4b5c109eca0a	staff	650b3df5-9cad-40dd-b403-fe532b2f9e83	0	09:00:00	20:00:00
ada0aeaf-0efc-4395-935a-2c4ca8f36577	staff	650b3df5-9cad-40dd-b403-fe532b2f9e83	1	09:00:00	20:00:00
53a15b16-a9c9-443d-86f4-0b404862a607	staff	650b3df5-9cad-40dd-b403-fe532b2f9e83	2	09:00:00	20:00:00
f8ee0476-47dd-4b57-94ce-6ca087a40d8b	staff	650b3df5-9cad-40dd-b403-fe532b2f9e83	3	09:00:00	20:00:00
93c0cec9-a831-4348-a416-f4277db20873	staff	650b3df5-9cad-40dd-b403-fe532b2f9e83	4	09:00:00	20:00:00
fdc112f9-fc76-401b-94d9-113e7a5564af	staff	650b3df5-9cad-40dd-b403-fe532b2f9e83	5	09:00:00	20:00:00
a0845248-bbdc-416c-98a1-44090dbbd735	staff	650b3df5-9cad-40dd-b403-fe532b2f9e83	6	09:00:00	20:00:00
9b0ea5dc-b2cd-4aff-8bd0-745afa9c761e	chair	bab8f300-58d3-4204-aa59-3277363d1036	0	09:00:00	20:00:00
af96559f-9b65-43fc-8595-661b5b420e2e	chair	bab8f300-58d3-4204-aa59-3277363d1036	1	09:00:00	20:00:00
0fb4be1e-48ad-461a-bd76-94d1c436732d	chair	bab8f300-58d3-4204-aa59-3277363d1036	2	09:00:00	20:00:00
ceda9bd9-16a1-4358-80de-5de170af92d2	chair	bab8f300-58d3-4204-aa59-3277363d1036	3	09:00:00	20:00:00
8bd176be-02e1-41bf-a33a-5c104cf66e67	chair	bab8f300-58d3-4204-aa59-3277363d1036	4	09:00:00	20:00:00
0af5c7c6-7986-42f3-9774-5ca77d9d3c54	chair	bab8f300-58d3-4204-aa59-3277363d1036	5	09:00:00	20:00:00
9023f821-3094-464f-b969-b5b87227a724	chair	bab8f300-58d3-4204-aa59-3277363d1036	6	09:00:00	20:00:00
7a64cd0e-62e3-4d6d-89bd-66b1e6cc46d1	staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	0	09:00:00	20:00:00
8908c3ea-9f2b-4f43-b978-63bdd490eb7e	staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	1	09:00:00	20:00:00
192e3af0-865d-491b-b449-fa40997dfd40	staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	2	09:00:00	20:00:00
a2928670-65ef-42b1-973a-477d1858e180	staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	3	09:00:00	20:00:00
e53db843-6a00-4022-8043-2518797dd525	staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	4	09:00:00	20:00:00
6fce8585-614f-4196-8667-0e305c10b765	staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	5	09:00:00	20:00:00
31a6b97e-e02f-4dc4-937c-e49aac597c99	staff	a3b2cb93-a39f-4cb4-9872-bec91a7edd69	6	09:00:00	20:00:00
fccdb0e1-bdff-4d97-92f7-a0718dfe47cb	chair	aedc7aca-46db-4fda-9bb9-19a72723e04d	0	09:00:00	20:00:00
56319efa-a39d-4977-ba01-2cf82d48e474	chair	aedc7aca-46db-4fda-9bb9-19a72723e04d	1	09:00:00	20:00:00
3edb37f9-96f9-46d3-baf1-d4e3dfd24a59	chair	aedc7aca-46db-4fda-9bb9-19a72723e04d	2	09:00:00	20:00:00
f5999c88-963b-471b-8d66-bf46981d1340	chair	aedc7aca-46db-4fda-9bb9-19a72723e04d	3	09:00:00	20:00:00
73b54b9e-6813-46f3-a9c8-8dbebbd63412	chair	aedc7aca-46db-4fda-9bb9-19a72723e04d	4	09:00:00	20:00:00
23704419-61e3-40b5-9011-2b5ab37dc3a4	chair	aedc7aca-46db-4fda-9bb9-19a72723e04d	5	09:00:00	20:00:00
8e84681f-4499-4d98-bc69-18d54b1a8e9d	chair	aedc7aca-46db-4fda-9bb9-19a72723e04d	6	09:00:00	20:00:00
b22beef4-17d8-4ba1-9ec2-567bc656a8a6	staff	ba7c9524-b0d4-4845-8886-5274ede7fd6a	0	09:00:00	20:00:00
cbcf44ec-f36a-4a6f-89a8-08aae81107eb	staff	ba7c9524-b0d4-4845-8886-5274ede7fd6a	1	09:00:00	20:00:00
18832f6d-0ab1-4253-a622-cf35eda3870a	staff	ba7c9524-b0d4-4845-8886-5274ede7fd6a	2	09:00:00	20:00:00
d1bb82f8-3fa7-4c47-a8c2-4b32d3970e45	staff	ba7c9524-b0d4-4845-8886-5274ede7fd6a	3	09:00:00	20:00:00
67fb574f-4bc0-4536-94f8-845f30d01803	staff	ba7c9524-b0d4-4845-8886-5274ede7fd6a	4	09:00:00	20:00:00
e68434f6-b936-42b9-a590-b231cd1bd176	staff	ba7c9524-b0d4-4845-8886-5274ede7fd6a	5	09:00:00	20:00:00
d18d36a9-ad1e-452e-800e-0b92cab01c54	staff	ba7c9524-b0d4-4845-8886-5274ede7fd6a	6	09:00:00	20:00:00
ebbcf7d1-83a9-448c-8d5a-e286dde5c0f7	chair	dedcd478-5995-49b3-9529-080290a7748d	0	09:00:00	20:00:00
0c0c3b21-207c-4fc6-a22e-4d402dfcf794	chair	dedcd478-5995-49b3-9529-080290a7748d	1	09:00:00	20:00:00
2acb36ed-6b88-4991-9452-4ad57b1b6fc2	chair	dedcd478-5995-49b3-9529-080290a7748d	2	09:00:00	20:00:00
f60ccfda-3136-41c7-8700-435204e553b0	chair	dedcd478-5995-49b3-9529-080290a7748d	3	09:00:00	20:00:00
67fce6d2-2516-4f6a-86bb-b69f74a95c4d	chair	dedcd478-5995-49b3-9529-080290a7748d	4	09:00:00	20:00:00
b9163542-74c5-4ab0-8013-41f00310cbdb	chair	dedcd478-5995-49b3-9529-080290a7748d	5	09:00:00	20:00:00
9b67ee18-1d77-4ea2-90f5-373aa1e1ff9e	chair	dedcd478-5995-49b3-9529-080290a7748d	6	09:00:00	20:00:00
a8055931-3640-4ec7-8b19-1e23ba27f5cf	staff	b8a2991d-41e8-4be8-bc0d-276fb036260d	0	09:00:00	20:00:00
92869fb5-713f-44d5-8596-1770098c01f4	staff	b8a2991d-41e8-4be8-bc0d-276fb036260d	1	09:00:00	20:00:00
0c5e651d-7bb2-4a2b-a810-3ceabc41f4de	staff	b8a2991d-41e8-4be8-bc0d-276fb036260d	2	09:00:00	20:00:00
51af010c-a459-4fda-a25e-1ff2e3554ec6	staff	b8a2991d-41e8-4be8-bc0d-276fb036260d	3	09:00:00	20:00:00
f8d0c8b7-2a1d-4101-a9dd-ac2ef9ea6980	staff	b8a2991d-41e8-4be8-bc0d-276fb036260d	4	09:00:00	20:00:00
ae9b1e9e-4a6b-43a6-866d-a6387b2599db	staff	b8a2991d-41e8-4be8-bc0d-276fb036260d	5	09:00:00	20:00:00
3a9dd4b4-6aba-4256-9652-af4c5d7bcd6a	staff	b8a2991d-41e8-4be8-bc0d-276fb036260d	6	09:00:00	20:00:00
1f7036ed-24df-417a-897c-fca4d861b824	chair	e4a7de1f-8db2-4272-ae14-25a205230bdf	0	09:00:00	20:00:00
54da4b3a-5a09-410a-b645-ab177f77a606	chair	e4a7de1f-8db2-4272-ae14-25a205230bdf	1	09:00:00	20:00:00
07bd06a0-5dd6-40d1-b680-dd9ed6db2e05	chair	e4a7de1f-8db2-4272-ae14-25a205230bdf	2	09:00:00	20:00:00
4cdc2929-483d-4edf-8867-81a4c6f394cc	chair	e4a7de1f-8db2-4272-ae14-25a205230bdf	3	09:00:00	20:00:00
adb6e47b-b2d4-4610-94a8-03ba49f51f1d	chair	e4a7de1f-8db2-4272-ae14-25a205230bdf	4	09:00:00	20:00:00
93af19fd-0fa1-4817-be26-936ec5615ab1	chair	e4a7de1f-8db2-4272-ae14-25a205230bdf	5	09:00:00	20:00:00
c4a0a918-5df4-434d-a809-9be7b049edcd	chair	e4a7de1f-8db2-4272-ae14-25a205230bdf	6	09:00:00	20:00:00
c67c428a-1a92-476e-9bdf-d16429c0d554	staff	efe05064-d22c-43cc-bafc-9e80e476f658	0	09:00:00	20:00:00
804853ac-c882-4a82-9f87-2868d30d30ba	staff	efe05064-d22c-43cc-bafc-9e80e476f658	1	09:00:00	20:00:00
9d51592e-8d4f-43d8-b8c9-f62c8382d2a0	staff	efe05064-d22c-43cc-bafc-9e80e476f658	2	09:00:00	20:00:00
301d59b2-7afd-45fb-a2ef-493cb6e38941	staff	efe05064-d22c-43cc-bafc-9e80e476f658	3	09:00:00	20:00:00
3fa8a981-f0ed-4085-8e61-dd58f844c355	staff	efe05064-d22c-43cc-bafc-9e80e476f658	4	09:00:00	20:00:00
940cc07a-11ad-4874-b4d5-80d4a1ea2bde	staff	efe05064-d22c-43cc-bafc-9e80e476f658	5	09:00:00	20:00:00
37e626f3-ce80-4652-8233-29c7d4a0614d	staff	efe05064-d22c-43cc-bafc-9e80e476f658	6	09:00:00	20:00:00
82291d76-9e43-4d77-beff-808bc25a7917	chair	33b1dae1-ed14-4628-9ae0-e3263846cb84	0	09:00:00	20:00:00
1f030070-9974-49c3-9a9e-b2e488d09f30	chair	33b1dae1-ed14-4628-9ae0-e3263846cb84	1	09:00:00	20:00:00
59f6f1cb-7740-49d9-ae26-055ee98f33f7	chair	33b1dae1-ed14-4628-9ae0-e3263846cb84	2	09:00:00	20:00:00
64c6c4f0-bbc3-48ab-8197-649ce2c52be0	chair	33b1dae1-ed14-4628-9ae0-e3263846cb84	3	09:00:00	20:00:00
787ae7f7-9c03-4d5d-9e87-74d624d7d521	chair	33b1dae1-ed14-4628-9ae0-e3263846cb84	4	09:00:00	20:00:00
4e12cf69-a91b-455e-a158-09831db19451	chair	33b1dae1-ed14-4628-9ae0-e3263846cb84	5	09:00:00	20:00:00
06318ef1-6ca6-46f3-a23d-8bb79b08abb2	chair	33b1dae1-ed14-4628-9ae0-e3263846cb84	6	09:00:00	20:00:00
da1f1618-2198-40c5-8ac9-003a8c0f0aa7	staff	30c7ba5b-2085-4124-a6f2-7986e79071f0	0	09:00:00	20:00:00
fd542855-1777-4f1c-a657-34cb4037c7d0	staff	30c7ba5b-2085-4124-a6f2-7986e79071f0	1	09:00:00	20:00:00
781a5c0b-c6cc-41a4-bbe4-c851c6ae381f	staff	30c7ba5b-2085-4124-a6f2-7986e79071f0	2	09:00:00	20:00:00
c867e4fb-2ab8-4a4f-ac2a-20204aeed0ad	staff	30c7ba5b-2085-4124-a6f2-7986e79071f0	3	09:00:00	20:00:00
8ccaf350-0a35-42e1-b7c7-05ff8b7fefdd	staff	30c7ba5b-2085-4124-a6f2-7986e79071f0	4	09:00:00	20:00:00
c43f1c41-7aba-4c85-87fb-7c5c82b3cb10	staff	30c7ba5b-2085-4124-a6f2-7986e79071f0	5	09:00:00	20:00:00
0bab3a09-cd0e-4c22-a065-339339d616d3	staff	30c7ba5b-2085-4124-a6f2-7986e79071f0	6	09:00:00	20:00:00
4ca9ea8a-7db0-4d96-b26b-2c27f8b8a44f	chair	d3af3925-bec6-4477-b2d9-f9da02b2cfca	0	09:00:00	20:00:00
f83f69cf-43b6-44dc-a425-8a303b2b9789	chair	d3af3925-bec6-4477-b2d9-f9da02b2cfca	1	09:00:00	20:00:00
bcfc28c2-3f48-494d-853c-17eccc7ff392	chair	d3af3925-bec6-4477-b2d9-f9da02b2cfca	2	09:00:00	20:00:00
0415ff6d-7680-41eb-a53c-4e415f4b12b5	chair	d3af3925-bec6-4477-b2d9-f9da02b2cfca	3	09:00:00	20:00:00
1b305ad4-fc17-4864-bd9a-62e9d195a268	chair	d4fd394b-d650-4bfb-b19d-577e7854340f	0	09:00:00	20:00:00
2127bd3c-58d6-4c29-95a4-a5af18d05f41	chair	d4fd394b-d650-4bfb-b19d-577e7854340f	1	09:00:00	20:00:00
97f6f661-8c9c-490b-80ee-7da1a0887747	chair	d4fd394b-d650-4bfb-b19d-577e7854340f	2	09:00:00	20:00:00
0d5f0529-1d12-4a1a-854f-2c146e892fd4	chair	d4fd394b-d650-4bfb-b19d-577e7854340f	3	09:00:00	20:00:00
09521c2b-5841-48b8-bb58-a4fdb6a570df	chair	d4fd394b-d650-4bfb-b19d-577e7854340f	4	09:00:00	20:00:00
2c3d015a-abfe-45b1-9275-19e13683f6c2	chair	d4fd394b-d650-4bfb-b19d-577e7854340f	5	09:00:00	20:00:00
14e5cf8e-e714-4937-864a-5c4eb7aa0c9a	chair	d4fd394b-d650-4bfb-b19d-577e7854340f	6	09:00:00	20:00:00
47bf684f-4988-49f8-824c-6090f0ee518d	staff	c2a7666a-c8e8-4090-bcc0-04d32926eadb	0	09:00:00	20:00:00
67f849af-d2a6-4335-a4b5-ad72fc3da6f3	staff	c2a7666a-c8e8-4090-bcc0-04d32926eadb	1	09:00:00	20:00:00
02b5cd89-d357-4af8-a780-456e95d8d499	staff	c2a7666a-c8e8-4090-bcc0-04d32926eadb	2	09:00:00	20:00:00
b3d82ed2-9558-49e1-b687-c221edcdeb5d	staff	c2a7666a-c8e8-4090-bcc0-04d32926eadb	3	09:00:00	20:00:00
0e12a810-e9a5-4990-942c-a9225d8b4307	staff	c2a7666a-c8e8-4090-bcc0-04d32926eadb	4	09:00:00	20:00:00
0a8bad36-01a0-4378-a7b2-b709aa49aba0	staff	c2a7666a-c8e8-4090-bcc0-04d32926eadb	5	09:00:00	20:00:00
9b241a99-f86e-4a15-a3a9-765b4142a997	staff	c2a7666a-c8e8-4090-bcc0-04d32926eadb	6	09:00:00	20:00:00
93d4eaaa-afe9-4406-a16f-1643acae722c	chair	b9b66f49-adc9-4547-a578-108005051357	0	09:00:00	20:00:00
0c58cb5e-a5e0-43bb-87d6-d35f3aa42803	chair	b9b66f49-adc9-4547-a578-108005051357	1	09:00:00	20:00:00
e7eeffe6-2029-4f9b-88e9-44040642c8d2	chair	b9b66f49-adc9-4547-a578-108005051357	2	09:00:00	20:00:00
d9b0a890-c4fe-4598-9f96-b86cf54c5242	chair	b9b66f49-adc9-4547-a578-108005051357	3	09:00:00	20:00:00
1dff0464-37be-4308-afcd-51dc9c5cbd9b	chair	b9b66f49-adc9-4547-a578-108005051357	4	09:00:00	20:00:00
27622446-02d9-40c1-8050-cb4eb668cecd	chair	b9b66f49-adc9-4547-a578-108005051357	5	09:00:00	20:00:00
fd07193b-08b0-4fb2-9768-51475605bd97	chair	b9b66f49-adc9-4547-a578-108005051357	6	09:00:00	20:00:00
91ab81b9-5830-4e26-8f48-a03f82f5bf8c	chair	9c5b49dc-2855-475e-8cfc-ce8be6aaa6bc	2	09:00:00	20:00:00
92baabf5-af7f-4599-9a39-bab65784d139	chair	9c5b49dc-2855-475e-8cfc-ce8be6aaa6bc	3	09:00:00	20:00:00
55aabc59-be0d-4b5a-aa3f-4035b8d59ac4	chair	9c5b49dc-2855-475e-8cfc-ce8be6aaa6bc	4	09:00:00	20:00:00
81eb1922-ad8d-444a-8f57-253e4bb29564	chair	9c5b49dc-2855-475e-8cfc-ce8be6aaa6bc	5	09:00:00	20:00:00
5f7c26b8-be8e-4ff5-8a06-2b026037a37f	chair	9c5b49dc-2855-475e-8cfc-ce8be6aaa6bc	6	09:00:00	20:00:00
f4799615-adff-4d08-8e3e-61cc9a8616a9	staff	c1f439d8-c58d-4ef3-a0f1-51bf34cf3bf5	0	09:00:00	20:00:00
6f2b2c20-38a9-42f9-adff-8c817c64b5a7	staff	c1f439d8-c58d-4ef3-a0f1-51bf34cf3bf5	1	09:00:00	20:00:00
eab23d97-5757-4b45-9268-9e7ecb540edf	staff	c1f439d8-c58d-4ef3-a0f1-51bf34cf3bf5	2	09:00:00	20:00:00
bd4f071a-3f50-4d7b-b62e-71db39ca2a5d	staff	c1f439d8-c58d-4ef3-a0f1-51bf34cf3bf5	3	09:00:00	20:00:00
e8564756-407f-4255-8997-1e9577dcd0ec	staff	c1f439d8-c58d-4ef3-a0f1-51bf34cf3bf5	4	09:00:00	20:00:00
f4b9c661-59df-4e13-bc6c-912320fd2b04	staff	c1f439d8-c58d-4ef3-a0f1-51bf34cf3bf5	5	09:00:00	20:00:00
6612b9dc-5dbc-4826-a36a-de8d7ccd289f	staff	c1f439d8-c58d-4ef3-a0f1-51bf34cf3bf5	6	09:00:00	20:00:00
2a7a4043-f1a4-4271-9b7e-19e6fb15a616	chair	a4c14dba-0f50-43ae-87ca-b0c48669924c	0	09:00:00	20:00:00
ecc91733-6eb8-4ceb-be15-08ca703aa10a	chair	a4c14dba-0f50-43ae-87ca-b0c48669924c	1	09:00:00	20:00:00
bb11b118-ccc9-4fcd-a2e6-33ff6a3371b0	chair	a4c14dba-0f50-43ae-87ca-b0c48669924c	2	09:00:00	20:00:00
ecf0f0ca-5643-4236-938c-8d6b6ddc0df5	chair	a4c14dba-0f50-43ae-87ca-b0c48669924c	3	09:00:00	20:00:00
ef29c155-48e9-496d-850d-b0d22687787d	chair	a4c14dba-0f50-43ae-87ca-b0c48669924c	4	09:00:00	20:00:00
9151b637-c928-4203-bc96-60f3a1a80a96	chair	a4c14dba-0f50-43ae-87ca-b0c48669924c	5	09:00:00	20:00:00
c186fc4d-7aac-4de1-aa5b-1a1fe2862da9	chair	a4c14dba-0f50-43ae-87ca-b0c48669924c	6	09:00:00	20:00:00
b99ce066-999b-4aaa-bfe5-c1a72b19c449	chair	d3af3925-bec6-4477-b2d9-f9da02b2cfca	4	09:00:00	20:00:00
f1c6844a-5ffb-46f4-b5e0-e74c334b4a9b	chair	d3af3925-bec6-4477-b2d9-f9da02b2cfca	5	09:00:00	20:00:00
a0dcbe2c-71bc-4313-9d31-c3cecd6d833f	chair	d3af3925-bec6-4477-b2d9-f9da02b2cfca	6	09:00:00	20:00:00
e604be55-38c0-45f7-8d53-f7b69b5bbdf5	staff	6421b62a-3327-4457-8d4b-d759b0a13b4a	0	09:00:00	20:00:00
12fa695d-15ac-4cc4-9e8a-b8f11e9d4c6f	staff	6421b62a-3327-4457-8d4b-d759b0a13b4a	1	09:00:00	20:00:00
a9636ab2-beda-4cfe-85eb-abe784dca2f7	staff	6421b62a-3327-4457-8d4b-d759b0a13b4a	2	09:00:00	20:00:00
b85f0239-ae7f-416a-aa9a-875de56b10e4	staff	6421b62a-3327-4457-8d4b-d759b0a13b4a	3	09:00:00	20:00:00
bfe2dd7d-91d5-4575-9518-dc455e36a0b6	staff	6421b62a-3327-4457-8d4b-d759b0a13b4a	4	09:00:00	20:00:00
180ae79f-f4d6-4a36-b5b7-786a789c0ed2	staff	6421b62a-3327-4457-8d4b-d759b0a13b4a	5	09:00:00	20:00:00
7e4ef7b8-73b1-4f4b-a5b1-2ba7204130d8	staff	6421b62a-3327-4457-8d4b-d759b0a13b4a	6	09:00:00	20:00:00
04213a35-4de4-40c7-ad10-99ca68df7455	chair	d28a00b0-aed9-424d-b101-e862f444d69b	0	09:00:00	20:00:00
22ba0e88-2bc7-42fe-93ce-f853816d6ab1	chair	d28a00b0-aed9-424d-b101-e862f444d69b	1	09:00:00	20:00:00
faa3662b-ed2e-49cb-a18b-7faa66b0f073	chair	d28a00b0-aed9-424d-b101-e862f444d69b	2	09:00:00	20:00:00
563219d1-d88a-45a7-864b-e07a0f7d340e	chair	d28a00b0-aed9-424d-b101-e862f444d69b	3	09:00:00	20:00:00
fce1f438-8823-4693-9b4a-0a38d22d91de	chair	d28a00b0-aed9-424d-b101-e862f444d69b	4	09:00:00	20:00:00
a7781b2d-3995-41ec-8c9c-1666c793a808	chair	d28a00b0-aed9-424d-b101-e862f444d69b	5	09:00:00	20:00:00
52a077a8-f9b0-4f6e-a11c-d57384405c0d	chair	d28a00b0-aed9-424d-b101-e862f444d69b	6	09:00:00	20:00:00
d6891f86-7350-42d0-9dea-cecdffdeee57	staff	3145ba23-2f1c-4100-a3ca-8688523c1de6	0	09:00:00	20:00:00
7cc5a801-b9ad-4f77-a8c9-9d85df5afb3b	staff	3145ba23-2f1c-4100-a3ca-8688523c1de6	1	09:00:00	20:00:00
b9d89f36-1f97-41f5-bd1e-500947843867	staff	3145ba23-2f1c-4100-a3ca-8688523c1de6	2	09:00:00	20:00:00
512aa213-93af-4d8c-a2db-cef758d61db7	staff	3145ba23-2f1c-4100-a3ca-8688523c1de6	3	09:00:00	20:00:00
6580af0c-296a-46f9-9c42-a63df3f033ea	staff	3145ba23-2f1c-4100-a3ca-8688523c1de6	4	09:00:00	20:00:00
ebb14af0-bef0-4cef-9c7f-2f52dae3135f	staff	3145ba23-2f1c-4100-a3ca-8688523c1de6	5	09:00:00	20:00:00
7cf152c5-68a8-4356-bd30-85af6d4f4666	staff	3145ba23-2f1c-4100-a3ca-8688523c1de6	6	09:00:00	20:00:00
cc97fb63-77be-4303-a2eb-2a9400e74de7	chair	4ac558b5-44f8-4546-9de3-f135500064d6	0	09:00:00	20:00:00
bb6f8716-cb12-4178-a58c-5da12aad0997	chair	4ac558b5-44f8-4546-9de3-f135500064d6	1	09:00:00	20:00:00
a8e09a3f-627a-47d1-962f-6aaba098435f	chair	4ac558b5-44f8-4546-9de3-f135500064d6	2	09:00:00	20:00:00
d330c2dc-f11e-4512-8cbf-1ab17b3fbc0f	chair	4ac558b5-44f8-4546-9de3-f135500064d6	3	09:00:00	20:00:00
df205051-9b29-4ba2-b22b-0bd3cb836aaf	chair	4ac558b5-44f8-4546-9de3-f135500064d6	4	09:00:00	20:00:00
ff3c24d7-37d9-428b-9a98-989bcb92669f	chair	4ac558b5-44f8-4546-9de3-f135500064d6	5	09:00:00	20:00:00
86c2972a-6b01-40a4-aba1-9fba958b0d14	chair	4ac558b5-44f8-4546-9de3-f135500064d6	6	09:00:00	20:00:00
17ef8142-d850-4e44-95c2-4bfbf019365b	staff	6154b0bb-a33d-4aa1-bb85-e74badea0943	0	09:00:00	20:00:00
7f2b35da-a908-45e8-aa12-0894fd1eac78	staff	6154b0bb-a33d-4aa1-bb85-e74badea0943	1	09:00:00	20:00:00
ccce8c84-e288-4526-a81e-ca68287205e7	staff	6154b0bb-a33d-4aa1-bb85-e74badea0943	2	09:00:00	20:00:00
0902b48c-1ae3-42af-9e44-79926eead6e5	staff	6154b0bb-a33d-4aa1-bb85-e74badea0943	3	09:00:00	20:00:00
d22d4168-d877-4731-a86e-fbdc7f8ff039	staff	6154b0bb-a33d-4aa1-bb85-e74badea0943	4	09:00:00	20:00:00
1f5653ea-682e-4fbf-b95a-339af59ad764	staff	6154b0bb-a33d-4aa1-bb85-e74badea0943	5	09:00:00	20:00:00
f95f1ae2-ed89-43bd-b782-03fcf97aa083	staff	6154b0bb-a33d-4aa1-bb85-e74badea0943	6	09:00:00	20:00:00
862d5a35-e0ad-479e-900e-33de0d72e476	chair	e5799bbe-6845-4fcf-9759-3f130d8e2e21	0	09:00:00	20:00:00
788cf414-3065-47b3-b1d0-17ff277cf385	chair	e5799bbe-6845-4fcf-9759-3f130d8e2e21	1	09:00:00	20:00:00
ca74aed3-7583-481f-a8ef-789c940d6d61	chair	e5799bbe-6845-4fcf-9759-3f130d8e2e21	2	09:00:00	20:00:00
da8fe780-2748-4633-aa02-b7870214865e	chair	e5799bbe-6845-4fcf-9759-3f130d8e2e21	3	09:00:00	20:00:00
2afcf17b-4eac-4baf-82a2-eb0ebed267cc	chair	e5799bbe-6845-4fcf-9759-3f130d8e2e21	4	09:00:00	20:00:00
e2b7affb-8823-40e5-8126-ccc2cd1c87db	chair	e5799bbe-6845-4fcf-9759-3f130d8e2e21	5	09:00:00	20:00:00
1c1f12e7-1050-45c7-ac24-c995ae9f2d23	chair	e5799bbe-6845-4fcf-9759-3f130d8e2e21	6	09:00:00	20:00:00
2c5e1548-6540-4d31-a778-de778264e501	staff	34d42336-3900-4918-a2d6-9068b8cfe6b0	0	09:00:00	20:00:00
c5e064ba-3a7b-42bf-8d69-cb15b7a528e6	staff	34d42336-3900-4918-a2d6-9068b8cfe6b0	1	09:00:00	20:00:00
3ef79f10-c087-4bbc-87a3-3445f1d14836	staff	34d42336-3900-4918-a2d6-9068b8cfe6b0	2	09:00:00	20:00:00
9c4ce25b-e2aa-4cc1-892b-09019516ead6	staff	34d42336-3900-4918-a2d6-9068b8cfe6b0	3	09:00:00	20:00:00
2a88c202-6971-4604-9e1e-82ab0663ef4e	staff	34d42336-3900-4918-a2d6-9068b8cfe6b0	4	09:00:00	20:00:00
acb4f730-0fde-437d-8dee-5b578f380f71	staff	34d42336-3900-4918-a2d6-9068b8cfe6b0	5	09:00:00	20:00:00
f837993e-55ee-41f4-94aa-909353ca9f6e	staff	34d42336-3900-4918-a2d6-9068b8cfe6b0	6	09:00:00	20:00:00
96cf422a-02fc-4dab-be3b-b43384779400	chair	51d39d57-ca24-4221-8099-a0069676ad6b	0	09:00:00	20:00:00
9c45b696-d640-4454-a13e-43063037c266	chair	51d39d57-ca24-4221-8099-a0069676ad6b	1	09:00:00	20:00:00
f7ddc1f4-6ca1-42a3-953f-6dad88c070bc	chair	51d39d57-ca24-4221-8099-a0069676ad6b	2	09:00:00	20:00:00
36506f12-ea21-4927-8952-09c11737ef0f	chair	51d39d57-ca24-4221-8099-a0069676ad6b	3	09:00:00	20:00:00
e50da2eb-f138-4156-9323-6fecfd0e200a	chair	51d39d57-ca24-4221-8099-a0069676ad6b	4	09:00:00	20:00:00
ea20a869-3646-4a63-ab52-2103bf96b91f	chair	51d39d57-ca24-4221-8099-a0069676ad6b	5	09:00:00	20:00:00
dd91cf9b-b370-4413-acff-cb73f7959c25	chair	51d39d57-ca24-4221-8099-a0069676ad6b	6	09:00:00	20:00:00
04b645a9-2943-48cf-8b5b-15b8cae3213d	chair	eefeb090-78d9-4e1b-bbf3-3fe4d4fe71b5	0	09:00:00	20:00:00
04b24efb-7f4d-4c1f-9b92-73b9237c68cc	chair	eefeb090-78d9-4e1b-bbf3-3fe4d4fe71b5	1	09:00:00	20:00:00
f58c0757-3ee9-43f8-888a-37440ac0e088	chair	eefeb090-78d9-4e1b-bbf3-3fe4d4fe71b5	2	09:00:00	20:00:00
9e91246c-3c80-4e37-8144-fa2a83d43e4e	chair	eefeb090-78d9-4e1b-bbf3-3fe4d4fe71b5	3	09:00:00	20:00:00
cf769858-f975-4b74-a9e8-227d9a47a382	chair	eefeb090-78d9-4e1b-bbf3-3fe4d4fe71b5	4	09:00:00	20:00:00
bb5eaba2-6521-4c11-bdb3-3ff43e6e2c79	chair	eefeb090-78d9-4e1b-bbf3-3fe4d4fe71b5	5	09:00:00	20:00:00
0b31eedd-ee99-47da-b6c8-5a9844707a9b	chair	eefeb090-78d9-4e1b-bbf3-3fe4d4fe71b5	6	09:00:00	20:00:00
9224dec2-6377-4a24-87ea-813ff206e282	staff	f03e27a5-59d9-4a0d-be4c-9d55c611afa2	0	09:00:00	20:00:00
90430c3a-771f-42ed-847d-6893d2833d06	staff	f03e27a5-59d9-4a0d-be4c-9d55c611afa2	1	09:00:00	20:00:00
e1aa1349-a853-42e6-95d1-31d9d31c5b91	staff	f03e27a5-59d9-4a0d-be4c-9d55c611afa2	2	09:00:00	20:00:00
45f82303-36ed-4745-997d-f2f5f168e4cf	staff	f03e27a5-59d9-4a0d-be4c-9d55c611afa2	3	09:00:00	20:00:00
a2a78c7a-369b-4cc8-976b-2054cc3d5455	staff	f03e27a5-59d9-4a0d-be4c-9d55c611afa2	4	09:00:00	20:00:00
4ceaa5e3-b4f8-4a27-a948-0c4b404f3da2	staff	f03e27a5-59d9-4a0d-be4c-9d55c611afa2	5	09:00:00	20:00:00
ce2987f9-42c4-45d9-a301-eb0648438949	staff	f03e27a5-59d9-4a0d-be4c-9d55c611afa2	6	09:00:00	20:00:00
5e3083da-eac6-4eb1-a0d8-d2d3a3ee7005	chair	ff1d3e5a-5cab-46a5-a6f7-886e43dcf321	0	09:00:00	20:00:00
4b19cd80-ce2d-4c59-b0fd-c14eebbc5b90	chair	ff1d3e5a-5cab-46a5-a6f7-886e43dcf321	1	09:00:00	20:00:00
9bcce816-4f72-4046-b6b1-9efb55995c07	chair	ff1d3e5a-5cab-46a5-a6f7-886e43dcf321	2	09:00:00	20:00:00
8dd85faf-f771-4ec4-b55d-cb34ce8385aa	chair	ff1d3e5a-5cab-46a5-a6f7-886e43dcf321	3	09:00:00	20:00:00
530df121-8446-472b-abb1-7ee8edbdda7b	chair	ff1d3e5a-5cab-46a5-a6f7-886e43dcf321	4	09:00:00	20:00:00
acad7d6f-c1d0-421c-85fb-622af53d714a	chair	ff1d3e5a-5cab-46a5-a6f7-886e43dcf321	5	09:00:00	20:00:00
afe16192-9e9b-41d8-bc3a-b127ea1b0391	chair	ff1d3e5a-5cab-46a5-a6f7-886e43dcf321	6	09:00:00	20:00:00
a35b828b-b3dd-41b9-a9ff-ec3e1a95070f	staff	e239ea1d-67db-4e64-aad9-ef9c45200291	0	09:00:00	20:00:00
82d87303-5790-4533-ae25-2f079d51a068	staff	e239ea1d-67db-4e64-aad9-ef9c45200291	1	09:00:00	20:00:00
3b49e591-3995-4b90-875e-86e26eeb5ed1	staff	e239ea1d-67db-4e64-aad9-ef9c45200291	2	09:00:00	20:00:00
1cad2eb8-d2df-4724-99b0-190381986846	staff	e239ea1d-67db-4e64-aad9-ef9c45200291	3	09:00:00	20:00:00
f01dafd7-fdbc-47e3-ac79-15bb98d5c2bd	staff	e239ea1d-67db-4e64-aad9-ef9c45200291	4	09:00:00	20:00:00
24a06390-614b-4c1f-9181-ac773b8872ff	staff	e239ea1d-67db-4e64-aad9-ef9c45200291	5	09:00:00	20:00:00
39115285-e404-4ed6-8cba-7d8011dffd17	staff	e239ea1d-67db-4e64-aad9-ef9c45200291	6	09:00:00	20:00:00
2c7aafdc-3323-4f46-a8b2-27b770cced88	chair	b0102f4b-7206-4392-b9e2-f5b2701ea49b	0	09:00:00	20:00:00
15e1673a-e962-4654-8fb2-5be07779330f	chair	01f0af38-1682-4906-a977-d4ba5b38e3f3	0	09:00:00	20:00:00
b707af86-d274-4fb7-8289-404ebc787a99	chair	01f0af38-1682-4906-a977-d4ba5b38e3f3	1	09:00:00	20:00:00
f0451e55-62b6-4da0-84c9-40caa15abbc7	chair	01f0af38-1682-4906-a977-d4ba5b38e3f3	2	09:00:00	20:00:00
eadbc988-8f3b-452f-9927-cf297239e4eb	chair	01f0af38-1682-4906-a977-d4ba5b38e3f3	3	09:00:00	20:00:00
c0c77d6e-a152-4cfe-9cf9-ff59f538cb00	chair	01f0af38-1682-4906-a977-d4ba5b38e3f3	4	09:00:00	20:00:00
893d5f52-8743-4f87-b46b-80f7c9292f46	chair	01f0af38-1682-4906-a977-d4ba5b38e3f3	5	09:00:00	20:00:00
9517aace-27de-44ec-8fff-6423041b7e2a	chair	01f0af38-1682-4906-a977-d4ba5b38e3f3	6	09:00:00	20:00:00
649dbb97-e918-4c4b-b953-1191a6919075	chair	641d4d73-2bb8-47a0-98c7-4b6373947074	0	09:00:00	20:00:00
386b8782-670c-4eb8-8fc2-2e6523a5c3b9	chair	641d4d73-2bb8-47a0-98c7-4b6373947074	1	09:00:00	20:00:00
aa3d3725-c321-47da-b245-e3d878933ec9	chair	641d4d73-2bb8-47a0-98c7-4b6373947074	2	09:00:00	20:00:00
0e206d63-55a0-4b47-ab5d-669ef2ada4f4	chair	641d4d73-2bb8-47a0-98c7-4b6373947074	3	09:00:00	20:00:00
0785c4c7-0150-42e6-97d7-f85f5b77f08a	chair	641d4d73-2bb8-47a0-98c7-4b6373947074	4	09:00:00	20:00:00
ae435727-c035-4a20-8ec9-68d233c75ec8	chair	641d4d73-2bb8-47a0-98c7-4b6373947074	5	09:00:00	20:00:00
ada1a80b-fc1f-44fc-82c6-a6fdc4fcc40e	chair	641d4d73-2bb8-47a0-98c7-4b6373947074	6	09:00:00	20:00:00
cc43f620-6031-4934-9706-36e7f04368ba	staff	190eec98-4dd0-4ac0-9ad3-31b4b2189239	0	09:00:00	20:00:00
09dac5bd-7c87-4abb-b613-5263f1844338	staff	190eec98-4dd0-4ac0-9ad3-31b4b2189239	1	09:00:00	20:00:00
50ea2dfb-8584-40cc-b6d2-9f16d155d951	staff	190eec98-4dd0-4ac0-9ad3-31b4b2189239	2	09:00:00	20:00:00
2367b3a6-282c-4f98-bb92-e6bcd854a5f6	staff	190eec98-4dd0-4ac0-9ad3-31b4b2189239	3	09:00:00	20:00:00
3e6cf929-7419-4afc-8040-8fe5516e89f9	staff	190eec98-4dd0-4ac0-9ad3-31b4b2189239	4	09:00:00	20:00:00
697f0874-cadf-4bd0-9a99-40506a4361ae	staff	190eec98-4dd0-4ac0-9ad3-31b4b2189239	5	09:00:00	20:00:00
ac623c62-4787-47d7-b4d3-02bac5d6406f	staff	190eec98-4dd0-4ac0-9ad3-31b4b2189239	6	09:00:00	20:00:00
cd1b0b4b-1466-4757-a2de-65b49f1ad249	chair	3502e9d8-865c-4dbe-b819-7e9af7ff70ca	0	09:00:00	20:00:00
611f23f0-039b-43d9-912b-4d7aa7602755	chair	3502e9d8-865c-4dbe-b819-7e9af7ff70ca	1	09:00:00	20:00:00
6ce32da0-f5c4-40f7-91eb-9489bbbbb606	staff	dfc88ac1-ede6-4b62-a170-63fc5d7dd3d4	0	09:00:00	20:00:00
0558f0cf-8000-48e8-b70c-18f91e2a8db3	staff	dfc88ac1-ede6-4b62-a170-63fc5d7dd3d4	1	09:00:00	20:00:00
dbdebe82-6fe9-404c-9b2d-cfee362e2889	staff	dfc88ac1-ede6-4b62-a170-63fc5d7dd3d4	2	09:00:00	20:00:00
577d48ab-50c0-4ca7-9f03-2aef4825d9ee	staff	dfc88ac1-ede6-4b62-a170-63fc5d7dd3d4	3	09:00:00	20:00:00
2dffa667-7716-439c-b36e-6afeca3332c3	staff	dfc88ac1-ede6-4b62-a170-63fc5d7dd3d4	4	09:00:00	20:00:00
3610da5b-32a5-4827-9a7f-2c07b9ce33ec	staff	dfc88ac1-ede6-4b62-a170-63fc5d7dd3d4	5	09:00:00	20:00:00
a560b3bb-0edb-4d10-a3fb-12c1c0b09fd2	staff	dfc88ac1-ede6-4b62-a170-63fc5d7dd3d4	6	09:00:00	20:00:00
1a39ca6e-f078-4a02-9267-1a0e53e71c4d	chair	2b99e353-293f-415a-b732-51fa5cc74e9b	0	09:00:00	20:00:00
38acba8c-e8e2-4cf1-a048-178841ff1ca6	chair	2b99e353-293f-415a-b732-51fa5cc74e9b	1	09:00:00	20:00:00
f5df940e-4af4-4f28-8196-a71a6440a418	chair	2b99e353-293f-415a-b732-51fa5cc74e9b	2	09:00:00	20:00:00
c286b6c5-a34b-451c-85f6-4c09e893a7fd	chair	2b99e353-293f-415a-b732-51fa5cc74e9b	3	09:00:00	20:00:00
85503175-d7ab-4189-babd-179148b5758e	chair	2b99e353-293f-415a-b732-51fa5cc74e9b	4	09:00:00	20:00:00
eaa4de08-9afd-4b03-823e-129218519bb8	chair	2b99e353-293f-415a-b732-51fa5cc74e9b	5	09:00:00	20:00:00
4eaddfd8-f9c6-4a5b-88fb-70409ed06695	chair	2b99e353-293f-415a-b732-51fa5cc74e9b	6	09:00:00	20:00:00
b8e9cad2-fc75-4cfc-9ef3-e0cd84d7ad81	staff	fe24b70c-b7f6-4b2d-960c-5d6af268b0cb	0	09:00:00	20:00:00
95641887-a976-4382-9474-4c54cee8ced8	staff	fe24b70c-b7f6-4b2d-960c-5d6af268b0cb	1	09:00:00	20:00:00
25f2c4a8-ac9b-41bb-b7f4-e1ceb0a192ee	staff	fe24b70c-b7f6-4b2d-960c-5d6af268b0cb	2	09:00:00	20:00:00
af0f0145-eff4-4be9-8f39-56476200694c	staff	fe24b70c-b7f6-4b2d-960c-5d6af268b0cb	3	09:00:00	20:00:00
74069903-7f9a-4503-b8c4-a4c03571cef9	staff	fe24b70c-b7f6-4b2d-960c-5d6af268b0cb	4	09:00:00	20:00:00
c7d55647-d490-422d-bea5-aae0e1feec91	staff	fe24b70c-b7f6-4b2d-960c-5d6af268b0cb	5	09:00:00	20:00:00
e3d35690-b301-4e07-bf16-cbbf67839fd5	staff	fe24b70c-b7f6-4b2d-960c-5d6af268b0cb	6	09:00:00	20:00:00
c38e8d1b-20e2-4bc4-8808-184b3c23d7a5	chair	c91ce9cd-46f3-483c-beb5-13adce6a4742	0	09:00:00	20:00:00
4b994ab8-801b-4976-9513-9a92deebf0ba	chair	c91ce9cd-46f3-483c-beb5-13adce6a4742	1	09:00:00	20:00:00
84a06ad0-6d39-4319-b506-029404833d73	chair	c91ce9cd-46f3-483c-beb5-13adce6a4742	2	09:00:00	20:00:00
ee849f1c-14da-4bc4-b254-a76d6c6564e4	chair	c91ce9cd-46f3-483c-beb5-13adce6a4742	3	09:00:00	20:00:00
0da2d3f1-8474-403e-a4dc-ca431b68fe8c	chair	c91ce9cd-46f3-483c-beb5-13adce6a4742	4	09:00:00	20:00:00
42dff130-5b7e-44d9-a177-829fb91cf804	chair	c91ce9cd-46f3-483c-beb5-13adce6a4742	5	09:00:00	20:00:00
ea2fdb82-11a4-43f7-9c45-41c93b598491	chair	c91ce9cd-46f3-483c-beb5-13adce6a4742	6	09:00:00	20:00:00
1d55b2a7-e4de-4fdf-b620-1dc1776e635c	staff	fbe2b299-5a41-4b36-81e0-700b9aeb80e7	0	09:00:00	20:00:00
350099e0-fcfc-4719-bbfd-0835f6608bc6	staff	fbe2b299-5a41-4b36-81e0-700b9aeb80e7	1	09:00:00	20:00:00
67c2c796-73fb-4a10-aed2-a4fa4672f509	staff	fbe2b299-5a41-4b36-81e0-700b9aeb80e7	2	09:00:00	20:00:00
82247d4f-9907-4291-b090-98c999901f69	staff	fbe2b299-5a41-4b36-81e0-700b9aeb80e7	3	09:00:00	20:00:00
29b993ef-6e1f-475e-8547-35d15e446727	staff	fbe2b299-5a41-4b36-81e0-700b9aeb80e7	4	09:00:00	20:00:00
5c620aff-97b6-470e-ad14-83368ad0c320	staff	fbe2b299-5a41-4b36-81e0-700b9aeb80e7	5	09:00:00	20:00:00
055de4a3-50ac-452f-b6ea-075b964f2d78	staff	fbe2b299-5a41-4b36-81e0-700b9aeb80e7	6	09:00:00	20:00:00
62a280c0-184f-428b-a7bf-e5ccdf70021d	chair	eeb21972-74c3-44ae-b56b-624d3bcedb81	0	09:00:00	20:00:00
fe55b500-db8f-475a-90a0-5b5cb74e79b6	chair	eeb21972-74c3-44ae-b56b-624d3bcedb81	1	09:00:00	20:00:00
efbde235-abc1-4808-ad46-63f24c0cbeda	chair	eeb21972-74c3-44ae-b56b-624d3bcedb81	2	09:00:00	20:00:00
3fd0547b-b0ee-40bf-8f8f-72759010b9be	chair	eeb21972-74c3-44ae-b56b-624d3bcedb81	3	09:00:00	20:00:00
f940c396-9c30-4daf-946e-3d8192bb881b	chair	eeb21972-74c3-44ae-b56b-624d3bcedb81	4	09:00:00	20:00:00
a16841c4-f24a-4f7a-90cd-a10e7bac0173	chair	eeb21972-74c3-44ae-b56b-624d3bcedb81	5	09:00:00	20:00:00
0c03bb10-3b02-4b5e-b7ca-aadddb46c70c	chair	eeb21972-74c3-44ae-b56b-624d3bcedb81	6	09:00:00	20:00:00
f12f1922-0b22-4ca8-9576-575e16b2d00a	staff	7ea453a7-f534-4afb-a400-3dd71f91c538	0	09:00:00	20:00:00
0d2b553f-3a7f-42ac-92e0-0c746e552888	staff	7ea453a7-f534-4afb-a400-3dd71f91c538	1	09:00:00	20:00:00
d22b7793-55e3-45cc-9cac-77d6db3ed901	staff	7ea453a7-f534-4afb-a400-3dd71f91c538	2	09:00:00	20:00:00
ce8668a8-fabc-4567-961c-2bfae510468f	staff	7ea453a7-f534-4afb-a400-3dd71f91c538	3	09:00:00	20:00:00
26890902-96a0-4c2a-97a8-53630efb96c7	staff	7ea453a7-f534-4afb-a400-3dd71f91c538	4	09:00:00	20:00:00
2c4cf095-f9ae-4ee1-b65a-c69fe15e516f	staff	7ea453a7-f534-4afb-a400-3dd71f91c538	5	09:00:00	20:00:00
2d2bbafe-5a3f-4e10-ba65-e76173a632e4	staff	7ea453a7-f534-4afb-a400-3dd71f91c538	6	09:00:00	20:00:00
92cd5e9d-8697-44d1-b4a1-8ce4902e1efa	chair	f8fb33b1-8d5b-487e-9dae-0ab3313f8e84	0	09:00:00	20:00:00
7cb32e0f-aad1-4444-bf0f-9b461c738ad8	chair	f8fb33b1-8d5b-487e-9dae-0ab3313f8e84	1	09:00:00	20:00:00
e9f6fe3f-36a9-4010-928e-ef7074179232	chair	f8fb33b1-8d5b-487e-9dae-0ab3313f8e84	2	09:00:00	20:00:00
feddaca6-4d78-4e12-b29b-8d12321accca	chair	f8fb33b1-8d5b-487e-9dae-0ab3313f8e84	3	09:00:00	20:00:00
3ec40b98-e62b-4361-81bd-4639fc76dd7e	chair	f8fb33b1-8d5b-487e-9dae-0ab3313f8e84	4	09:00:00	20:00:00
6559d9fc-b0d6-477e-b96c-4c5e395123db	chair	f8fb33b1-8d5b-487e-9dae-0ab3313f8e84	5	09:00:00	20:00:00
3b1849b6-42a4-4f35-8cf1-c29ecc78f59a	chair	f8fb33b1-8d5b-487e-9dae-0ab3313f8e84	6	09:00:00	20:00:00
879ff38a-a68a-4b02-ae77-ac8419f795ec	staff	3799ff0a-0064-4f2a-8717-4d2c35b40060	0	09:00:00	20:00:00
766c3f90-140a-4531-a654-62a75779e230	staff	3799ff0a-0064-4f2a-8717-4d2c35b40060	1	09:00:00	20:00:00
cf45bd13-e5ef-4575-950e-231658dfcf18	staff	3799ff0a-0064-4f2a-8717-4d2c35b40060	2	09:00:00	20:00:00
3bf47f0f-9a42-4059-a68b-b3f1e763ad93	staff	3799ff0a-0064-4f2a-8717-4d2c35b40060	3	09:00:00	20:00:00
e921c30f-46b8-46a8-a3b9-17f544145a88	staff	3799ff0a-0064-4f2a-8717-4d2c35b40060	4	09:00:00	20:00:00
0586d956-9a45-4a97-b0be-204b8cc8ff2b	staff	3799ff0a-0064-4f2a-8717-4d2c35b40060	5	09:00:00	20:00:00
8daabd83-774f-4a37-b031-a2fa1a08c01e	staff	3799ff0a-0064-4f2a-8717-4d2c35b40060	6	09:00:00	20:00:00
575fe32e-eb0f-4d70-a5e5-9dfbc33a9e6a	chair	f2bd08c8-34ee-431d-81b8-8063def28c29	0	09:00:00	20:00:00
9613335f-f8e2-49cb-b44f-8e24d78c923e	chair	f2bd08c8-34ee-431d-81b8-8063def28c29	1	09:00:00	20:00:00
9cbc6739-1688-46e9-929f-50eb0ca2d32b	chair	f2bd08c8-34ee-431d-81b8-8063def28c29	2	09:00:00	20:00:00
b0e28aba-2f93-4b36-b01e-00d52253f04e	chair	f2bd08c8-34ee-431d-81b8-8063def28c29	3	09:00:00	20:00:00
02c85489-f263-4fb6-8853-a5f709dd057a	chair	f2bd08c8-34ee-431d-81b8-8063def28c29	4	09:00:00	20:00:00
9210c854-e815-4a1c-9930-c889b97cf118	chair	f2bd08c8-34ee-431d-81b8-8063def28c29	5	09:00:00	20:00:00
533d5430-6075-429f-8816-ed96a63896d8	chair	f2bd08c8-34ee-431d-81b8-8063def28c29	6	09:00:00	20:00:00
08912225-8959-4d0f-a00a-668fbe3a523a	staff	4e457734-15ac-4ffc-9a23-fbeb7f75150a	0	09:00:00	20:00:00
3a8c421a-25b4-40ae-9298-8cc57cc07c02	staff	4e457734-15ac-4ffc-9a23-fbeb7f75150a	1	09:00:00	20:00:00
a52a495c-e155-433c-95cc-f525b9b1e136	staff	4e457734-15ac-4ffc-9a23-fbeb7f75150a	2	09:00:00	20:00:00
9a65a428-7f5d-497f-b3a0-cec346be3e3b	staff	4e457734-15ac-4ffc-9a23-fbeb7f75150a	3	09:00:00	20:00:00
cc36f174-6e2f-4d74-a811-317126c176b5	staff	4e457734-15ac-4ffc-9a23-fbeb7f75150a	4	09:00:00	20:00:00
7d7e4ffd-f4a5-4c64-8cdd-84b8ec3ceb9f	staff	4e457734-15ac-4ffc-9a23-fbeb7f75150a	5	09:00:00	20:00:00
d90ead18-4d10-4be1-b32d-47134a4c1853	staff	4e457734-15ac-4ffc-9a23-fbeb7f75150a	6	09:00:00	20:00:00
839ba717-9c53-4550-ab84-c8be11974f09	chair	94be1c66-7549-4dba-b8c9-27735fbe0b36	0	09:00:00	20:00:00
2efee8de-b635-463c-a273-d21eac38510c	chair	94be1c66-7549-4dba-b8c9-27735fbe0b36	1	09:00:00	20:00:00
971b6ca9-f38b-4592-bbaa-838346ebf924	chair	94be1c66-7549-4dba-b8c9-27735fbe0b36	2	09:00:00	20:00:00
ab424591-620c-412d-8f42-6a28bc22517e	chair	94be1c66-7549-4dba-b8c9-27735fbe0b36	3	09:00:00	20:00:00
12485875-c400-4653-b7f3-5122142aadc0	chair	94be1c66-7549-4dba-b8c9-27735fbe0b36	4	09:00:00	20:00:00
cc0f3f46-061d-4a6f-8479-b23f8374e8ff	chair	94be1c66-7549-4dba-b8c9-27735fbe0b36	5	09:00:00	20:00:00
2e1db656-c21a-4c1f-98b4-f3f6cb877496	chair	94be1c66-7549-4dba-b8c9-27735fbe0b36	6	09:00:00	20:00:00
569b40d8-3bda-4cdf-a4f6-238c8457e612	staff	d103be7a-51b0-4e4f-a608-7350cc921072	0	09:00:00	20:00:00
1fceba74-0916-42be-aaf7-58a46f6de07d	staff	d103be7a-51b0-4e4f-a608-7350cc921072	1	09:00:00	20:00:00
7b53cfc0-2607-44a6-8685-31a6b99a297b	staff	d103be7a-51b0-4e4f-a608-7350cc921072	2	09:00:00	20:00:00
0aa99754-e62c-4cd0-9dc5-fc54e5bf7545	staff	d103be7a-51b0-4e4f-a608-7350cc921072	3	09:00:00	20:00:00
289c38dc-a2c2-420b-a9b5-ce30023811f3	staff	d103be7a-51b0-4e4f-a608-7350cc921072	4	09:00:00	20:00:00
258ecb11-3237-4df9-95b0-ef24d4e145a8	staff	d103be7a-51b0-4e4f-a608-7350cc921072	5	09:00:00	20:00:00
d8ba3ef0-592d-49b9-8524-eddeb90899eb	staff	d103be7a-51b0-4e4f-a608-7350cc921072	6	09:00:00	20:00:00
68a0e46c-7e6a-44b7-8818-fb2f48727ab3	chair	17b74f53-27b8-48cf-9516-4c26dc0b1cec	0	09:00:00	20:00:00
039931f2-045c-4335-8047-f996c14fdb7d	chair	17b74f53-27b8-48cf-9516-4c26dc0b1cec	1	09:00:00	20:00:00
769815ff-b26e-4359-86c3-9d5cf38f3e59	chair	17b74f53-27b8-48cf-9516-4c26dc0b1cec	2	09:00:00	20:00:00
36901ab4-3d11-45ba-ae19-432b6399aace	chair	17b74f53-27b8-48cf-9516-4c26dc0b1cec	3	09:00:00	20:00:00
2796795f-e009-4b5f-b603-aca96319304f	chair	17b74f53-27b8-48cf-9516-4c26dc0b1cec	4	09:00:00	20:00:00
fd103940-5eb4-4d70-a5d8-bd2b5d77e64c	chair	17b74f53-27b8-48cf-9516-4c26dc0b1cec	5	09:00:00	20:00:00
79a01d0e-980c-4328-b71d-573c7d08ee48	chair	17b74f53-27b8-48cf-9516-4c26dc0b1cec	6	09:00:00	20:00:00
0cae3afa-efc1-4f2b-9e6e-7af0acba1942	staff	a5c68558-e3ac-43c3-98ce-5d0d466d51ab	0	09:00:00	20:00:00
626ac6b0-842b-47ea-94a6-72e3df6b4948	staff	a5c68558-e3ac-43c3-98ce-5d0d466d51ab	1	09:00:00	20:00:00
f3f6319a-8e62-4170-9b53-31a5c75dfd5f	staff	a5c68558-e3ac-43c3-98ce-5d0d466d51ab	2	09:00:00	20:00:00
625a0a33-3c9f-4972-a55e-8d3b0fbfd565	staff	a5c68558-e3ac-43c3-98ce-5d0d466d51ab	3	09:00:00	20:00:00
2e166915-1653-4a3d-b784-c6984ab5fac1	staff	a5c68558-e3ac-43c3-98ce-5d0d466d51ab	4	09:00:00	20:00:00
b1b241ee-dec1-41d9-b06c-bd17094ce81b	staff	a5c68558-e3ac-43c3-98ce-5d0d466d51ab	5	09:00:00	20:00:00
d28104b3-e1ad-41a0-8373-4feab7490eb9	staff	a5c68558-e3ac-43c3-98ce-5d0d466d51ab	6	09:00:00	20:00:00
126a34f8-f664-412f-83ca-61d0974468a5	chair	3e11de57-aec7-4991-8b5f-d954c5e1f520	0	09:00:00	20:00:00
93d83be2-ccc0-43bf-bba7-092df8d822af	chair	3e11de57-aec7-4991-8b5f-d954c5e1f520	1	09:00:00	20:00:00
ededd9e9-997f-4a22-8d3f-5bd95530a762	chair	3e11de57-aec7-4991-8b5f-d954c5e1f520	2	09:00:00	20:00:00
7dbf8e22-854a-459a-a941-b3cf34362856	chair	3e11de57-aec7-4991-8b5f-d954c5e1f520	3	09:00:00	20:00:00
97e00ea4-d9d5-47a8-9714-2f648118a45f	chair	3e11de57-aec7-4991-8b5f-d954c5e1f520	4	09:00:00	20:00:00
7d869c92-3bc3-4657-87d4-d00664672d8e	chair	3e11de57-aec7-4991-8b5f-d954c5e1f520	5	09:00:00	20:00:00
d46ef7c4-07fc-489d-93ad-353eb8bda762	chair	3e11de57-aec7-4991-8b5f-d954c5e1f520	6	09:00:00	20:00:00
6026b4e4-fd0e-454c-8c59-96a16baaf39c	staff	a4984776-fd5b-43a9-9096-a1e5e2d83cc3	0	09:00:00	20:00:00
32165541-8cce-4c49-9a11-526532cbb052	staff	a4984776-fd5b-43a9-9096-a1e5e2d83cc3	1	09:00:00	20:00:00
39d3f66a-14fb-4131-8dda-95aad4a2c0c4	staff	a4984776-fd5b-43a9-9096-a1e5e2d83cc3	2	09:00:00	20:00:00
288d1983-7cee-4cd0-9fab-fca00b93f69b	staff	a4984776-fd5b-43a9-9096-a1e5e2d83cc3	3	09:00:00	20:00:00
20539bc8-47a6-4d6b-8bb5-4015bcaaacb4	staff	a4984776-fd5b-43a9-9096-a1e5e2d83cc3	4	09:00:00	20:00:00
24501783-bcfb-44fb-8b5d-b031abbeed4f	staff	a4984776-fd5b-43a9-9096-a1e5e2d83cc3	5	09:00:00	20:00:00
56fd6798-632c-41b9-aef0-aa9331335900	staff	a4984776-fd5b-43a9-9096-a1e5e2d83cc3	6	09:00:00	20:00:00
a8a17fe6-7cb8-4a4a-b08b-2c0d76edc1ea	chair	9298b232-802f-4169-b23c-21ad3403860c	0	09:00:00	20:00:00
99ac66f5-71db-433c-86b3-a5b9bf0f3101	chair	9298b232-802f-4169-b23c-21ad3403860c	1	09:00:00	20:00:00
0b86352e-eea3-46aa-b52b-756ce4861054	chair	9298b232-802f-4169-b23c-21ad3403860c	2	09:00:00	20:00:00
d5733915-6d79-4e20-8719-817a1b29c0de	chair	9298b232-802f-4169-b23c-21ad3403860c	3	09:00:00	20:00:00
ef4112b2-9317-4d06-b957-ebebb0d4ec02	chair	9298b232-802f-4169-b23c-21ad3403860c	4	09:00:00	20:00:00
619dbebf-b9a4-43db-a1f1-00b835e2e92a	chair	9298b232-802f-4169-b23c-21ad3403860c	5	09:00:00	20:00:00
bb6aec03-01ee-453a-971c-6db84b723f7a	chair	9298b232-802f-4169-b23c-21ad3403860c	6	09:00:00	20:00:00
63673e40-e8cd-4218-b9c3-07dccccd39e4	staff	9075c684-ae7e-415d-90bb-1c5c67083279	0	09:00:00	20:00:00
998da936-0a7d-4f11-a4a1-29556c9f0bc8	staff	9075c684-ae7e-415d-90bb-1c5c67083279	1	09:00:00	20:00:00
365cab05-b3de-4177-8a5f-9ac9e9ccdedd	staff	9075c684-ae7e-415d-90bb-1c5c67083279	2	09:00:00	20:00:00
0e1fbb46-c9b7-410f-82d0-917f067998e5	staff	9075c684-ae7e-415d-90bb-1c5c67083279	3	09:00:00	20:00:00
1a2149e3-4151-4e75-9cf6-caee1bc7708b	staff	9075c684-ae7e-415d-90bb-1c5c67083279	4	09:00:00	20:00:00
ba828488-cd26-41a3-91ca-23224dc90777	staff	9075c684-ae7e-415d-90bb-1c5c67083279	5	09:00:00	20:00:00
5fc01180-a187-45b6-9d1e-aacca365a0ce	staff	9075c684-ae7e-415d-90bb-1c5c67083279	6	09:00:00	20:00:00
7a57a6f6-5dd7-4d31-9534-4fef00349f5a	chair	e5501cee-e6b9-44e2-aa7e-76d6be4e898b	0	09:00:00	20:00:00
516c8a10-b00b-406b-9e5f-783e5c7cc4cc	chair	e5501cee-e6b9-44e2-aa7e-76d6be4e898b	1	09:00:00	20:00:00
5aadfcfa-8b11-43a5-ba19-a1e89a849b4d	chair	e5501cee-e6b9-44e2-aa7e-76d6be4e898b	2	09:00:00	20:00:00
e296f43b-54c2-4275-b6ee-cb99a883fd97	chair	e5501cee-e6b9-44e2-aa7e-76d6be4e898b	3	09:00:00	20:00:00
bcc90e33-f254-42df-87e8-ef34235358ee	chair	e5501cee-e6b9-44e2-aa7e-76d6be4e898b	4	09:00:00	20:00:00
59bb9dae-e446-40c6-b76a-bebfca55279a	chair	e5501cee-e6b9-44e2-aa7e-76d6be4e898b	5	09:00:00	20:00:00
ae3b99e2-9c11-4bb1-a012-59979496b1e8	chair	e5501cee-e6b9-44e2-aa7e-76d6be4e898b	6	09:00:00	20:00:00
4d034b20-916d-4dbe-8eb6-163338b07413	staff	09b2f5ef-cd02-491a-bd54-be0c30e9c654	0	09:00:00	20:00:00
088a34e1-8bdd-4b30-b41c-11386e5d0692	staff	09b2f5ef-cd02-491a-bd54-be0c30e9c654	1	09:00:00	20:00:00
d8680cb1-4ffe-4876-a46a-60040ecd90d8	staff	09b2f5ef-cd02-491a-bd54-be0c30e9c654	2	09:00:00	20:00:00
a71018b8-c217-4806-952f-eedf49764ffc	staff	09b2f5ef-cd02-491a-bd54-be0c30e9c654	3	09:00:00	20:00:00
bf818b21-f340-45c5-b4be-33f4778c815a	staff	09b2f5ef-cd02-491a-bd54-be0c30e9c654	4	09:00:00	20:00:00
86e9c37a-46d2-4059-a9a1-d202dcdcd721	staff	09b2f5ef-cd02-491a-bd54-be0c30e9c654	5	09:00:00	20:00:00
f5eaf6cd-ec1b-4561-87cd-9999ba297f89	staff	09b2f5ef-cd02-491a-bd54-be0c30e9c654	6	09:00:00	20:00:00
d50031a3-ed23-4651-9240-551a15b3561b	chair	e8e68f1f-0b0e-4762-b77c-a4d6d0e285a6	0	09:00:00	20:00:00
f96ab4c2-a50d-4b1d-9a37-7f2d0038e83d	chair	e8e68f1f-0b0e-4762-b77c-a4d6d0e285a6	1	09:00:00	20:00:00
9231dd70-afab-41d4-94b5-f5cbd7f4744f	chair	e8e68f1f-0b0e-4762-b77c-a4d6d0e285a6	2	09:00:00	20:00:00
ff7d1233-331e-4b67-a55f-fbbe8526702c	chair	e8e68f1f-0b0e-4762-b77c-a4d6d0e285a6	3	09:00:00	20:00:00
cbb3b1bd-753f-4869-8cde-f02c061509fc	chair	e8e68f1f-0b0e-4762-b77c-a4d6d0e285a6	4	09:00:00	20:00:00
1c5e74bb-324d-4812-b2cd-bc43ba87f5e7	chair	e8e68f1f-0b0e-4762-b77c-a4d6d0e285a6	5	09:00:00	20:00:00
85747575-1685-4d08-84ce-90ed8ed2b847	chair	e8e68f1f-0b0e-4762-b77c-a4d6d0e285a6	6	09:00:00	20:00:00
428b5b8a-de33-4c37-8edf-dc3b44f6032e	staff	7871f6e8-d0f5-45db-84be-9693bfe02b5c	0	09:00:00	20:00:00
4f427213-b8f1-49a5-89d5-98db50765ce8	staff	7871f6e8-d0f5-45db-84be-9693bfe02b5c	1	09:00:00	20:00:00
712c3341-e9bf-494b-a6f4-f9e6021c2312	staff	7871f6e8-d0f5-45db-84be-9693bfe02b5c	2	09:00:00	20:00:00
e2b38584-99e9-4228-94f8-b8172f977f48	staff	7871f6e8-d0f5-45db-84be-9693bfe02b5c	3	09:00:00	20:00:00
39014a4a-66c9-4218-8a54-077cb8ac1536	staff	7871f6e8-d0f5-45db-84be-9693bfe02b5c	4	09:00:00	20:00:00
f98617fa-119f-4168-a3be-5e19f75e30af	staff	7871f6e8-d0f5-45db-84be-9693bfe02b5c	5	09:00:00	20:00:00
216a3d93-cec0-46da-925d-73d5e657709b	staff	7871f6e8-d0f5-45db-84be-9693bfe02b5c	6	09:00:00	20:00:00
dc4491de-e269-410c-9c4c-de218128e191	chair	59b876eb-b05f-4415-b98a-e362310ecb4d	0	09:00:00	20:00:00
2cbebaf0-254a-40cc-b36a-4e603083002e	chair	59b876eb-b05f-4415-b98a-e362310ecb4d	1	09:00:00	20:00:00
cb1f6306-e97c-41f7-b09a-951711640c83	chair	59b876eb-b05f-4415-b98a-e362310ecb4d	2	09:00:00	20:00:00
f666582f-e485-4e29-bdf7-e32999e1aaee	chair	59b876eb-b05f-4415-b98a-e362310ecb4d	3	09:00:00	20:00:00
28298763-4f85-45d5-96a6-d1127652a74a	chair	59b876eb-b05f-4415-b98a-e362310ecb4d	4	09:00:00	20:00:00
dae0a33c-033f-4b01-a238-1670b1e0c3ce	chair	59b876eb-b05f-4415-b98a-e362310ecb4d	5	09:00:00	20:00:00
382d2dbf-5600-4491-82fd-c71ce5b07cc7	chair	59b876eb-b05f-4415-b98a-e362310ecb4d	6	09:00:00	20:00:00
4567eb3e-2f91-4297-af7e-bc891d0db5a1	chair	c439c9bd-a178-45b9-a246-89d0acae1e44	0	09:00:00	20:00:00
78e1d877-e600-43bf-b834-b58be0ae6c7f	chair	c439c9bd-a178-45b9-a246-89d0acae1e44	1	09:00:00	20:00:00
8ca3c078-5523-43aa-a52b-5a4f420800c7	chair	c439c9bd-a178-45b9-a246-89d0acae1e44	2	09:00:00	20:00:00
a96805e4-53d9-46dc-b29a-2cffcd1c3ad0	chair	c439c9bd-a178-45b9-a246-89d0acae1e44	3	09:00:00	20:00:00
631c2911-ddc7-4c76-a176-7d3189fba58c	chair	c439c9bd-a178-45b9-a246-89d0acae1e44	4	09:00:00	20:00:00
20b6661f-4606-4882-8be8-ab0a0f2b9c48	chair	c439c9bd-a178-45b9-a246-89d0acae1e44	5	09:00:00	20:00:00
220d9b01-6f17-4342-b94d-1fc7a40f371b	chair	c439c9bd-a178-45b9-a246-89d0acae1e44	6	09:00:00	20:00:00
81020ed0-6c37-4de1-ba05-dbb2bc256757	staff	b7fd6924-84b4-4c66-a43f-d1c6e08fcbe4	0	09:00:00	20:00:00
8a1af00a-6a0c-4cb0-b366-a696f0c92ffe	staff	b7fd6924-84b4-4c66-a43f-d1c6e08fcbe4	1	09:00:00	20:00:00
1b0f1a42-71f4-4cb2-ab53-e56299f628fc	staff	b7fd6924-84b4-4c66-a43f-d1c6e08fcbe4	2	09:00:00	20:00:00
c4334351-978b-41e5-b704-5d15c77f2231	staff	b7fd6924-84b4-4c66-a43f-d1c6e08fcbe4	3	09:00:00	20:00:00
86db0df3-2bd0-4736-a85e-225be28af889	staff	b7fd6924-84b4-4c66-a43f-d1c6e08fcbe4	4	09:00:00	20:00:00
92cdc111-2c73-4622-b39d-418499038d7a	staff	b7fd6924-84b4-4c66-a43f-d1c6e08fcbe4	5	09:00:00	20:00:00
10eff7ce-e8af-4415-be93-0342bc3e59b0	staff	b7fd6924-84b4-4c66-a43f-d1c6e08fcbe4	6	09:00:00	20:00:00
fcd590f7-f648-48d5-aac9-88f7a02e37aa	chair	6af240ea-b0d1-4236-bf89-6c39276314e1	0	09:00:00	20:00:00
cbc44edd-e935-4e3d-b24e-7de5376dc921	chair	6af240ea-b0d1-4236-bf89-6c39276314e1	1	09:00:00	20:00:00
14da9706-8510-4554-a874-2a9e7bff3b26	chair	6af240ea-b0d1-4236-bf89-6c39276314e1	2	09:00:00	20:00:00
f6a350b8-9b38-4cd0-ad68-c4ad3f08b558	chair	6af240ea-b0d1-4236-bf89-6c39276314e1	3	09:00:00	20:00:00
800669bd-953e-418e-af32-bc577cfbcc8d	chair	6af240ea-b0d1-4236-bf89-6c39276314e1	4	09:00:00	20:00:00
65285052-5ef8-4ad0-8a9b-34da265141af	chair	6af240ea-b0d1-4236-bf89-6c39276314e1	5	09:00:00	20:00:00
615b971d-1f81-4b2c-a857-32c92494a4e1	chair	6af240ea-b0d1-4236-bf89-6c39276314e1	6	09:00:00	20:00:00
b0f97df6-12aa-4e0a-9361-59eef30502b2	staff	f073a0ff-6e6f-43d4-9a63-9ed194b88797	0	09:00:00	20:00:00
21b26ce7-3e19-4275-b115-35a7741344ed	staff	f073a0ff-6e6f-43d4-9a63-9ed194b88797	1	09:00:00	20:00:00
58e3d8ec-9abb-4a9e-8c97-5de31e8c2fa5	staff	f073a0ff-6e6f-43d4-9a63-9ed194b88797	2	09:00:00	20:00:00
73b2f6bd-73a4-48de-86ff-ecdf7f8c2301	staff	f073a0ff-6e6f-43d4-9a63-9ed194b88797	3	09:00:00	20:00:00
a084b8f7-3af6-4b54-a0c8-d75a0bdbba51	staff	f073a0ff-6e6f-43d4-9a63-9ed194b88797	4	09:00:00	20:00:00
1701c958-8595-4170-acb1-15529a310a28	staff	f073a0ff-6e6f-43d4-9a63-9ed194b88797	5	09:00:00	20:00:00
bb8108ee-68a6-489e-96b8-48f00a5e68f6	staff	f073a0ff-6e6f-43d4-9a63-9ed194b88797	6	09:00:00	20:00:00
75ad67d8-56ee-43b6-8905-8d922253cf48	chair	1f6a2459-5a01-4196-ab32-b0d412037c8d	0	09:00:00	20:00:00
a92c5d67-df6e-4f8f-b307-7444c1fb693f	chair	1f6a2459-5a01-4196-ab32-b0d412037c8d	1	09:00:00	20:00:00
9e238140-163e-4106-bf4c-304dee15a051	chair	1f6a2459-5a01-4196-ab32-b0d412037c8d	2	09:00:00	20:00:00
d528f201-70db-4ddc-b8fe-5bb705217be2	chair	1f6a2459-5a01-4196-ab32-b0d412037c8d	3	09:00:00	20:00:00
8805e5a4-12cb-4674-8c05-1993596758ed	chair	1f6a2459-5a01-4196-ab32-b0d412037c8d	4	09:00:00	20:00:00
0d732099-914f-4af9-8c7c-24de5bfc2c65	chair	1f6a2459-5a01-4196-ab32-b0d412037c8d	5	09:00:00	20:00:00
e138312a-2581-44c5-85c2-9eab11dcb1f3	chair	1f6a2459-5a01-4196-ab32-b0d412037c8d	6	09:00:00	20:00:00
8304f884-8e1c-423c-a365-adaa2c8d2ad7	staff	133a6ecc-53ba-4f45-a858-9e8df3ce87b2	0	09:00:00	20:00:00
d6bd8c64-2e94-4cdb-80eb-d046ca5bb3e0	staff	133a6ecc-53ba-4f45-a858-9e8df3ce87b2	1	09:00:00	20:00:00
1a9233c5-22a5-4184-aee8-d6fc9427c18a	staff	133a6ecc-53ba-4f45-a858-9e8df3ce87b2	2	09:00:00	20:00:00
cd47ea38-9663-451f-adb4-f3b56f16d45f	staff	133a6ecc-53ba-4f45-a858-9e8df3ce87b2	3	09:00:00	20:00:00
a10e9b24-621f-4e96-b1c5-1ddc94e53c46	staff	133a6ecc-53ba-4f45-a858-9e8df3ce87b2	4	09:00:00	20:00:00
0bffea47-6b17-4616-9c77-cd4d8c28fa4f	staff	133a6ecc-53ba-4f45-a858-9e8df3ce87b2	5	09:00:00	20:00:00
63b49f1e-6dee-49dc-90a9-e23ad6c98355	staff	133a6ecc-53ba-4f45-a858-9e8df3ce87b2	6	09:00:00	20:00:00
af7bce28-73e7-4fcd-86ab-531763ae9158	staff	50070078-f099-4cb5-a8ce-c6bde911a49e	0	09:00:00	20:00:00
f49dbd53-2a00-494e-be13-f8c42999bdeb	staff	50070078-f099-4cb5-a8ce-c6bde911a49e	1	09:00:00	20:00:00
dafad853-b999-427b-9813-015899817e47	staff	50070078-f099-4cb5-a8ce-c6bde911a49e	2	09:00:00	20:00:00
0d7732cc-923a-41b4-bffa-1a62ace7ee7d	staff	50070078-f099-4cb5-a8ce-c6bde911a49e	3	09:00:00	20:00:00
1bc357d7-cfde-4f98-8871-f984b5b96a4d	staff	50070078-f099-4cb5-a8ce-c6bde911a49e	4	09:00:00	20:00:00
f10c1aa7-13c6-40c4-ab50-c6534c74fb8e	staff	50070078-f099-4cb5-a8ce-c6bde911a49e	5	09:00:00	20:00:00
6c66fb83-721b-4c8b-9d87-81b62ebb604a	staff	50070078-f099-4cb5-a8ce-c6bde911a49e	6	09:00:00	20:00:00
be080287-2291-48fd-aaa9-75dab3123946	chair	78a0f4fd-3ac0-4275-b179-a32323356af2	0	09:00:00	20:00:00
e744be46-efca-4fc6-91a9-31d03fcc0ce1	chair	78a0f4fd-3ac0-4275-b179-a32323356af2	1	09:00:00	20:00:00
767e6a07-2938-4998-80c1-9af9c731ebce	chair	78a0f4fd-3ac0-4275-b179-a32323356af2	2	09:00:00	20:00:00
75db8ede-5f26-476c-86b9-57bce3b4784f	chair	78a0f4fd-3ac0-4275-b179-a32323356af2	3	09:00:00	20:00:00
3cca09ac-f1b0-40de-a828-003d4608e520	chair	78a0f4fd-3ac0-4275-b179-a32323356af2	4	09:00:00	20:00:00
10d95ac8-2edf-455a-81b2-a470cd33dcb6	chair	78a0f4fd-3ac0-4275-b179-a32323356af2	5	09:00:00	20:00:00
52002418-eae1-4d89-abda-d712130f25c1	chair	78a0f4fd-3ac0-4275-b179-a32323356af2	6	09:00:00	20:00:00
1e6addf7-df86-4fd5-8515-61d18fc6c086	staff	cbd2f87e-787d-40ee-80ea-9b90b71c298e	0	09:00:00	20:00:00
f292991c-dbdc-4505-aff8-47cf096d7771	staff	cbd2f87e-787d-40ee-80ea-9b90b71c298e	1	09:00:00	20:00:00
f4787fca-93a3-49d9-82a6-b5e54628ff93	staff	cbd2f87e-787d-40ee-80ea-9b90b71c298e	2	09:00:00	20:00:00
21115ed8-7808-4b5a-bf98-d0c441f5a570	staff	cbd2f87e-787d-40ee-80ea-9b90b71c298e	3	09:00:00	20:00:00
2a9782e9-35e3-4de8-b1f9-fc33350722d3	staff	cbd2f87e-787d-40ee-80ea-9b90b71c298e	4	09:00:00	20:00:00
9b8f0ab1-3294-4acb-8de1-aaca5aa455dc	staff	cbd2f87e-787d-40ee-80ea-9b90b71c298e	5	09:00:00	20:00:00
a4ae644e-50c5-43cf-9404-8d4300540be4	staff	cbd2f87e-787d-40ee-80ea-9b90b71c298e	6	09:00:00	20:00:00
af697d7d-bae8-4c71-a855-7d661a6ade3a	chair	a2e3c715-0bbf-4a8f-b765-4b2d517052ef	0	09:00:00	20:00:00
d6f8527b-6761-4a68-9b69-adf24533cb6d	chair	a2e3c715-0bbf-4a8f-b765-4b2d517052ef	1	09:00:00	20:00:00
f4b35555-db95-481e-af40-27c3fb8ecc36	chair	a2e3c715-0bbf-4a8f-b765-4b2d517052ef	2	09:00:00	20:00:00
cf590a2b-e10f-4640-af88-fb55f1de4c5e	chair	a2e3c715-0bbf-4a8f-b765-4b2d517052ef	3	09:00:00	20:00:00
35f0b659-65e3-426a-b362-eec754afcd4e	chair	a2e3c715-0bbf-4a8f-b765-4b2d517052ef	4	09:00:00	20:00:00
aa9e821a-8f76-45fd-8cd1-ab9efca9a6a6	chair	a2e3c715-0bbf-4a8f-b765-4b2d517052ef	5	09:00:00	20:00:00
a0dd4a83-af43-49b6-acc2-c8c44ff46ce5	chair	a2e3c715-0bbf-4a8f-b765-4b2d517052ef	6	09:00:00	20:00:00
be573af1-0fc4-46e1-a9f4-85456030ad93	staff	544ceb5a-2fea-47d6-acef-76045154881a	0	09:00:00	20:00:00
f3e75a16-7631-4f02-b7ff-4dc567b6b172	staff	544ceb5a-2fea-47d6-acef-76045154881a	1	09:00:00	20:00:00
6cd9d1dd-d1ab-4bcc-85d4-731eb76ff3ca	staff	544ceb5a-2fea-47d6-acef-76045154881a	2	09:00:00	20:00:00
01ecab49-6c8d-4d85-b6dc-9499e3d7da43	staff	052328d1-4f15-426d-ab6e-c04cde71cb11	0	09:00:00	20:00:00
2476c856-8c68-4b9e-94fa-c72b11a4868f	staff	052328d1-4f15-426d-ab6e-c04cde71cb11	1	09:00:00	20:00:00
fd5431f7-850f-40a8-8663-67c5b0669b40	staff	052328d1-4f15-426d-ab6e-c04cde71cb11	2	09:00:00	20:00:00
730b68b7-2b51-4d37-a6dc-2d7abaf362de	staff	052328d1-4f15-426d-ab6e-c04cde71cb11	3	09:00:00	20:00:00
981f3074-89b0-49d1-9b26-f137563e4720	staff	052328d1-4f15-426d-ab6e-c04cde71cb11	4	09:00:00	20:00:00
6be51896-be67-42cf-a967-68127a8b7230	staff	052328d1-4f15-426d-ab6e-c04cde71cb11	5	09:00:00	20:00:00
9ec2d3b1-187c-4c70-98c4-fd607580028c	staff	052328d1-4f15-426d-ab6e-c04cde71cb11	6	09:00:00	20:00:00
edff6c20-a80a-40ad-b267-bcce6ce3e596	chair	11bcdf43-287d-45f4-995e-fc1f2ad21cb0	0	09:00:00	20:00:00
ee47a331-5080-4e8f-ab29-bc3ac89c5e89	chair	11bcdf43-287d-45f4-995e-fc1f2ad21cb0	1	09:00:00	20:00:00
7e757588-3d65-4622-8955-c7a3f249234d	chair	11bcdf43-287d-45f4-995e-fc1f2ad21cb0	2	09:00:00	20:00:00
5fc02fea-dc98-49c2-ab74-0f2d252609b2	chair	11bcdf43-287d-45f4-995e-fc1f2ad21cb0	3	09:00:00	20:00:00
b381af79-2482-463a-8555-2be044f44353	chair	11bcdf43-287d-45f4-995e-fc1f2ad21cb0	4	09:00:00	20:00:00
7f9807a8-a571-40db-9e80-92043cf16685	chair	11bcdf43-287d-45f4-995e-fc1f2ad21cb0	5	09:00:00	20:00:00
a8c0909d-e2c5-4c99-a9fc-fa92e0a1726a	chair	11bcdf43-287d-45f4-995e-fc1f2ad21cb0	6	09:00:00	20:00:00
0a3c8501-d4cf-4c30-a10e-34e902b5a9d5	chair	956eb3ea-02ac-4bfc-bfbb-7d1731fdff84	0	09:00:00	20:00:00
b6605ad9-9fc7-4439-983e-40624a99ac17	chair	956eb3ea-02ac-4bfc-bfbb-7d1731fdff84	1	09:00:00	20:00:00
db0020bd-a812-45f7-a1e0-bb93ae7f1be7	chair	956eb3ea-02ac-4bfc-bfbb-7d1731fdff84	2	09:00:00	20:00:00
e36f5532-5be1-482c-9076-63c1c243fccf	chair	956eb3ea-02ac-4bfc-bfbb-7d1731fdff84	3	09:00:00	20:00:00
c8e09bf0-1a26-445a-bd4b-04e5a1b7f78d	chair	956eb3ea-02ac-4bfc-bfbb-7d1731fdff84	4	09:00:00	20:00:00
3a83cdc7-6965-438d-855d-a5d501404b0c	chair	956eb3ea-02ac-4bfc-bfbb-7d1731fdff84	5	09:00:00	20:00:00
dcc06ac9-30ee-4806-bc3f-361d8311f607	chair	956eb3ea-02ac-4bfc-bfbb-7d1731fdff84	6	09:00:00	20:00:00
9de32867-6b93-47e8-b678-3d25067b5047	chair	4489cf8b-2916-42fa-b8c8-54604b93ac86	0	09:00:00	20:00:00
b618435e-59e7-4602-b778-482227c8b1ba	chair	4489cf8b-2916-42fa-b8c8-54604b93ac86	1	09:00:00	20:00:00
12485be5-7da3-477f-a28c-a6a7f00942a1	chair	4489cf8b-2916-42fa-b8c8-54604b93ac86	2	09:00:00	20:00:00
50583682-2105-4893-9c8d-8bc088c3a16b	chair	4489cf8b-2916-42fa-b8c8-54604b93ac86	3	09:00:00	20:00:00
fb83a829-1fda-4257-b206-88e33470169b	chair	4489cf8b-2916-42fa-b8c8-54604b93ac86	4	09:00:00	20:00:00
42fb0066-af5e-40dc-9d33-7c5517223052	chair	4489cf8b-2916-42fa-b8c8-54604b93ac86	5	09:00:00	20:00:00
4cc32b8d-fe9a-4f41-8658-10368f997897	chair	4489cf8b-2916-42fa-b8c8-54604b93ac86	6	09:00:00	20:00:00
559241ca-2121-4168-95b3-0d0ddf947c7f	staff	9e8afae2-1456-42ef-8843-d3ed612706f3	0	09:00:00	20:00:00
ee90323d-ff1c-414d-b001-88fc9e66cc1f	staff	9e8afae2-1456-42ef-8843-d3ed612706f3	1	09:00:00	20:00:00
fc57a29d-3428-476c-bef8-5bcbe3755a47	staff	9e8afae2-1456-42ef-8843-d3ed612706f3	2	09:00:00	20:00:00
727ad8a0-0d2a-442e-b0e4-afab36e9d350	staff	9e8afae2-1456-42ef-8843-d3ed612706f3	3	09:00:00	20:00:00
1291086b-1ccf-46e1-8e4e-5a245a44676e	staff	9e8afae2-1456-42ef-8843-d3ed612706f3	4	09:00:00	20:00:00
03b554de-e179-4a8e-831c-ac2894f5e2c4	staff	9e8afae2-1456-42ef-8843-d3ed612706f3	5	09:00:00	20:00:00
25158c68-13c2-47b3-8a00-581c049ba2df	staff	9e8afae2-1456-42ef-8843-d3ed612706f3	6	09:00:00	20:00:00
0a829b2a-6600-46ca-b2d6-3e1c68c1d069	chair	987953d3-d427-4f8a-8031-045c0aff6acd	0	09:00:00	20:00:00
9d68f715-fe8d-4cdb-853e-29dc43b2397b	chair	987953d3-d427-4f8a-8031-045c0aff6acd	1	09:00:00	20:00:00
5072b3b0-343c-4b73-9f7a-f061788e026d	chair	987953d3-d427-4f8a-8031-045c0aff6acd	2	09:00:00	20:00:00
5adb300d-e8f3-4385-8a86-d4ce12159e0c	chair	987953d3-d427-4f8a-8031-045c0aff6acd	3	09:00:00	20:00:00
dcd73248-4039-4984-a753-47af7005125a	chair	987953d3-d427-4f8a-8031-045c0aff6acd	4	09:00:00	20:00:00
fb5839b0-3b7f-4179-a19d-2892b349d252	chair	987953d3-d427-4f8a-8031-045c0aff6acd	5	09:00:00	20:00:00
27193dd5-3175-4f28-a1b1-3459b7dcd91b	chair	987953d3-d427-4f8a-8031-045c0aff6acd	6	09:00:00	20:00:00
d0ad0bf5-fb50-4c33-a104-89e2fdc1e3be	staff	bee3515c-19e3-454f-922b-8f24d8a75913	0	09:00:00	20:00:00
ce58883e-ed6a-482d-88a9-595f5afb9416	staff	bee3515c-19e3-454f-922b-8f24d8a75913	1	09:00:00	20:00:00
56ddbd35-6b4a-4e2c-963f-0e4a9553ebfc	staff	bee3515c-19e3-454f-922b-8f24d8a75913	2	09:00:00	20:00:00
a54b0954-049d-424e-9245-801b1c6ddd6e	staff	bee3515c-19e3-454f-922b-8f24d8a75913	3	09:00:00	20:00:00
c84dc351-32f1-493f-8602-2adfae90b19f	staff	bee3515c-19e3-454f-922b-8f24d8a75913	4	09:00:00	20:00:00
071ed537-3a8c-4d62-a374-ee6f076b608e	staff	bee3515c-19e3-454f-922b-8f24d8a75913	5	09:00:00	20:00:00
66534b11-bf4a-4e0b-bb59-3e295d176688	staff	bee3515c-19e3-454f-922b-8f24d8a75913	6	09:00:00	20:00:00
45b7d2db-1da7-4932-9415-64007f90afa2	chair	587eea71-d4c6-4f7e-9660-0d3a106cb33a	0	09:00:00	20:00:00
c6924f32-aeb0-44ad-8c24-593059c8f9a4	chair	587eea71-d4c6-4f7e-9660-0d3a106cb33a	1	09:00:00	20:00:00
89928d04-81a2-41e0-8277-5aded5bab69a	chair	587eea71-d4c6-4f7e-9660-0d3a106cb33a	2	09:00:00	20:00:00
0bef1893-2c7d-4d45-85fc-86c43faa6f09	chair	587eea71-d4c6-4f7e-9660-0d3a106cb33a	3	09:00:00	20:00:00
04a860f3-cfaa-4c82-8068-8b57b19254c4	chair	587eea71-d4c6-4f7e-9660-0d3a106cb33a	4	09:00:00	20:00:00
6f8e9861-6111-4a43-a25f-192878b9555d	chair	587eea71-d4c6-4f7e-9660-0d3a106cb33a	5	09:00:00	20:00:00
05383cf8-01ca-4ac5-a91e-452a8cb9c8d4	chair	587eea71-d4c6-4f7e-9660-0d3a106cb33a	6	09:00:00	20:00:00
968b7882-feb6-4e88-8183-e6e8a3b9dd14	staff	05cf7580-8f7d-433b-a660-ab1b55791e8c	0	09:00:00	20:00:00
13e6617a-5f49-4fc6-a2c2-5db3d61bc61f	staff	05cf7580-8f7d-433b-a660-ab1b55791e8c	1	09:00:00	20:00:00
ee1cff8e-32a9-42bc-8003-12f6d85a0547	staff	05cf7580-8f7d-433b-a660-ab1b55791e8c	2	09:00:00	20:00:00
216c2148-fb92-4bab-ade4-a7c6ed5c6712	staff	05cf7580-8f7d-433b-a660-ab1b55791e8c	3	09:00:00	20:00:00
8f35ec4b-bfee-42fc-b906-acfb373f1fb3	staff	05cf7580-8f7d-433b-a660-ab1b55791e8c	4	09:00:00	20:00:00
817a44f5-40f4-478e-834c-12a43459256a	staff	05cf7580-8f7d-433b-a660-ab1b55791e8c	5	09:00:00	20:00:00
d28791de-dcca-4f7c-88ed-e9c0b88add9c	staff	05cf7580-8f7d-433b-a660-ab1b55791e8c	6	09:00:00	20:00:00
617d8a54-6ec1-40b8-a1e2-712a8e27622c	chair	4a4ecc6e-6b57-4f34-9e28-39d89f684d3c	0	09:00:00	20:00:00
ddf292fb-0e0e-4925-8061-186277ef09bc	chair	4a4ecc6e-6b57-4f34-9e28-39d89f684d3c	1	09:00:00	20:00:00
c149c8ee-6a5e-414b-a40d-50d2e1ae7726	chair	4a4ecc6e-6b57-4f34-9e28-39d89f684d3c	2	09:00:00	20:00:00
72668517-d18e-4c44-938a-b1d56e4631ab	chair	4a4ecc6e-6b57-4f34-9e28-39d89f684d3c	3	09:00:00	20:00:00
4234d7cf-3846-405d-8816-59aecffa02ec	chair	4a4ecc6e-6b57-4f34-9e28-39d89f684d3c	4	09:00:00	20:00:00
7ece1444-7caf-438b-8fd4-191711d5b12e	chair	4a4ecc6e-6b57-4f34-9e28-39d89f684d3c	5	09:00:00	20:00:00
aefeba87-1e43-4a7b-aaf4-09ca46c2b8f0	chair	4a4ecc6e-6b57-4f34-9e28-39d89f684d3c	6	09:00:00	20:00:00
ebb08dd5-179e-480c-b5e5-9bff435364a3	staff	e16ebfba-a63f-4728-98ad-b8ee65ac2b47	0	09:00:00	20:00:00
d39217e3-d53d-487d-a5d8-4e64dda0f9b7	staff	e16ebfba-a63f-4728-98ad-b8ee65ac2b47	1	09:00:00	20:00:00
c2903c7c-7603-4a27-9a11-22871445863e	staff	e16ebfba-a63f-4728-98ad-b8ee65ac2b47	2	09:00:00	20:00:00
ec8e8e2d-5899-4b27-97be-1f33aeedd1cf	staff	e16ebfba-a63f-4728-98ad-b8ee65ac2b47	3	09:00:00	20:00:00
2c47e2ea-44ef-4a77-a654-bf1171300713	staff	e16ebfba-a63f-4728-98ad-b8ee65ac2b47	4	09:00:00	20:00:00
70847bc0-c606-470c-ae63-53a83353b970	staff	e16ebfba-a63f-4728-98ad-b8ee65ac2b47	5	09:00:00	20:00:00
624464fa-2a4a-4aa1-b3c6-7fa601450603	staff	e16ebfba-a63f-4728-98ad-b8ee65ac2b47	6	09:00:00	20:00:00
c35fa2d3-6515-4a73-af61-e38602efc1bb	chair	79b02ef5-a0ec-4905-b9ff-1ab404ba7967	0	09:00:00	20:00:00
7f5ff309-a35a-4abb-a544-685badb20fb2	chair	79b02ef5-a0ec-4905-b9ff-1ab404ba7967	1	09:00:00	20:00:00
07ae9bdf-1ac5-41f2-9ebb-d350744e8c91	chair	79b02ef5-a0ec-4905-b9ff-1ab404ba7967	2	09:00:00	20:00:00
d877e23a-2813-4a42-9136-8f9ee274e819	chair	79b02ef5-a0ec-4905-b9ff-1ab404ba7967	3	09:00:00	20:00:00
9fc291c2-e156-4d42-b1f4-d5ba7aabdea5	chair	79b02ef5-a0ec-4905-b9ff-1ab404ba7967	4	09:00:00	20:00:00
1b277a5c-852e-419c-b4c8-ee3a3eb0a47d	chair	79b02ef5-a0ec-4905-b9ff-1ab404ba7967	5	09:00:00	20:00:00
39fb0204-fd81-4b70-ac99-32053d6dfb8b	chair	79b02ef5-a0ec-4905-b9ff-1ab404ba7967	6	09:00:00	20:00:00
d742319f-a25d-4644-a790-57d29aea8b7b	staff	11d45054-392d-46ea-9af4-6f785af5ebb1	0	09:00:00	20:00:00
b85486c1-28de-47f1-b6b9-cd4c1dfe1eee	staff	11d45054-392d-46ea-9af4-6f785af5ebb1	1	09:00:00	20:00:00
385b8827-560d-4f35-af3d-429323e3ef0f	staff	11d45054-392d-46ea-9af4-6f785af5ebb1	2	09:00:00	20:00:00
8eb4595c-f6f2-465b-9bff-834f95e8e416	staff	11d45054-392d-46ea-9af4-6f785af5ebb1	3	09:00:00	20:00:00
bde9daab-711c-4745-b503-9f67ef0c994b	staff	11d45054-392d-46ea-9af4-6f785af5ebb1	4	09:00:00	20:00:00
86535072-520e-4bc2-9c4d-8ed70da29c9f	staff	11d45054-392d-46ea-9af4-6f785af5ebb1	5	09:00:00	20:00:00
eec02a5e-1ca0-49e2-abb0-b96dac61fef8	staff	11d45054-392d-46ea-9af4-6f785af5ebb1	6	09:00:00	20:00:00
3255d801-647b-4055-8346-e91b3c810b65	chair	15c9e2f0-4497-44dd-920c-3225a600686b	0	09:00:00	20:00:00
0f181ab9-dc62-4fca-ad89-772f299b98f0	chair	15c9e2f0-4497-44dd-920c-3225a600686b	1	09:00:00	20:00:00
f300dfe7-eb59-4a63-9bc6-84cfc3bb7c71	chair	15c9e2f0-4497-44dd-920c-3225a600686b	2	09:00:00	20:00:00
69394796-f425-4dad-97e7-4a1ccdce1266	chair	15c9e2f0-4497-44dd-920c-3225a600686b	3	09:00:00	20:00:00
6ffb5e18-f7ec-4e73-b195-7f41a8e35184	chair	15c9e2f0-4497-44dd-920c-3225a600686b	4	09:00:00	20:00:00
0a04a871-5fce-4e44-82bf-b8acf376887e	chair	15c9e2f0-4497-44dd-920c-3225a600686b	5	09:00:00	20:00:00
4c704b03-2229-439f-9c6d-165f297ee2a6	chair	15c9e2f0-4497-44dd-920c-3225a600686b	6	09:00:00	20:00:00
caed2901-46c6-435c-b630-68c565f3568a	staff	544ceb5a-2fea-47d6-acef-76045154881a	3	09:00:00	20:00:00
a043841b-b5c3-4d8f-8ace-9203730a2be9	staff	544ceb5a-2fea-47d6-acef-76045154881a	4	09:00:00	20:00:00
c77a9b9d-1b69-439a-81f2-4f9c14905a4f	staff	544ceb5a-2fea-47d6-acef-76045154881a	5	09:00:00	20:00:00
df4d2f1f-0063-412e-b73f-b85fdd516bcc	staff	544ceb5a-2fea-47d6-acef-76045154881a	6	09:00:00	20:00:00
6c870cf3-a87d-405e-8c59-19bf7cbe861e	chair	51ea5f58-4223-4554-9353-bc60c970a7d9	0	09:00:00	20:00:00
aea27abe-b33a-4e39-a345-3b774b323ab8	chair	51ea5f58-4223-4554-9353-bc60c970a7d9	1	09:00:00	20:00:00
b35cf2a3-5ac2-48cb-8664-ebf4e0a88574	chair	51ea5f58-4223-4554-9353-bc60c970a7d9	2	09:00:00	20:00:00
e1227058-7d4d-4347-a6b1-5017be96efcd	chair	51ea5f58-4223-4554-9353-bc60c970a7d9	3	09:00:00	20:00:00
846d74d0-169b-4988-90ba-0c372fa705a6	chair	51ea5f58-4223-4554-9353-bc60c970a7d9	4	09:00:00	20:00:00
a71c361a-cc87-4817-bd2c-fb07753d41ef	chair	51ea5f58-4223-4554-9353-bc60c970a7d9	5	09:00:00	20:00:00
d97acae1-28d8-4965-aa97-94957ddfe093	chair	51ea5f58-4223-4554-9353-bc60c970a7d9	6	09:00:00	20:00:00
b53c1edf-f528-4a11-8afa-136ffb2f306c	staff	9ff568fe-8383-455f-ac18-18299a003bb6	0	09:00:00	20:00:00
5d217a7f-cb67-4162-b7f1-a2ec5c8bb297	staff	9ff568fe-8383-455f-ac18-18299a003bb6	1	09:00:00	20:00:00
c2c565f2-84cd-4d6b-96f8-2609eb6ae0a6	staff	9ff568fe-8383-455f-ac18-18299a003bb6	2	09:00:00	20:00:00
06b735a4-69d8-4796-a0d7-549c7a146614	staff	9ff568fe-8383-455f-ac18-18299a003bb6	3	09:00:00	20:00:00
8cce88cc-c39a-4d91-bffb-631f26f1ce89	staff	9ff568fe-8383-455f-ac18-18299a003bb6	4	09:00:00	20:00:00
5bd57368-6275-48dd-9b41-3a2e3ff40b9f	staff	9ff568fe-8383-455f-ac18-18299a003bb6	5	09:00:00	20:00:00
a52e9a0f-178a-4074-b43e-e70f18f81343	staff	9ff568fe-8383-455f-ac18-18299a003bb6	6	09:00:00	20:00:00
5315f9ba-a65a-47f2-a6c4-63fc4f676376	staff	4094637e-5070-4e5e-a1c7-627a2f8cb985	0	09:00:00	20:00:00
9ee32a75-d06b-43e4-86ae-207c10a8e53c	staff	4094637e-5070-4e5e-a1c7-627a2f8cb985	1	09:00:00	20:00:00
0499b9c6-cfef-49f4-afff-8803c00afbc9	staff	4094637e-5070-4e5e-a1c7-627a2f8cb985	2	09:00:00	20:00:00
7a2248a7-1af3-403f-b702-be09e4147880	staff	4094637e-5070-4e5e-a1c7-627a2f8cb985	3	09:00:00	20:00:00
843f77ba-ac63-4ea6-b4bf-1439198852ed	staff	4094637e-5070-4e5e-a1c7-627a2f8cb985	4	09:00:00	20:00:00
c0cdc8c7-d1d8-4006-a8d6-6cc42617fd6b	staff	4094637e-5070-4e5e-a1c7-627a2f8cb985	5	09:00:00	20:00:00
fd581898-1f08-4352-a694-c2f2a291e6a3	staff	4094637e-5070-4e5e-a1c7-627a2f8cb985	6	09:00:00	20:00:00
976097ba-9e35-4acd-8504-2fb61f0dbe4d	chair	198217d7-dcfc-488a-8b1a-fe5d3937dd7a	0	09:00:00	20:00:00
ff394955-7692-4b49-8e39-5764d58b89c4	chair	198217d7-dcfc-488a-8b1a-fe5d3937dd7a	1	09:00:00	20:00:00
36e65a5b-2174-4326-a49e-2c7586c49fa4	chair	198217d7-dcfc-488a-8b1a-fe5d3937dd7a	2	09:00:00	20:00:00
59b9c0ae-f2f1-4c55-9938-e3d734faa641	chair	198217d7-dcfc-488a-8b1a-fe5d3937dd7a	3	09:00:00	20:00:00
f671cda3-58e7-40e1-a78b-d5970eb7da07	chair	198217d7-dcfc-488a-8b1a-fe5d3937dd7a	4	09:00:00	20:00:00
4325e8ac-eb64-408b-b0b9-ea8312f4fc6a	chair	198217d7-dcfc-488a-8b1a-fe5d3937dd7a	5	09:00:00	20:00:00
958eb1e5-0651-455d-b37a-600c14626e04	chair	198217d7-dcfc-488a-8b1a-fe5d3937dd7a	6	09:00:00	20:00:00
a85067c3-a480-48a6-9f0e-477e44bc3ed1	staff	366b1baf-e776-41fb-b606-9b32f7261a03	0	09:00:00	20:00:00
3f260b21-2411-4de9-b57e-019429f61f15	staff	366b1baf-e776-41fb-b606-9b32f7261a03	1	09:00:00	20:00:00
9f629a35-8fe1-4c2d-adf9-9ccb538cdefc	staff	366b1baf-e776-41fb-b606-9b32f7261a03	2	09:00:00	20:00:00
e01a0b9c-be20-4482-99cb-a9a7625a5ada	staff	366b1baf-e776-41fb-b606-9b32f7261a03	3	09:00:00	20:00:00
a3b57d6c-93fa-4fd8-8b66-292f937bfe39	staff	366b1baf-e776-41fb-b606-9b32f7261a03	4	09:00:00	20:00:00
3e186b0d-b169-4781-a1ce-3aa6d39a496c	staff	366b1baf-e776-41fb-b606-9b32f7261a03	5	09:00:00	20:00:00
b94a2253-7ee1-4420-8be6-96f9bf38ff89	staff	366b1baf-e776-41fb-b606-9b32f7261a03	6	09:00:00	20:00:00
d30493ec-3cb4-4e43-bfce-1b2a6b796020	chair	d5f5fcef-8bae-4365-adde-9f43556ed141	0	09:00:00	20:00:00
376a7067-18b0-4cc7-a4c1-b3ce90adef26	chair	d5f5fcef-8bae-4365-adde-9f43556ed141	1	09:00:00	20:00:00
3c52c534-2fcf-4964-a976-ee4721e44f8d	chair	d5f5fcef-8bae-4365-adde-9f43556ed141	2	09:00:00	20:00:00
de5411e7-78a7-41ad-b242-b2c2bd8c3491	chair	d5f5fcef-8bae-4365-adde-9f43556ed141	3	09:00:00	20:00:00
25200872-c129-4c53-a0f5-a64ba24704b9	chair	d5f5fcef-8bae-4365-adde-9f43556ed141	4	09:00:00	20:00:00
efef4d58-3f33-4a4d-a039-2bce64b56b82	chair	d5f5fcef-8bae-4365-adde-9f43556ed141	5	09:00:00	20:00:00
8c12b7b0-bbbb-4a76-9eda-6c1f5f50ea62	chair	d5f5fcef-8bae-4365-adde-9f43556ed141	6	09:00:00	20:00:00
8de4a6be-5215-46c8-a7f0-602646b136a6	staff	de0edb73-fc1a-4d2e-85c4-fad6ba995838	0	09:00:00	20:00:00
302e1642-21bd-443a-918d-e9bf579e3ce7	staff	de0edb73-fc1a-4d2e-85c4-fad6ba995838	1	09:00:00	20:00:00
acf7ea30-4afa-4b8b-a9e7-eb47494af264	staff	de0edb73-fc1a-4d2e-85c4-fad6ba995838	2	09:00:00	20:00:00
53580dfc-b3ea-48d7-8705-145b41f8d000	staff	de0edb73-fc1a-4d2e-85c4-fad6ba995838	3	09:00:00	20:00:00
d6766f8f-4b14-445a-a6ad-36e1e3d01597	staff	de0edb73-fc1a-4d2e-85c4-fad6ba995838	4	09:00:00	20:00:00
8c15dea3-4506-45c8-a1ff-5d1d50dbde99	staff	de0edb73-fc1a-4d2e-85c4-fad6ba995838	5	09:00:00	20:00:00
ac3c48b9-fa85-44dd-9e5d-6ee109096b0a	staff	de0edb73-fc1a-4d2e-85c4-fad6ba995838	6	09:00:00	20:00:00
3cc8fcb0-3ff3-4a0f-8d47-f5fb8a979920	chair	52e02b16-cf87-4e89-add9-60619bd5131a	0	09:00:00	20:00:00
04772251-7f4b-4611-9f9e-e9ab4515bc0f	chair	52e02b16-cf87-4e89-add9-60619bd5131a	1	09:00:00	20:00:00
4edb44e6-8aa2-47e5-aa3d-c600ae9c4d55	chair	52e02b16-cf87-4e89-add9-60619bd5131a	2	09:00:00	20:00:00
01ca3248-2e28-4803-9da0-fbbb188f764e	chair	52e02b16-cf87-4e89-add9-60619bd5131a	3	09:00:00	20:00:00
1530e296-7428-40a7-8057-44791caf9abd	chair	52e02b16-cf87-4e89-add9-60619bd5131a	4	09:00:00	20:00:00
78c00cac-1368-40a5-8ac2-d53a4390c5e4	chair	52e02b16-cf87-4e89-add9-60619bd5131a	5	09:00:00	20:00:00
e84d8d53-0b36-4f28-b1a6-54f18b38a1a5	chair	52e02b16-cf87-4e89-add9-60619bd5131a	6	09:00:00	20:00:00
4c93e0e2-1afa-4707-a8af-56c47059e1bf	chair	b0102f4b-7206-4392-b9e2-f5b2701ea49b	1	09:00:00	20:00:00
2aa659a4-4369-4f10-b3f2-a38ecfeea34a	chair	b0102f4b-7206-4392-b9e2-f5b2701ea49b	2	09:00:00	20:00:00
b16162f8-91a8-45d1-8db8-0dd54ca6f906	chair	b0102f4b-7206-4392-b9e2-f5b2701ea49b	3	09:00:00	20:00:00
6ed69137-1e03-4725-9105-eccf3f41312d	chair	b0102f4b-7206-4392-b9e2-f5b2701ea49b	4	09:00:00	20:00:00
73b749ef-5dea-4012-aba2-9290ac687eb8	chair	b0102f4b-7206-4392-b9e2-f5b2701ea49b	5	09:00:00	20:00:00
676546fb-05a8-40e4-8246-28898164ec4c	chair	b0102f4b-7206-4392-b9e2-f5b2701ea49b	6	09:00:00	20:00:00
ba5ace55-3ad1-4360-bbb1-9ab95d12cdf8	staff	8cecfbcd-5e85-410a-b260-665f1caa2eb4	0	09:00:00	20:00:00
136b3f9d-7d80-47c1-9939-0bb96c652329	staff	8cecfbcd-5e85-410a-b260-665f1caa2eb4	1	09:00:00	20:00:00
29362b22-ea3f-4627-861a-bfca442692cb	staff	8cecfbcd-5e85-410a-b260-665f1caa2eb4	2	09:00:00	20:00:00
8d4bd97c-8693-4407-9b46-0122c3e86e12	staff	8cecfbcd-5e85-410a-b260-665f1caa2eb4	3	09:00:00	20:00:00
66a5b943-192a-4359-a3a0-ece1cc9a6392	staff	8cecfbcd-5e85-410a-b260-665f1caa2eb4	4	09:00:00	20:00:00
130d49bf-f8ed-4e83-a07c-a2f9cdb0fcec	staff	8cecfbcd-5e85-410a-b260-665f1caa2eb4	5	09:00:00	20:00:00
7cf4315d-6d8a-47e9-bc11-2ab0054c05b9	staff	8cecfbcd-5e85-410a-b260-665f1caa2eb4	6	09:00:00	20:00:00
90d67194-a76c-43ad-bf87-c14293f8322a	chair	4cb3daaf-0583-4545-ad60-05949b03cbe2	0	09:00:00	20:00:00
b7aa1ada-5b13-4fd2-97b1-7f34f6143fe5	chair	4cb3daaf-0583-4545-ad60-05949b03cbe2	1	09:00:00	20:00:00
7bb0b4d5-3bcd-486e-87bf-7df535c81857	chair	4cb3daaf-0583-4545-ad60-05949b03cbe2	2	09:00:00	20:00:00
8c5a6992-7157-46b2-b2dd-a2325f4bb8f8	chair	4cb3daaf-0583-4545-ad60-05949b03cbe2	3	09:00:00	20:00:00
87e75d1f-a8aa-46a1-8054-c0aae78776a2	chair	4cb3daaf-0583-4545-ad60-05949b03cbe2	4	09:00:00	20:00:00
d5b210ce-9a69-44e1-8bf3-5728bcba3818	chair	4cb3daaf-0583-4545-ad60-05949b03cbe2	5	09:00:00	20:00:00
42603bf7-53ca-4ace-af09-14d445266a66	chair	4cb3daaf-0583-4545-ad60-05949b03cbe2	6	09:00:00	20:00:00
e9647960-7792-4a79-b562-160b01127223	staff	e3ecb356-03e8-4d45-85cb-50adc81a474a	0	09:00:00	20:00:00
6eef27c2-421b-4a72-b83a-35a8b77a993f	staff	e3ecb356-03e8-4d45-85cb-50adc81a474a	1	09:00:00	20:00:00
602965e0-0872-40f8-863a-3e522710f0d0	staff	e3ecb356-03e8-4d45-85cb-50adc81a474a	2	09:00:00	20:00:00
5311c2fb-a481-4b47-8b6c-50939e38b3ae	staff	e3ecb356-03e8-4d45-85cb-50adc81a474a	3	09:00:00	20:00:00
8f448676-02e6-4453-8259-972c8fc9dcf0	staff	e3ecb356-03e8-4d45-85cb-50adc81a474a	4	09:00:00	20:00:00
1b554e2a-4ab8-4e9f-9709-9edcabfaf9d0	staff	e3ecb356-03e8-4d45-85cb-50adc81a474a	5	09:00:00	20:00:00
3ae145f9-854b-4bf9-b8bf-e8a3a5165788	staff	e3ecb356-03e8-4d45-85cb-50adc81a474a	6	09:00:00	20:00:00
7354bc48-e58e-4035-8329-98ff8de7bcf8	chair	b90c8e63-436c-415a-ae95-08999126140c	0	09:00:00	20:00:00
bfb96b08-264a-46fe-be6a-4577c7198ad3	chair	b90c8e63-436c-415a-ae95-08999126140c	1	09:00:00	20:00:00
59ae0e87-b5e8-4a09-a68b-c45b242df3ae	chair	b90c8e63-436c-415a-ae95-08999126140c	2	09:00:00	20:00:00
b52145d1-bfb9-471f-8a90-249441444eb4	chair	b90c8e63-436c-415a-ae95-08999126140c	3	09:00:00	20:00:00
fe570457-f36c-424e-a895-4cbd3758ab11	chair	b90c8e63-436c-415a-ae95-08999126140c	4	09:00:00	20:00:00
7cc08fa8-43f0-4049-8fc3-ff041df7a687	chair	b90c8e63-436c-415a-ae95-08999126140c	5	09:00:00	20:00:00
ee633147-3dc1-4e18-9d48-01d2f6e42987	chair	b90c8e63-436c-415a-ae95-08999126140c	6	09:00:00	20:00:00
8df8a26f-93e3-45e1-b1f2-492d4687451e	staff	8fcfcba0-a241-4d09-8dad-4160d4f18116	0	09:00:00	20:00:00
a2b270da-db42-41f1-8182-2e967dfe80bf	staff	8fcfcba0-a241-4d09-8dad-4160d4f18116	1	09:00:00	20:00:00
962a0777-5aa8-435e-a44d-6e6079e5fe16	staff	8fcfcba0-a241-4d09-8dad-4160d4f18116	2	09:00:00	20:00:00
38afbfec-3bdf-4eef-984d-55a2c16f1ade	staff	8fcfcba0-a241-4d09-8dad-4160d4f18116	3	09:00:00	20:00:00
98a429a4-4465-42f0-b1f4-8bcbb50b86da	staff	8fcfcba0-a241-4d09-8dad-4160d4f18116	4	09:00:00	20:00:00
708bd5de-e807-4afb-9160-ea6bf9948263	staff	8fcfcba0-a241-4d09-8dad-4160d4f18116	5	09:00:00	20:00:00
7533aba2-3445-4c92-ab28-51f2b4cf84dd	staff	8fcfcba0-a241-4d09-8dad-4160d4f18116	6	09:00:00	20:00:00
5f5dfa95-9e9b-4b8d-bdf5-ed46ed97999a	chair	26dbc2f4-1a2a-4319-b559-6d7c17bf166a	0	09:00:00	20:00:00
5e80a955-0592-4536-8c3e-877899f0ad94	chair	26dbc2f4-1a2a-4319-b559-6d7c17bf166a	1	09:00:00	20:00:00
2a357ec2-b69b-4e32-bfc0-4d09975da763	chair	26dbc2f4-1a2a-4319-b559-6d7c17bf166a	2	09:00:00	20:00:00
9da64db9-2fd7-468d-a734-9769a6812f32	chair	26dbc2f4-1a2a-4319-b559-6d7c17bf166a	3	09:00:00	20:00:00
f1605ff2-a0ae-45fa-becc-74851e0aee9c	chair	26dbc2f4-1a2a-4319-b559-6d7c17bf166a	4	09:00:00	20:00:00
1125084c-4e0c-4355-903c-55da2082ac1b	chair	26dbc2f4-1a2a-4319-b559-6d7c17bf166a	5	09:00:00	20:00:00
8b3fee93-37c4-41c5-831e-2f2493c97b38	chair	26dbc2f4-1a2a-4319-b559-6d7c17bf166a	6	09:00:00	20:00:00
3fa8f34b-c93e-4603-a3c1-14975f707599	chair	ed6ba726-6d7d-4f56-bfce-c8e14170130b	0	09:00:00	20:00:00
994247e4-f202-40b4-bdfd-4601c3820f47	chair	ed6ba726-6d7d-4f56-bfce-c8e14170130b	1	09:00:00	20:00:00
96f1c5e6-7c91-4122-95c4-4172cbf95373	chair	ed6ba726-6d7d-4f56-bfce-c8e14170130b	2	09:00:00	20:00:00
3ff8bf2a-1ba7-40fd-a0cb-0484342a8403	chair	ed6ba726-6d7d-4f56-bfce-c8e14170130b	3	09:00:00	20:00:00
014d6d44-2988-479e-b819-ad06a722e8ea	chair	ed6ba726-6d7d-4f56-bfce-c8e14170130b	4	09:00:00	20:00:00
b3022497-250b-45c9-afa3-0a718c7db3d4	chair	ed6ba726-6d7d-4f56-bfce-c8e14170130b	5	09:00:00	20:00:00
582be04a-b1e4-4ca6-9793-765c57eff89c	chair	ed6ba726-6d7d-4f56-bfce-c8e14170130b	6	09:00:00	20:00:00
0b6d4d3e-d320-4d3e-94d1-9a611b49eb6e	staff	033f2976-aa70-43db-b8b6-b850b66193f8	0	09:00:00	20:00:00
276114a0-31c0-4432-8aaa-2563b035e7ea	staff	033f2976-aa70-43db-b8b6-b850b66193f8	1	09:00:00	20:00:00
3249dcbd-280a-4134-9530-b06436eb8e9b	staff	033f2976-aa70-43db-b8b6-b850b66193f8	2	09:00:00	20:00:00
53895817-e0f9-4bc3-9884-f6236f922e95	staff	033f2976-aa70-43db-b8b6-b850b66193f8	3	09:00:00	20:00:00
ce3ff96c-37dd-4d20-bd28-9c8a45077d77	staff	033f2976-aa70-43db-b8b6-b850b66193f8	4	09:00:00	20:00:00
e4e516df-a947-422a-aa10-2089292785d6	staff	033f2976-aa70-43db-b8b6-b850b66193f8	5	09:00:00	20:00:00
372b4c05-e840-46c0-9ba5-6de11623b232	staff	033f2976-aa70-43db-b8b6-b850b66193f8	6	09:00:00	20:00:00
57f123d6-1f79-4ad5-9c1d-d7fa63d6f121	chair	c5eb655d-5259-4300-997e-b290f0cac571	0	09:00:00	20:00:00
70756285-d0b9-4cc3-853d-dcf94dffc4cf	chair	c5eb655d-5259-4300-997e-b290f0cac571	1	09:00:00	20:00:00
8fed9b73-c4df-4e1b-bb16-e48cc4e93270	chair	c5eb655d-5259-4300-997e-b290f0cac571	2	09:00:00	20:00:00
f80fe2f7-d4e2-4857-90d0-990c7fe9b03d	chair	c5eb655d-5259-4300-997e-b290f0cac571	3	09:00:00	20:00:00
a177970e-6a76-4796-a7cb-999481ba7fe7	chair	c5eb655d-5259-4300-997e-b290f0cac571	4	09:00:00	20:00:00
372d2637-8622-4b0d-91d6-a78b8331c74e	chair	c5eb655d-5259-4300-997e-b290f0cac571	5	09:00:00	20:00:00
b3b11a94-bab4-4762-8c25-ad9f1ace0878	chair	c5eb655d-5259-4300-997e-b290f0cac571	6	09:00:00	20:00:00
9f90661a-0106-43ae-adee-6853e872187c	staff	9c2bc407-3577-4e1c-9123-65557b53d545	0	09:00:00	20:00:00
89daaf09-6cd1-4aa0-9002-6211e115e885	staff	9c2bc407-3577-4e1c-9123-65557b53d545	1	09:00:00	20:00:00
5f73b2e3-e6f5-4c19-83c6-93141fa1685a	staff	9c2bc407-3577-4e1c-9123-65557b53d545	2	09:00:00	20:00:00
8b565784-3ddb-461c-bee9-5d94789a68ac	staff	9c2bc407-3577-4e1c-9123-65557b53d545	3	09:00:00	20:00:00
69cd9be5-bbb9-4a0d-9b8e-84f827fa12c8	staff	9c2bc407-3577-4e1c-9123-65557b53d545	4	09:00:00	20:00:00
ffb09283-e01c-4143-bd92-d11b5572796b	staff	9c2bc407-3577-4e1c-9123-65557b53d545	5	09:00:00	20:00:00
0fd87ce0-1977-4c35-9e49-24be9e7920e3	staff	9c2bc407-3577-4e1c-9123-65557b53d545	6	09:00:00	20:00:00
22c2e573-8719-4e80-811f-263cd4ab3c40	chair	a4414bb1-07d5-424d-99f8-25fd84c57ffc	0	09:00:00	20:00:00
fce97b2d-29ff-4c2b-9885-23d281990112	chair	a4414bb1-07d5-424d-99f8-25fd84c57ffc	1	09:00:00	20:00:00
54de85ec-2c81-47b7-a917-ad78561f43db	chair	a4414bb1-07d5-424d-99f8-25fd84c57ffc	2	09:00:00	20:00:00
a200c9b4-1c63-486c-86f0-2b49e4689a09	chair	a4414bb1-07d5-424d-99f8-25fd84c57ffc	3	09:00:00	20:00:00
415e51ae-74fc-43e9-9347-6908ff811888	chair	a4414bb1-07d5-424d-99f8-25fd84c57ffc	4	09:00:00	20:00:00
37cbe908-a046-445a-8963-dcd3f60b4b30	chair	a4414bb1-07d5-424d-99f8-25fd84c57ffc	5	09:00:00	20:00:00
10a42a7a-5874-450d-b130-e5a875ff54dd	chair	a4414bb1-07d5-424d-99f8-25fd84c57ffc	6	09:00:00	20:00:00
02df80be-5a13-4ff5-806d-04321fd805c6	staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	0	09:00:00	20:00:00
5d3b61f9-2d19-4873-95c2-dcd0a98580f6	staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	1	09:00:00	20:00:00
61974521-e7c9-4aec-bb71-6b9170c1c552	staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	2	09:00:00	20:00:00
31aed33a-912f-43cb-a97d-81471b2fd45d	staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	3	09:00:00	20:00:00
d57f0c48-63e4-4f06-8a49-bc91efa89827	staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	4	09:00:00	20:00:00
0b4b672f-5087-43c0-864a-10fc6dc6a7c4	staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	5	09:00:00	20:00:00
b896e5df-1e87-4156-9666-68e30c47b92f	staff	a024e0e3-c2ab-410e-98ab-5a6cdaa3b6e8	6	09:00:00	20:00:00
8bc202fc-b85c-47ca-8420-a0ce670aa63b	chair	62a18340-f533-4a3a-9c4a-5a004b306a49	0	09:00:00	20:00:00
3c14d6ef-e332-4176-890b-b73190b6bb55	chair	62a18340-f533-4a3a-9c4a-5a004b306a49	1	09:00:00	20:00:00
b8bd0d91-f866-4142-8102-d87b8d414cc7	chair	62a18340-f533-4a3a-9c4a-5a004b306a49	2	09:00:00	20:00:00
58839c5e-bc25-4ce6-9073-07524f1c9692	chair	62a18340-f533-4a3a-9c4a-5a004b306a49	3	09:00:00	20:00:00
5bf145e7-32bc-4abc-b813-e06331753842	chair	62a18340-f533-4a3a-9c4a-5a004b306a49	4	09:00:00	20:00:00
ac1dec33-a6ea-48de-9712-3b2142aec11a	chair	62a18340-f533-4a3a-9c4a-5a004b306a49	5	09:00:00	20:00:00
413d4d8a-b7ce-440f-92ba-ba94aee1e10d	chair	62a18340-f533-4a3a-9c4a-5a004b306a49	6	09:00:00	20:00:00
4a940787-0350-44a9-b8c9-1f008029b93d	staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	0	09:00:00	20:00:00
0d3c04f9-27a4-4f2c-91e7-63e71cf5d743	staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	1	09:00:00	20:00:00
f73b925e-4efc-4dca-834e-4c0f6d7a9e93	staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	2	09:00:00	20:00:00
48ddfad4-d7d2-4ea7-a7b5-b66f3596ad1d	staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	3	09:00:00	20:00:00
ec3f3cbe-751f-485a-a6e3-66d3f748cfce	staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	4	09:00:00	20:00:00
f9a0580a-0cf5-4e30-89a8-142f901c177e	staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	5	09:00:00	20:00:00
c8a3d058-fc9d-4be0-94a3-074f942f0ac9	staff	fd8e1e25-280c-4c6f-bed3-f070bcce4912	6	09:00:00	20:00:00
b9b02318-565a-4637-99f0-b2584778be6f	chair	c4741883-9f7c-4c47-b7ab-af3b03a10452	0	09:00:00	20:00:00
6c19df11-6637-4516-82e3-ea6064f5475a	chair	c4741883-9f7c-4c47-b7ab-af3b03a10452	1	09:00:00	20:00:00
a1223718-343b-448f-a07c-f54c3561b423	chair	c4741883-9f7c-4c47-b7ab-af3b03a10452	2	09:00:00	20:00:00
66922f3a-4329-4f9e-a20c-e7087be3a63a	chair	c4741883-9f7c-4c47-b7ab-af3b03a10452	3	09:00:00	20:00:00
2092e29b-89eb-4470-884b-51c12d3e0e44	chair	c4741883-9f7c-4c47-b7ab-af3b03a10452	4	09:00:00	20:00:00
9e0d88b5-1f39-4c51-a841-7e1d26e01b41	chair	c4741883-9f7c-4c47-b7ab-af3b03a10452	5	09:00:00	20:00:00
227447bc-226b-4318-aacc-8cddd18a184e	chair	c4741883-9f7c-4c47-b7ab-af3b03a10452	6	09:00:00	20:00:00
543818b5-e2f5-4fdc-813f-a66f14a8bf3e	staff	f9caeb69-4985-4a00-92ba-9f4485840efd	0	09:00:00	20:00:00
fb662197-d6b8-460e-a255-6187c2becf55	staff	f9caeb69-4985-4a00-92ba-9f4485840efd	1	09:00:00	20:00:00
13185f3e-49cb-4492-900f-24d0c579d695	staff	f9caeb69-4985-4a00-92ba-9f4485840efd	2	09:00:00	20:00:00
250cacd8-437f-4fac-9289-17c9de35e0b3	staff	f9caeb69-4985-4a00-92ba-9f4485840efd	3	09:00:00	20:00:00
e350f94f-8970-4418-b82d-f450457e04d0	staff	f9caeb69-4985-4a00-92ba-9f4485840efd	4	09:00:00	20:00:00
9f5e8390-f758-448c-9769-2fd9e72c74cf	staff	f9caeb69-4985-4a00-92ba-9f4485840efd	5	09:00:00	20:00:00
01d7fd57-a2a7-4a80-8076-57ad7d7e66ed	staff	f9caeb69-4985-4a00-92ba-9f4485840efd	6	09:00:00	20:00:00
b7d2297e-c660-4f78-bf96-49582019a1b7	chair	c73991dd-f2b5-46a3-9559-5536614fdc66	0	09:00:00	20:00:00
678e8e16-187a-4348-8c23-a591b8f5c080	chair	c73991dd-f2b5-46a3-9559-5536614fdc66	1	09:00:00	20:00:00
a4feed40-025a-4ef9-8ace-0f16c2587289	chair	c73991dd-f2b5-46a3-9559-5536614fdc66	2	09:00:00	20:00:00
7e83038f-96ed-46dd-8d99-d1555cb6604d	chair	c73991dd-f2b5-46a3-9559-5536614fdc66	3	09:00:00	20:00:00
ef8acaff-7a55-424c-b91b-cd43dfe16b31	chair	c73991dd-f2b5-46a3-9559-5536614fdc66	4	09:00:00	20:00:00
5399a635-549c-4408-bcd4-29597677ebce	chair	c73991dd-f2b5-46a3-9559-5536614fdc66	5	09:00:00	20:00:00
7684e2b4-e99d-413c-baeb-cbd80612a7b7	chair	c73991dd-f2b5-46a3-9559-5536614fdc66	6	09:00:00	20:00:00
2dc49e0a-3f33-4b10-a5f3-67498eae52b4	staff	b9e31fd8-d9b4-43e0-ae3e-fe78fe07c56a	0	09:00:00	20:00:00
752a2c68-aba2-481e-ba5c-102de0532d28	staff	b9e31fd8-d9b4-43e0-ae3e-fe78fe07c56a	1	09:00:00	20:00:00
dea770cc-34f4-497e-9747-4074ac1c193c	staff	b9e31fd8-d9b4-43e0-ae3e-fe78fe07c56a	2	09:00:00	20:00:00
b98a7d84-8ec6-4e50-922a-e421191600a5	staff	b9e31fd8-d9b4-43e0-ae3e-fe78fe07c56a	3	09:00:00	20:00:00
4d29612e-3269-4569-9a9a-f049386fc991	staff	b9e31fd8-d9b4-43e0-ae3e-fe78fe07c56a	4	09:00:00	20:00:00
09e0ebc9-220a-4ab5-b4e5-56447ba5ca41	staff	b9e31fd8-d9b4-43e0-ae3e-fe78fe07c56a	5	09:00:00	20:00:00
c9c2a176-5f29-4351-b23d-20ef6343bac8	staff	b9e31fd8-d9b4-43e0-ae3e-fe78fe07c56a	6	09:00:00	20:00:00
bf18b3bd-d73c-4f47-ad9e-9f0178d0638c	chair	a0327d43-e82c-43bc-89dd-fdac6a3ce746	0	09:00:00	20:00:00
c57b6644-f904-430a-ac19-c48184c3b76d	chair	a0327d43-e82c-43bc-89dd-fdac6a3ce746	1	09:00:00	20:00:00
80e72d6f-b8e6-4e46-ab30-a2a8d5573863	chair	a0327d43-e82c-43bc-89dd-fdac6a3ce746	2	09:00:00	20:00:00
3e7d25f9-6ba2-407e-9086-a4e70ed6290c	chair	a0327d43-e82c-43bc-89dd-fdac6a3ce746	3	09:00:00	20:00:00
42f6a6a3-43d2-4379-8469-8dfc68bdd719	chair	a0327d43-e82c-43bc-89dd-fdac6a3ce746	4	09:00:00	20:00:00
b8e9e506-926f-4f9d-8149-ce739cef15dc	chair	a0327d43-e82c-43bc-89dd-fdac6a3ce746	5	09:00:00	20:00:00
daf5bfca-fa4c-4e96-9cdc-397b7babbd26	chair	a0327d43-e82c-43bc-89dd-fdac6a3ce746	6	09:00:00	20:00:00
08931587-f773-47a3-aeeb-c8b02038d95d	staff	16d1ba6d-ef25-495d-b7ca-32728de6b6cd	0	09:00:00	20:00:00
18d92f2c-04b8-49e6-9374-87fb39753b7f	staff	16d1ba6d-ef25-495d-b7ca-32728de6b6cd	1	09:00:00	20:00:00
fa7118b2-74c3-405e-924a-e8872f345016	staff	16d1ba6d-ef25-495d-b7ca-32728de6b6cd	2	09:00:00	20:00:00
c6b6cc16-1c60-4f1a-b33b-731e4da3fb19	staff	16d1ba6d-ef25-495d-b7ca-32728de6b6cd	3	09:00:00	20:00:00
a58fa202-cfab-46d8-af44-ea7c15175991	staff	16d1ba6d-ef25-495d-b7ca-32728de6b6cd	4	09:00:00	20:00:00
61a40b98-9020-4460-a711-431657c7b55c	staff	16d1ba6d-ef25-495d-b7ca-32728de6b6cd	5	09:00:00	20:00:00
03f485c8-3cd6-4fd3-bdaf-0e8f9dbe9478	staff	16d1ba6d-ef25-495d-b7ca-32728de6b6cd	6	09:00:00	20:00:00
feda9bf9-a829-499b-959c-0479c85e2607	chair	efa5af82-2904-4b89-adad-8d79624a633d	0	09:00:00	20:00:00
f89ca9cf-5d8e-4689-8028-f90714b17ec6	chair	efa5af82-2904-4b89-adad-8d79624a633d	1	09:00:00	20:00:00
b7598ab2-83aa-4483-ba1e-a3afca72f681	chair	efa5af82-2904-4b89-adad-8d79624a633d	2	09:00:00	20:00:00
b5ccdbd2-34a0-4cf6-b2eb-57468d1f6365	chair	efa5af82-2904-4b89-adad-8d79624a633d	3	09:00:00	20:00:00
a524447a-0e4f-44dc-b0e0-51e6890e4a47	chair	efa5af82-2904-4b89-adad-8d79624a633d	4	09:00:00	20:00:00
b4763070-8b02-4f05-93e8-f6e4c3ef1aee	chair	efa5af82-2904-4b89-adad-8d79624a633d	5	09:00:00	20:00:00
ac7444de-7188-47da-8613-8199f3f71e9d	chair	efa5af82-2904-4b89-adad-8d79624a633d	6	09:00:00	20:00:00
c54eb46f-ae9b-4fad-b535-bcfefec960b5	staff	1f2dbb13-c832-4c51-ac26-33a5033a9f36	0	09:00:00	20:00:00
fe09e97d-92c0-48f4-854b-570b0eb6b3e3	staff	1f2dbb13-c832-4c51-ac26-33a5033a9f36	1	09:00:00	20:00:00
99b8ed7d-7cac-4d8b-a9f1-9ad6ba028ec6	staff	1f2dbb13-c832-4c51-ac26-33a5033a9f36	2	09:00:00	20:00:00
2c4e15a2-d206-46a5-afa5-cd2d611c4495	staff	1f2dbb13-c832-4c51-ac26-33a5033a9f36	3	09:00:00	20:00:00
532867a6-bcc0-48a8-b813-6e3732ae5040	staff	1f2dbb13-c832-4c51-ac26-33a5033a9f36	4	09:00:00	20:00:00
0224b2ed-dd98-4d1f-925e-f705b411a957	staff	1f2dbb13-c832-4c51-ac26-33a5033a9f36	5	09:00:00	20:00:00
450c4827-192a-466e-a2b5-07f9dc1aca9c	staff	1f2dbb13-c832-4c51-ac26-33a5033a9f36	6	09:00:00	20:00:00
083bae78-ec30-4ede-8f15-9e04f65ed5b0	chair	30d3a3e9-fb2f-4da6-8193-f5c8bb2a24c7	0	09:00:00	20:00:00
0e2df72b-39c3-4353-bd49-d801343a2c9d	chair	30d3a3e9-fb2f-4da6-8193-f5c8bb2a24c7	1	09:00:00	20:00:00
71a10d7b-da5b-41de-aa54-828dcdc28c9a	chair	30d3a3e9-fb2f-4da6-8193-f5c8bb2a24c7	2	09:00:00	20:00:00
5d194f08-53e1-4d06-af34-571e08b1f3d9	chair	30d3a3e9-fb2f-4da6-8193-f5c8bb2a24c7	3	09:00:00	20:00:00
5863b729-2077-4915-8862-0481c7c67bae	chair	30d3a3e9-fb2f-4da6-8193-f5c8bb2a24c7	4	09:00:00	20:00:00
b92622cf-bc60-4e9e-ace5-2c83f80864ab	chair	30d3a3e9-fb2f-4da6-8193-f5c8bb2a24c7	5	09:00:00	20:00:00
ea070aff-6587-40c1-8815-ef5827e2b148	chair	30d3a3e9-fb2f-4da6-8193-f5c8bb2a24c7	6	09:00:00	20:00:00
aa8f391c-d502-4e8f-92b9-5c278fb0026a	staff	32a99ba7-b901-43e1-9064-04292dcd8653	0	09:00:00	20:00:00
cf34778e-7a59-4cc4-900c-256e4146cfd1	staff	32a99ba7-b901-43e1-9064-04292dcd8653	1	09:00:00	20:00:00
f7dadfd3-1dc2-44e0-95af-2869111f0fb5	staff	32a99ba7-b901-43e1-9064-04292dcd8653	2	09:00:00	20:00:00
b33308c4-0763-484b-bb2a-13a849555e6c	staff	32a99ba7-b901-43e1-9064-04292dcd8653	3	09:00:00	20:00:00
2bb2a7de-89b6-45d1-bfb8-7dfbc8eee04f	staff	32a99ba7-b901-43e1-9064-04292dcd8653	4	09:00:00	20:00:00
75430429-1aa0-4fd6-9b40-f82c083ee30f	staff	32a99ba7-b901-43e1-9064-04292dcd8653	5	09:00:00	20:00:00
011297c1-69cb-4d49-89b1-aa44b1a3a03c	staff	32a99ba7-b901-43e1-9064-04292dcd8653	6	09:00:00	20:00:00
39071398-559a-4d46-8388-4dca96bf24fb	chair	6b90b157-2e22-43fb-9932-ba1d1bd2a393	0	09:00:00	20:00:00
543450ab-9c5c-4b3f-8e10-c358d9842e71	chair	6b90b157-2e22-43fb-9932-ba1d1bd2a393	1	09:00:00	20:00:00
fc2bf48b-00de-4061-8ee7-098f8449bed6	chair	6b90b157-2e22-43fb-9932-ba1d1bd2a393	2	09:00:00	20:00:00
ef6dc9f8-db98-4e03-904a-50de7c03d04c	chair	6b90b157-2e22-43fb-9932-ba1d1bd2a393	3	09:00:00	20:00:00
0f3f2221-382a-438b-a793-e52d0cabb25b	chair	6b90b157-2e22-43fb-9932-ba1d1bd2a393	4	09:00:00	20:00:00
becb4c65-a153-4b3a-b3b3-97a163c86e07	chair	6b90b157-2e22-43fb-9932-ba1d1bd2a393	5	09:00:00	20:00:00
7aff2ea7-ec5b-400d-9719-3cb819df0b32	chair	6b90b157-2e22-43fb-9932-ba1d1bd2a393	6	09:00:00	20:00:00
6cfcf82e-414a-4a16-b5f3-52141814c8be	staff	4da92dd7-f9c2-487f-a1ae-7170bec48876	0	09:00:00	20:00:00
7635b378-49e8-45a2-8039-bfb9bf5d2cdc	staff	4da92dd7-f9c2-487f-a1ae-7170bec48876	1	09:00:00	20:00:00
871b1f9c-0689-4378-966b-c83951657ddd	staff	4da92dd7-f9c2-487f-a1ae-7170bec48876	2	09:00:00	20:00:00
e9b024e9-f13c-44d0-9bf2-a5c3029c138e	staff	4da92dd7-f9c2-487f-a1ae-7170bec48876	3	09:00:00	20:00:00
bf9797d0-a6e4-411a-aac6-430ce2ed0873	staff	4da92dd7-f9c2-487f-a1ae-7170bec48876	4	09:00:00	20:00:00
09a944cb-15cd-4072-b9d6-eccfcaa27f16	staff	4da92dd7-f9c2-487f-a1ae-7170bec48876	5	09:00:00	20:00:00
cfe461f4-9d97-49e5-b52b-3e73a48057b5	staff	4da92dd7-f9c2-487f-a1ae-7170bec48876	6	09:00:00	20:00:00
a6ea857d-ed4a-47bc-8bde-e4e2006a858f	chair	c753e632-33e9-4bb0-8cbc-cf39243fef1c	0	09:00:00	20:00:00
fb000e51-4fff-46a6-80f3-70792e53c006	chair	c753e632-33e9-4bb0-8cbc-cf39243fef1c	1	09:00:00	20:00:00
a3a12f10-2753-42f6-9c51-ad89d765ebdb	chair	c753e632-33e9-4bb0-8cbc-cf39243fef1c	2	09:00:00	20:00:00
a7339c47-669d-43ae-aa1a-3562ae897524	chair	c753e632-33e9-4bb0-8cbc-cf39243fef1c	3	09:00:00	20:00:00
cd9f22f0-03cd-443e-b090-89924fb61f85	chair	c753e632-33e9-4bb0-8cbc-cf39243fef1c	4	09:00:00	20:00:00
bc193cec-76b8-496e-9bfa-8c36142c4efb	chair	c753e632-33e9-4bb0-8cbc-cf39243fef1c	5	09:00:00	20:00:00
a1fb923a-557e-4a0f-865a-aee2e261784f	chair	c753e632-33e9-4bb0-8cbc-cf39243fef1c	6	09:00:00	20:00:00
74bdad56-4172-4797-9eb9-bbbe7f1585ba	staff	2443d906-bfd5-4337-9ec1-33f957ceac62	0	09:00:00	20:00:00
31df25b8-61fc-40d1-a823-3b7845722ebe	staff	2443d906-bfd5-4337-9ec1-33f957ceac62	1	09:00:00	20:00:00
a7cf0666-ab90-412a-98a0-ce2647e19116	staff	2443d906-bfd5-4337-9ec1-33f957ceac62	2	09:00:00	20:00:00
14674554-14d3-4324-99c4-8f7c3323818c	staff	2443d906-bfd5-4337-9ec1-33f957ceac62	3	09:00:00	20:00:00
811093e6-28cc-49fd-9657-85cad5aeb24e	staff	2443d906-bfd5-4337-9ec1-33f957ceac62	4	09:00:00	20:00:00
1cb7fe6e-4183-4dd7-88fa-4e584ecb8ddd	staff	2443d906-bfd5-4337-9ec1-33f957ceac62	5	09:00:00	20:00:00
e560ddbf-5004-42c6-96d7-3205746c0a04	staff	2443d906-bfd5-4337-9ec1-33f957ceac62	6	09:00:00	20:00:00
1064dbc0-bc51-471a-8575-6d91893e5cc5	staff	9721f83e-e980-47ee-a67a-466e2657db37	0	09:00:00	20:00:00
8eab0f5a-39c7-4838-ab0f-1b3c65ecb827	staff	9721f83e-e980-47ee-a67a-466e2657db37	1	09:00:00	20:00:00
34954e6a-5661-4400-8b97-ba33c93c12be	staff	9721f83e-e980-47ee-a67a-466e2657db37	2	09:00:00	20:00:00
7897c615-1fe5-4eff-9b97-1ba4d04ec804	staff	9721f83e-e980-47ee-a67a-466e2657db37	3	09:00:00	20:00:00
58dcf823-b773-4cda-af97-7dcb731977e2	staff	9721f83e-e980-47ee-a67a-466e2657db37	4	09:00:00	20:00:00
7cad1f72-8ce6-4c93-bf43-f67e25b95da8	staff	9721f83e-e980-47ee-a67a-466e2657db37	5	09:00:00	20:00:00
54e7f818-7b93-43d0-9bb1-b7fdc0c50da2	staff	9721f83e-e980-47ee-a67a-466e2657db37	6	09:00:00	20:00:00
23a68b68-de12-44b2-83c8-2d717cf23f28	chair	1f500a10-70ef-4698-b114-25fbe0d51fbe	0	09:00:00	20:00:00
32b9253b-3c6f-47a4-a709-2ce2897ab6a4	chair	1f500a10-70ef-4698-b114-25fbe0d51fbe	1	09:00:00	20:00:00
473511d8-e207-4b82-bc57-2580bc0f8fec	chair	1f500a10-70ef-4698-b114-25fbe0d51fbe	2	09:00:00	20:00:00
16220ab7-2fee-4953-864d-8d21a2081211	chair	1f500a10-70ef-4698-b114-25fbe0d51fbe	3	09:00:00	20:00:00
4951479e-6ad7-4d51-8062-2aea5834e9cf	chair	1f500a10-70ef-4698-b114-25fbe0d51fbe	4	09:00:00	20:00:00
ee6dd9a0-1117-486f-9f3e-551526d6fbd8	chair	1f500a10-70ef-4698-b114-25fbe0d51fbe	5	09:00:00	20:00:00
17a8f823-0f65-4ee2-bbb5-d80a28aac4db	chair	1f500a10-70ef-4698-b114-25fbe0d51fbe	6	09:00:00	20:00:00
37eaa3d8-d69d-40f7-8764-455cf572a0f7	chair	43eb04dd-d502-4760-88b2-714ee3f97b7e	0	09:00:00	20:00:00
b7cb6290-e7ac-420b-be08-a834e9a1cd3c	chair	43eb04dd-d502-4760-88b2-714ee3f97b7e	1	09:00:00	20:00:00
7f61128c-c397-445e-850b-199c3ce521a6	chair	43eb04dd-d502-4760-88b2-714ee3f97b7e	2	09:00:00	20:00:00
3aa83ddf-accb-4c51-986c-9ead5714e863	chair	43eb04dd-d502-4760-88b2-714ee3f97b7e	3	09:00:00	20:00:00
3e1f7841-5f7e-42dc-8125-8ae807039317	chair	43eb04dd-d502-4760-88b2-714ee3f97b7e	4	09:00:00	20:00:00
ad6e2a8e-99a5-4519-9361-d1928fbc3213	chair	43eb04dd-d502-4760-88b2-714ee3f97b7e	5	09:00:00	20:00:00
c3c53354-2c5e-49e9-9c14-54a785b673a8	chair	43eb04dd-d502-4760-88b2-714ee3f97b7e	6	09:00:00	20:00:00
99ee7e91-9b76-4149-8499-5e66913ab240	chair	5765d8c6-3ef8-4cbc-aa4a-2e4e12f7524c	0	09:00:00	20:00:00
84a09639-5cc4-46b7-8d05-edff5a3f8370	chair	5765d8c6-3ef8-4cbc-aa4a-2e4e12f7524c	1	09:00:00	20:00:00
31e96340-633a-4e91-b81a-558203a3660f	chair	5765d8c6-3ef8-4cbc-aa4a-2e4e12f7524c	2	09:00:00	20:00:00
46a6e897-8513-4c49-9202-f8485cdabf90	chair	5765d8c6-3ef8-4cbc-aa4a-2e4e12f7524c	3	09:00:00	20:00:00
ac021c2f-ef53-46e1-bf94-f4e9270ba8b8	chair	5765d8c6-3ef8-4cbc-aa4a-2e4e12f7524c	4	09:00:00	20:00:00
eb823ea5-516a-443a-a891-3af443e5e31b	chair	5765d8c6-3ef8-4cbc-aa4a-2e4e12f7524c	5	09:00:00	20:00:00
d8c6f88a-cdd7-4c5c-afd6-f443bbd6e661	chair	5765d8c6-3ef8-4cbc-aa4a-2e4e12f7524c	6	09:00:00	20:00:00
8e6a681c-4654-4579-a783-3cfca36e514f	staff	11210303-546e-44a6-8a49-dd27833042ec	0	09:00:00	20:00:00
4a0b5101-b046-4144-9ef8-d9f53b80d64e	staff	11210303-546e-44a6-8a49-dd27833042ec	1	09:00:00	20:00:00
581cfe91-a9a4-40ec-8a11-31c6def7a2fc	staff	11210303-546e-44a6-8a49-dd27833042ec	2	09:00:00	20:00:00
523e6d6a-06ab-421d-a8d0-122a0a992fe0	staff	11210303-546e-44a6-8a49-dd27833042ec	3	09:00:00	20:00:00
32c76a7f-2e1e-4c20-b444-952d0c399368	staff	11210303-546e-44a6-8a49-dd27833042ec	4	09:00:00	20:00:00
cbe0d112-29d6-418c-8f89-b921e4389493	staff	11210303-546e-44a6-8a49-dd27833042ec	5	09:00:00	20:00:00
afbc9e4b-4ad4-4c59-8f37-b5b9fa598149	staff	11210303-546e-44a6-8a49-dd27833042ec	6	09:00:00	20:00:00
5e5b34b5-96f9-483e-a819-43da9c63610a	chair	3cba42b4-6adb-4989-9277-b42d0d05af41	0	09:00:00	20:00:00
7f080460-a889-4503-8a06-bf97b0d5910f	chair	3cba42b4-6adb-4989-9277-b42d0d05af41	1	09:00:00	20:00:00
a460a6e3-f548-41ea-9bb0-fb24fbb15541	chair	3cba42b4-6adb-4989-9277-b42d0d05af41	2	09:00:00	20:00:00
6d9112cf-6254-4c8e-b9b6-52b348a27240	chair	3cba42b4-6adb-4989-9277-b42d0d05af41	3	09:00:00	20:00:00
7a24d72a-b33b-45c5-9297-9d6a281f6ba5	chair	3cba42b4-6adb-4989-9277-b42d0d05af41	4	09:00:00	20:00:00
b8edb44d-c940-481d-a84c-787f24e96a1e	chair	3cba42b4-6adb-4989-9277-b42d0d05af41	5	09:00:00	20:00:00
c259fb1a-34cb-4365-be70-5ae7bd87ed34	chair	3cba42b4-6adb-4989-9277-b42d0d05af41	6	09:00:00	20:00:00
aabea794-3e7e-41f2-9ee0-2622e433b5d0	staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	0	09:00:00	20:00:00
2f91ece6-cfab-4d2a-b6e0-e03722443ef1	staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	1	09:00:00	20:00:00
512dd757-87b3-46b5-b041-cef7adbb2a1f	staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	2	09:00:00	20:00:00
e529210f-2864-486a-978f-3c0c33bb92cb	staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	3	09:00:00	20:00:00
83aa80be-ba70-4f4d-b86e-6672f5615dd6	staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	4	09:00:00	20:00:00
f4759a00-f7fd-4f47-bdf8-3a9dd3bb6acd	staff	e2200c8d-5e09-4149-bea1-d3a6a7f0e421	0	09:00:00	20:00:00
4d1fd821-1d65-4671-b400-21597eab24fb	staff	e2200c8d-5e09-4149-bea1-d3a6a7f0e421	1	09:00:00	20:00:00
5335dd99-3499-4525-b47a-7895fd149573	staff	e2200c8d-5e09-4149-bea1-d3a6a7f0e421	2	09:00:00	20:00:00
2acc3ecd-d324-482b-916a-e687dc25452a	staff	e2200c8d-5e09-4149-bea1-d3a6a7f0e421	3	09:00:00	20:00:00
ce2e20fd-a6db-4832-92ea-1ecaf9ce1c22	staff	e2200c8d-5e09-4149-bea1-d3a6a7f0e421	4	09:00:00	20:00:00
7dfafa62-5616-420e-adbc-019bc0ea8787	staff	e2200c8d-5e09-4149-bea1-d3a6a7f0e421	5	09:00:00	20:00:00
ae09b11c-b556-4159-8208-4a660f0ce506	staff	e2200c8d-5e09-4149-bea1-d3a6a7f0e421	6	09:00:00	20:00:00
e0d968af-252b-48c4-9699-e14ede878294	chair	65175517-9f0c-4da3-86d1-90871674bb91	0	09:00:00	20:00:00
be7605a9-15b7-4892-92b0-d98863c6f33a	chair	65175517-9f0c-4da3-86d1-90871674bb91	1	09:00:00	20:00:00
3112e5f7-3b0c-45f3-9c62-8ca87ab15650	chair	65175517-9f0c-4da3-86d1-90871674bb91	2	09:00:00	20:00:00
8e4689c2-c08d-480f-a7db-dfdccb65f84e	chair	65175517-9f0c-4da3-86d1-90871674bb91	3	09:00:00	20:00:00
03a6eca7-34d6-4923-93a6-ace46766a1de	chair	65175517-9f0c-4da3-86d1-90871674bb91	4	09:00:00	20:00:00
8eb1a82b-c8c9-48ca-ac1e-d19fc2edcdb2	chair	65175517-9f0c-4da3-86d1-90871674bb91	5	09:00:00	20:00:00
943ae6dc-8884-41fb-ad4d-75b7c41792fb	chair	65175517-9f0c-4da3-86d1-90871674bb91	6	09:00:00	20:00:00
40b2a1ce-9457-40cd-9d02-0eb2cf8a313d	staff	16da35bd-5216-41c2-a656-5550e901e96f	0	09:00:00	20:00:00
e7fc4ac2-04ea-4e85-8446-b104b925d20d	staff	16da35bd-5216-41c2-a656-5550e901e96f	1	09:00:00	20:00:00
0f5f4bd1-1381-4412-bc29-493cd9bed17c	staff	16da35bd-5216-41c2-a656-5550e901e96f	2	09:00:00	20:00:00
263e822f-d042-4b7c-9130-49c600f8bdbb	staff	16da35bd-5216-41c2-a656-5550e901e96f	3	09:00:00	20:00:00
9aed9db5-fa6d-4bca-b4c6-283d74475dbf	staff	16da35bd-5216-41c2-a656-5550e901e96f	4	09:00:00	20:00:00
3d2b8b39-2bf8-474b-9c9c-44ef8dd0f08e	staff	16da35bd-5216-41c2-a656-5550e901e96f	5	09:00:00	20:00:00
2e78a20d-b3b4-4bce-aaf5-22723f0e7d63	staff	16da35bd-5216-41c2-a656-5550e901e96f	6	09:00:00	20:00:00
dbc22a0b-09fd-4675-9bf5-5f53fe266552	chair	5f7bfae1-9466-418e-8949-13b6f9ee506b	0	09:00:00	20:00:00
333e0b5a-eeb9-4f35-b72e-b6f45f8d07e9	chair	5f7bfae1-9466-418e-8949-13b6f9ee506b	1	09:00:00	20:00:00
e0601ace-820a-41c9-abd5-349767835b32	chair	5f7bfae1-9466-418e-8949-13b6f9ee506b	2	09:00:00	20:00:00
e97781bb-5784-4e43-8d18-513db5ca7191	chair	5f7bfae1-9466-418e-8949-13b6f9ee506b	3	09:00:00	20:00:00
13827b2c-4bc3-467a-8e9e-2739189c35fc	chair	5f7bfae1-9466-418e-8949-13b6f9ee506b	4	09:00:00	20:00:00
808c86ac-e79a-47f3-b5b0-5c20bb332465	chair	5f7bfae1-9466-418e-8949-13b6f9ee506b	5	09:00:00	20:00:00
8310e83b-142e-4f38-870b-1e5cffa955e9	chair	5f7bfae1-9466-418e-8949-13b6f9ee506b	6	09:00:00	20:00:00
7080df5b-7f2b-4f20-89cd-7682d5a6d7bb	staff	d30ef226-19d4-4e79-a50c-a15e99f31d14	0	09:00:00	20:00:00
eb06aca0-a186-4d48-800a-2600f49a27d5	staff	d30ef226-19d4-4e79-a50c-a15e99f31d14	1	09:00:00	20:00:00
2bb84f72-072e-4572-935a-d3eac06fbb97	staff	d30ef226-19d4-4e79-a50c-a15e99f31d14	2	09:00:00	20:00:00
22115b97-6a3b-4116-87c0-34c9304e98ed	staff	d30ef226-19d4-4e79-a50c-a15e99f31d14	3	09:00:00	20:00:00
608cb41a-bb57-4c24-81f3-da0853009bd2	staff	d30ef226-19d4-4e79-a50c-a15e99f31d14	4	09:00:00	20:00:00
9d5c62ec-48cf-46a9-abe1-f3afc89fe49d	staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	5	09:00:00	20:00:00
9e6bd9b5-4ad9-4818-ad80-943914cbd226	staff	7a95cf70-0805-4d3e-a1e9-b5db7b2f531c	6	09:00:00	20:00:00
21c68d9b-596b-4fd7-aa43-b48c93526465	chair	26d35845-2fc6-4cf9-8608-12ecb460fcf2	0	09:00:00	20:00:00
a59a5dbc-8dbe-40b9-a46c-217def83ab19	chair	26d35845-2fc6-4cf9-8608-12ecb460fcf2	1	09:00:00	20:00:00
fc2b5739-c956-49e6-bb1d-64ac4dc92f3e	chair	26d35845-2fc6-4cf9-8608-12ecb460fcf2	2	09:00:00	20:00:00
f064becb-84eb-4947-b5f9-b85bc9dc5a64	chair	26d35845-2fc6-4cf9-8608-12ecb460fcf2	3	09:00:00	20:00:00
ec5c2f9e-99d0-4831-a084-635e1f00e5c0	chair	26d35845-2fc6-4cf9-8608-12ecb460fcf2	4	09:00:00	20:00:00
72a2e9e4-f19a-497b-a00a-53c94786abf4	chair	26d35845-2fc6-4cf9-8608-12ecb460fcf2	5	09:00:00	20:00:00
38a7d02b-7880-4020-8e6f-2598523d0edc	chair	26d35845-2fc6-4cf9-8608-12ecb460fcf2	6	09:00:00	20:00:00
fe2ea607-6c3e-4e29-9b52-d65033efb81b	staff	e366d7da-0479-44df-bd5a-5a2d666f9313	0	09:00:00	20:00:00
651b4380-aef1-4f79-80c0-891aa5d657fa	staff	e366d7da-0479-44df-bd5a-5a2d666f9313	1	09:00:00	20:00:00
6a378028-a7e4-40e1-bc75-9250c7f1f87c	staff	e366d7da-0479-44df-bd5a-5a2d666f9313	2	09:00:00	20:00:00
8437b00e-6ddf-4319-988e-384b79487a60	staff	e366d7da-0479-44df-bd5a-5a2d666f9313	3	09:00:00	20:00:00
6a3f31ce-375f-4a65-b4a8-c4811138326e	staff	e366d7da-0479-44df-bd5a-5a2d666f9313	4	09:00:00	20:00:00
b1be84bd-9a4d-413f-86c8-6cfbe6e28e1f	staff	e366d7da-0479-44df-bd5a-5a2d666f9313	5	09:00:00	20:00:00
a42fdfa9-7ba4-4eca-9757-a502ed0c6258	staff	e366d7da-0479-44df-bd5a-5a2d666f9313	6	09:00:00	20:00:00
b35c552f-5a16-422f-800c-6879b1a12c54	chair	fdf1e9f8-8301-4c2f-b594-51bcf4a43473	0	09:00:00	20:00:00
59795708-b59a-4c5d-8fe9-5c395fe88c16	chair	fdf1e9f8-8301-4c2f-b594-51bcf4a43473	1	09:00:00	20:00:00
2d2c8102-e6f9-4001-b41d-deee3c758e08	chair	fdf1e9f8-8301-4c2f-b594-51bcf4a43473	2	09:00:00	20:00:00
1d4b47c0-7776-4e50-82f4-2ef938750ebb	chair	fdf1e9f8-8301-4c2f-b594-51bcf4a43473	3	09:00:00	20:00:00
dfcde93d-4189-4346-bede-32387d5e8640	chair	fdf1e9f8-8301-4c2f-b594-51bcf4a43473	4	09:00:00	20:00:00
ca4bd942-ee38-40b5-81d7-5472d9296a2c	chair	fdf1e9f8-8301-4c2f-b594-51bcf4a43473	5	09:00:00	20:00:00
0fd5fc30-8a46-46aa-ae1d-47fbbad39155	chair	fdf1e9f8-8301-4c2f-b594-51bcf4a43473	6	09:00:00	20:00:00
75ace59a-e133-4b4b-86d4-8ccd947d48da	staff	9533b3d5-242d-418b-8b8f-29f546d663b3	0	09:00:00	20:00:00
1bf5d781-f4c6-46b0-9cc5-ecc8d41d1c83	staff	9533b3d5-242d-418b-8b8f-29f546d663b3	1	09:00:00	20:00:00
f8129edb-cbb0-4c5b-9ec1-6882e3dedddb	staff	9533b3d5-242d-418b-8b8f-29f546d663b3	2	09:00:00	20:00:00
32aac9df-a44d-49a0-b625-5161cb8d3be3	staff	9533b3d5-242d-418b-8b8f-29f546d663b3	3	09:00:00	20:00:00
1bbba127-c026-42a0-a93e-96a45ff4715b	staff	9533b3d5-242d-418b-8b8f-29f546d663b3	4	09:00:00	20:00:00
d25d92a0-2ba3-41fb-a4a8-6822b4bc83e8	staff	9533b3d5-242d-418b-8b8f-29f546d663b3	5	09:00:00	20:00:00
7a6f72cf-4cd2-464c-9e12-6a498f49f450	staff	9533b3d5-242d-418b-8b8f-29f546d663b3	6	09:00:00	20:00:00
e3f21c6b-2261-42e0-8a98-780be07f7f0a	chair	23648f5a-e24e-4c41-a1a6-a3784ac7ecf1	0	09:00:00	20:00:00
450388dc-088b-45d0-b0ea-81dda257e84f	chair	23648f5a-e24e-4c41-a1a6-a3784ac7ecf1	1	09:00:00	20:00:00
e9ee2a18-be66-4c2a-83c1-4db2fc8190d7	chair	23648f5a-e24e-4c41-a1a6-a3784ac7ecf1	2	09:00:00	20:00:00
a36047fe-5008-4fab-9456-64bfc034162f	chair	23648f5a-e24e-4c41-a1a6-a3784ac7ecf1	3	09:00:00	20:00:00
65ccb2c8-c458-4549-9259-d9231f1c4cc6	chair	23648f5a-e24e-4c41-a1a6-a3784ac7ecf1	4	09:00:00	20:00:00
ed3779e1-e03d-49fd-91cd-e21d3fa90f8a	chair	23648f5a-e24e-4c41-a1a6-a3784ac7ecf1	5	09:00:00	20:00:00
ae93fa7f-d3df-41b4-b80c-647e20ff212a	chair	23648f5a-e24e-4c41-a1a6-a3784ac7ecf1	6	09:00:00	20:00:00
221d2c9c-0032-4968-983f-261de2723499	staff	ec6b2c18-2cc2-41c9-9165-956cad61d761	0	09:00:00	20:00:00
12a1e445-04c3-4ad1-9130-2d2c9f5fddc3	staff	ec6b2c18-2cc2-41c9-9165-956cad61d761	1	09:00:00	20:00:00
046a367c-1fa6-4f7a-bc23-f4377458abcd	staff	ec6b2c18-2cc2-41c9-9165-956cad61d761	2	09:00:00	20:00:00
53be12e1-aebd-4e69-8c16-d97ef43e1be5	staff	ec6b2c18-2cc2-41c9-9165-956cad61d761	3	09:00:00	20:00:00
4005a5b3-d1e0-4d94-b281-4ee32e0496ca	staff	ec6b2c18-2cc2-41c9-9165-956cad61d761	4	09:00:00	20:00:00
7479dee7-d1ef-4f98-b583-b13dbe08b647	staff	ec6b2c18-2cc2-41c9-9165-956cad61d761	5	09:00:00	20:00:00
28f91737-f1d4-4cea-a626-8bfc4f4993af	staff	ec6b2c18-2cc2-41c9-9165-956cad61d761	6	09:00:00	20:00:00
b4d3284d-6724-42cd-8874-73a678b69d77	chair	190c4b40-8114-4ab3-862e-3fdfb9182954	0	09:00:00	20:00:00
3d108db8-871f-4d01-bac6-93203e8bbb2a	chair	190c4b40-8114-4ab3-862e-3fdfb9182954	1	09:00:00	20:00:00
475deba6-a06a-48a0-bf7e-d6730dbedd1e	chair	190c4b40-8114-4ab3-862e-3fdfb9182954	2	09:00:00	20:00:00
148634ba-19c0-4053-bcc0-1340db9f8fa0	chair	190c4b40-8114-4ab3-862e-3fdfb9182954	3	09:00:00	20:00:00
f5fc0a7b-8344-4d4f-8380-66566064e332	chair	190c4b40-8114-4ab3-862e-3fdfb9182954	4	09:00:00	20:00:00
58946e16-9f10-4027-9581-dce370ddfdcc	chair	190c4b40-8114-4ab3-862e-3fdfb9182954	5	09:00:00	20:00:00
398c0164-9946-41fb-8965-39233e121a2c	chair	190c4b40-8114-4ab3-862e-3fdfb9182954	6	09:00:00	20:00:00
19bba01e-e0a9-4b10-ac8b-91c1b8828975	staff	199d69f0-cb29-4014-bb76-9984a0190631	0	09:00:00	20:00:00
d376a79d-8051-4dcc-89eb-2bc674ef4bea	staff	199d69f0-cb29-4014-bb76-9984a0190631	1	09:00:00	20:00:00
9bea8bbc-ae99-4a38-8d36-4ade01bf3538	staff	199d69f0-cb29-4014-bb76-9984a0190631	2	09:00:00	20:00:00
a28bf125-192d-4dc3-9b6d-df2d9194a510	staff	199d69f0-cb29-4014-bb76-9984a0190631	3	09:00:00	20:00:00
c8ffc6c0-f9f1-4306-b67f-3cabdd623d4a	staff	199d69f0-cb29-4014-bb76-9984a0190631	4	09:00:00	20:00:00
9b9d6800-7ac9-4e1e-a81c-28543b7d97b7	staff	199d69f0-cb29-4014-bb76-9984a0190631	5	09:00:00	20:00:00
787668c1-9cd6-4909-aa42-447d31e7b0b3	staff	199d69f0-cb29-4014-bb76-9984a0190631	6	09:00:00	20:00:00
122befab-3228-4843-a60c-717c464d58bd	chair	d9f4dd34-8494-4f85-bc4c-a4d73b248f6d	0	09:00:00	20:00:00
02ff421a-26bf-4af7-a971-efe173b7de77	chair	d9f4dd34-8494-4f85-bc4c-a4d73b248f6d	1	09:00:00	20:00:00
edb371a2-e9ec-457e-b6fd-9a25678ea1fa	chair	d9f4dd34-8494-4f85-bc4c-a4d73b248f6d	2	09:00:00	20:00:00
6595e34c-d3f4-4609-a917-634a2612e29e	chair	d9f4dd34-8494-4f85-bc4c-a4d73b248f6d	3	09:00:00	20:00:00
ed909cfe-0414-475c-9fad-c5a5de29757d	chair	d9f4dd34-8494-4f85-bc4c-a4d73b248f6d	4	09:00:00	20:00:00
1ef74adf-4fe8-4404-b270-187d3e8127cd	chair	d9f4dd34-8494-4f85-bc4c-a4d73b248f6d	5	09:00:00	20:00:00
67ac744f-cefc-4cb0-9fb9-280cd5b945e5	chair	d9f4dd34-8494-4f85-bc4c-a4d73b248f6d	6	09:00:00	20:00:00
afe66475-a9b9-464c-bdb1-72b42a00430b	staff	d1bc980a-d262-4c4a-a479-4e213b65da23	0	09:00:00	20:00:00
de9e9837-7679-4032-bc4a-ce9ade9883c5	staff	d1bc980a-d262-4c4a-a479-4e213b65da23	1	09:00:00	20:00:00
f58fe263-9220-43ea-828b-5f0fd29c429a	staff	d1bc980a-d262-4c4a-a479-4e213b65da23	2	09:00:00	20:00:00
f6fe99f2-3bd3-4de6-bcdc-7e79092fab2b	staff	d1bc980a-d262-4c4a-a479-4e213b65da23	3	09:00:00	20:00:00
f849b71a-b721-499d-82a9-49a13eae290f	staff	d1bc980a-d262-4c4a-a479-4e213b65da23	4	09:00:00	20:00:00
7d2a82a5-9c5a-453c-88a7-0c9be2b31d10	staff	d1bc980a-d262-4c4a-a479-4e213b65da23	5	09:00:00	20:00:00
2dcab265-269f-466e-8325-dea04204a922	staff	d1bc980a-d262-4c4a-a479-4e213b65da23	6	09:00:00	20:00:00
7937a0e1-b8d6-42ab-8e47-1f1f342807bd	chair	3f5bc8be-f2dd-4bfa-92d5-921c3b952e1d	0	09:00:00	20:00:00
c790ec20-ede0-439a-95a9-e11065e5a93c	chair	3f5bc8be-f2dd-4bfa-92d5-921c3b952e1d	1	09:00:00	20:00:00
6172fb48-8b64-41a7-9e22-81224992a631	chair	3f5bc8be-f2dd-4bfa-92d5-921c3b952e1d	2	09:00:00	20:00:00
61b53894-aadf-4787-b063-8ada6abcb392	chair	3f5bc8be-f2dd-4bfa-92d5-921c3b952e1d	3	09:00:00	20:00:00
48545ec9-9822-4111-aca9-8bddf9d0678a	chair	3f5bc8be-f2dd-4bfa-92d5-921c3b952e1d	4	09:00:00	20:00:00
ced77f1f-c0d7-49a5-934e-55a10d65e1be	chair	3f5bc8be-f2dd-4bfa-92d5-921c3b952e1d	5	09:00:00	20:00:00
70c7d3b6-40b9-4f99-a19b-c543305c64df	chair	3f5bc8be-f2dd-4bfa-92d5-921c3b952e1d	6	09:00:00	20:00:00
a8bdd3f6-a518-4847-9608-5e013d8794b3	staff	4737eee4-96e0-484a-bc2c-21fa476cecec	0	09:00:00	20:00:00
093aa47d-6559-4cc6-9d60-b2ce5bb4972b	staff	4737eee4-96e0-484a-bc2c-21fa476cecec	1	09:00:00	20:00:00
cb8620ca-01d5-4c09-bdbd-62bd6989cd37	staff	4737eee4-96e0-484a-bc2c-21fa476cecec	2	09:00:00	20:00:00
1bb903d5-1e25-4f11-be2a-0fd95b36ec06	staff	4737eee4-96e0-484a-bc2c-21fa476cecec	3	09:00:00	20:00:00
6e0eca6d-2266-4a84-b056-42ab46dc5bd5	staff	4737eee4-96e0-484a-bc2c-21fa476cecec	4	09:00:00	20:00:00
ac52ceec-1a44-40b7-992e-4c18cb901f76	staff	4737eee4-96e0-484a-bc2c-21fa476cecec	5	09:00:00	20:00:00
58b638fd-6ff1-4a7e-9765-cf5acdb40c70	staff	4737eee4-96e0-484a-bc2c-21fa476cecec	6	09:00:00	20:00:00
9f13f2cc-17b2-4b6b-b55a-293357cf05b2	chair	5b570db9-071b-4a2b-a3cb-cb6b7878763f	0	09:00:00	20:00:00
1e09eec7-108c-4f21-b974-601c82e4a91c	chair	5b570db9-071b-4a2b-a3cb-cb6b7878763f	1	09:00:00	20:00:00
4ba9c605-c4a5-4a49-9c83-f8db0605acd8	staff	d30ef226-19d4-4e79-a50c-a15e99f31d14	5	09:00:00	20:00:00
c1d30fd2-007e-4f30-a93c-8cda05d3239e	staff	d30ef226-19d4-4e79-a50c-a15e99f31d14	6	09:00:00	20:00:00
ae17b732-33eb-47c2-8235-f19de565fb46	chair	8cc8a2e2-e614-479b-82e1-922bcda2e9bd	0	09:00:00	20:00:00
53fbd5d0-dfab-46f9-9529-b5ff74afea2b	chair	8cc8a2e2-e614-479b-82e1-922bcda2e9bd	1	09:00:00	20:00:00
86ee16fa-c38d-4098-9d6e-34db533d187e	chair	8cc8a2e2-e614-479b-82e1-922bcda2e9bd	2	09:00:00	20:00:00
a034572e-aa11-41fe-b6f0-5860ee743571	chair	8cc8a2e2-e614-479b-82e1-922bcda2e9bd	3	09:00:00	20:00:00
c0f24eea-e6fd-43b7-8808-35222688bb97	chair	8cc8a2e2-e614-479b-82e1-922bcda2e9bd	4	09:00:00	20:00:00
b0b5a88b-1ed2-4dd1-aae9-370f90c5c1d4	chair	8cc8a2e2-e614-479b-82e1-922bcda2e9bd	5	09:00:00	20:00:00
42679a58-ec9c-466a-b922-9740f7739943	chair	8cc8a2e2-e614-479b-82e1-922bcda2e9bd	6	09:00:00	20:00:00
aaaaaaaa-0000-0000-0000-000000000000	staff	22222222-2222-2222-2222-222222222222	0	09:00:00	20:00:00
aaaaaaaa-0000-0000-0000-000000000001	staff	22222222-2222-2222-2222-222222222222	1	09:00:00	20:00:00
aaaaaaaa-0000-0000-0000-000000000002	staff	22222222-2222-2222-2222-222222222222	2	09:00:00	20:00:00
aaaaaaaa-0000-0000-0000-000000000003	staff	22222222-2222-2222-2222-222222222222	3	09:00:00	20:00:00
aaaaaaaa-0000-0000-0000-000000000004	staff	22222222-2222-2222-2222-222222222222	4	09:00:00	20:00:00
aaaaaaaa-0000-0000-0000-000000000005	staff	22222222-2222-2222-2222-222222222222	5	09:00:00	20:00:00
aaaaaaaa-0000-0000-0000-000000000006	staff	22222222-2222-2222-2222-222222222222	6	09:00:00	20:00:00
bbbbbbbb-0000-0000-0000-000000000000	chair	33333333-3333-3333-3333-333333333333	0	09:00:00	20:00:00
bbbbbbbb-0000-0000-0000-000000000001	chair	33333333-3333-3333-3333-333333333333	1	09:00:00	20:00:00
bbbbbbbb-0000-0000-0000-000000000002	chair	33333333-3333-3333-3333-333333333333	2	09:00:00	20:00:00
bbbbbbbb-0000-0000-0000-000000000003	chair	33333333-3333-3333-3333-333333333333	3	09:00:00	20:00:00
bbbbbbbb-0000-0000-0000-000000000004	chair	33333333-3333-3333-3333-333333333333	4	09:00:00	20:00:00
bbbbbbbb-0000-0000-0000-000000000005	chair	33333333-3333-3333-3333-333333333333	5	09:00:00	20:00:00
bbbbbbbb-0000-0000-0000-000000000006	chair	33333333-3333-3333-3333-333333333333	6	09:00:00	20:00:00
eeeeeeee-0000-0000-0000-000000000000	staff	dddddddd-3333-3333-3333-333333333333	0	09:00:00	20:00:00
eeeeeeee-0000-0000-0000-000000000001	staff	dddddddd-3333-3333-3333-333333333333	1	09:00:00	20:00:00
eeeeeeee-0000-0000-0000-000000000002	staff	dddddddd-3333-3333-3333-333333333333	2	09:00:00	20:00:00
eeeeeeee-0000-0000-0000-000000000003	staff	dddddddd-3333-3333-3333-333333333333	3	09:00:00	20:00:00
eeeeeeee-0000-0000-0000-000000000004	staff	dddddddd-3333-3333-3333-333333333333	4	09:00:00	20:00:00
eeeeeeee-0000-0000-0000-000000000005	staff	dddddddd-3333-3333-3333-333333333333	5	09:00:00	20:00:00
eeeeeeee-0000-0000-0000-000000000006	staff	dddddddd-3333-3333-3333-333333333333	6	09:00:00	20:00:00
bbbbbbbb-1000-0000-0000-000000000000	chair	33333333-3333-3333-3333-333333333334	0	09:00:00	20:00:00
bbbbbbbb-1000-0000-0000-000000000001	chair	33333333-3333-3333-3333-333333333334	1	09:00:00	20:00:00
bbbbbbbb-1000-0000-0000-000000000002	chair	33333333-3333-3333-3333-333333333334	2	09:00:00	20:00:00
bbbbbbbb-1000-0000-0000-000000000003	chair	33333333-3333-3333-3333-333333333334	3	09:00:00	20:00:00
bbbbbbbb-1000-0000-0000-000000000004	chair	33333333-3333-3333-3333-333333333334	4	09:00:00	20:00:00
bbbbbbbb-1000-0000-0000-000000000005	chair	33333333-3333-3333-3333-333333333334	5	09:00:00	20:00:00
bbbbbbbb-1000-0000-0000-000000000006	chair	33333333-3333-3333-3333-333333333334	6	09:00:00	20:00:00
ae010100-0000-4000-8000-000000000000	staff	ab010000-0000-4000-8000-000000000001	0	09:00:00	20:00:00
ae010200-0000-4000-8000-000000000000	staff	ab010000-0000-4000-8000-000000000002	0	09:00:00	20:00:00
ae020100-0000-4000-8000-000000000000	staff	ab020000-0000-4000-8000-000000000001	0	09:00:00	20:00:00
ae030100-0000-4000-8000-000000000000	staff	ab030000-0000-4000-8000-000000000001	0	09:00:00	20:00:00
ae030200-0000-4000-8000-000000000000	staff	ab030000-0000-4000-8000-000000000002	0	09:00:00	20:00:00
ae040100-0000-4000-8000-000000000000	staff	ab040000-0000-4000-8000-000000000001	0	09:00:00	20:00:00
ae050100-0000-4000-8000-000000000000	staff	ab050000-0000-4000-8000-000000000001	0	09:00:00	20:00:00
ae050200-0000-4000-8000-000000000000	staff	ab050000-0000-4000-8000-000000000002	0	09:00:00	20:00:00
ae010300-0000-4000-8000-000000000000	chair	ac010000-0000-4000-8000-000000000001	0	09:00:00	20:00:00
ae020300-0000-4000-8000-000000000000	chair	ac020000-0000-4000-8000-000000000001	0	09:00:00	20:00:00
ae030300-0000-4000-8000-000000000000	chair	ac030000-0000-4000-8000-000000000001	0	09:00:00	20:00:00
ae040300-0000-4000-8000-000000000000	chair	ac040000-0000-4000-8000-000000000001	0	09:00:00	20:00:00
ae050300-0000-4000-8000-000000000000	chair	ac050000-0000-4000-8000-000000000001	0	09:00:00	20:00:00
ae010100-0000-4000-8000-000000000001	staff	ab010000-0000-4000-8000-000000000001	1	09:00:00	20:00:00
ae010200-0000-4000-8000-000000000001	staff	ab010000-0000-4000-8000-000000000002	1	09:00:00	20:00:00
ae020100-0000-4000-8000-000000000001	staff	ab020000-0000-4000-8000-000000000001	1	09:00:00	20:00:00
ae030100-0000-4000-8000-000000000001	staff	ab030000-0000-4000-8000-000000000001	1	09:00:00	20:00:00
ae030200-0000-4000-8000-000000000001	staff	ab030000-0000-4000-8000-000000000002	1	09:00:00	20:00:00
ae040100-0000-4000-8000-000000000001	staff	ab040000-0000-4000-8000-000000000001	1	09:00:00	20:00:00
ae050100-0000-4000-8000-000000000001	staff	ab050000-0000-4000-8000-000000000001	1	09:00:00	20:00:00
ae050200-0000-4000-8000-000000000001	staff	ab050000-0000-4000-8000-000000000002	1	09:00:00	20:00:00
ae010300-0000-4000-8000-000000000001	chair	ac010000-0000-4000-8000-000000000001	1	09:00:00	20:00:00
ae020300-0000-4000-8000-000000000001	chair	ac020000-0000-4000-8000-000000000001	1	09:00:00	20:00:00
ae030300-0000-4000-8000-000000000001	chair	ac030000-0000-4000-8000-000000000001	1	09:00:00	20:00:00
ae040300-0000-4000-8000-000000000001	chair	ac040000-0000-4000-8000-000000000001	1	09:00:00	20:00:00
ae050300-0000-4000-8000-000000000001	chair	ac050000-0000-4000-8000-000000000001	1	09:00:00	20:00:00
ae010100-0000-4000-8000-000000000002	staff	ab010000-0000-4000-8000-000000000001	2	09:00:00	20:00:00
ae010200-0000-4000-8000-000000000002	staff	ab010000-0000-4000-8000-000000000002	2	09:00:00	20:00:00
ae020100-0000-4000-8000-000000000002	staff	ab020000-0000-4000-8000-000000000001	2	09:00:00	20:00:00
ae030100-0000-4000-8000-000000000002	staff	ab030000-0000-4000-8000-000000000001	2	09:00:00	20:00:00
ae030200-0000-4000-8000-000000000002	staff	ab030000-0000-4000-8000-000000000002	2	09:00:00	20:00:00
ae040100-0000-4000-8000-000000000002	staff	ab040000-0000-4000-8000-000000000001	2	09:00:00	20:00:00
ae050100-0000-4000-8000-000000000002	staff	ab050000-0000-4000-8000-000000000001	2	09:00:00	20:00:00
ae050200-0000-4000-8000-000000000002	staff	ab050000-0000-4000-8000-000000000002	2	09:00:00	20:00:00
ae010300-0000-4000-8000-000000000002	chair	ac010000-0000-4000-8000-000000000001	2	09:00:00	20:00:00
ae020300-0000-4000-8000-000000000002	chair	ac020000-0000-4000-8000-000000000001	2	09:00:00	20:00:00
ae030300-0000-4000-8000-000000000002	chair	ac030000-0000-4000-8000-000000000001	2	09:00:00	20:00:00
ae040300-0000-4000-8000-000000000002	chair	ac040000-0000-4000-8000-000000000001	2	09:00:00	20:00:00
ae050300-0000-4000-8000-000000000002	chair	ac050000-0000-4000-8000-000000000001	2	09:00:00	20:00:00
ae010100-0000-4000-8000-000000000003	staff	ab010000-0000-4000-8000-000000000001	3	09:00:00	20:00:00
ae010200-0000-4000-8000-000000000003	staff	ab010000-0000-4000-8000-000000000002	3	09:00:00	20:00:00
ae020100-0000-4000-8000-000000000003	staff	ab020000-0000-4000-8000-000000000001	3	09:00:00	20:00:00
ae030100-0000-4000-8000-000000000003	staff	ab030000-0000-4000-8000-000000000001	3	09:00:00	20:00:00
ae030200-0000-4000-8000-000000000003	staff	ab030000-0000-4000-8000-000000000002	3	09:00:00	20:00:00
ae040100-0000-4000-8000-000000000003	staff	ab040000-0000-4000-8000-000000000001	3	09:00:00	20:00:00
ae050100-0000-4000-8000-000000000003	staff	ab050000-0000-4000-8000-000000000001	3	09:00:00	20:00:00
ae050200-0000-4000-8000-000000000003	staff	ab050000-0000-4000-8000-000000000002	3	09:00:00	20:00:00
ae010300-0000-4000-8000-000000000003	chair	ac010000-0000-4000-8000-000000000001	3	09:00:00	20:00:00
ae020300-0000-4000-8000-000000000003	chair	ac020000-0000-4000-8000-000000000001	3	09:00:00	20:00:00
ae030300-0000-4000-8000-000000000003	chair	ac030000-0000-4000-8000-000000000001	3	09:00:00	20:00:00
ae040300-0000-4000-8000-000000000003	chair	ac040000-0000-4000-8000-000000000001	3	09:00:00	20:00:00
7237d515-7b87-420a-9d62-f22854c881b2	chair	5b570db9-071b-4a2b-a3cb-cb6b7878763f	2	09:00:00	20:00:00
00cca5d0-e5bc-49aa-b9e9-afe67f533b5b	chair	5b570db9-071b-4a2b-a3cb-cb6b7878763f	3	09:00:00	20:00:00
53d9c6bf-71ac-4f74-ae37-2f050e437b4f	chair	5b570db9-071b-4a2b-a3cb-cb6b7878763f	4	09:00:00	20:00:00
ad704425-5727-4389-9135-5f76356f4622	chair	5b570db9-071b-4a2b-a3cb-cb6b7878763f	5	09:00:00	20:00:00
11c06ccf-b3fa-4488-93fa-1f1dc751d73a	chair	5b570db9-071b-4a2b-a3cb-cb6b7878763f	6	09:00:00	20:00:00
451fa40a-d196-4834-a52e-899dfe9bfce5	staff	d4d83171-36d3-40be-9f3a-d584794db7f4	0	09:00:00	20:00:00
d6b8ce3a-dfc5-4e69-8684-ed537d149212	staff	d4d83171-36d3-40be-9f3a-d584794db7f4	1	09:00:00	20:00:00
deb8969c-097a-4eae-ac2f-f080ce9486f2	staff	d4d83171-36d3-40be-9f3a-d584794db7f4	2	09:00:00	20:00:00
a137e653-971a-4b6d-ae3c-ac188018a344	staff	d4d83171-36d3-40be-9f3a-d584794db7f4	3	09:00:00	20:00:00
ad04557e-ed6a-4822-bc43-46c30dfe2f56	staff	d4d83171-36d3-40be-9f3a-d584794db7f4	4	09:00:00	20:00:00
5af442ee-6fa1-495f-acc6-659004396606	staff	d4d83171-36d3-40be-9f3a-d584794db7f4	5	09:00:00	20:00:00
3ea05030-49e6-4b08-bce7-cb67141b1595	staff	d4d83171-36d3-40be-9f3a-d584794db7f4	6	09:00:00	20:00:00
e041ed21-a2fb-4c28-9d0a-90c1b09130df	chair	d86ee85e-1293-4053-bfe6-f576d249a402	0	09:00:00	20:00:00
725bdb67-05b0-42b6-9ac1-a47ff7635bdc	chair	d86ee85e-1293-4053-bfe6-f576d249a402	1	09:00:00	20:00:00
78736a9d-60c3-4936-8f12-b9cbd257dadb	chair	d86ee85e-1293-4053-bfe6-f576d249a402	2	09:00:00	20:00:00
23d1de2d-4147-41f1-8c05-c316a2e992c5	chair	d86ee85e-1293-4053-bfe6-f576d249a402	3	09:00:00	20:00:00
45a7bcbe-972f-4504-9e07-32504beb9193	chair	d86ee85e-1293-4053-bfe6-f576d249a402	4	09:00:00	20:00:00
81965a02-fc40-43ab-ad5f-b6f55a184b9e	chair	d86ee85e-1293-4053-bfe6-f576d249a402	5	09:00:00	20:00:00
9868e81e-feff-46fc-aa84-479cf7bf0424	chair	d86ee85e-1293-4053-bfe6-f576d249a402	6	09:00:00	20:00:00
3070503c-8cb1-41b6-ac83-13c2592493b0	staff	274d5221-7f2c-46d4-b797-119ae3f82652	0	09:00:00	20:00:00
d2f24fdd-6021-4e61-ae8a-76bc997c76cd	staff	274d5221-7f2c-46d4-b797-119ae3f82652	1	09:00:00	20:00:00
92502388-5d14-4483-a47d-8b6afc61396f	staff	274d5221-7f2c-46d4-b797-119ae3f82652	2	09:00:00	20:00:00
7d29c275-9a20-4c74-b112-8c8dfc6a150f	staff	274d5221-7f2c-46d4-b797-119ae3f82652	3	09:00:00	20:00:00
4697ecd0-73b1-4215-ba64-7557bfe0dcb0	staff	274d5221-7f2c-46d4-b797-119ae3f82652	4	09:00:00	20:00:00
27af974f-94e6-44f8-a7d9-79ee8027ef89	staff	274d5221-7f2c-46d4-b797-119ae3f82652	5	09:00:00	20:00:00
0bfebfd2-10ad-4379-a71e-c4edb3afe619	staff	274d5221-7f2c-46d4-b797-119ae3f82652	6	09:00:00	20:00:00
0ee4acbc-7f9c-4a6a-b54f-38ca258b5815	chair	d8e47ef5-0633-4c8e-8547-125a436fca96	0	09:00:00	20:00:00
4195a63c-9f34-4bd3-8b20-b4a765124c0d	chair	d8e47ef5-0633-4c8e-8547-125a436fca96	1	09:00:00	20:00:00
c5fa8a53-ac58-44dc-b7b2-812422ed8369	chair	d8e47ef5-0633-4c8e-8547-125a436fca96	2	09:00:00	20:00:00
4277715b-4c3c-490c-9bc4-d043f6814023	chair	d8e47ef5-0633-4c8e-8547-125a436fca96	3	09:00:00	20:00:00
d70f0d49-4ac2-4f94-9d4d-5dd3e15a6f68	chair	d8e47ef5-0633-4c8e-8547-125a436fca96	4	09:00:00	20:00:00
bde4abca-c13f-472b-9c88-27c58c3ed77c	chair	d8e47ef5-0633-4c8e-8547-125a436fca96	5	09:00:00	20:00:00
7dd416bf-d319-4f3d-9beb-50d92fbb8e2b	chair	d8e47ef5-0633-4c8e-8547-125a436fca96	6	09:00:00	20:00:00
51170f02-5946-4c3a-878e-1bdbb9c93688	staff	44c43473-b2c1-487d-9176-157713994ca8	0	09:00:00	20:00:00
5950d5be-4e65-4e89-836a-aa36eeeefa18	staff	44c43473-b2c1-487d-9176-157713994ca8	1	09:00:00	20:00:00
8a293a2e-2287-4754-833c-565aef05d3f4	staff	44c43473-b2c1-487d-9176-157713994ca8	2	09:00:00	20:00:00
b30f6fcf-d0a8-4e51-994e-9b865e8a2962	staff	44c43473-b2c1-487d-9176-157713994ca8	3	09:00:00	20:00:00
b2eea691-7309-4670-8467-e78b380ff2d3	staff	44c43473-b2c1-487d-9176-157713994ca8	4	09:00:00	20:00:00
44c5281c-4591-4c37-9268-0b1360ad429c	staff	44c43473-b2c1-487d-9176-157713994ca8	5	09:00:00	20:00:00
6f3078b0-8a7e-4a92-9d4b-cca71e6e3963	staff	44c43473-b2c1-487d-9176-157713994ca8	6	09:00:00	20:00:00
8cdf908c-931b-475b-a1bc-db0eca7fab4c	chair	15abcb13-3e78-4c16-94b4-2f0d5d88c5a3	0	09:00:00	20:00:00
1decf749-cd1f-4d70-80ac-7ec8b7eb3986	chair	15abcb13-3e78-4c16-94b4-2f0d5d88c5a3	1	09:00:00	20:00:00
d5ef7566-d587-401c-8bc1-350354e5b3e4	chair	15abcb13-3e78-4c16-94b4-2f0d5d88c5a3	2	09:00:00	20:00:00
7809bf5f-7caf-4624-881e-36ecfd4f103e	chair	15abcb13-3e78-4c16-94b4-2f0d5d88c5a3	3	09:00:00	20:00:00
41ad615c-7ad5-4c72-8813-b613e77de243	chair	15abcb13-3e78-4c16-94b4-2f0d5d88c5a3	4	09:00:00	20:00:00
f3c535ce-fa2d-4654-9090-f6609f12ac55	chair	15abcb13-3e78-4c16-94b4-2f0d5d88c5a3	5	09:00:00	20:00:00
eb05e662-631b-421e-b1ff-2e74f184937f	chair	15abcb13-3e78-4c16-94b4-2f0d5d88c5a3	6	09:00:00	20:00:00
0ebefd64-4c2f-4b7d-a71a-9fd6eb6802cb	staff	63446f6a-49e7-431e-868b-33c534155203	0	09:00:00	20:00:00
7aefe7dc-d3c0-40f1-8266-05358075cf0d	staff	63446f6a-49e7-431e-868b-33c534155203	1	09:00:00	20:00:00
6183ee97-c146-4214-b2e8-e2b7e5a849cf	staff	63446f6a-49e7-431e-868b-33c534155203	2	09:00:00	20:00:00
6cdd1e5a-83cd-4f72-886d-bd30e7edf5b9	staff	63446f6a-49e7-431e-868b-33c534155203	3	09:00:00	20:00:00
6f8bf5c1-c62a-4b61-a3a4-563b0de5c06f	staff	63446f6a-49e7-431e-868b-33c534155203	4	09:00:00	20:00:00
89c3b326-51c2-4c01-b8c7-1a26e1ec83e1	staff	63446f6a-49e7-431e-868b-33c534155203	5	09:00:00	20:00:00
3c6ed777-3d09-4115-898d-3581f3c970d4	staff	63446f6a-49e7-431e-868b-33c534155203	6	09:00:00	20:00:00
65cbeaae-81d2-4706-ae81-733a31b41c43	chair	ca3cdd6c-a936-47f6-8d4b-326405cbf5d6	0	09:00:00	20:00:00
c8dfbea1-f870-40b8-8267-4fd9204232c7	chair	ca3cdd6c-a936-47f6-8d4b-326405cbf5d6	1	09:00:00	20:00:00
4fcadd00-0465-4d2e-9430-db82072b492b	chair	ca3cdd6c-a936-47f6-8d4b-326405cbf5d6	2	09:00:00	20:00:00
7135156e-cea7-4ba8-9869-3696345603c6	chair	ca3cdd6c-a936-47f6-8d4b-326405cbf5d6	3	09:00:00	20:00:00
fcb90bdf-2670-4dbd-b7a4-20b0b4b4d768	chair	ca3cdd6c-a936-47f6-8d4b-326405cbf5d6	4	09:00:00	20:00:00
3b9595be-0581-4b7b-bd04-0e7357a1d63b	chair	ca3cdd6c-a936-47f6-8d4b-326405cbf5d6	5	09:00:00	20:00:00
e986f4df-726a-4e9e-b4e6-f0de281ad44a	chair	ca3cdd6c-a936-47f6-8d4b-326405cbf5d6	6	09:00:00	20:00:00
b3c433d5-e445-4639-98af-0188cc1306f3	staff	7ea40eb1-7057-49a7-a1c5-1b9b04c48018	0	09:00:00	20:00:00
08511456-b914-41f8-9a25-05bf236d0787	staff	7ea40eb1-7057-49a7-a1c5-1b9b04c48018	1	09:00:00	20:00:00
4bdc635b-d97e-46e9-bb68-3dfcc1740c89	staff	7ea40eb1-7057-49a7-a1c5-1b9b04c48018	2	09:00:00	20:00:00
2a58de57-f825-48f3-9a9f-9e7d2025381f	staff	7ea40eb1-7057-49a7-a1c5-1b9b04c48018	3	09:00:00	20:00:00
10457ad4-11e0-41d2-b02f-819c18cc1ea2	staff	7ea40eb1-7057-49a7-a1c5-1b9b04c48018	4	09:00:00	20:00:00
a97b084e-f334-4051-b012-dfa1ba94bf24	staff	7ea40eb1-7057-49a7-a1c5-1b9b04c48018	5	09:00:00	20:00:00
49a04b19-9b23-4ba2-bc37-8b9922b16b5a	staff	7ea40eb1-7057-49a7-a1c5-1b9b04c48018	6	09:00:00	20:00:00
ab52f2bb-8ce4-4c1f-8109-37d74976ee4c	staff	f3d31de6-d22e-4d38-a366-f5848e504bfb	0	09:00:00	20:00:00
71aed6d5-cf0a-4e06-9532-c8299234b90a	staff	f3d31de6-d22e-4d38-a366-f5848e504bfb	1	09:00:00	20:00:00
38b4e60c-63c4-43ce-b4f1-a95ae223b9b4	staff	f3d31de6-d22e-4d38-a366-f5848e504bfb	2	09:00:00	20:00:00
2ef7ea54-d7f8-470e-9760-5a1cbd1abd5e	staff	f3d31de6-d22e-4d38-a366-f5848e504bfb	3	09:00:00	20:00:00
14d95a27-430b-45df-86f8-455e34e6fcd8	staff	f3d31de6-d22e-4d38-a366-f5848e504bfb	4	09:00:00	20:00:00
ff95f2cb-c239-4ee9-844e-10c1be3cdaf1	staff	f3d31de6-d22e-4d38-a366-f5848e504bfb	5	09:00:00	20:00:00
f6deed3f-3e64-4907-9915-dc8df8df1f77	staff	f3d31de6-d22e-4d38-a366-f5848e504bfb	6	09:00:00	20:00:00
b325ac45-ede3-46b8-9bab-fec5fc6dd3a5	chair	f47cdf8a-1654-4527-9864-5c84a1d7bde0	0	09:00:00	20:00:00
66c6b858-9fde-43c1-b72f-6f16b51d38c7	chair	f47cdf8a-1654-4527-9864-5c84a1d7bde0	1	09:00:00	20:00:00
a3d559f1-b52e-435c-8bbb-d628ae68670a	chair	f47cdf8a-1654-4527-9864-5c84a1d7bde0	2	09:00:00	20:00:00
6a65fbe5-0973-4d2b-b569-6509738158ad	chair	f47cdf8a-1654-4527-9864-5c84a1d7bde0	3	09:00:00	20:00:00
7595b684-7adc-4dd7-99e2-6a5c5230e00d	chair	f47cdf8a-1654-4527-9864-5c84a1d7bde0	4	09:00:00	20:00:00
f69b5a2f-b244-4bbc-8e38-f54a9817b736	chair	f47cdf8a-1654-4527-9864-5c84a1d7bde0	5	09:00:00	20:00:00
b910c1d4-b9c6-4d0d-89bb-754b42ee7502	chair	f47cdf8a-1654-4527-9864-5c84a1d7bde0	6	09:00:00	20:00:00
fbb545f0-eac1-451e-ab1c-bfcf12f713c7	chair	c27395cd-525d-4ce5-937e-8f65da2f19cc	0	09:00:00	20:00:00
8e7651e0-351f-48a1-8763-9b298e47b5cf	chair	c27395cd-525d-4ce5-937e-8f65da2f19cc	1	09:00:00	20:00:00
30ed1f1f-da70-4f66-b221-692fff4eea22	chair	c27395cd-525d-4ce5-937e-8f65da2f19cc	2	09:00:00	20:00:00
ee4e9a08-7993-4ec3-9897-e1d7724f47cc	chair	c27395cd-525d-4ce5-937e-8f65da2f19cc	3	09:00:00	20:00:00
5f8728b5-fd31-4d0d-a01e-94db7c6a9a29	chair	c27395cd-525d-4ce5-937e-8f65da2f19cc	4	09:00:00	20:00:00
4244c080-aac1-443d-9f6e-0225b260be86	chair	c27395cd-525d-4ce5-937e-8f65da2f19cc	5	09:00:00	20:00:00
c3edc414-2f60-4180-9c97-24b1b0cc66b0	chair	c27395cd-525d-4ce5-937e-8f65da2f19cc	6	09:00:00	20:00:00
9e04ae0f-f6fc-4c08-be1a-4b5caddf7aca	chair	08096e11-14f5-4180-8a42-3e39ef4f7d4c	0	09:00:00	20:00:00
25ca3eca-5f3b-49d9-a359-ce929b9e8756	chair	08096e11-14f5-4180-8a42-3e39ef4f7d4c	1	09:00:00	20:00:00
7ca478ce-abfb-4db6-bc89-3f140fd9f93a	chair	08096e11-14f5-4180-8a42-3e39ef4f7d4c	2	09:00:00	20:00:00
b2cffeef-a528-4a6a-b8f7-da0b8724393d	chair	08096e11-14f5-4180-8a42-3e39ef4f7d4c	3	09:00:00	20:00:00
c9caa7ee-1c69-4290-9d36-161b9d7da872	chair	08096e11-14f5-4180-8a42-3e39ef4f7d4c	4	09:00:00	20:00:00
c2d1ae6f-fdea-43bc-b9fc-6405f4489aad	chair	08096e11-14f5-4180-8a42-3e39ef4f7d4c	5	09:00:00	20:00:00
3d9bb13d-4201-432f-bb76-5e136e7e4dbc	chair	08096e11-14f5-4180-8a42-3e39ef4f7d4c	6	09:00:00	20:00:00
23189f3a-f5e4-4485-970f-ef8efbc5434a	staff	73e51bbb-8122-4773-ba10-d37fdd063fa5	0	09:00:00	20:00:00
e1e163b3-6d4c-43e2-af5c-6f5fb2f820cc	staff	73e51bbb-8122-4773-ba10-d37fdd063fa5	1	09:00:00	20:00:00
d5e0705d-9928-43d8-babc-43b216c9204c	staff	73e51bbb-8122-4773-ba10-d37fdd063fa5	2	09:00:00	20:00:00
bd048fb7-c457-491c-bd5b-c3877896aefe	staff	73e51bbb-8122-4773-ba10-d37fdd063fa5	3	09:00:00	20:00:00
5151ef24-ba53-4c2f-8836-4080d43937c5	staff	73e51bbb-8122-4773-ba10-d37fdd063fa5	4	09:00:00	20:00:00
d1577caf-ccbe-40f4-9d25-cd37a3b670dc	staff	73e51bbb-8122-4773-ba10-d37fdd063fa5	5	09:00:00	20:00:00
41994ae2-ac87-4191-a1d2-f06e2e1f555b	staff	73e51bbb-8122-4773-ba10-d37fdd063fa5	6	09:00:00	20:00:00
f308607c-f5ce-41da-9242-5695ac059edf	chair	1e641a63-f525-420c-ab45-9f5d9503913a	0	09:00:00	20:00:00
4207e67c-f7ce-4052-9c93-7b6b7b9f2a8e	chair	1e641a63-f525-420c-ab45-9f5d9503913a	1	09:00:00	20:00:00
38e4804d-50c8-4377-94d3-c3830d3f800a	chair	1e641a63-f525-420c-ab45-9f5d9503913a	2	09:00:00	20:00:00
9b58f194-11a4-426d-ab78-c381e1a1722d	chair	1e641a63-f525-420c-ab45-9f5d9503913a	3	09:00:00	20:00:00
ad155df4-8960-4972-a0b5-9024803cd2ae	chair	1e641a63-f525-420c-ab45-9f5d9503913a	4	09:00:00	20:00:00
982a5a58-1051-46a4-9f81-568bb41beb28	chair	1e641a63-f525-420c-ab45-9f5d9503913a	5	09:00:00	20:00:00
18e06793-e630-4ae0-93e1-bc13decd36b1	chair	1e641a63-f525-420c-ab45-9f5d9503913a	6	09:00:00	20:00:00
c4d88134-ab86-4d7e-b009-dcf8e640d338	staff	b25a26a7-eb8d-49a2-b10f-79544277cebb	0	09:00:00	20:00:00
90afaf98-4b20-46ee-8caa-229e484688c7	staff	b25a26a7-eb8d-49a2-b10f-79544277cebb	1	09:00:00	20:00:00
9e27cfc3-cfe6-49dc-86f7-5070d840af8c	staff	b25a26a7-eb8d-49a2-b10f-79544277cebb	2	09:00:00	20:00:00
5aba4b95-c42d-44f9-a539-84ecf00c0f4c	staff	b25a26a7-eb8d-49a2-b10f-79544277cebb	3	09:00:00	20:00:00
9671aad1-0988-4d9b-944c-dc1bf894494a	staff	b25a26a7-eb8d-49a2-b10f-79544277cebb	4	09:00:00	20:00:00
bb076314-716e-4860-abb9-fac213220f8d	staff	b25a26a7-eb8d-49a2-b10f-79544277cebb	5	09:00:00	20:00:00
564358ea-5a23-4c9b-814b-d36a774515af	staff	b25a26a7-eb8d-49a2-b10f-79544277cebb	6	09:00:00	20:00:00
4bbbd8c8-7823-4241-8e1e-5b05ea8821c5	chair	6b17463d-cd48-4c3c-bd39-f468a9bc6ff0	0	09:00:00	20:00:00
bd9a64f0-d6c3-45dd-8ff3-d8506047a3a0	chair	6b17463d-cd48-4c3c-bd39-f468a9bc6ff0	1	09:00:00	20:00:00
d64ac84e-93e7-4218-be22-024e99b31beb	chair	6b17463d-cd48-4c3c-bd39-f468a9bc6ff0	2	09:00:00	20:00:00
d89e9d8e-a93b-4d44-af77-cabca1817599	chair	6b17463d-cd48-4c3c-bd39-f468a9bc6ff0	3	09:00:00	20:00:00
3e9e715b-35a0-4c2d-99c9-96fd76907bfa	chair	6b17463d-cd48-4c3c-bd39-f468a9bc6ff0	4	09:00:00	20:00:00
086317d3-500d-49d2-9ef4-8649b30e011d	chair	6b17463d-cd48-4c3c-bd39-f468a9bc6ff0	5	09:00:00	20:00:00
42bffa43-17f6-44a8-b2cb-e7ea01d256bd	chair	6b17463d-cd48-4c3c-bd39-f468a9bc6ff0	6	09:00:00	20:00:00
554fc871-bf4c-48fa-953c-73d1271c583c	staff	712bfffd-6e35-4ef4-9259-2bfed0c5e4d6	0	09:00:00	20:00:00
78cb9487-7acb-46a9-832d-6a5c1abcfcf5	staff	712bfffd-6e35-4ef4-9259-2bfed0c5e4d6	1	09:00:00	20:00:00
9940bf7d-486d-4093-8b74-cad2aaf25038	staff	712bfffd-6e35-4ef4-9259-2bfed0c5e4d6	2	09:00:00	20:00:00
691fb47c-2fd4-4116-8362-c2c030c7d2be	staff	712bfffd-6e35-4ef4-9259-2bfed0c5e4d6	3	09:00:00	20:00:00
d7b6d76d-578b-4706-9047-46cff8538381	staff	712bfffd-6e35-4ef4-9259-2bfed0c5e4d6	4	09:00:00	20:00:00
2dfb5e1f-edee-4f7b-9d5b-d47631803aee	staff	712bfffd-6e35-4ef4-9259-2bfed0c5e4d6	5	09:00:00	20:00:00
d0f99086-ed63-423c-954e-f31170d9ba88	staff	712bfffd-6e35-4ef4-9259-2bfed0c5e4d6	6	09:00:00	20:00:00
ef05eef0-7a94-472a-a982-2930423d3cf0	chair	0a8afcc8-f839-40fd-ad10-8425236d22e4	0	09:00:00	20:00:00
5a68565c-4c2b-4331-8936-09f9f707ea5c	chair	0a8afcc8-f839-40fd-ad10-8425236d22e4	1	09:00:00	20:00:00
a7e6c454-5c1b-4d12-baaf-09bb5878c3f4	chair	0a8afcc8-f839-40fd-ad10-8425236d22e4	2	09:00:00	20:00:00
440e52c5-19e5-4c14-bf69-072368bd347a	chair	0a8afcc8-f839-40fd-ad10-8425236d22e4	3	09:00:00	20:00:00
f9993721-686c-437f-a419-6faadb51e02e	chair	0a8afcc8-f839-40fd-ad10-8425236d22e4	4	09:00:00	20:00:00
be7eb313-795c-41ee-9ec8-8d779db2b0ea	chair	0a8afcc8-f839-40fd-ad10-8425236d22e4	5	09:00:00	20:00:00
b0596d07-4cc1-4cd2-bebe-872a947be67c	chair	0a8afcc8-f839-40fd-ad10-8425236d22e4	6	09:00:00	20:00:00
960f1994-5ebf-4492-bc0c-a2841f92a479	staff	388daaa5-789a-4514-9bc5-511649f2f437	0	09:00:00	20:00:00
eb3a3c70-008b-4fb9-8a05-0dfea609645f	staff	388daaa5-789a-4514-9bc5-511649f2f437	1	09:00:00	20:00:00
6e9ae1c1-471d-4ac4-843a-f34d2279df90	staff	388daaa5-789a-4514-9bc5-511649f2f437	2	09:00:00	20:00:00
6607689a-ff9f-48f9-b8a6-3cca9e82e8f5	staff	388daaa5-789a-4514-9bc5-511649f2f437	3	09:00:00	20:00:00
75bf333c-1856-4edb-8fbc-957b62eac29f	staff	388daaa5-789a-4514-9bc5-511649f2f437	4	09:00:00	20:00:00
54fa5e7f-505f-4c0f-8c72-87c4dd734615	staff	388daaa5-789a-4514-9bc5-511649f2f437	5	09:00:00	20:00:00
90788dfe-2f81-44c8-b2af-684a8cafc876	staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	0	09:00:00	20:00:00
ff894a0d-b7b1-4c6d-afd1-e8d09319f5b2	staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	1	09:00:00	20:00:00
cc6bc4dc-97e7-4349-84f4-36aec0563cd9	staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	2	09:00:00	20:00:00
39dc1517-a418-4b74-8a2f-aae30365e9f9	staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	3	09:00:00	20:00:00
96ea3a70-5d8b-4cba-b40a-687c46461bde	staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	4	09:00:00	20:00:00
1a85d2c0-409a-415c-98ce-cca5a6cdd652	staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	5	09:00:00	20:00:00
1589d0af-a15f-4fcb-91c7-e55f5e2e3488	staff	bb302d69-79ff-4921-86d1-8e6e22ae92cb	6	09:00:00	20:00:00
d907eae6-b5e3-4710-a71c-fb1483a93818	chair	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	0	09:00:00	20:00:00
906d15bf-c8a8-4ce5-9c90-3c64367ee203	chair	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	1	09:00:00	20:00:00
91578f0a-c8f8-4183-af24-7b039264f50e	chair	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	2	09:00:00	20:00:00
31f3b5e0-605d-44ee-8927-fb339d05441a	chair	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	3	09:00:00	20:00:00
b11a1122-3eac-4d0b-b135-52d3d1da2255	chair	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	4	09:00:00	20:00:00
f5908dd0-ac54-4753-85a8-034bd3324e0b	chair	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	5	09:00:00	20:00:00
c1e19113-adf3-476a-9c59-43946929760a	chair	75ef94c4-f803-4b53-8d55-6e5a0edda6c6	6	09:00:00	20:00:00
0a9dfc45-2b55-4b68-8ca7-24a458774e64	staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	0	09:00:00	20:00:00
2c154fa8-1cce-41a8-9628-467236f4d453	staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	1	09:00:00	20:00:00
5a9b7095-e788-4d91-8009-6813a1bfb384	staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	2	09:00:00	20:00:00
5a2c52c8-d0ef-458a-8635-99155ff5bfcd	staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	3	09:00:00	20:00:00
8b64a403-149d-4f8b-9468-8692c3180419	staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	4	09:00:00	20:00:00
d8aa6dd6-0b14-4395-b766-65bf7bd8c04a	staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	5	09:00:00	20:00:00
2bb8f8e2-1fa0-459b-b23a-d680c7e91905	staff	d41ffc8a-603b-483a-bfe3-3c7994ef116c	6	09:00:00	20:00:00
4273805e-09ed-409d-a595-0150a7b6d881	chair	28472931-9bb9-4b4e-88d1-f7fd8531916b	0	09:00:00	20:00:00
ec84b435-3503-4c92-9f2c-ed702493bfb4	chair	28472931-9bb9-4b4e-88d1-f7fd8531916b	1	09:00:00	20:00:00
9186c1d5-1e7e-4c23-bd5d-1b532168fddd	chair	28472931-9bb9-4b4e-88d1-f7fd8531916b	2	09:00:00	20:00:00
942da271-6bf0-4221-b485-0878b7787dd6	chair	28472931-9bb9-4b4e-88d1-f7fd8531916b	3	09:00:00	20:00:00
57fe6734-6d77-4cf5-b998-a1dd9f65222c	chair	28472931-9bb9-4b4e-88d1-f7fd8531916b	4	09:00:00	20:00:00
a7dcf728-7f24-4702-bff2-6f1ba28e0ed1	chair	28472931-9bb9-4b4e-88d1-f7fd8531916b	5	09:00:00	20:00:00
1160a90c-97a3-4d99-a66c-d11fc2480e65	chair	28472931-9bb9-4b4e-88d1-f7fd8531916b	6	09:00:00	20:00:00
dd5b4a8b-3db2-4b9a-9fb8-0c72052e2108	staff	0bbae851-7318-4213-8961-75ff34de841f	0	09:00:00	20:00:00
29e70314-cdc9-43bd-bbed-37550a6b2e71	staff	0bbae851-7318-4213-8961-75ff34de841f	1	09:00:00	20:00:00
be9b84f9-58c9-4ebd-b485-9a381a660dc5	staff	0bbae851-7318-4213-8961-75ff34de841f	2	09:00:00	20:00:00
a55b6899-77e9-4a88-a1c4-ddf3e15ce65d	staff	0bbae851-7318-4213-8961-75ff34de841f	3	09:00:00	20:00:00
764403e3-696d-4a7d-b77d-5db0d028860a	staff	0bbae851-7318-4213-8961-75ff34de841f	4	09:00:00	20:00:00
c87540a9-b27c-4fb3-b6a1-bf87250ecf83	staff	0bbae851-7318-4213-8961-75ff34de841f	5	09:00:00	20:00:00
68ec9f41-a093-4331-83ff-1f8dabd4c129	staff	0bbae851-7318-4213-8961-75ff34de841f	6	09:00:00	20:00:00
021704ee-cdfc-4325-a804-0344c489a161	chair	eabac63f-822a-4195-9c94-90ce656a571a	0	09:00:00	20:00:00
58704646-100c-4c99-8f64-2e4ffc6a68ac	chair	eabac63f-822a-4195-9c94-90ce656a571a	1	09:00:00	20:00:00
bed130d1-3970-406b-a195-0a40b61c5840	chair	eabac63f-822a-4195-9c94-90ce656a571a	2	09:00:00	20:00:00
3de36894-a56b-415c-ac97-1e86a3b8cb8e	chair	eabac63f-822a-4195-9c94-90ce656a571a	3	09:00:00	20:00:00
000796c8-8087-47a8-9661-e938892eed47	chair	eabac63f-822a-4195-9c94-90ce656a571a	4	09:00:00	20:00:00
2880d20a-d4ee-4ed5-b1da-0ca062eabb7f	chair	eabac63f-822a-4195-9c94-90ce656a571a	5	09:00:00	20:00:00
6c63441c-3aeb-4dc7-be17-2016e12d4ebc	chair	eabac63f-822a-4195-9c94-90ce656a571a	6	09:00:00	20:00:00
4b78a05d-6560-4586-8391-d0d743ab6430	staff	3a61b3fd-5024-41f9-af02-4afaff34c331	0	09:00:00	20:00:00
b85298b5-3742-4b7e-9f73-676875b86a2a	staff	3a61b3fd-5024-41f9-af02-4afaff34c331	1	09:00:00	20:00:00
9d9431ca-3f9b-4ecb-8712-953297dc5e3b	staff	3a61b3fd-5024-41f9-af02-4afaff34c331	2	09:00:00	20:00:00
3c1ff291-4025-424b-9d1c-f39f12457f7d	staff	3a61b3fd-5024-41f9-af02-4afaff34c331	3	09:00:00	20:00:00
1c8f5693-1ea6-4401-8a75-224cd16418c2	staff	3a61b3fd-5024-41f9-af02-4afaff34c331	4	09:00:00	20:00:00
d792a1e1-6440-4869-ab48-f4079dec5234	staff	3a61b3fd-5024-41f9-af02-4afaff34c331	5	09:00:00	20:00:00
e8004dea-a0a2-44cd-a9f5-0f74ec0beb6c	staff	3a61b3fd-5024-41f9-af02-4afaff34c331	6	09:00:00	20:00:00
b3ae6ebf-4571-4bbf-83d1-f5ca3217c5b0	chair	f536c85e-6c6a-4f64-bda8-f4e0394fa364	0	09:00:00	20:00:00
918f4aa3-3b01-416d-834c-2bc2246c85c8	chair	f536c85e-6c6a-4f64-bda8-f4e0394fa364	1	09:00:00	20:00:00
83041746-3380-4b76-ba1a-dc52cb36c801	chair	f536c85e-6c6a-4f64-bda8-f4e0394fa364	2	09:00:00	20:00:00
d60a44da-991a-4a76-950b-077101c23256	chair	f536c85e-6c6a-4f64-bda8-f4e0394fa364	3	09:00:00	20:00:00
a318a3fa-2ccb-41af-8b26-bee7cd459d96	chair	f536c85e-6c6a-4f64-bda8-f4e0394fa364	4	09:00:00	20:00:00
4878b546-1cb1-4945-8d22-6e15ad5aac30	chair	f536c85e-6c6a-4f64-bda8-f4e0394fa364	5	09:00:00	20:00:00
63fe35e4-b183-4512-b302-54bd9265494d	chair	f536c85e-6c6a-4f64-bda8-f4e0394fa364	6	09:00:00	20:00:00
160413f4-c036-4b49-81d9-75680f6d3000	staff	0780d8d7-804a-4666-89d9-e08d9f17102b	0	09:00:00	20:00:00
7c6cd106-d0f3-47e1-a3dc-f38adf630e6f	staff	0780d8d7-804a-4666-89d9-e08d9f17102b	1	09:00:00	20:00:00
fa182bf4-cada-4789-8a2b-7e1e9e10d0b2	staff	0780d8d7-804a-4666-89d9-e08d9f17102b	2	09:00:00	20:00:00
f5d752db-9678-473c-bd38-25f87399a4c3	staff	0780d8d7-804a-4666-89d9-e08d9f17102b	3	09:00:00	20:00:00
7578eae0-2b7c-47a3-9791-f0805795d056	staff	0780d8d7-804a-4666-89d9-e08d9f17102b	4	09:00:00	20:00:00
02dd661a-5b44-49d9-b4c2-cd9c3164e6c6	staff	0780d8d7-804a-4666-89d9-e08d9f17102b	5	09:00:00	20:00:00
63d5c309-e54d-4dea-8466-fbebcb889519	staff	0780d8d7-804a-4666-89d9-e08d9f17102b	6	09:00:00	20:00:00
1977a334-62ad-4bb9-9638-2024739bfcff	chair	0c7268ab-3d59-46f0-8f0a-2dc1bf69b310	0	09:00:00	20:00:00
b2e68e80-163f-4ee5-837d-869985699299	chair	0c7268ab-3d59-46f0-8f0a-2dc1bf69b310	1	09:00:00	20:00:00
43c38c8e-29e0-42e2-92c0-12a7ec70c0f2	chair	0c7268ab-3d59-46f0-8f0a-2dc1bf69b310	2	09:00:00	20:00:00
ad6449ca-44df-4965-a0fd-00e383b649cd	chair	0c7268ab-3d59-46f0-8f0a-2dc1bf69b310	3	09:00:00	20:00:00
6cbcfdd0-672a-40c1-9b63-876fb19c8ec8	chair	0c7268ab-3d59-46f0-8f0a-2dc1bf69b310	4	09:00:00	20:00:00
246a98ae-0d3e-4ac6-806b-8ae82298f455	chair	0c7268ab-3d59-46f0-8f0a-2dc1bf69b310	5	09:00:00	20:00:00
8015076c-493c-403d-8344-4938936e612d	chair	0c7268ab-3d59-46f0-8f0a-2dc1bf69b310	6	09:00:00	20:00:00
e68dfd74-3381-4d30-9bb9-4f1e7fd4eda8	staff	61b8298d-a97f-4ea6-a255-a95c04d82457	0	09:00:00	20:00:00
00424a3a-e476-4ede-9160-b9db68a551c9	staff	61b8298d-a97f-4ea6-a255-a95c04d82457	1	09:00:00	20:00:00
1725dcf7-0168-479f-886c-5ecb9d363356	staff	61b8298d-a97f-4ea6-a255-a95c04d82457	2	09:00:00	20:00:00
0a84a647-5d9f-4a06-a679-c189056fe74c	staff	61b8298d-a97f-4ea6-a255-a95c04d82457	3	09:00:00	20:00:00
687963c3-cf30-427c-bf03-40b8186d9a37	staff	61b8298d-a97f-4ea6-a255-a95c04d82457	4	09:00:00	20:00:00
4e89d2ad-4d12-4c54-bce5-de8653f30e06	staff	61b8298d-a97f-4ea6-a255-a95c04d82457	5	09:00:00	20:00:00
37e8e109-802d-4938-9367-1831aee17848	staff	61b8298d-a97f-4ea6-a255-a95c04d82457	6	09:00:00	20:00:00
b1fc02bd-eee2-46ff-8f3b-a245f4f3c692	chair	0f54877d-4251-4314-ac05-9381c80f2b01	0	09:00:00	20:00:00
29f1b539-db27-4f9b-a86b-0c057eff409c	chair	0f54877d-4251-4314-ac05-9381c80f2b01	1	09:00:00	20:00:00
85f0b326-5044-4d1f-a933-06a153b2e1d4	chair	0f54877d-4251-4314-ac05-9381c80f2b01	2	09:00:00	20:00:00
608b2830-757a-4663-af3b-2ebe11ac0e05	chair	0f54877d-4251-4314-ac05-9381c80f2b01	3	09:00:00	20:00:00
f4e835f5-bd4b-449b-9977-40d21af9a7ab	chair	0f54877d-4251-4314-ac05-9381c80f2b01	4	09:00:00	20:00:00
598a987f-52f8-420e-9204-09249c86d049	chair	0f54877d-4251-4314-ac05-9381c80f2b01	5	09:00:00	20:00:00
bd42d080-c170-4108-8f39-479ba9b0c063	chair	0f54877d-4251-4314-ac05-9381c80f2b01	6	09:00:00	20:00:00
ae050300-0000-4000-8000-000000000003	chair	ac050000-0000-4000-8000-000000000001	3	09:00:00	20:00:00
ae010100-0000-4000-8000-000000000004	staff	ab010000-0000-4000-8000-000000000001	4	09:00:00	20:00:00
ae010200-0000-4000-8000-000000000004	staff	ab010000-0000-4000-8000-000000000002	4	09:00:00	20:00:00
ae020100-0000-4000-8000-000000000004	staff	ab020000-0000-4000-8000-000000000001	4	09:00:00	20:00:00
49ec3c2e-a3c7-497c-855a-cd0a148a1aa5	staff	388daaa5-789a-4514-9bc5-511649f2f437	6	09:00:00	20:00:00
94be5682-395b-4f27-a90e-a7af9a6c167d	chair	67a081de-5fc5-4fd0-b950-5c075f491261	0	09:00:00	20:00:00
8af0078e-72de-4950-964b-d31477d16b94	chair	67a081de-5fc5-4fd0-b950-5c075f491261	1	09:00:00	20:00:00
19dadb68-e06c-4f29-8e2b-6864f590acce	chair	67a081de-5fc5-4fd0-b950-5c075f491261	2	09:00:00	20:00:00
320d4c4e-5e93-4ed1-9f0d-2bf5d0833c0f	chair	67a081de-5fc5-4fd0-b950-5c075f491261	3	09:00:00	20:00:00
594dda7e-bf45-4cdd-b88c-46d0f4abf4a7	chair	67a081de-5fc5-4fd0-b950-5c075f491261	4	09:00:00	20:00:00
13effe2a-360d-435e-b950-bfd4c0054fdf	chair	67a081de-5fc5-4fd0-b950-5c075f491261	5	09:00:00	20:00:00
78b9afbe-1466-400f-8b24-39a3a3db4548	chair	67a081de-5fc5-4fd0-b950-5c075f491261	6	09:00:00	20:00:00
03a49f6d-7fac-4bb0-9148-e767f06d843b	staff	389aab4c-9d68-4e3e-bc97-a3d7af01f4da	0	09:00:00	20:00:00
d1e6af46-f48a-4f2e-a0c6-f3942091e4e8	staff	389aab4c-9d68-4e3e-bc97-a3d7af01f4da	1	09:00:00	20:00:00
180e73f4-a501-41de-b05a-2a6eb57f4a8c	staff	389aab4c-9d68-4e3e-bc97-a3d7af01f4da	2	09:00:00	20:00:00
3ce73f69-e399-44e7-a4de-6b3521b5d3ce	staff	389aab4c-9d68-4e3e-bc97-a3d7af01f4da	3	09:00:00	20:00:00
45760487-d85a-455d-b4bf-15cad43d5518	staff	389aab4c-9d68-4e3e-bc97-a3d7af01f4da	4	09:00:00	20:00:00
35f829f3-6c6f-40e4-a4a8-d0cc0cd9ce2b	staff	389aab4c-9d68-4e3e-bc97-a3d7af01f4da	5	09:00:00	20:00:00
319b6d70-7ba9-4caf-99ba-8717601ddaeb	staff	389aab4c-9d68-4e3e-bc97-a3d7af01f4da	6	09:00:00	20:00:00
649084dc-71f5-4fc2-ab5d-724b9e9c2745	chair	ce3420c7-4ca5-4ef5-9ae8-e5b1083b2204	0	09:00:00	20:00:00
bc675cf8-752d-47b3-9b51-75d3e1ac52e2	chair	ce3420c7-4ca5-4ef5-9ae8-e5b1083b2204	1	09:00:00	20:00:00
17a6add1-caa2-42b5-af4d-e66b92a21df0	chair	ce3420c7-4ca5-4ef5-9ae8-e5b1083b2204	2	09:00:00	20:00:00
7fba92fe-6c51-4909-9493-523ac18f327f	chair	ce3420c7-4ca5-4ef5-9ae8-e5b1083b2204	3	09:00:00	20:00:00
c85855d3-db77-4f13-a773-7c5f21ce596f	chair	ce3420c7-4ca5-4ef5-9ae8-e5b1083b2204	4	09:00:00	20:00:00
f3f151d8-8783-4b2b-8e2b-fc6658203ca8	chair	ce3420c7-4ca5-4ef5-9ae8-e5b1083b2204	5	09:00:00	20:00:00
ccfd3f15-c896-4d91-929a-a517dd053aaa	chair	ce3420c7-4ca5-4ef5-9ae8-e5b1083b2204	6	09:00:00	20:00:00
7cf6f314-efc0-496b-a304-2fd6658ee9e4	staff	694a7f83-6458-4401-9505-c25d2a216006	0	09:00:00	20:00:00
5aa90fe4-21de-4dbe-b074-c9c19682204e	staff	694a7f83-6458-4401-9505-c25d2a216006	1	09:00:00	20:00:00
a902bfe5-c62a-4669-8168-7ab7435ae73c	staff	694a7f83-6458-4401-9505-c25d2a216006	2	09:00:00	20:00:00
3df9fc0b-192c-48f3-ab90-48289915a181	staff	694a7f83-6458-4401-9505-c25d2a216006	3	09:00:00	20:00:00
934962ef-df6b-4d9c-98bd-dfb7f0bdc291	staff	694a7f83-6458-4401-9505-c25d2a216006	4	09:00:00	20:00:00
3f3ca667-8f2d-4956-8a21-bcb114f05d74	staff	694a7f83-6458-4401-9505-c25d2a216006	5	09:00:00	20:00:00
6b48a5d1-21fc-41d1-b4a7-0dcdb490b755	staff	694a7f83-6458-4401-9505-c25d2a216006	6	09:00:00	20:00:00
5853dbd0-7963-4084-ab5a-7222b627d94c	chair	2bb4030e-6263-4a6d-a24b-90f9371f050e	0	09:00:00	20:00:00
0d5d98d8-c18d-40f6-92a3-a8ca513fec19	chair	2bb4030e-6263-4a6d-a24b-90f9371f050e	1	09:00:00	20:00:00
f4c1c044-75e3-4058-90f7-0f80b72c4369	chair	2bb4030e-6263-4a6d-a24b-90f9371f050e	2	09:00:00	20:00:00
d3057d61-f976-4a5e-b4b3-6adc17655cc2	chair	2bb4030e-6263-4a6d-a24b-90f9371f050e	3	09:00:00	20:00:00
6ef6d5f8-c1f7-4253-a974-889b55759b0a	chair	2bb4030e-6263-4a6d-a24b-90f9371f050e	4	09:00:00	20:00:00
fb7f62ab-76ce-4cfd-8c2c-1f2da6914ab4	chair	2bb4030e-6263-4a6d-a24b-90f9371f050e	5	09:00:00	20:00:00
830da247-b823-49da-aac1-19428f3ec176	chair	2bb4030e-6263-4a6d-a24b-90f9371f050e	6	09:00:00	20:00:00
32cd1ec9-3935-4a2b-b6d3-71135101ca16	staff	51f6dc27-15f5-44a3-9826-0805962f6322	0	09:00:00	20:00:00
32861cdb-0ac6-4891-b114-fd7f4ff16cb6	staff	51f6dc27-15f5-44a3-9826-0805962f6322	1	09:00:00	20:00:00
30fe1325-5fb2-4382-866d-9a63a1fc5654	staff	51f6dc27-15f5-44a3-9826-0805962f6322	2	09:00:00	20:00:00
43742d82-f545-43a6-82d6-800f43d3fecb	staff	51f6dc27-15f5-44a3-9826-0805962f6322	3	09:00:00	20:00:00
ec0bf2c0-8a4c-44ec-831c-ed99619844b5	staff	51f6dc27-15f5-44a3-9826-0805962f6322	4	09:00:00	20:00:00
9f5fb3fd-c327-466e-923b-5c7df9c4d020	staff	51f6dc27-15f5-44a3-9826-0805962f6322	5	09:00:00	20:00:00
8eb7d11c-a6c5-4354-92b6-94bcc9d5f12e	staff	51f6dc27-15f5-44a3-9826-0805962f6322	6	09:00:00	20:00:00
4aaaaca2-9d72-4ab9-a40c-21eb21246aba	chair	5d5c2e95-5a1a-477a-865c-c63b42a1cacb	0	09:00:00	20:00:00
c1fbbab6-4754-43bc-a7f2-fe955f962daa	chair	5d5c2e95-5a1a-477a-865c-c63b42a1cacb	1	09:00:00	20:00:00
e7e829e1-7a27-42d5-af4f-8a32e9893f19	chair	5d5c2e95-5a1a-477a-865c-c63b42a1cacb	2	09:00:00	20:00:00
c3c1fa2d-1122-4508-8e53-79ac326d286b	chair	5d5c2e95-5a1a-477a-865c-c63b42a1cacb	3	09:00:00	20:00:00
0fdf6357-75ef-441c-8258-2f8152d0e022	chair	5d5c2e95-5a1a-477a-865c-c63b42a1cacb	4	09:00:00	20:00:00
203a0b21-e88b-4457-88e9-4f00a8776649	chair	5d5c2e95-5a1a-477a-865c-c63b42a1cacb	5	09:00:00	20:00:00
76f51781-24cc-4a19-9796-aa048d1c7975	chair	5d5c2e95-5a1a-477a-865c-c63b42a1cacb	6	09:00:00	20:00:00
ae030100-0000-4000-8000-000000000004	staff	ab030000-0000-4000-8000-000000000001	4	09:00:00	20:00:00
ae030200-0000-4000-8000-000000000004	staff	ab030000-0000-4000-8000-000000000002	4	09:00:00	20:00:00
ae040100-0000-4000-8000-000000000004	staff	ab040000-0000-4000-8000-000000000001	4	09:00:00	20:00:00
ae050100-0000-4000-8000-000000000004	staff	ab050000-0000-4000-8000-000000000001	4	09:00:00	20:00:00
ae050200-0000-4000-8000-000000000004	staff	ab050000-0000-4000-8000-000000000002	4	09:00:00	20:00:00
ae010300-0000-4000-8000-000000000004	chair	ac010000-0000-4000-8000-000000000001	4	09:00:00	20:00:00
ae020300-0000-4000-8000-000000000004	chair	ac020000-0000-4000-8000-000000000001	4	09:00:00	20:00:00
ae030300-0000-4000-8000-000000000004	chair	ac030000-0000-4000-8000-000000000001	4	09:00:00	20:00:00
ae040300-0000-4000-8000-000000000004	chair	ac040000-0000-4000-8000-000000000001	4	09:00:00	20:00:00
ae050300-0000-4000-8000-000000000004	chair	ac050000-0000-4000-8000-000000000001	4	09:00:00	20:00:00
ae010100-0000-4000-8000-000000000005	staff	ab010000-0000-4000-8000-000000000001	5	09:00:00	20:00:00
ae010200-0000-4000-8000-000000000005	staff	ab010000-0000-4000-8000-000000000002	5	09:00:00	20:00:00
ae020100-0000-4000-8000-000000000005	staff	ab020000-0000-4000-8000-000000000001	5	09:00:00	20:00:00
ae030100-0000-4000-8000-000000000005	staff	ab030000-0000-4000-8000-000000000001	5	09:00:00	20:00:00
ae030200-0000-4000-8000-000000000005	staff	ab030000-0000-4000-8000-000000000002	5	09:00:00	20:00:00
ae040100-0000-4000-8000-000000000005	staff	ab040000-0000-4000-8000-000000000001	5	09:00:00	20:00:00
ae050100-0000-4000-8000-000000000005	staff	ab050000-0000-4000-8000-000000000001	5	09:00:00	20:00:00
ae050200-0000-4000-8000-000000000005	staff	ab050000-0000-4000-8000-000000000002	5	09:00:00	20:00:00
ae010300-0000-4000-8000-000000000005	chair	ac010000-0000-4000-8000-000000000001	5	09:00:00	20:00:00
ae020300-0000-4000-8000-000000000005	chair	ac020000-0000-4000-8000-000000000001	5	09:00:00	20:00:00
ae030300-0000-4000-8000-000000000005	chair	ac030000-0000-4000-8000-000000000001	5	09:00:00	20:00:00
ae040300-0000-4000-8000-000000000005	chair	ac040000-0000-4000-8000-000000000001	5	09:00:00	20:00:00
ae050300-0000-4000-8000-000000000005	chair	ac050000-0000-4000-8000-000000000001	5	09:00:00	20:00:00
ae010100-0000-4000-8000-000000000006	staff	ab010000-0000-4000-8000-000000000001	6	09:00:00	20:00:00
ae010200-0000-4000-8000-000000000006	staff	ab010000-0000-4000-8000-000000000002	6	09:00:00	20:00:00
ae020100-0000-4000-8000-000000000006	staff	ab020000-0000-4000-8000-000000000001	6	09:00:00	20:00:00
ae030100-0000-4000-8000-000000000006	staff	ab030000-0000-4000-8000-000000000001	6	09:00:00	20:00:00
ae030200-0000-4000-8000-000000000006	staff	ab030000-0000-4000-8000-000000000002	6	09:00:00	20:00:00
ae040100-0000-4000-8000-000000000006	staff	ab040000-0000-4000-8000-000000000001	6	09:00:00	20:00:00
ae050100-0000-4000-8000-000000000006	staff	ab050000-0000-4000-8000-000000000001	6	09:00:00	20:00:00
ae050200-0000-4000-8000-000000000006	staff	ab050000-0000-4000-8000-000000000002	6	09:00:00	20:00:00
ae010300-0000-4000-8000-000000000006	chair	ac010000-0000-4000-8000-000000000001	6	09:00:00	20:00:00
ae020300-0000-4000-8000-000000000006	chair	ac020000-0000-4000-8000-000000000001	6	09:00:00	20:00:00
ae030300-0000-4000-8000-000000000006	chair	ac030000-0000-4000-8000-000000000001	6	09:00:00	20:00:00
ae040300-0000-4000-8000-000000000006	chair	ac040000-0000-4000-8000-000000000001	6	09:00:00	20:00:00
ae050300-0000-4000-8000-000000000006	chair	ac050000-0000-4000-8000-000000000001	6	09:00:00	20:00:00
7fbd513c-366d-4394-98e7-789e2d50f9c9	staff	50390ddd-1517-4019-bfbe-6818793a54eb	0	09:00:00	20:00:00
680718a0-200a-4dfc-9181-7ba2286c9150	staff	50390ddd-1517-4019-bfbe-6818793a54eb	1	09:00:00	20:00:00
fa040b3e-3867-4919-b424-07d32a36247f	staff	50390ddd-1517-4019-bfbe-6818793a54eb	2	09:00:00	20:00:00
6a8aea64-e047-4253-8820-64dec38748ea	staff	50390ddd-1517-4019-bfbe-6818793a54eb	3	09:00:00	20:00:00
794dbcc5-4531-48c3-9187-b107c045f902	staff	50390ddd-1517-4019-bfbe-6818793a54eb	4	09:00:00	20:00:00
bde86eb5-483d-486d-87ce-00017f7427aa	staff	50390ddd-1517-4019-bfbe-6818793a54eb	5	09:00:00	20:00:00
3d45b0f1-14e9-49ed-9e9f-0fcdaa039745	staff	50390ddd-1517-4019-bfbe-6818793a54eb	6	09:00:00	20:00:00
caa896f3-583b-46e5-9414-1f86bf84655f	chair	d55ddfe7-875e-40e6-8378-4282ce2bb44d	0	09:00:00	20:00:00
3028ec5a-d919-43d9-97d2-6be11c7dda10	chair	d55ddfe7-875e-40e6-8378-4282ce2bb44d	1	09:00:00	20:00:00
19d65042-0c75-4ac0-9369-e63496693f4f	chair	d55ddfe7-875e-40e6-8378-4282ce2bb44d	2	09:00:00	20:00:00
68548f92-88ca-4eaa-9056-1c62037f1dbc	chair	d55ddfe7-875e-40e6-8378-4282ce2bb44d	3	09:00:00	20:00:00
a9ac2626-918c-40ba-a052-813f9e3c3eb8	chair	d55ddfe7-875e-40e6-8378-4282ce2bb44d	4	09:00:00	20:00:00
2a1f26e4-8ce3-41a8-8628-215f829a2f41	chair	d55ddfe7-875e-40e6-8378-4282ce2bb44d	5	09:00:00	20:00:00
5b33273d-a202-4123-a426-d6650c059fc8	chair	d55ddfe7-875e-40e6-8378-4282ce2bb44d	6	09:00:00	20:00:00
\.


--
-- Name: appointment appointment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_pkey PRIMARY KEY (id);


--
-- Name: bot_chat bot_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bot_chat
    ADD CONSTRAINT bot_chat_pkey PRIMARY KEY (id);


--
-- Name: bot_session bot_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bot_session
    ADD CONSTRAINT bot_session_pkey PRIMARY KEY (id);


--
-- Name: chair_equipment chair_equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chair_equipment
    ADD CONSTRAINT chair_equipment_pkey PRIMARY KEY (chair_id, equipment_id);


--
-- Name: chair chair_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chair
    ADD CONSTRAINT chair_pkey PRIMARY KEY (id);


--
-- Name: chair_unavailable chair_unavailable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chair_unavailable
    ADD CONSTRAINT chair_unavailable_pkey PRIMARY KEY (id);


--
-- Name: customer_note customer_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_note
    ADD CONSTRAINT customer_note_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: day_off day_off_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.day_off
    ADD CONSTRAINT day_off_pkey PRIMARY KEY (id);


--
-- Name: device_token device_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_token
    ADD CONSTRAINT device_token_pkey PRIMARY KEY (id);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (id);


--
-- Name: holiday holiday_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.holiday
    ADD CONSTRAINT holiday_pkey PRIMARY KEY (id);


--
-- Name: appointment no_chair_overlap; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT no_chair_overlap EXCLUDE USING gist (chair_id WITH =, time_range WITH &&) WHERE ((status = ANY (ARRAY['pending'::public."ApptStatus", 'held'::public."ApptStatus", 'confirmed'::public."ApptStatus"])));


--
-- Name: appointment no_staff_overlap; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT no_staff_overlap EXCLUDE USING gist (staff_member_id WITH =, time_range WITH &&) WHERE ((status = ANY (ARRAY['pending'::public."ApptStatus", 'held'::public."ApptStatus", 'confirmed'::public."ApptStatus"])));


--
-- Name: notification_log notification_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_log
    ADD CONSTRAINT notification_log_pkey PRIMARY KEY (id);


--
-- Name: otp otp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp
    ADD CONSTRAINT otp_pkey PRIMARY KEY (id);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: platform_admin platform_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_admin
    ADD CONSTRAINT platform_admin_pkey PRIMARY KEY (id);


--
-- Name: platform_audit_log platform_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_audit_log
    ADD CONSTRAINT platform_audit_log_pkey PRIMARY KEY (id);


--
-- Name: qr_scan_event qr_scan_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_scan_event
    ADD CONSTRAINT qr_scan_event_pkey PRIMARY KEY (id);


--
-- Name: salon_notification salon_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salon_notification
    ADD CONSTRAINT salon_notification_pkey PRIMARY KEY (id);


--
-- Name: salon salon_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salon
    ADD CONSTRAINT salon_pkey PRIMARY KEY (id);


--
-- Name: service_equipment service_equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_equipment
    ADD CONSTRAINT service_equipment_pkey PRIMARY KEY (service_id, equipment_id);


--
-- Name: service service_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT service_pkey PRIMARY KEY (id);


--
-- Name: service_staff service_staff_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_staff
    ADD CONSTRAINT service_staff_pkey PRIMARY KEY (service_id, staff_member_id);


--
-- Name: staff_member staff_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_member
    ADD CONSTRAINT staff_member_pkey PRIMARY KEY (id);


--
-- Name: subscription_payment subscription_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_payment
    ADD CONSTRAINT subscription_payment_pkey PRIMARY KEY (id);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (id);


--
-- Name: waitlist_entry waitlist_entry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waitlist_entry
    ADD CONSTRAINT waitlist_entry_pkey PRIMARY KEY (id);


--
-- Name: working_hours working_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.working_hours
    ADD CONSTRAINT working_hours_pkey PRIMARY KEY (id);


--
-- Name: bot_chat_platform_chat_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX bot_chat_platform_chat_id_key ON public.bot_chat USING btree (platform, chat_id);


--
-- Name: bot_session_platform_chat_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX bot_session_platform_chat_id_key ON public.bot_session USING btree (platform, chat_id);


--
-- Name: customer_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX customer_phone_key ON public.customer USING btree (phone);


--
-- Name: notification_log_appointment_type_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_log_appointment_type_status_idx ON public.notification_log USING btree (appointment_id, type, channel, status);


--
-- Name: platform_admin_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX platform_admin_phone_key ON public.platform_admin USING btree (phone);


--
-- Name: platform_audit_log_admin_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX platform_audit_log_admin_created_idx ON public.platform_audit_log USING btree (admin_id, created_at);


--
-- Name: platform_audit_log_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX platform_audit_log_created_at_idx ON public.platform_audit_log USING btree (created_at);


--
-- Name: platform_audit_log_entity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX platform_audit_log_entity_idx ON public.platform_audit_log USING btree (entity_type, entity_id);


--
-- Name: salon_notification_salon_id_audience_read_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salon_notification_salon_id_audience_read_at_idx ON public.salon_notification USING btree (salon_id, audience, read_at);


--
-- Name: salon_notification_salon_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salon_notification_salon_id_created_at_idx ON public.salon_notification USING btree (salon_id, created_at);


--
-- Name: salon_notification_salon_id_read_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salon_notification_salon_id_read_at_idx ON public.salon_notification USING btree (salon_id, read_at);


--
-- Name: salon_notification_salon_id_staff_member_id_read_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX salon_notification_salon_id_staff_member_id_read_at_idx ON public.salon_notification USING btree (salon_id, staff_member_id, read_at);


--
-- Name: salon_qr_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX salon_qr_token_key ON public.salon USING btree (qr_token);


--
-- Name: staff_member_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX staff_member_phone_key ON public.staff_member USING btree (phone);


--
-- Name: subscription_salon_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX subscription_salon_id_key ON public.subscription USING btree (salon_id);


--
-- Name: appointment appointment_chair_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_chair_id_fkey FOREIGN KEY (chair_id) REFERENCES public.chair(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: appointment appointment_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: appointment appointment_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salon(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: appointment appointment_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: appointment appointment_staff_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointment
    ADD CONSTRAINT appointment_staff_member_id_fkey FOREIGN KEY (staff_member_id) REFERENCES public.staff_member(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bot_chat bot_chat_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bot_chat
    ADD CONSTRAINT bot_chat_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bot_chat bot_chat_staff_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bot_chat
    ADD CONSTRAINT bot_chat_staff_member_id_fkey FOREIGN KEY (staff_member_id) REFERENCES public.staff_member(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: chair_equipment chair_equipment_chair_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chair_equipment
    ADD CONSTRAINT chair_equipment_chair_id_fkey FOREIGN KEY (chair_id) REFERENCES public.chair(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chair_equipment chair_equipment_equipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chair_equipment
    ADD CONSTRAINT chair_equipment_equipment_id_fkey FOREIGN KEY (equipment_id) REFERENCES public.equipment(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chair chair_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chair
    ADD CONSTRAINT chair_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salon(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chair_unavailable chair_unavailable_chair_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chair_unavailable
    ADD CONSTRAINT chair_unavailable_chair_id_fkey FOREIGN KEY (chair_id) REFERENCES public.chair(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customer_note customer_note_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_note
    ADD CONSTRAINT customer_note_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.staff_member(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customer_note customer_note_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_note
    ADD CONSTRAINT customer_note_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customer customer_preferred_staff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_preferred_staff_id_fkey FOREIGN KEY (preferred_staff_id) REFERENCES public.staff_member(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: day_off day_off_staff_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.day_off
    ADD CONSTRAINT day_off_staff_member_id_fkey FOREIGN KEY (staff_member_id) REFERENCES public.staff_member(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: device_token device_token_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_token
    ADD CONSTRAINT device_token_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: equipment equipment_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salon(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: holiday holiday_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.holiday
    ADD CONSTRAINT holiday_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salon(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: notification_log notification_log_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_log
    ADD CONSTRAINT notification_log_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointment(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payment payment_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointment(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: platform_audit_log platform_audit_log_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_audit_log
    ADD CONSTRAINT platform_audit_log_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.platform_admin(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: qr_scan_event qr_scan_event_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.qr_scan_event
    ADD CONSTRAINT qr_scan_event_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salon(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: salon_notification salon_notification_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salon_notification
    ADD CONSTRAINT salon_notification_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salon(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: salon_notification salon_notification_staff_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salon_notification
    ADD CONSTRAINT salon_notification_staff_member_id_fkey FOREIGN KEY (staff_member_id) REFERENCES public.staff_member(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: service_equipment service_equipment_equipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_equipment
    ADD CONSTRAINT service_equipment_equipment_id_fkey FOREIGN KEY (equipment_id) REFERENCES public.equipment(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: service_equipment service_equipment_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_equipment
    ADD CONSTRAINT service_equipment_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: service service_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT service_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salon(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: service_staff service_staff_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_staff
    ADD CONSTRAINT service_staff_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: service_staff service_staff_staff_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_staff
    ADD CONSTRAINT service_staff_staff_member_id_fkey FOREIGN KEY (staff_member_id) REFERENCES public.staff_member(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: staff_member staff_member_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff_member
    ADD CONSTRAINT staff_member_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salon(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscription_payment subscription_payment_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_payment
    ADD CONSTRAINT subscription_payment_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscription(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscription subscription_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription
    ADD CONSTRAINT subscription_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salon(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: waitlist_entry waitlist_entry_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waitlist_entry
    ADD CONSTRAINT waitlist_entry_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: waitlist_entry waitlist_entry_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waitlist_entry
    ADD CONSTRAINT waitlist_entry_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salon(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: waitlist_entry waitlist_entry_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.waitlist_entry
    ADD CONSTRAINT waitlist_entry_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.service(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict eUVBAMSX2UbTNBbUqVm6oZvpLjC945N6y7goggqLaLm4hAqC82D6X3oBZrwHNQV

